# atm-bench export — r2f-e4-p2-s11-g-r1cfg-r3

- run_id: `r2f-e4-p2-s11-g-r1cfg-r3` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 151608 | — |
| duration_ms | 496.08 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=25, blocked=11 | — |
| committed | 25 | — |
| oracle pass (marker survives) | 35 | — |
| lost updates (oracle fail) | 1 | — |
| integration pass rate of committed | 140% | — |
| effective success rate of all intents | 97.2% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 22 | — |
| composer co-writes | 8 | — |
| CAS rebase on apply | 21 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 496.41 | — |
| throughput intents/s | 72.52 | — |
| goodput oracle-pass/s | 70.51 | — |
| latency_ms mean / p50 / p95 | 6.19 / 4.14 / 21.27 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 24.12 / 14.84 / 117.12 | — |
| total_ms mean / p50 / p95 | 79.39 / 55.98 / 206.43 | — |
| overhead_ms mean / p50 / p95 | 31.15 / 20.35 / 138.9 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 8 | 0 | 0 |
| cold_queue | 22 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=16, atm_provisional_write_lease=5, file-hash-drift: Target file hash sha256:c6ad7e714d5fdcf8dd3794a9fcfb20850c77bbb105a8a37aabdfaaa669cb7332 does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=4, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:6d77c89091924ec8fd397a6b63d8417991a0ef7ecd7dae6b07be2764aaf74d9c does not match proposal fileBeforeHash sha256:ff676eb00fd55db03dc591ae367167be2eaeabb09e44a6def287424ccec3e129.=2, canonical target base hash is stale: src/store.ts=2, atm_compose=2, file-hash-drift: Target file hash sha256:bc0cd8749ca6e4480039827e7b967b03b65d73daad723aaf15047586edf909d1 does not match proposal fileBeforeHash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8.=1, canonical target base hash is stale: src/config.ts=1, file-hash-drift: Target file hash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=19, composer_merge=5, hot_provisional=4 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=151608, duration_ms=496.08
