# atm-bench export — r2f-e4-p2-s11-g-slock-r2

- run_id: `r2f-e4-p2-s11-g-slock-r2` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154354 | — |
| duration_ms | 641.57 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=25, blocked=11 | — |
| committed | 25 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 144% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 18 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 641.3 | — |
| throughput intents/s | 56.14 | — |
| goodput oracle-pass/s | 56.14 | — |
| latency_ms mean / p50 / p95 | 5.13 / 3.82 / 21.36 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 47.96 / 18.5 / 126.28 | — |
| total_ms mean / p50 / p95 | 108.07 / 57.71 / 285.83 | — |
| overhead_ms mean / p50 / p95 | 53.9 / 23.84 / 144.27 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_compose+cas_rebase=5, atm_provisional_write_lease=5, steward-final-patch-required: proposals 'prop-s11-t004-i0' and 'prop-s11-t004-i2' change overlapping base line 22 of src/config.ts; a steward-authored final patch is required [proposals: prop-s11-t004-i0, prop-s11-t004-i2]=3, steward-final-patch-required: proposals 'prop-s11-t000-i0' and 'prop-s11-t002-i6' change overlapping base line 22 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t000-i0, prop-s11-t002-i6]=2, file-hash-drift: Target file hash sha256:9f86dec7896da8e457a17cbd903d3cff7e4ea840af82598c6eda44b68706c38a does not match proposal fileBeforeHash sha256:a8d2b778b6493cd220cf26f81c97e69b7651963b227518c7f2fee7ddde0ef40f.=2, file-hash-drift: Target file hash sha256:063e6bb7d5487973d566cf87d7bb8448cd3afd867d7798530376ee73c8c85ef8 does not match proposal fileBeforeHash sha256:7cf12d4c27310123fc1a3de26fd958be666187a55758a90349a57ce893365ead.=1, file-hash-drift: Target file hash sha256:37e0355b8822690406aad410eaa45b7089b5698c62df95632ca861392988d987 does not match proposal fileBeforeHash sha256:3038289f914a3090be47e68fff94401c7058175f1823523534afa67cd27a4755.=1, file-hash-drift: Target file hash sha256:b7b22d4b881f8f1bace886777be07ad1b89fcd26ad414741811c7811493bd089 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=1, file-hash-drift: Target file hash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=16, composer_merge=8, hot_provisional=4 |
| no_conflict | hot_provisional=2, cold_queue=2, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154354, duration_ms=641.57
