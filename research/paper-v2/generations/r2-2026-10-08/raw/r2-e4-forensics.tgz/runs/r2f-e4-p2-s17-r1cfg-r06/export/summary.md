# atm-bench export — r2f-e4-p2-s17-r1cfg-r06

- run_id: `r2f-e4-p2-s17-r1cfg-r06` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 145196 | — |
| duration_ms | 557.78 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 161.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 556.74 | — |
| throughput intents/s | 61.07 | — |
| goodput oracle-pass/s | 61.07 | — |
| latency_ms mean / p50 / p95 | 5.87 / 4.08 / 14.36 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 30.91 / 14.42 / 129.75 | — |
| total_ms mean / p50 / p95 | 77.91 / 47.56 / 183.97 | — |
| overhead_ms mean / p50 / p95 | 37.52 / 19.53 / 146.87 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 14 | 0 | 0 |
| composer_merge | 9 | 0 | 0 |
| hot_provisional | 11 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=9, atm_serial_queue=8, file-hash-drift: Target file hash sha256:4522f6ec17ae3fbe00dac6d3864a365c2cdf475f050cd8d3a7e7a849e67e1b26 does not match proposal fileBeforeHash sha256:94cdad271f84d86408059bc10d9b947bae922e7ce822e40fd31b2ccebf03f546.=3, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 21 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=2, file-hash-drift: Target file hash sha256:a482e4b4bd932652d53d7e1ef2f17a4aa48fc3b0bba6a73da15c00b21a26fbbf does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=2, file-hash-drift: Target file hash sha256:956ec302161afff4acac6df6a368e7fdc336e6f1d61845bac006ca62377e8440 does not match proposal fileBeforeHash sha256:a482e4b4bd932652d53d7e1ef2f17a4aa48fc3b0bba6a73da15c00b21a26fbbf.=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:33651ea2fb8216f72603f1833c3175b61e13d3a85020aaa1fb5c3d2dd81f9035 does not match proposal fileBeforeHash sha256:956ec302161afff4acac6df6a368e7fdc336e6f1d61845bac006ca62377e8440.=1, atm_provisional_write_lease+cas_rebase=1, file-hash-drift: Target file hash sha256:7032442047769e6115bbfb3450cce14f41b7b17099ff4162f5fd04c00829cc9c does not match proposal fileBeforeHash sha256:3e33bb151f0838190a471bbc96858fee2ae72967a0dd8f0ce8edb344bc9fca29.=1, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=14, hot_provisional=7, composer_merge=5 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | hot_provisional=2, composer_merge=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=145196, duration_ms=557.78
