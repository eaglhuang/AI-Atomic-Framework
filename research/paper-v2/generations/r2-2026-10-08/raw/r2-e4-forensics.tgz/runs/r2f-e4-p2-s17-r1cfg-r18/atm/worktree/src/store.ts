/** In-memory store slices (HOT). */
export type State = { users: string[]; orders: number[]; meta: Record<string, string> };

// <region:reducers>
export function reduceUsers(state: State, user: string): State {
  return { ...state, users: [...state.users, user] };
}
// atm-edit s17-t000-i0 by cursor:mock-s0
// atm-edit s17-t004-i4 by codex:mock-s5
// atm-edit s17-t004-i1 by claude:mock-s1
// atm-edit s17-t004-i5 by other:mock-s6
// atm-edit s17-t004-i0 by cursor:mock-s0
// </region:reducers>

// <region:selectors>
export function selectUserCount(state: State): number {
  return state.users.length;
}
// atm-edit s17-t000-i3 by cursor:mock-s3
// </region:selectors>

// <region:actions>
export function createOrder(state: State, id: number): State {
  return { ...state, orders: [...state.orders, id] };
}
// atm-edit s17-t000-i1 by claude:mock-s1
// atm-edit s17-t004-i6 by other:mock-s7
// atm-edit s17-t004-i3 by cursor:mock-s3
// </region:actions>

export const initialState: State = { users: [], orders: [], meta: {} };
