# atm-bench export — r2f-e4-p2-s17-g-r1cfg-r3

- run_id: `r2f-e4-p2-s17-g-r1cfg-r3` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 144641 | — |
| duration_ms | 436.32 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 19 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 434.45 | — |
| throughput intents/s | 78.26 | — |
| goodput oracle-pass/s | 78.26 | — |
| latency_ms mean / p50 / p95 | 6.2 / 4.95 / 14.04 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 27.78 / 14.1 / 118.97 | — |
| total_ms mean / p50 / p95 | 77.72 / 52.66 / 164.8 | — |
| overhead_ms mean / p50 / p95 | 34.82 / 20.29 / 134.79 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 16 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| composer_merge | 9 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=9, atm_serial_queue=8, canonical target base hash is stale: src/config.ts=3, file-hash-drift: Target file hash sha256:1c1c6aff147ab355eecf751a6de21a8a1d5c418a2310d242b2eccef84cae6bb6 does not match proposal fileBeforeHash sha256:7def02c286644bcac414c0f952c0cc3f5ec31ef822de020821ee7dc9365b9dc0.=3, file-hash-drift: Target file hash sha256:f52d98d84cc21466f9ad18fbd9a3aec905d9da47180284e78cfe8ec143f25612 does not match proposal fileBeforeHash sha256:60e44aa00274a52b46045068cae0cd44244c0859505e4f2d3a7d78d509f4cab0.=2, file-hash-drift: Target file hash sha256:0b23afd14f84d7dbe10a2ede350faa9584aa845ffdd0fab5df49b0fe89468b7a does not match proposal fileBeforeHash sha256:016c758f318fd9abe3c1b747e8dbd36f2c2a6138311c878554fb0ac3cac89d2f.=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, atm_compose+cas_rebase=2, canonical target base hash is stale: src/store.ts=1, atm_compose=1, file-hash-drift: Target file hash sha256:f984f7889c2f81e53adfb5f843d6041b7bf24a4878cbaba4792862e81abf29de does not match proposal fileBeforeHash sha256:1c1c6aff147ab355eecf751a6de21a8a1d5c418a2310d242b2eccef84cae6bb6.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=16, hot_provisional=5, composer_merge=5 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=144641, duration_ms=436.32
