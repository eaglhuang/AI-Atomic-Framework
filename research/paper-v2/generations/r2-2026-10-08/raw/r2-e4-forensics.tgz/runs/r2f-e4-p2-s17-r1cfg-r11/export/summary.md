# atm-bench export — r2f-e4-p2-s17-r1cfg-r11

- run_id: `r2f-e4-p2-s17-r1cfg-r11` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 145684 | — |
| duration_ms | 655.29 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 161.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 653.91 | — |
| throughput intents/s | 51.99 | — |
| goodput oracle-pass/s | 51.99 | — |
| latency_ms mean / p50 / p95 | 5.62 / 3.89 / 15.8 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 58.57 / 14.76 / 227.48 | — |
| total_ms mean / p50 / p95 | 119.05 / 57.69 / 384.53 | — |
| overhead_ms mean / p50 / p95 | 64.88 / 19.48 / 231.01 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 9 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:e4b4d2694566edc6fdcafb263bb7ec2e3f6d095b8bb597b4dddb81bf074e5cc6 does not match proposal fileBeforeHash sha256:1466db735a2c933611c7f055a9f2860be1a84c3864bda9b5eabc450a2ed2cf3c.=3, file-hash-drift: Target file hash sha256:cb1bab3e26b39141919c2cd07ebb9c25e90ee0a2233996d02c41cb92a932804a does not match proposal fileBeforeHash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef.=2, file-hash-drift: Target file hash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:1466db735a2c933611c7f055a9f2860be1a84c3864bda9b5eabc450a2ed2cf3c does not match proposal fileBeforeHash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd.=2, steward-final-patch-required: proposals 'prop-s17-t004-i0' and 'prop-s17-t004-i5' change overlapping base line 10 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t004-i0, prop-s17-t004-i5]=2, file-hash-drift: Target file hash sha256:f1b1539c7d070129de4bf318c3414a6836c9058fa2ec0dd9e78d16c7569eee29 does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=1, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, atm_compose=1, atm_provisional_write_lease+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=15, hot_provisional=6, composer_merge=5 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=145684, duration_ms=655.29
