# atm-bench export — r2f-e4-p2-s17-r1cfg-r04

- run_id: `r2f-e4-p2-s17-r1cfg-r04` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 146269 | — |
| duration_ms | 506.43 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 161.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 14 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 504.97 | — |
| throughput intents/s | 67.33 | — |
| goodput oracle-pass/s | 67.33 | — |
| latency_ms mean / p50 / p95 | 5.18 / 4.18 / 13.97 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 34.68 / 14.65 / 112.52 | — |
| total_ms mean / p50 / p95 | 81.57 / 48.05 / 169.27 | — |
| overhead_ms mean / p50 / p95 | 40.63 / 19.87 / 130.85 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 10 | 0 | 0 |
| composer_merge | 10 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=10, atm_serial_queue=8, atm_compose+cas_rebase=3, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 22 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=2, file-hash-drift: Target file hash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, file-hash-drift: Target file hash sha256:706b7228d17cdd613071aa58ef2cdfb957f2f9e523fe45a477bb1dcecd52926b does not match proposal fileBeforeHash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da.=2, file-hash-drift: Target file hash sha256:ad810dd68039d876b7530fc2b38637901b745eb1a665e481bc15e1ea6cb5347a does not match proposal fileBeforeHash sha256:0e4ec64db7a63c576452380f4d1216bdf88666727b5ecbfe16b47fc8ed6f73d9.=2, canonical target base hash is stale: src/config.ts=1, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:00cdaf66fb6c2e4a2e8fa0e46db1d588551043224ec264670a0f4738732dc6bb does not match proposal fileBeforeHash sha256:e7b6f5dd8710ad3e2c0d25f44f4b3175df70e4e5593db2499e35e3b247570767.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, composer_merge=7, hot_provisional=6 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=2, cold_queue=1, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=146269, duration_ms=506.43
