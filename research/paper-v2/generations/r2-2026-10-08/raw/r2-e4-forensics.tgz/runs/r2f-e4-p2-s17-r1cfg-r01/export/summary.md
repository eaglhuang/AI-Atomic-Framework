# atm-bench export — r2f-e4-p2-s17-r1cfg-r01

- run_id: `r2f-e4-p2-s17-r1cfg-r01` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 143276 | — |
| duration_ms | 557.3 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=24, blocked=10 | — |
| committed | 24 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 141.7% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 12 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 556.01 | — |
| throughput intents/s | 61.15 | — |
| goodput oracle-pass/s | 61.15 | — |
| latency_ms mean / p50 / p95 | 5.05 / 3.76 / 13.87 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 43.01 / 13.65 / 119.13 | — |
| total_ms mean / p50 / p95 | 90.7 / 44.5 / 277.16 | — |
| overhead_ms mean / p50 / p95 | 48.73 / 18.62 / 145.06 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| cold_queue | 12 | 0 | 0 |
| hot_provisional | 12 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=11, atm_serial_queue=9, file-hash-drift: Target file hash sha256:e2a35d288db6ce4669cad008e61ff9a2e039713eb0ad1f140d1b579ed3e0f6c0 does not match proposal fileBeforeHash sha256:83d246f0d84d86e617ae5dd15517ad51b3cb4005da587bc9ecf3114a3e666a16.=3, atm_compose=3, file-hash-drift: Target file hash sha256:3d662a3b8f47bf5e9651964cf78121be7271b06d63f68e328dee39ef1f2cbe90 does not match proposal fileBeforeHash sha256:83c22af2d74b26f156ce37ce66c271819ba4c97f51c7e94bd12a7c476ae4003e.=2, file-hash-drift: Target file hash sha256:f7613fd10cbf78675f5bbde069e901a81ac3e8e7c8d16670c47655cd6eb9b383 does not match proposal fileBeforeHash sha256:851ea0e03ac37fd7d7cd4374cda54eed9f5bad8ee1123cc80b3306a984d58f56.=2, file-hash-drift: Target file hash sha256:fcb13dcebddc31be0a5cd880e9e5878497c05e543d01d738ad315b23c8b21ce7 does not match proposal fileBeforeHash sha256:e40fdb5999f47e01799f248d384c6260bec6adb9c9c1158338aac830f3e8dfc0.=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:83c22af2d74b26f156ce37ce66c271819ba4c97f51c7e94bd12a7c476ae4003e does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=1, file-hash-drift: Target file hash sha256:e40fdb5999f47e01799f248d384c6260bec6adb9c9c1158338aac830f3e8dfc0 does not match proposal fileBeforeHash sha256:e2a35d288db6ce4669cad008e61ff9a2e039713eb0ad1f140d1b579ed3e0f6c0.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=12, composer_merge=7, hot_provisional=7 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | hot_provisional=2, composer_merge=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=143276, duration_ms=557.3
