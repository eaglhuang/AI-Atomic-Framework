# atm-bench export — r2f-e4-p2-s17-g-slock-r5

- run_id: `r2f-e4-p2-s17-g-slock-r5` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 143205 | — |
| duration_ms | 714.6 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=25, blocked=9 | — |
| committed | 25 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 136% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 11 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 714.19 | — |
| throughput intents/s | 47.61 | — |
| goodput oracle-pass/s | 47.61 | — |
| latency_ms mean / p50 / p95 | 4.9 / 3.45 / 14.33 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 42.33 / 13.41 / 117.01 | — |
| total_ms mean / p50 / p95 | 94.75 / 45.55 / 239.43 | — |
| overhead_ms mean / p50 / p95 | 47.87 / 17.75 / 132.91 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 11 | 0 | 0 |
| hot_provisional | 13 | 0 | 0 |
| composer_merge | 10 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=13, atm_serial_queue=7, atm_compose+cas_rebase=4, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, file-hash-drift: Target file hash sha256:56af38d14eb8ad3996aa76de9ab0fa4cb6c7ddb2e5709053d2901c5efd138e9b does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=2, atm_compose=1, file-hash-drift: Target file hash sha256:250342c0d6aa9793886b719adfec6d2f93df5123b08473724e8ec2edfe6d35a2 does not match proposal fileBeforeHash sha256:c1412640a00d5b12091c98711a32329e1f6a3467a8a6c47ada124f48fbc353c3.=1, file-hash-drift: Target file hash sha256:8da99425d5f9dc254464bd9940db09a2952fa27b9878173c31c695e3309f77ee does not match proposal fileBeforeHash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e.=1, file-hash-drift: Target file hash sha256:9737207413edbe11c9d6bd5fdf30720782eb6d7521ca0f362cbd0050f7a74006 does not match proposal fileBeforeHash sha256:e2eeb486a3a3cf4fd059702bfceef6a6c0b504c2f9c690e950d64cd454aafd42.=1, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | hot_provisional=11, cold_queue=8, composer_merge=7 |
| no_conflict | hot_provisional=2, cold_queue=1, composer_merge=1 |
| composer_cowrite | cold_queue=2, composer_merge=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=143205, duration_ms=714.6
