# atm-bench export — r2f-e4-p2-s11-g-slock-r4

- run_id: `r2f-e4-p2-s11-g-slock-r4` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154852 | — |
| duration_ms | 686.84 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 15 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 687.29 | — |
| throughput intents/s | 52.38 | — |
| goodput oracle-pass/s | 52.38 | — |
| latency_ms mean / p50 / p95 | 4.96 / 3.36 / 16.2 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 45.52 / 16.3 / 118.91 | — |
| total_ms mean / p50 / p95 | 100.52 / 51.88 / 251.64 | — |
| overhead_ms mean / p50 / p95 | 51.14 / 22.4 / 137.22 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:72158b0b477ef71ac1bab8a81ee412edb35ce271d65d994fe22303080a804c47 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=3, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:477e5940293fa8e7188b235e309aa38a60618158324a30b379312b23c24896a0 does not match proposal fileBeforeHash sha256:e060d8f8c4c1b3549c1ede003679b88d05ca7f6638a9eea88b44e0c4a31b58d2.=2, file-hash-drift: Target file hash sha256:cb0fd73caf7a5f365c5690fe8a3e6fbac17e8bf04784ba275c31213c5682f497 does not match proposal fileBeforeHash sha256:6c8df05d942b459ae61d122a2fabbf5ea04d95b44c3be5084f4f4633d4f47686.=2, steward-final-patch-required: proposals 'prop-s11-t000-i0' and 'prop-s11-t002-i6' change overlapping base line 22 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t000-i0, prop-s11-t002-i6]=2, file-hash-drift: Target file hash sha256:063e6bb7d5487973d566cf87d7bb8448cd3afd867d7798530376ee73c8c85ef8 does not match proposal fileBeforeHash sha256:7cf12d4c27310123fc1a3de26fd958be666187a55758a90349a57ce893365ead.=1, file-hash-drift: Target file hash sha256:37e0355b8822690406aad410eaa45b7089b5698c62df95632ca861392988d987 does not match proposal fileBeforeHash sha256:3038289f914a3090be47e68fff94401c7058175f1823523534afa67cd27a4755.=1, file-hash-drift: Target file hash sha256:6c8df05d942b459ae61d122a2fabbf5ea04d95b44c3be5084f4f4633d4f47686 does not match proposal fileBeforeHash sha256:600bb99e9d0f5fa748ef56881b85336314f19fbe9bf7b7b2369d532498f84457.=1, file-hash-drift: Target file hash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:e060d8f8c4c1b3549c1ede003679b88d05ca7f6638a9eea88b44e0c4a31b58d2 does not match proposal fileBeforeHash sha256:f4816e2c04174663241b69d9e0aa4385132c4f205d1b79ff88097b4b45c61209.=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=14, composer_merge=9, hot_provisional=5 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154852, duration_ms=686.84
