# atm-bench export — r2-smoke-v2rt-mp

- run_id: `r2-smoke-v2rt-mp` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 145623 | — |
| duration_ms | 586.1 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 585.6 | — |
| throughput intents/s | 58.06 | — |
| goodput oracle-pass/s | 58.06 | — |
| latency_ms mean / p50 / p95 | 5.68 / 3.89 / 14.64 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 45.2 / 15.43 / 136.93 | — |
| total_ms mean / p50 / p95 | 103.47 / 49.2 / 271.76 | — |
| overhead_ms mean / p50 / p95 | 51.69 / 21.42 / 151.89 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=3, file-hash-drift: Target file hash sha256:b43a2dfb4fc63404b1a6c5d7cdc3596a04f3979fcd7b95bcbfea1db2018ca840 does not match proposal fileBeforeHash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef.=2, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 20 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=2, file-hash-drift: Target file hash sha256:40744dfc624023cb438d740ba77813ef3e16cfcfc4c29d5fbd26b574536270de does not match proposal fileBeforeHash sha256:610f7d6c9beb1616516a9628f8d35817dd2e80e09f315f1b80de888882e0bbd7.=2, file-hash-drift: Target file hash sha256:821c8d30afc00f27a29712c72c46fc0cba9f1754d0c7f782f2363d5347a9f82c does not match proposal fileBeforeHash sha256:f1b1539c7d070129de4bf318c3414a6836c9058fa2ec0dd9e78d16c7569eee29.=2, atm_compose=2, file-hash-drift: Target file hash sha256:00f8ed0ed2de449b553a916015aa11e8b49ffe16033b4ba27331bc7cee0a20af does not match proposal fileBeforeHash sha256:bd20bfdc70c2939ec0f94d906771c229313f29a170a55099883a531cd8a7ea3a.=1, file-hash-drift: Target file hash sha256:36125700d2cb9d7050418ceb7a2625604454ae38b29681a9a0a788cb9cb79c44 does not match proposal fileBeforeHash sha256:821c8d30afc00f27a29712c72c46fc0cba9f1754d0c7f782f2363d5347a9f82c.=1, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, atm_compose+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=14, composer_merge=8, hot_provisional=4 |
| no_conflict | hot_provisional=4 |
| composer_cowrite | composer_merge=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=145623, duration_ms=586.1
