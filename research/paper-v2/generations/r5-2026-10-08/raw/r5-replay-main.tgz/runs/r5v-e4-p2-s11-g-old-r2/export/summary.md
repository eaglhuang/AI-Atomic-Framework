# atm-bench export — r5v-e4-p2-s11-g-old-r2

- run_id: `r5v-e4-p2-s11-g-old-r2` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 155936 | — |
| duration_ms | 631.12 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 171.4% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 19 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 20 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 631.81 | — |
| throughput intents/s | 56.98 | — |
| goodput oracle-pass/s | 56.98 | — |
| latency_ms mean / p50 / p95 | 5.14 / 3.54 / 16.86 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 31.27 / 13.16 / 113.99 | — |
| total_ms mean / p50 / p95 | 82.38 / 54.3 / 196.85 | — |
| overhead_ms mean / p50 / p95 | 37.24 / 19.11 / 128.12 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| cold_queue | 19 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:c6ad7e714d5fdcf8dd3794a9fcfb20850c77bbb105a8a37aabdfaaa669cb7332 does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=4, steward-final-patch-required: proposals 'prop-s11-t004-i1' and 'prop-s11-t004-i5' change overlapping base line 31 of src/config.ts; a steward-authored final patch is required [proposals: prop-s11-t004-i1, prop-s11-t004-i5]=3, file-hash-drift: Target file hash sha256:027d9deca0844046863d8610936fa40e32c8c9f44df1818ef06e765c99b592e9 does not match proposal fileBeforeHash sha256:d7cf52d67201318b7110c24e47f695f411af4527e9310a18bb7b941315837085.=2, file-hash-drift: Target file hash sha256:d7cf52d67201318b7110c24e47f695f411af4527e9310a18bb7b941315837085 does not match proposal fileBeforeHash sha256:ad5073b16d240dcde48e2be33b8f3c0b5a546aabdfa9b8211aeb2277f20e75b9.=2, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:bc0cd8749ca6e4480039827e7b967b03b65d73daad723aaf15047586edf909d1 does not match proposal fileBeforeHash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8.=1, atm_compose=1, canonical target base hash is stale: src/store.ts=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=16, composer_merge=7, hot_provisional=5 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=155936, duration_ms=631.12
