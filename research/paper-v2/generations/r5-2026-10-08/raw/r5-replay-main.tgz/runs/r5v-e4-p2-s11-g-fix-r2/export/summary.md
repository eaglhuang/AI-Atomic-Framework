# atm-bench export — r5v-e4-p2-s11-g-fix-r2

- run_id: `r5v-e4-p2-s11-g-fix-r2` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154412 | — |
| duration_ms | 541.53 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=24, blocked=12 | — |
| committed | 24 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 150% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 20 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 22 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 541.52 | — |
| throughput intents/s | 66.48 | — |
| goodput oracle-pass/s | 66.48 | — |
| latency_ms mean / p50 / p95 | 5.63 / 3.45 / 19.27 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 39.19 / 15.67 / 120.13 | — |
| total_ms mean / p50 / p95 | 89.52 / 54.93 / 179.86 | — |
| overhead_ms mean / p50 / p95 | 45.63 / 22.23 / 141.66 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 20 | 0 | 0 |
| hot_provisional | 5 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=15, atm_provisional_write_lease=5, steward-final-patch-required: proposals 'prop-s11-t001-i3' and 'prop-s11-t001-i5' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t001-i3, prop-s11-t001-i5]=3, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:c856776721a3ca3a99e3fa12e523b949ab50828e99001862c2a6c88937de205a does not match proposal fileBeforeHash sha256:4643c6bad94a2d46177b79adf78d3edbb1e15af765d3db1c3e881f6721faead7.=3, file-hash-drift: Target file hash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8 does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=2, file-hash-drift: Target file hash sha256:173692fcc448fa0a8d0df44050556935ef9179fe928ada304a66276e93bbb8de does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=2, file-hash-drift: Target file hash sha256:bc0cd8749ca6e4480039827e7b967b03b65d73daad723aaf15047586edf909d1 does not match proposal fileBeforeHash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8.=1, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=18, composer_merge=9, hot_provisional=1 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154412, duration_ms=541.53
