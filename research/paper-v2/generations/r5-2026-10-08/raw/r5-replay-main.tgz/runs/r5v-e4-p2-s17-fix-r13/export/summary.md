# atm-bench export — r5v-e4-p2-s17-fix-r13

- run_id: `r5v-e4-p2-s17-fix-r13` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 146986 | — |
| duration_ms | 502.43 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 16 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 501.87 | — |
| throughput intents/s | 67.75 | — |
| goodput oracle-pass/s | 67.75 | — |
| latency_ms mean / p50 / p95 | 7.81 / 6.31 / 14.42 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 32.96 / 17.04 / 125.23 | — |
| total_ms mean / p50 / p95 | 88.7 / 52.84 / 191.01 | — |
| overhead_ms mean / p50 / p95 | 41.77 / 26.22 / 149.85 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 16 | 0 | 0 |
| composer_merge | 9 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:1de58ac7eabcf0ed337cddec96961bdfdc0ea641dcc6f6d4652934f3bab37cd9 does not match proposal fileBeforeHash sha256:4522f6ec17ae3fbe00dac6d3864a365c2cdf475f050cd8d3a7e7a849e67e1b26.=3, file-hash-drift: Target file hash sha256:cd645b85df4ae0ffac8db49bb31a0a71a18a27fe2d5411dfb4e8d14dddbfda15 does not match proposal fileBeforeHash sha256:1de58ac7eabcf0ed337cddec96961bdfdc0ea641dcc6f6d4652934f3bab37cd9.=2, file-hash-drift: Target file hash sha256:ddccb4d116cb025e37e09bbd578657095afe5489f89886e26f1ac909061ab5a9 does not match proposal fileBeforeHash sha256:5534802094ed7e67adb48d4fda5a251b29d829f201d5e4c975cb08b9c185a6f6.=2, atm_compose+cas_rebase=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, file-hash-drift: Target file hash sha256:7f6627da1d4f97e3f1dc4555b57b1922cda0f50c1494735a28b3df566d1984e6 does not match proposal fileBeforeHash sha256:7def02c286644bcac414c0f952c0cc3f5ec31ef822de020821ee7dc9365b9dc0.=2, file-hash-drift: Target file hash sha256:62f57e4871312187b27628656f7b6e972dae4ae433885f1d89e240d8e00d27cb does not match proposal fileBeforeHash sha256:7f6627da1d4f97e3f1dc4555b57b1922cda0f50c1494735a28b3df566d1984e6.=1, atm_compose=1, compose-context-mismatch: proposal 'prop-s17-t004-i3' context mismatch at base line 25: expected "// </region:actions>", found "// atm-edit s17-t004-i2 by codex:mock-s2" [proposals: prop-s17-t004-i3]=1, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=16, composer_merge=5, hot_provisional=5 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=146986, duration_ms=502.43
