# atm-bench export — r5v-e4-p2-s17-fix-r06

- run_id: `r5v-e4-p2-s17-fix-r06` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 146193 | — |
| duration_ms | 676.86 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 12 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 14 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 675.46 | — |
| throughput intents/s | 50.34 | — |
| goodput oracle-pass/s | 50.34 | — |
| latency_ms mean / p50 / p95 | 8.12 / 5.38 / 24.53 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 45.24 / 20.48 / 131.26 | — |
| total_ms mean / p50 / p95 | 104.81 / 74.36 / 208.54 | — |
| overhead_ms mean / p50 / p95 | 54.73 / 27.38 / 148.72 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 12 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| composer_merge | 13 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=8, atm_serial_queue=7, file-hash-drift: Target file hash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=3, atm_compose=3, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 21 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=2, file-hash-drift: Target file hash sha256:0b23afd14f84d7dbe10a2ede350faa9584aa845ffdd0fab5df49b0fe89468b7a does not match proposal fileBeforeHash sha256:016c758f318fd9abe3c1b747e8dbd36f2c2a6138311c878554fb0ac3cac89d2f.=2, canonical target base hash is stale: src/routes.ts=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, file-hash-drift: Target file hash sha256:746ba4dc69c569c11be72c0d89e988151778598778c063c4204ffc80bf8ccbf1 does not match proposal fileBeforeHash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd.=2, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, atm_provisional_write_lease+cas_rebase=1, atm_compose+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=12, composer_merge=8, hot_provisional=6 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=146193, duration_ms=676.86
