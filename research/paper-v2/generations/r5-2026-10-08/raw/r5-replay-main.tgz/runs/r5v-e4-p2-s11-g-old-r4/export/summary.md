# atm-bench export — r5v-e4-p2-s11-g-old-r4

- run_id: `r5v-e4-p2-s11-g-old-r4` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154795 | — |
| duration_ms | 503.49 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 35 | — |
| lost updates (oracle fail) | 1 | — |
| integration pass rate of committed | 166.7% | — |
| effective success rate of all intents | 97.2% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 14 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 502.96 | — |
| throughput intents/s | 71.58 | — |
| goodput oracle-pass/s | 69.59 | — |
| latency_ms mean / p50 / p95 | 5.86 / 3.36 / 17.66 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 27.48 / 14.22 / 129.03 | — |
| total_ms mean / p50 / p95 | 80.84 / 52.24 / 187.89 | — |
| overhead_ms mean / p50 / p95 | 34.3 / 20.24 / 146.85 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 9 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=9, file-hash-drift: Target file hash sha256:5476fa0dd18c350d7d0aa4fa2caa9ba832cc774903bf5d4888ea2b388b03da65 does not match proposal fileBeforeHash sha256:267a5b7059d3c74183538f7d633c972fee8faf35c66f279a365f5cf9d2fbc9ba.=4, file-hash-drift: Target file hash sha256:101940666fe9e14173474d88ce3624a9e53373623222d6b78b431340c86ce1b6 does not match proposal fileBeforeHash sha256:173692fcc448fa0a8d0df44050556935ef9179fe928ada304a66276e93bbb8de.=3, file-hash-drift: Target file hash sha256:65e9dbf7c3060ca5e03dc2630011a389a38d1616ab6ae123d352feb06ac21d66 does not match proposal fileBeforeHash sha256:7d61bbb56dbcf4784f96960b8de5184d2a6f6542ecd76302d0edfa3dc6185740.=3, steward-final-patch-required: proposals 'prop-s11-t002-i2' and 'prop-s11-t003-i5' change overlapping base line 15 of src/store.ts; a steward-authored final patch is required [proposals: prop-s11-t002-i2, prop-s11-t003-i5]=2, file-hash-drift: Target file hash sha256:173692fcc448fa0a8d0df44050556935ef9179fe928ada304a66276e93bbb8de does not match proposal fileBeforeHash sha256:c27b45350c6bba0ee003f6536f60919a8fe7c123a599e09672e23d505418fd55.=2, canonical target base hash is stale: src/routes.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=16, composer_merge=7, hot_provisional=5 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154795, duration_ms=503.49
