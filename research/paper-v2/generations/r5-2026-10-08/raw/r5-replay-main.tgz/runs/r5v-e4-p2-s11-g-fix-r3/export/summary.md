# atm-bench export — r5v-e4-p2-s11-g-fix-r3

- run_id: `r5v-e4-p2-s11-g-fix-r3` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 150913 | — |
| duration_ms | 609.14 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=27, blocked=9 | — |
| committed | 27 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 133.3% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 17 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 609.56 | — |
| throughput intents/s | 59.06 | — |
| goodput oracle-pass/s | 59.06 | — |
| latency_ms mean / p50 / p95 | 5.05 / 3.68 / 15.77 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 47.05 / 14.63 / 122.14 | — |
| total_ms mean / p50 / p95 | 98.13 / 61.55 / 192.26 | — |
| overhead_ms mean / p50 / p95 | 52.72 / 19.21 / 138.1 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=7, atm_compose+cas_rebase=4, file-hash-drift: Target file hash sha256:5f2ca2bee4bb9671c19c39a20f4534f5bab05dd4bafac25b3b5d1360401959ed does not match proposal fileBeforeHash sha256:d1794ee66780d52fdc25ed42f76eeddecbc40f47cdc74369b0947d0c65258e87.=2, atm_compose=2, file-hash-drift: Target file hash sha256:ac417e9fb1ee8f6d68f20ff1226419e7c425ef92f53098280fee5f6eb522a99d does not match proposal fileBeforeHash sha256:267a5b7059d3c74183538f7d633c972fee8faf35c66f279a365f5cf9d2fbc9ba.=2, file-hash-drift: Target file hash sha256:2b6eb484c12fbb60463fc1024c7ff42613e55201833eaedbc5115999d8cbff4b does not match proposal fileBeforeHash sha256:a8841c38c8d83962738411f8ccf8c857f7e8d3c55037ccc3d2060f0da0bb7c05.=2, file-hash-drift: Target file hash sha256:7b3307343864540923984d5ffa1bab8fea9b3573ecaa1f11fa38dd8658f2193c does not match proposal fileBeforeHash sha256:665e4ddc77c327282c30f1d0c1ef3ef06a1dd79d4300ee4f5e51a8a826446d0a.=1, file-hash-drift: Target file hash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, canonical target base hash is stale: src/routes.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=15, composer_merge=10, hot_provisional=3 |
| no_conflict | hot_provisional=3, composer_merge=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=150913, duration_ms=609.14
