# atm-bench export — r5v-e4-p2-s11-g-old-r3

- run_id: `r5v-e4-p2-s11-g-old-r3` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 155312 | — |
| duration_ms | 640.38 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 19 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 22 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 641.05 | — |
| throughput intents/s | 56.16 | — |
| goodput oracle-pass/s | 56.16 | — |
| latency_ms mean / p50 / p95 | 4.76 / 3.62 / 14.92 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 32.88 / 14.87 / 118.4 | — |
| total_ms mean / p50 / p95 | 83.6 / 50.69 / 200.73 | — |
| overhead_ms mean / p50 / p95 | 38.52 / 18.59 / 136.89 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| cold_queue | 19 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:c6ad7e714d5fdcf8dd3794a9fcfb20850c77bbb105a8a37aabdfaaa669cb7332 does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=4, steward-final-patch-required: proposals 'prop-s11-t004-i1' and 'prop-s11-t004-i5' change overlapping base line 31 of src/config.ts; a steward-authored final patch is required [proposals: prop-s11-t004-i1, prop-s11-t004-i5]=3, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:402f1cbfd5a0ec54d356a94821d0da28806ae48c8e4c2da66754fef01eb6881b does not match proposal fileBeforeHash sha256:f2e53bfaae15e501acd0d45d3f5f713e1923289d0d20e0a7d02142ef6b455c27.=2, file-hash-drift: Target file hash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, compose-context-mismatch: proposal 'prop-s11-t000-i2' context mismatch at base line 15: expected "// </region:orders>", found "// atm-edit s11-t000-i3 by cursor:mock-s3" [proposals: prop-s11-t000-i2]=1, file-hash-drift: Target file hash sha256:ddc59502be5c789a86f52f1135b0b175853fd062858439244b3432dcf6c002d9 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=1, canonical target base hash is stale: src/store.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=16, composer_merge=7, hot_provisional=5 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=155312, duration_ms=640.38
