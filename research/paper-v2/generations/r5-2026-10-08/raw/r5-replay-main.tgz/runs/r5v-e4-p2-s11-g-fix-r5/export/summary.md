# atm-bench export — r5v-e4-p2-s11-g-fix-r5

- run_id: `r5v-e4-p2-s11-g-fix-r5` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154377 | — |
| duration_ms | 560.43 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 171.4% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 18 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 559.45 | — |
| throughput intents/s | 64.35 | — |
| goodput oracle-pass/s | 64.35 | — |
| latency_ms mean / p50 / p95 | 5.59 / 4.36 / 14.75 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 40.53 / 16.01 / 116.66 | — |
| total_ms mean / p50 / p95 | 90.14 / 65.9 / 170.26 | — |
| overhead_ms mean / p50 / p95 | 46.71 / 22.31 / 132.98 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=7, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:b34546f5e33aa03a974c2a985f03b9c0271d3def443b583e359dd256c7ce5e61 does not match proposal fileBeforeHash sha256:bdc39144302499f2e041704bfe5aa1e109bca717881dbadb77b9e9ae78fd005c.=2, file-hash-drift: Target file hash sha256:8efd455ea700a9390ec5c8cc1285ba16d477bb5b0b1bea24b51bf40700274db6 does not match proposal fileBeforeHash sha256:146e1f35e5ebbecb59e115fb9f850f18c0359275d9fd2ee0737a6d7b1ae67777.=2, canonical target base hash is stale: src/routes.ts=2, file-hash-drift: Target file hash sha256:146e1f35e5ebbecb59e115fb9f850f18c0359275d9fd2ee0737a6d7b1ae67777 does not match proposal fileBeforeHash sha256:600bb99e9d0f5fa748ef56881b85336314f19fbe9bf7b7b2369d532498f84457.=2, file-hash-drift: Target file hash sha256:72158b0b477ef71ac1bab8a81ee412edb35ce271d65d994fe22303080a804c47 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=2, file-hash-drift: Target file hash sha256:d99e5e85da084aeae432d3559da480044e5df796d88bcb0ab29b8a2541f40196 does not match proposal fileBeforeHash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171.=2, file-hash-drift: Target file hash sha256:0fa13448853df878d77930ffcd6082099aee81711cfa33093714471dc3678d1c does not match proposal fileBeforeHash sha256:72158b0b477ef71ac1bab8a81ee412edb35ce271d65d994fe22303080a804c47.=2, file-hash-drift: Target file hash sha256:063e6bb7d5487973d566cf87d7bb8448cd3afd867d7798530376ee73c8c85ef8 does not match proposal fileBeforeHash sha256:7cf12d4c27310123fc1a3de26fd958be666187a55758a90349a57ce893365ead.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=14, composer_merge=9, hot_provisional=5 |
| no_conflict | hot_provisional=3, composer_merge=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154377, duration_ms=560.43
