# atm-bench export — r5v-e4-p2-s11-g-old-r1

- run_id: `r5v-e4-p2-s11-g-old-r1` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154964 | — |
| duration_ms | 556.13 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 20 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 22 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 556.28 | — |
| throughput intents/s | 64.72 | — |
| goodput oracle-pass/s | 64.72 | — |
| latency_ms mean / p50 / p95 | 4.74 / 3.62 / 13.58 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 33.78 / 13.64 / 117.39 | — |
| total_ms mean / p50 / p95 | 83.91 / 56.19 / 202.74 | — |
| overhead_ms mean / p50 / p95 | 39.37 / 18.7 / 138.76 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| cold_queue | 20 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=15, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:c6ad7e714d5fdcf8dd3794a9fcfb20850c77bbb105a8a37aabdfaaa669cb7332 does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=4, file-hash-drift: Target file hash sha256:f44c2a2897027dea58c8624713cf72978765225e599afba06e188f74fee3b052 does not match proposal fileBeforeHash sha256:9804635699101240f6102f06ce6e855ff2276755a668c7d30d859d395237021d.=2, file-hash-drift: Target file hash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:4b6b7a8f569ba8f660b927979b1955bd8d722107be72aa601ae56d9e69de31ec does not match proposal fileBeforeHash sha256:bf49d95e71b17fef0c056f9794943bb069b86dc9e61543f0efd5b170de337f9b.=2, file-hash-drift: Target file hash sha256:749ae435cf06ca9a683c6e7d6468986d409aa1a731dda1c0a7a90c087feb640e does not match proposal fileBeforeHash sha256:646e607d675f103abc363b33116490528fc6aea2e9b0207d1a9cb5623ab6b6e5.=1, file-hash-drift: Target file hash sha256:73249c387330a8ec766a76122d96223e2fcd95f554a539931ba67a4f38b7d1d7 does not match proposal fileBeforeHash sha256:6c8df05d942b459ae61d122a2fabbf5ea04d95b44c3be5084f4f4633d4f47686.=1, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:6c8df05d942b459ae61d122a2fabbf5ea04d95b44c3be5084f4f4633d4f47686 does not match proposal fileBeforeHash sha256:600bb99e9d0f5fa748ef56881b85336314f19fbe9bf7b7b2369d532498f84457.=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=17, composer_merge=7, hot_provisional=4 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154964, duration_ms=556.13
