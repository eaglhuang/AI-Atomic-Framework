# atm-bench export — r5v-e4-p2-s17-fix-r03

- run_id: `r5v-e4-p2-s17-fix-r03` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 148683 | — |
| duration_ms | 668.28 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=15 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 178.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 667.77 | — |
| throughput intents/s | 50.92 | — |
| goodput oracle-pass/s | 50.92 | — |
| latency_ms mean / p50 / p95 | 6.71 / 5.12 / 16.77 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 53.24 / 24.67 / 132.65 | — |
| total_ms mean / p50 / p95 | 111.55 / 90.31 / 220.23 | — |
| overhead_ms mean / p50 / p95 | 61.25 / 33.17 / 149.63 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 13 | 0 | 0 |
| composer_merge | 14 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:070ef02374ab22ae019e3ff51a38ff3bc57a39faab4021e4fe304695891f46b1 does not match proposal fileBeforeHash sha256:9b688e852591ff442a8d6ee63e2e6d1857f00b4ca96db75cdb376c74d0b6a769.=3, steward-final-patch-required: proposals 'prop-s17-t004-i1' and 'prop-s17-t004-i4' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t004-i1, prop-s17-t004-i4]=3, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, atm_compose=2, file-hash-drift: Target file hash sha256:93d208270ccd8f51e5c59aacc332db7d94686bd765fa16488a0d1b4e4360aa7c does not match proposal fileBeforeHash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da.=2, steward-final-patch-required: proposals 'prop-s17-t004-i0' and 'prop-s17-t004-i5' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t004-i0, prop-s17-t004-i5]=2, file-hash-drift: Target file hash sha256:56af38d14eb8ad3996aa76de9ab0fa4cb6c7ddb2e5709053d2901c5efd138e9b does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=1, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=11, composer_merge=10, hot_provisional=5 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | cold_queue=2, composer_merge=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=148683, duration_ms=668.28
