# atm-bench export — r5v-e4-p2-s11-g-q-r3

- run_id: `r5v-e4-p2-s11-g-q-r3` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-37847584/AI-Atomic-Framework-37847584e24afc08ea58cfe380bb5b1220fbe335/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154892 | — |
| duration_ms | 672.67 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 15 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 673.05 | — |
| throughput intents/s | 53.49 | — |
| goodput oracle-pass/s | 53.49 | — |
| latency_ms mean / p50 / p95 | 5.25 / 3.9 / 15.65 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 43.11 / 17.2 / 131.09 | — |
| total_ms mean / p50 / p95 | 95.66 / 54.76 / 213.19 | — |
| overhead_ms mean / p50 / p95 | 49.21 / 23.59 / 135.35 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=6, steward-final-patch-required: proposals 'prop-s11-t001-i3' and 'prop-s11-t001-i5' both edit region 'orders' of src/routes.ts; overlapping region edits stay blocked [proposals: prop-s11-t001-i3, prop-s11-t001-i5]=4, atm_compose+cas_rebase=3, steward-final-patch-required: proposals 'prop-s11-t002-i1' and 'prop-s11-t002-i3' both edit region 'selectors' of src/store.ts; overlapping region edits stay blocked [proposals: prop-s11-t002-i1, prop-s11-t002-i3]=2, steward-final-patch-required: proposal 'prop-s11-t004-i4' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t004-i4]=2, atm_compose=2, steward-final-patch-required: proposals 'prop-s11-t003-i6' and 'prop-s11-t004-i3' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s11-t003-i6, prop-s11-t004-i3]=2, steward-final-patch-required: proposal 'prop-s11-t001-i1' overlaps region 'users', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t001-i1]=1, steward-final-patch-required: proposal 'prop-s11-t003-i1' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i1]=1, steward-final-patch-required: proposal 'prop-s11-t000-i2' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i2]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=15, composer_merge=10, hot_provisional=3 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154892, duration_ms=672.67
