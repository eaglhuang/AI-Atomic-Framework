# atm-bench export — r5v-e4-p2-s17-fix-r04

- run_id: `r5v-e4-p2-s17-fix-r04` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 145042 | — |
| duration_ms | 576.61 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 161.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 575.51 | — |
| throughput intents/s | 59.08 | — |
| goodput oracle-pass/s | 59.08 | — |
| latency_ms mean / p50 / p95 | 6.83 / 5.18 / 19.58 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 43.29 / 20.24 / 129.71 | — |
| total_ms mean / p50 / p95 | 97.2 / 55.79 / 257.77 | — |
| overhead_ms mean / p50 / p95 | 51.21 / 25.5 / 142.84 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 10 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=10, atm_serial_queue=8, file-hash-drift: Target file hash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=3, file-hash-drift: Target file hash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e does not match proposal fileBeforeHash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd.=3, file-hash-drift: Target file hash sha256:cb1bab3e26b39141919c2cd07ebb9c25e90ee0a2233996d02c41cb92a932804a does not match proposal fileBeforeHash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef.=2, atm_compose=2, file-hash-drift: Target file hash sha256:dcd67fad4f6553bc68cc12a73f92d884fa1d2c036aaff8619f79b6256c1d39e6 does not match proposal fileBeforeHash sha256:553aecebed3b00dd2d067f3571e129681ac23113c9cda78eb786bc1b94b54609.=2, compose-context-mismatch: proposal 'prop-s17-t004-i1' context mismatch at base line 11: expected "// </region:reducers>", found "// atm-edit s17-t004-i5 by other:mock-s6" [proposals: prop-s17-t004-i1]=1, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, atm_compose+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, hot_provisional=7, composer_merge=6 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=145042, duration_ms=576.61
