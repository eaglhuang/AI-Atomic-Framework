# atm-bench export — r5v-e4-p2-s11-g-old-r5

- run_id: `r5v-e4-p2-s11-g-old-r5` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 153914 | — |
| duration_ms | 650.93 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 19 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 18 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 650.58 | — |
| throughput intents/s | 55.34 | — |
| goodput oracle-pass/s | 55.34 | — |
| latency_ms mean / p50 / p95 | 5.39 / 3.91 / 14.82 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 39.86 / 13.22 / 118.14 | — |
| total_ms mean / p50 / p95 | 90.34 / 56.85 / 203.69 | — |
| overhead_ms mean / p50 / p95 | 45.96 / 18.08 / 139.96 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 19 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=5, file-hash-drift: Target file hash sha256:c6ad7e714d5fdcf8dd3794a9fcfb20850c77bbb105a8a37aabdfaaa669cb7332 does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=4, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:dcc0dc6067af35d03de64e9a83d6b604e872b01dc52c961b81b7069cb8ce4038 does not match proposal fileBeforeHash sha256:b7d95c21485b25933646b6495415f0388a096a7cd05d03e16e91c8eb555f4485.=2, file-hash-drift: Target file hash sha256:612ce24739db7382a853399e28b4c3921fb9189118847f70d2d62d4ca62321a9 does not match proposal fileBeforeHash sha256:146e1f35e5ebbecb59e115fb9f850f18c0359275d9fd2ee0737a6d7b1ae67777.=2, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:bc0cd8749ca6e4480039827e7b967b03b65d73daad723aaf15047586edf909d1 does not match proposal fileBeforeHash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8.=1, file-hash-drift: Target file hash sha256:146e1f35e5ebbecb59e115fb9f850f18c0359275d9fd2ee0737a6d7b1ae67777 does not match proposal fileBeforeHash sha256:600bb99e9d0f5fa748ef56881b85336314f19fbe9bf7b7b2369d532498f84457.=1, atm_compose=1, file-hash-drift: Target file hash sha256:6c79126b7fc145f416c249588ca0f6ea648359fa45de050590b760a695d20e26 does not match proposal fileBeforeHash sha256:ba97b2a3c71e86a591b85923d68989a026c30955311b5ebfa57470d8206be1e3.=1, canonical target base hash is stale: src/store.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=16, composer_merge=8, hot_provisional=4 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=153914, duration_ms=650.93
