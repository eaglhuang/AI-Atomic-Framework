# atm-bench export — r5v-e4-p2-s11-g-fix-r1

- run_id: `r5v-e4-p2-s11-g-fix-r1` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 153202 | — |
| duration_ms | 580.43 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=24, blocked=12 | — |
| committed | 24 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 150% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 21 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 25 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 580.52 | — |
| throughput intents/s | 62.01 | — |
| goodput oracle-pass/s | 62.01 | — |
| latency_ms mean / p50 / p95 | 5.67 / 3.87 / 18.38 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 29 / 14.62 / 119.4 | — |
| total_ms mean / p50 / p95 | 82.72 / 52.08 / 215.75 | — |
| overhead_ms mean / p50 / p95 | 35.72 / 20.14 / 146.62 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 9 | 0 | 0 |
| cold_queue | 21 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=15, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:c6ad7e714d5fdcf8dd3794a9fcfb20850c77bbb105a8a37aabdfaaa669cb7332 does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=4, file-hash-drift: Target file hash sha256:815947cb3df5ef8cb0a891f1fc09525731f0d00abee2aab9e8f90dde623b33f6 does not match proposal fileBeforeHash sha256:600bb99e9d0f5fa748ef56881b85336314f19fbe9bf7b7b2369d532498f84457.=3, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:1b390cf1ac4feffda28e92b920e2954443eda7cb7c9eb97307dfcd8650a7c7a6 does not match proposal fileBeforeHash sha256:230155795b34ed67cf8feeb6243d0834123b2c8879bc64dacdd85e50a10eeb10.=2, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:8087360d973675dfe93faffb1d012fc850e94c30b63b7c9c1053f707d1e2085f does not match proposal fileBeforeHash sha256:ab645ed1f97a0d11bb30d1f9794e2bec2105eb4c8d55ab19d1d3d8d3add3a67e.=1, file-hash-drift: Target file hash sha256:a5a27b00733f250682d271e5d94954d8ffe8c3c89d230d8ce9610801610dc831 does not match proposal fileBeforeHash sha256:b7b22d4b881f8f1bace886777be07ad1b89fcd26ad414741811c7811493bd089.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=18, composer_merge=6, hot_provisional=4 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=153202, duration_ms=580.43
