/** App config (HOT) — writable via ATM WriteIntent bounded regions. */
export interface DbConfig { host: string; port: number; name: string }
export interface CacheConfig { ttlSec: number; backend: 'memory' | 'redis' }
export interface FeatureFlags { billingV2: boolean; experimentalSearch: boolean }

// <region:db>
export const dbConfig: DbConfig = {
  host: 'localhost',
  port: 5432,
  name: 'app',
};
// atm-edit s23-t000-i1 by codex:mock-s2
// </region:db>

// <region:cache>
export const cacheConfig: CacheConfig = {
  ttlSec: 60,
  backend: 'memory',
};
// atm-edit s23-t004-i2 by codex:mock-s2
// atm-edit s23-t004-i0 by cursor:mock-s0
// </region:cache>

// <region:flags>
export const featureFlags: FeatureFlags = {
  billingV2: false,
  experimentalSearch: false,
};
// </region:flags>
