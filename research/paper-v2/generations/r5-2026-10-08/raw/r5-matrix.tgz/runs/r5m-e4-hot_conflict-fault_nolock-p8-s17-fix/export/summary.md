# atm-bench export — r5m-e4-hot_conflict-fault_nolock-p8-s17-fix

- run_id: `r5m-e4-hot_conflict-fault_nolock-p8-s17-fix` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 147727 | — |
| duration_ms | 650.5 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=12 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 154.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 6 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 649.09 | — |
| throughput intents/s | 52.38 | — |
| goodput oracle-pass/s | 52.38 | — |
| latency_ms mean / p50 / p95 | 15.42 / 9.67 / 51.62 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 81.96 / 21.02 / 270.87 | — |
| total_ms mean / p50 / p95 | 112.76 / 50.12 / 301.3 | — |
| overhead_ms mean / p50 / p95 | 97.88 / 32.35 / 293.07 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 14 | 0 | 0 |
| composer_merge | 9 | 0 | 0 |
| hot_provisional | 11 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=11, atm_serial_queue=9, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=5, file-hash-drift: Target file hash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:97c243dc7053b942f2e727f1f649f633a26692e99d6d2c7847a2f71a2ad4b2ff does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:36f020c65968dec6f293e33c28b714b33eb62c60b7bd52b5a3140a7e86cc70f4 does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=1, file-hash-drift: Target file hash sha256:54d8724e2a20e01aa0be306f1bd3595984b6e375020fa2804e33b2ec9fce8322 does not match proposal fileBeforeHash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd.=1, file-hash-drift: Target file hash sha256:6e58b7084a624fcc3ea6978cd036d1b3371a2d2595e48a76728f94f9b3a8b931 does not match proposal fileBeforeHash sha256:eb55eddde0d3e1fa2540331ac52a41e435a38a7565b44ef2d1a3c8c6fc7da52f.=1, atm_compose=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:c8d73a3c9a6d2cc305fc00908539024c66273152b37ec0aa75e5d44edd5a017f does not match proposal fileBeforeHash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=12, hot_provisional=8, composer_merge=6 |
| no_conflict | hot_provisional=2, cold_queue=1, composer_merge=1 |
| composer_cowrite | composer_merge=2, hot_provisional=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=147727, duration_ms=650.5
