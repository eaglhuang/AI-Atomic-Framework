# atm-bench export — r5m-e4-hot_conflict-fault_nolock-p8-s11-nq

- run_id: `r5m-e4-hot_conflict-fault_nolock-p8-s11-nq` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-37847584/AI-Atomic-Framework-37847584e24afc08ea58cfe380bb5b1220fbe335/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154352 | — |
| duration_ms | 643.81 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=25, blocked=11 | — |
| committed | 25 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 144% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 20 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 643.93 | — |
| throughput intents/s | 55.91 | — |
| goodput oracle-pass/s | 55.91 | — |
| latency_ms mean / p50 / p95 | 16.33 / 11.89 / 42.08 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 86.66 / 27.6 / 259.58 | — |
| total_ms mean / p50 / p95 | 121.61 / 75.88 / 315.98 | — |
| overhead_ms mean / p50 / p95 | 103.42 / 61.51 / 290.21 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 20 | 0 | 0 |
| hot_provisional | 5 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=16, atm_provisional_write_lease=5, atm_compose+cas_rebase=2, atm_compose=2, steward-final-patch-required: proposal 'prop-s11-t000-i1' overlaps region 'users', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i1]=1, steward-final-patch-required: proposal 'prop-s11-t002-i4' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i4]=1, steward-final-patch-required: proposal 'prop-s11-t000-i2' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i2]=1, steward-final-patch-required: proposal 'prop-s11-t003-i4' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i4]=1, steward-final-patch-required: proposal 'prop-s11-t004-i5' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t004-i5]=1, steward-final-patch-required: proposal 'prop-s11-t000-i0' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i0]=1, steward-final-patch-required: proposal 'prop-s11-t003-i0' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i0]=1, steward-final-patch-required: proposal 'prop-s11-t000-i3' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i3]=1, steward-final-patch-required: proposal 'prop-s11-t002-i6' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i6]=1, steward-final-patch-required: proposal 'prop-s11-t002-i7' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i7]=1, steward-final-patch-required: proposal 'prop-s11-t003-i6' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i6]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=18, composer_merge=8, hot_provisional=2 |
| no_conflict | hot_provisional=2, cold_queue=2, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154352, duration_ms=643.81
