# atm-bench export — r5m-e4-hot_conflict-fault_nolock-p8-s17-old

- run_id: `r5m-e4-hot_conflict-fault_nolock-p8-s17-old` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 147350 | — |
| duration_ms | 687.27 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=12 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 154.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 11 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 685.88 | — |
| throughput intents/s | 49.57 | — |
| goodput oracle-pass/s | 49.57 | — |
| latency_ms mean / p50 / p95 | 15.17 / 7.74 / 45.59 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 82.32 / 18.94 / 267.2 | — |
| total_ms mean / p50 / p95 | 113.05 / 51.3 / 315.54 | — |
| overhead_ms mean / p50 / p95 | 97.94 / 30.4 / 300.32 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 15 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| composer_merge | 10 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=4, file-hash-drift: Target file hash sha256:bd20bfdc70c2939ec0f94d906771c229313f29a170a55099883a531cd8a7ea3a does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:8be14aa66e06bc04e96554a65c810cba0f1ef2f2b55a2166c9f72dd8b704a7b3 does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:83efafe0030e7148cc3c078a6f5f214501a3b7fe1208bb2fcf49b77618012fce does not match proposal fileBeforeHash sha256:bd74bd0afc6a882651df72731c89b5a3a8d0d85f422ef2b1b07164fa6351c7e7.=1, atm_compose+cas_rebase=1, canonical target base hash is stale: src/store.ts=1, atm_compose=1, file-hash-drift: Target file hash sha256:b1922a01f27b5f0e51d3bedc0bce35eefbc9746969a5ab7bf22b9c17096c864c does not match proposal fileBeforeHash sha256:6352b41403bb24d353ba77b7159e61bfb20a6e78c82d560f84e7569c04875687.=1, file-hash-drift: Target file hash sha256:6352b41403bb24d353ba77b7159e61bfb20a6e78c82d560f84e7569c04875687 does not match proposal fileBeforeHash sha256:3fff25580e23004e2119348fc0b52f46c243b55f201729c097e471a90f955a4f.=1, file-hash-drift: Target file hash sha256:8be14aa66e06bc04e96554a65c810cba0f1ef2f2b55a2166c9f72dd8b704a7b3 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:37ab041f22751301118579215ce528e7e57c0d8a7bf1fa899f1512fe3343bed8 does not match proposal fileBeforeHash sha256:792a99d41579b7a64323e25fbc89efb7deb326d3b3822fc94d6777528739c347.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=14, hot_provisional=7, composer_merge=5 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=147350, duration_ms=687.27
