# atm-bench export — r5m-e4-hot_conflict-fault_naive-p8-s23-old

- run_id: `r5m-e4-hot_conflict-fault_naive-p8-s23-old` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 158182 | — |
| duration_ms | 662.13 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 10 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 2 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 658.71 | — |
| throughput intents/s | 54.65 | — |
| goodput oracle-pass/s | 54.65 | — |
| latency_ms mean / p50 / p95 | 11.73 / 10.5 / 26.65 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 85.37 / 110.09 / 195.82 | — |
| total_ms mean / p50 / p95 | 114.04 / 122.49 / 229.37 | — |
| overhead_ms mean / p50 / p95 | 97.53 / 114.35 / 215.36 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| hot_provisional | 14 | 0 | 0 |
| cold_queue | 10 | 0 | 0 |
| composer_merge | 12 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=11, atm_serial_queue=7, file-hash-drift: Target file hash sha256:d1172c579b2f2940eed2ce6262dd7322e2562f85cb8c7770df5e794eb53c77aa does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=3, file-hash-drift: Target file hash sha256:abd1f3cd43c1b4c751a859d3e2765b687f6672c076d7394e88c8702f5172095b does not match proposal fileBeforeHash sha256:e186c90c34b9a8461eb14f0aaf8390815fc993fec3344f50b2ab9679c525e209.=2, file-hash-drift: Target file hash sha256:cedd2bd01b527ad7f5bea13d539199ca318097c6af668e07858b7c6e61183f2b does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:b3354d6c9fc8ff9ae149907c20a1087f431fcfcf7dfe1348ee335fceba308f0a does not match proposal fileBeforeHash sha256:c1d67974e8bcbb7a4c43ea15ae18b75c26a7aa722c720b747d2d107ca752b673.=1, canonical target base hash is stale: src/store.ts=1, atm_provisional_write_lease+cas_rebase=1, file-hash-drift: Target file hash sha256:b3354d6c9fc8ff9ae149907c20a1087f431fcfcf7dfe1348ee335fceba308f0a does not match proposal fileBeforeHash sha256:00b601abae857910814760d026795fa361c887a8c3747383ae2688bce95d428c.=1, file-hash-drift: Target file hash sha256:ed34adbb5aee1c1fab5120cc5506ba70a2fd866238a03a102372caeea7064eaa does not match proposal fileBeforeHash sha256:b280eae914a527fc80d9697c6087aceccd240291d2a6b8be1d6524e101bf440a.=1, file-hash-drift: Target file hash sha256:c1d67974e8bcbb7a4c43ea15ae18b75c26a7aa722c720b747d2d107ca752b673 does not match proposal fileBeforeHash sha256:cedd2bd01b527ad7f5bea13d539199ca318097c6af668e07858b7c6e61183f2b.=1, file-hash-drift: Target file hash sha256:c1d67974e8bcbb7a4c43ea15ae18b75c26a7aa722c720b747d2d107ca752b673 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, canonical target base hash is stale: src/config.ts=1, file-hash-drift: Target file hash sha256:b280eae914a527fc80d9697c6087aceccd240291d2a6b8be1d6524e101bf440a does not match proposal fileBeforeHash sha256:beeb79bc0ade66bd774510489eb6af6237d49513186eafb13aaffee834d89326.=1, file-hash-drift: Target file hash sha256:beeb79bc0ade66bd774510489eb6af6237d49513186eafb13aaffee834d89326 does not match proposal fileBeforeHash sha256:bb4f7a30c6eff34677f7b8abcaa03e545ce0af341fb401f863442d0ce52d9aa9.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1, cold_queue=1 |
| no_conflict | hot_provisional=5, cold_queue=1, composer_merge=1 |
| hot_provisional | composer_merge=9, cold_queue=8, hot_provisional=8 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=158182, duration_ms=662.13
