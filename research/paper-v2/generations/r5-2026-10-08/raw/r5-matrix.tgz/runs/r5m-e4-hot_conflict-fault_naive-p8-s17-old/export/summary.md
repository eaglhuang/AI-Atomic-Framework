# atm-bench export — r5m-e4-hot_conflict-fault_naive-p8-s17-old

- run_id: `r5m-e4-hot_conflict-fault_naive-p8-s17-old` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 145347 | — |
| duration_ms | 611 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=12 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 154.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 21 | — |
| composer co-writes | 6 | — |
| CAS rebase on apply | 6 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 610.01 | — |
| throughput intents/s | 55.74 | — |
| goodput oracle-pass/s | 55.74 | — |
| latency_ms mean / p50 / p95 | 13.17 / 9.44 / 34.12 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 89.55 / 17.62 / 311.78 | — |
| total_ms mean / p50 / p95 | 118.07 / 47.51 / 346.27 | — |
| overhead_ms mean / p50 / p95 | 103.22 / 26.45 / 331.05 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 6 | 0 | 0 |
| cold_queue | 21 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=17, atm_provisional_write_lease=5, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=3, canonical target base hash is stale: src/store.ts=2, file-hash-drift: Target file hash sha256:988eac119ef3d655b605621a356a29ad67274e7003fead65559743ff352ab356 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, canonical target base hash is stale: src/config.ts=1, file-hash-drift: Target file hash sha256:ce037a2c28db2fc34790ea156854b8c1c46475bae23f3385bb5c4d9236a75a21 does not match proposal fileBeforeHash sha256:988eac119ef3d655b605621a356a29ad67274e7003fead65559743ff352ab356.=1, file-hash-drift: Target file hash sha256:45eed7675d4aa4a7bf6e187a287e3bc9aacb03a5435cc8c4c7cea0c7a708fb34 does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:1ca3f9f0e4ca88fde032da813bd2e470e1610a9d6e5625d90d7865566412920a does not match proposal fileBeforeHash sha256:5a1397cc1f02d233ed20972d9129fa7e6e64131e098f5762fc19462c985b267c.=1, file-hash-drift: Target file hash sha256:948f5ffa597e705ce9a8feb5267cbac76d8ba7199b30b8344d0dc13d8c43d9ff does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=19, hot_provisional=4, composer_merge=3 |
| no_conflict | hot_provisional=3, cold_queue=1 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=145347, duration_ms=611
