# atm-bench export — r5m-e4-hot_conflict-fault_nolock-p8-s23-nq

- run_id: `r5m-e4-hot_conflict-fault_nolock-p8-s23-nq` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-37847584/AI-Atomic-Framework-37847584e24afc08ea58cfe380bb5b1220fbe335/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 155360 | — |
| duration_ms | 682.61 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 6 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 679.6 | — |
| throughput intents/s | 52.97 | — |
| goodput oracle-pass/s | 52.97 | — |
| latency_ms mean / p50 / p95 | 14.92 / 8.75 / 42.26 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 93.67 / 26.51 / 284.89 | — |
| total_ms mean / p50 / p95 | 125.41 / 75.91 / 337.43 | — |
| overhead_ms mean / p50 / p95 | 109.05 / 54.49 / 316.19 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=7, atm_compose=1, steward-final-patch-required: proposal 'prop-s23-t003-i1' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t003-i1]=1, steward-final-patch-required: proposal 'prop-s23-t001-i4' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t001-i4]=1, atm_compose+cas_rebase=1, steward-final-patch-required: proposal 'prop-s23-t000-i0' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t000-i0]=1, steward-final-patch-required: proposal 'prop-s23-t002-i2' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t002-i2]=1, steward-final-patch-required: proposal 'prop-s23-t001-i5' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t001-i5]=1, steward-final-patch-required: proposal 'prop-s23-t004-i5' overlaps region 'users', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t004-i5]=1, steward-final-patch-required: proposal 'prop-s23-t004-i0' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t004-i0]=1, steward-final-patch-required: proposal 'prop-s23-t003-i3' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t003-i3]=1, steward-final-patch-required: proposal 'prop-s23-t000-i4' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t000-i4]=1, steward-final-patch-required: proposal 'prop-s23-t004-i6' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t004-i6]=1, steward-final-patch-required: proposal 'prop-s23-t000-i5' overlaps region 'cache', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t000-i5]=1, steward-final-patch-required: proposal 'prop-s23-t002-i6' overlaps region 'cache', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t002-i6]=1, steward-final-patch-required: proposal 'prop-s23-t004-i7' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t004-i7]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, cold_queue=2 |
| no_conflict | hot_provisional=4, cold_queue=2, composer_merge=1 |
| hot_provisional | cold_queue=13, composer_merge=9, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=155360, duration_ms=682.61
