# atm-bench export — r5m-e4-hot_conflict-fault_nolock-p8-s23-old

- run_id: `r5m-e4-hot_conflict-fault_nolock-p8-s23-old` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 161193 | — |
| duration_ms | 757.81 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=19, commit=17 | — |
| committed | 17 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 211.8% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 16 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 755.08 | — |
| throughput intents/s | 47.68 | — |
| goodput oracle-pass/s | 47.68 | — |
| latency_ms mean / p50 / p95 | 13.42 / 8.98 / 36.76 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 92.51 / 110.95 / 254.35 | — |
| total_ms mean / p50 / p95 | 122.89 / 134.31 / 295.23 | — |
| overhead_ms mean / p50 / p95 | 106.36 / 116.03 / 276.33 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 16 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| hot_provisional | 4 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=4, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=3, file-hash-drift: Target file hash sha256:709ecbfaa89d55daa9e3bf08fd508e73d11c806ca825f06c1ada6a1faf78634b does not match proposal fileBeforeHash sha256:3f5d0cc56edd9e80ceb8d0cc184a3eb37ae3f7a361149d2e1d78f27e24132f2d.=2, file-hash-drift: Target file hash sha256:bc4f617174786da624968181643709560ca615526052bc61d1a4e77b2aec5335 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=2, file-hash-drift: Target file hash sha256:69010286a8c3c0a2cff8894622be239a2fef54f0e7b2613c8316ad0b887af8e8 does not match proposal fileBeforeHash sha256:7099d93b31b132a379acc14772fb4c766fdb046e055f7cd86b617ba99240f742.=2, file-hash-drift: Target file hash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9 does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=2, file-hash-drift: Target file hash sha256:a29bb0f74df8dd73fe03d652396b6902a23e19678368526bc8abc84b92a2436f does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:7099d93b31b132a379acc14772fb4c766fdb046e055f7cd86b617ba99240f742 does not match proposal fileBeforeHash sha256:e47a6b11ed6bc63bc0ad4fe8a8bcca77e214f62b4f6cd758f2dcbcaad142b1a3.=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:7099d93b31b132a379acc14772fb4c766fdb046e055f7cd86b617ba99240f742 does not match proposal fileBeforeHash sha256:27d3ccd8878c970e59c1d4ea6eebfabf34085961fffe82ce580684b933445904.=1, file-hash-drift: Target file hash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:7099d93b31b132a379acc14772fb4c766fdb046e055f7cd86b617ba99240f742 does not match proposal fileBeforeHash sha256:1525d348b0142cd693cfc07c3c30dafdd416b7f502b281215130889856812b3d.=1, file-hash-drift: Target file hash sha256:e62f1005cd1b0ed8afbb024f43ea2635d1b83ab229aeabd0306c555ebaff3136 does not match proposal fileBeforeHash sha256:9b32ba2d6909eccca98dc460deb1fdf338893cab8581606443828991984318f0.=1, file-hash-drift: Target file hash sha256:e62f1005cd1b0ed8afbb024f43ea2635d1b83ab229aeabd0306c555ebaff3136 does not match proposal fileBeforeHash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=3, composer_merge=2, cold_queue=2 |
| hot_provisional | cold_queue=14, composer_merge=10, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=161193, duration_ms=757.81
