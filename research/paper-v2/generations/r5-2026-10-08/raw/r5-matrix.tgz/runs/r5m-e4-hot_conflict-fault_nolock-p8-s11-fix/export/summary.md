# atm-bench export — r5m-e4-hot_conflict-fault_nolock-p8-s11-fix

- run_id: `r5m-e4-hot_conflict-fault_nolock-p8-s11-fix` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 160443 | — |
| duration_ms | 715.31 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=19, commit=17 | — |
| committed | 17 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 211.8% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 6 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 715.3 | — |
| throughput intents/s | 50.33 | — |
| goodput oracle-pass/s | 50.33 | — |
| latency_ms mean / p50 / p95 | 14.42 / 11.12 / 36.12 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 86.44 / 110.02 / 272.41 | — |
| total_ms mean / p50 / p95 | 119.74 / 126.37 / 324 | — |
| overhead_ms mean / p50 / p95 | 101.3 / 114.07 / 298.59 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |
| hot_provisional | 5 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=4, file-hash-drift: Target file hash sha256:17c05f0e3c26f09bd697649fd920dcfaee61c75ce0dcde7cab110f87e772b767 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=3, file-hash-drift: Target file hash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=3, file-hash-drift: Target file hash sha256:e3458a98b8824434335e74915f54ddddd7bc90275257d68b234d0f14ee621d1a does not match proposal fileBeforeHash sha256:6be72741f79245fadedf6bc77d8f664365c8dd7d63a40787fc21da205c52a0ee.=2, file-hash-drift: Target file hash sha256:1113169808fd50422370255f2ea51bee822fefc661886c79e435ae14cd4f52d0 does not match proposal fileBeforeHash sha256:8c216388953701b12d61d028759ce591ecc95302af8efa5fcb6972ab0ef82943.=2, file-hash-drift: Target file hash sha256:8c216388953701b12d61d028759ce591ecc95302af8efa5fcb6972ab0ef82943 does not match proposal fileBeforeHash sha256:ac417e9fb1ee8f6d68f20ff1226419e7c425ef92f53098280fee5f6eb522a99d.=2, file-hash-drift: Target file hash sha256:17c05f0e3c26f09bd697649fd920dcfaee61c75ce0dcde7cab110f87e772b767 does not match proposal fileBeforeHash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171.=2, file-hash-drift: Target file hash sha256:e02086cb54b95f8d804dbffc2baa2524ffd4eee358ab4c9fa54e51a9cc1686bb does not match proposal fileBeforeHash sha256:17c05f0e3c26f09bd697649fd920dcfaee61c75ce0dcde7cab110f87e772b767.=1, file-hash-drift: Target file hash sha256:5074b3d6506b66f4c45cc89a70046a57cef2e630225f9fd3432009621ff5b79a does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:0205191f1007d47bd000acb202e5d5269b7759e42e2c45642edd6f31b4508a22 does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=1, atm_compose+cas_rebase=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:456d260801057b99bb0b1c0c822792b9bff4500f9fbf18226c4c9f4e4c2e9d38 does not match proposal fileBeforeHash sha256:0205191f1007d47bd000acb202e5d5269b7759e42e2c45642edd6f31b4508a22.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=17, composer_merge=10, hot_provisional=1 |
| no_conflict | hot_provisional=3, composer_merge=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=160443, duration_ms=715.31
