# atm-bench export — r5m-e4-hot_conflict-fault_naive-p8-s17-opt

- run_id: `r5m-e4-hot_conflict-fault_naive-p8-s17-opt` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-2118bc66/AI-Atomic-Framework-2118bc66efb3ac3bc0ddaede6a2f7cb18526b030/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 145833 | — |
| duration_ms | 888.95 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=24, blocked=10 | — |
| committed | 24 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 141.7% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 11 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 2 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 887.82 | — |
| throughput intents/s | 38.3 | — |
| goodput oracle-pass/s | 38.3 | — |
| latency_ms mean / p50 / p95 | 24.57 / 18.38 / 54.65 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 106.91 / 115.44 / 298.73 | — |
| total_ms mean / p50 / p95 | 146.81 / 137.19 / 345.79 | — |
| overhead_ms mean / p50 / p95 | 131.96 / 124.8 / 330.03 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| hot_provisional | 9 | 0 | 0 |
| composer_merge | 14 | 0 | 0 |
| cold_queue | 11 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=8, atm_compose=7, atm_serial_queue=7, steward-final-patch-required: proposal 'prop-s17-t002-i1' overlaps region 'cache', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t002-i1]=1, steward-final-patch-required: proposal 'prop-s17-t000-i2' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t000-i2]=1, steward-final-patch-required: proposal 'prop-s17-t003-i2' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t003-i2]=1, steward-final-patch-required: proposal 'prop-s17-t004-i2' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t004-i2]=1, atm_provisional_write_lease+cas_rebase=1, atm_compose+cas_rebase=1, steward-final-patch-required: proposal 'prop-s17-t000-i5' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t000-i5]=1, steward-final-patch-required: proposal 'prop-s17-t001-i5' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t001-i5]=1, steward-final-patch-required: proposal 'prop-s17-t004-i5' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t004-i5]=1, steward-final-patch-required: proposal 'prop-s17-t000-i6' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t000-i6]=1, steward-final-patch-required: proposal 'prop-s17-t001-i6' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t001-i6]=1, steward-final-patch-required: proposal 'prop-s17-t002-i6' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t002-i6]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=11, cold_queue=10, hot_provisional=5 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=2, cold_queue=1, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=145833, duration_ms=888.95
