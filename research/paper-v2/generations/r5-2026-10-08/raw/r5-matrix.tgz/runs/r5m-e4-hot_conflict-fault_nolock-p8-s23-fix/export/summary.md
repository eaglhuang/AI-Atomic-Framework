# atm-bench export — r5m-e4-hot_conflict-fault_nolock-p8-s23-fix

- run_id: `r5m-e4-hot_conflict-fault_nolock-p8-s23-fix` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 159255 | — |
| duration_ms | 632.25 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 629.62 | — |
| throughput intents/s | 57.18 | — |
| goodput oracle-pass/s | 57.18 | — |
| latency_ms mean / p50 / p95 | 14.79 / 9.48 / 52.03 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 79.37 / 21.38 / 240.45 | — |
| total_ms mean / p50 / p95 | 111.04 / 54.68 / 282.51 | — |
| overhead_ms mean / p50 / p95 | 94.65 / 36.76 / 263.94 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=10, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:9b32ba2d6909eccca98dc460deb1fdf338893cab8581606443828991984318f0 does not match proposal fileBeforeHash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9.=4, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=3, file-hash-drift: Target file hash sha256:d2aced757fb0c65e8608f358a583acf3dbcf16c9ad097126c8cbbd5ba9852d79 does not match proposal fileBeforeHash sha256:e6e6ab5150e6781904154d4d55910b6ae060878a8a8e2deec2aabe28446ae6f1.=2, file-hash-drift: Target file hash sha256:a67d81b7ae41111ff8b057ee3a1ddab7d5ea04aa15e49f18746f433a12df16e3 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:50feeaa3d771087d867d8eba41248610ee3b8fa79a0fd71e3d0d0a88c57aed98 does not match proposal fileBeforeHash sha256:a67d81b7ae41111ff8b057ee3a1ddab7d5ea04aa15e49f18746f433a12df16e3.=1, atm_compose=1, file-hash-drift: Target file hash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, compose-context-mismatch: proposal 'prop-s23-t001-i2' context mismatch at base line 22: expected "// atm-edit s23-t001-i6 by other:mock-s6", found "}" [proposals: prop-s23-t001-i2]=1, file-hash-drift: Target file hash sha256:50feeaa3d771087d867d8eba41248610ee3b8fa79a0fd71e3d0d0a88c57aed98 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:8c6869359307ba3b14353dc137e7542aa7b2dd368515c720d84955a8364d8153 does not match proposal fileBeforeHash sha256:0e1a712f401f70f5d8c04a69cf0bf3dcfeff81f8fdc38204e34bc2b57469e993.=1, file-hash-drift: Target file hash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9 does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=1, file-hash-drift: Target file hash sha256:e6e6ab5150e6781904154d4d55910b6ae060878a8a8e2deec2aabe28446ae6f1 does not match proposal fileBeforeHash sha256:9a24d95d62d9e828b4b1638c70b4ac5c35361617cfefdc6b6a41bbd1ce4d6708.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=4, cold_queue=2, composer_merge=1 |
| hot_provisional | cold_queue=15, composer_merge=6, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=159255, duration_ms=632.25
