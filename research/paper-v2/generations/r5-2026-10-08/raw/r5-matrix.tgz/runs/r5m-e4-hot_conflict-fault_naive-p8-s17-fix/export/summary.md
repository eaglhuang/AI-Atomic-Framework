# atm-bench export — r5m-e4-hot_conflict-fault_naive-p8-s17-fix

- run_id: `r5m-e4-hot_conflict-fault_naive-p8-s17-fix` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 148971 | — |
| duration_ms | 652.07 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 8 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 651.39 | — |
| throughput intents/s | 52.2 | — |
| goodput oracle-pass/s | 52.2 | — |
| latency_ms mean / p50 / p95 | 11.5 / 6.4 / 34.09 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 92.58 / 112.09 / 275.84 | — |
| total_ms mean / p50 / p95 | 119.28 / 126.45 / 315.47 | — |
| overhead_ms mean / p50 / p95 | 104.53 / 116.27 / 300.66 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 14 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=5, file-hash-drift: Target file hash sha256:805a775f09e8dc578699a8d628ecafa030de13dbe65b72c2cf184c2f9c54ab1f does not match proposal fileBeforeHash sha256:83d246f0d84d86e617ae5dd15517ad51b3cb4005da587bc9ecf3114a3e666a16.=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:6975dc24e769c21145e1d363533a290895bd16dff852ffb77d6161d07c0d8f8d does not match proposal fileBeforeHash sha256:805a775f09e8dc578699a8d628ecafa030de13dbe65b72c2cf184c2f9c54ab1f.=1, file-hash-drift: Target file hash sha256:12253900332ab6a0cf983f59077b17c45928983cb7d0afb665201c53b98dd70a does not match proposal fileBeforeHash sha256:83d246f0d84d86e617ae5dd15517ad51b3cb4005da587bc9ecf3114a3e666a16.=1, atm_compose=1, file-hash-drift: Target file hash sha256:805a775f09e8dc578699a8d628ecafa030de13dbe65b72c2cf184c2f9c54ab1f does not match proposal fileBeforeHash sha256:12253900332ab6a0cf983f59077b17c45928983cb7d0afb665201c53b98dd70a.=1, file-hash-drift: Target file hash sha256:e0039134990c69d6534af97469287077ddea2016b056d08b333528ce7be221d5 does not match proposal fileBeforeHash sha256:69b951073cdc63364d457c9121318ff62be8e58ba58e45fd54981ebd78462e52.=1, file-hash-drift: Target file hash sha256:69b951073cdc63364d457c9121318ff62be8e58ba58e45fd54981ebd78462e52 does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=1, file-hash-drift: Target file hash sha256:a11ec99c977b7082413e805521f02b702baba4c298e14d8c576b67edaf726c6e does not match proposal fileBeforeHash sha256:e53f17d763738f68a21a2c63cd7d18d69d1ce44332bc4da05179a61abb734183.=1, canonical target base hash is stale: src/store.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, composer_merge=10, hot_provisional=3 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | composer_merge=2, cold_queue=1, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=148971, duration_ms=652.07
