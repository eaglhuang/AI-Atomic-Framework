# atm-bench export — r5m-e4-hot_conflict-fault_naive-p8-s11-old

- run_id: `r5m-e4-hot_conflict-fault_naive-p8-s11-old` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 158448 | — |
| duration_ms | 606.56 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 35 | — |
| lost updates (oracle fail) | 1 | — |
| integration pass rate of committed | 175% | — |
| effective success rate of all intents | 97.2% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 19 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 10 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 606.05 | — |
| throughput intents/s | 59.4 | — |
| goodput oracle-pass/s | 57.75 | — |
| latency_ms mean / p50 / p95 | 12.53 / 9.23 / 31.81 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 75.82 / 23.69 / 274.96 | — |
| total_ms mean / p50 / p95 | 107.24 / 54.72 / 320.78 | — |
| overhead_ms mean / p50 / p95 | 88.81 / 33.97 / 295.76 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 9 | 0 | 0 |
| cold_queue | 19 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=5, file-hash-drift: Target file hash sha256:eca7a5210cab42e7fe75b89a5f1cf28bf74f20c3fec152e43739b4f9b99371bc does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=3, file-hash-drift: Target file hash sha256:d84eb0c97ad61d8de1f28084596eb467b6fdb9fb91c908ff3b7236ee92e1768b does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:0205191f1007d47bd000acb202e5d5269b7759e42e2c45642edd6f31b4508a22 does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=2, file-hash-drift: Target file hash sha256:5b48a7c826b012ebe1cd76327375bd68d8cd340d5ddfdb9e50dd69ef42be5b5c does not match proposal fileBeforeHash sha256:b7b22d4b881f8f1bace886777be07ad1b89fcd26ad414741811c7811493bd089.=2, file-hash-drift: Target file hash sha256:f4e894274c22a6ed478c394f4c4af8d3e89ba9fc815cbf5f5a3216d0686d8d4a does not match proposal fileBeforeHash sha256:a3990c2b78e88aaa9f9b54158abe08d94e4b93816828bf61b84815900ba7ce74.=1, file-hash-drift: Target file hash sha256:9031e117720775306a199bde5e5bbc6f661f9c5c76c89a6a7e885a58fb5c4d54 does not match proposal fileBeforeHash sha256:8ca9633ffdeadb61c4de690f25c5ab3128dfaa57a0e1280259930f65820c7180.=1, file-hash-drift: Target file hash sha256:8ca9633ffdeadb61c4de690f25c5ab3128dfaa57a0e1280259930f65820c7180 does not match proposal fileBeforeHash sha256:23412beeb20140f78c38c94cdbb7c59505fe41e22fd62f3c6be409c263a0ce79.=1, atm_provisional_write_lease+cas_rebase=1, file-hash-drift: Target file hash sha256:747aae25652fac8d872ca136b4daa83f63cf10d64733bd0a78de0ce8346e0e02 does not match proposal fileBeforeHash sha256:5b48a7c826b012ebe1cd76327375bd68d8cd340d5ddfdb9e50dd69ef42be5b5c.=1, file-hash-drift: Target file hash sha256:c113d19a938ec64551e3f35829ad9bcd21732d307494be805d472003b47eff43 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:23412beeb20140f78c38c94cdbb7c59505fe41e22fd62f3c6be409c263a0ce79 does not match proposal fileBeforeHash sha256:267a5b7059d3c74183538f7d633c972fee8faf35c66f279a365f5cf9d2fbc9ba.=1, file-hash-drift: Target file hash sha256:d84eb0c97ad61d8de1f28084596eb467b6fdb9fb91c908ff3b7236ee92e1768b does not match proposal fileBeforeHash sha256:c113d19a938ec64551e3f35829ad9bcd21732d307494be805d472003b47eff43.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=18, composer_merge=6, hot_provisional=4 |
| no_conflict | hot_provisional=3, composer_merge=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=158448, duration_ms=606.56
