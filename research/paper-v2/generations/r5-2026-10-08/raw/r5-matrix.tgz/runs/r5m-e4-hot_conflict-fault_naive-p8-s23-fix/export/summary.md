# atm-bench export — r5m-e4-hot_conflict-fault_naive-p8-s23-fix

- run_id: `r5m-e4-hot_conflict-fault_naive-p8-s23-fix` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 160137 | — |
| duration_ms | 595.93 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=20, commit=16 | — |
| committed | 16 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 225% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 4 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 592.87 | — |
| throughput intents/s | 60.72 | — |
| goodput oracle-pass/s | 60.72 | — |
| latency_ms mean / p50 / p95 | 11.65 / 7.93 / 27.05 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 82.13 / 21.64 / 252.11 | — |
| total_ms mean / p50 / p95 | 110.64 / 50.71 / 294.52 | — |
| overhead_ms mean / p50 / p95 | 94.21 / 35.24 / 280.21 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=5, file-hash-drift: Target file hash sha256:fb0d96fe57cf3dbd000e9552f0cf7611021443e8c008bcaef3a054e4c476fa8a does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=3, file-hash-drift: Target file hash sha256:be08dfec74d2159e17a6caeaf23bde98dbafa793fdc9e763a2d00a2dce784668 does not match proposal fileBeforeHash sha256:fb0d96fe57cf3dbd000e9552f0cf7611021443e8c008bcaef3a054e4c476fa8a.=2, file-hash-drift: Target file hash sha256:8a4bb9e136c41e47bf2afa54b6acea8743196f99d5702859595c02ebe959c3ee does not match proposal fileBeforeHash sha256:1bae20b6dc9a658098e666ba1b711cabf91c4520746f9386b6732c766e20ddbf.=2, file-hash-drift: Target file hash sha256:c40de74b5333e80fde0e7fb8dca8ddf00aba07f6328a41cf728ec8703aada46f does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, atm_provisional_write_lease+cas_rebase=1, file-hash-drift: Target file hash sha256:c40de74b5333e80fde0e7fb8dca8ddf00aba07f6328a41cf728ec8703aada46f does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, compose-context-mismatch: proposal 'prop-s23-t002-i4' context mismatch at base line 21: expected "// </region:cache>", found "// atm-edit s23-t002-i3 by cursor:mock-s3" [proposals: prop-s23-t002-i4]=1, file-hash-drift: Target file hash sha256:be08dfec74d2159e17a6caeaf23bde98dbafa793fdc9e763a2d00a2dce784668 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:31b782c9e36309441be84aea73e930b9f112e2e22dd5e9bce4845ce8ebc0abe8 does not match proposal fileBeforeHash sha256:d898cd1312bae2da2946e08d4ab1acbcd96afefe48a7a063a70972c3f3592968.=1, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:8a4bb9e136c41e47bf2afa54b6acea8743196f99d5702859595c02ebe959c3ee does not match proposal fileBeforeHash sha256:c8cf38505da9c341a617a5d96b9956e37f6c5d34692ac0d6c78385f09c07fbee.=1, file-hash-drift: Target file hash sha256:d4baa65572eaac0dc399722316144fb7cde76423d62dd07cb47add4c1d17f3a3 does not match proposal fileBeforeHash sha256:c40de74b5333e80fde0e7fb8dca8ddf00aba07f6328a41cf728ec8703aada46f.=1, atm_compose=1, file-hash-drift: Target file hash sha256:d4baa65572eaac0dc399722316144fb7cde76423d62dd07cb47add4c1d17f3a3 does not match proposal fileBeforeHash sha256:d898cd1312bae2da2946e08d4ab1acbcd96afefe48a7a063a70972c3f3592968.=1, file-hash-drift: Target file hash sha256:053bb2e9b0f1808d33530a0532bf774f318119b6c68ebacd4c25ae7b854a3109 does not match proposal fileBeforeHash sha256:be08dfec74d2159e17a6caeaf23bde98dbafa793fdc9e763a2d00a2dce784668.=1, file-hash-drift: Target file hash sha256:1bae20b6dc9a658098e666ba1b711cabf91c4520746f9386b6732c766e20ddbf does not match proposal fileBeforeHash sha256:bb4f7a30c6eff34677f7b8abcaa03e545ce0af341fb401f863442d0ce52d9aa9.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=3, composer_merge=3, cold_queue=1 |
| hot_provisional | cold_queue=14, hot_provisional=6, composer_merge=5 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=160137, duration_ms=595.93
