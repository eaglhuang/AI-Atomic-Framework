# atm-bench export — r5m-e4-hot_conflict-fault_nolock-p8-s11-old

- run_id: `r5m-e4-hot_conflict-fault_nolock-p8-s11-old` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 159907 | — |
| duration_ms | 693.32 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=19, commit=17 | — |
| committed | 17 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 211.8% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 1 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 693.2 | — |
| throughput intents/s | 51.93 | — |
| goodput oracle-pass/s | 51.93 | — |
| latency_ms mean / p50 / p95 | 13.48 / 7.36 / 41.94 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 88.37 / 109.75 / 274.98 | — |
| total_ms mean / p50 / p95 | 120.51 / 125.81 / 328.34 | — |
| overhead_ms mean / p50 / p95 | 102.28 / 112.43 / 303.53 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:7cd5162da35684effeefe01cddaf0467a84e0c81acef59f83c4e291764fad50a does not match proposal fileBeforeHash sha256:315d2a390cd98e58aafab98d52a8fd6cdbd2697611bf0b4f7de4d63e12963313.=3, file-hash-drift: Target file hash sha256:5e365f94dc9008c12e3fb0ffc577a75bde1ea89d4ac8ce99f2f8064a4a065c97 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:0f21a67d3af16a650b6a5a4ffbd753e6283a112474e25447c2fb7a5b9ca45613 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:bb67b137049589d6641f57d809b4880f3b82178c5dca9198032cc7e608551902 does not match proposal fileBeforeHash sha256:21793508a73f0b68cfc67780ec7ca23385fc0a63888fac036f9cbecb4467cced.=2, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, canonical target base hash is stale: src/store.ts=2, file-hash-drift: Target file hash sha256:d4b3841f9a4982b368f34b3ce144c250c6cadb18bf1b72359dfc19e37ac3735d does not match proposal fileBeforeHash sha256:5e365f94dc9008c12e3fb0ffc577a75bde1ea89d4ac8ce99f2f8064a4a065c97.=1, file-hash-drift: Target file hash sha256:095150c0536b0302fa0daa0554d3b577b82c8e4152e65a0ebd37f8b441037565 does not match proposal fileBeforeHash sha256:1438b095ccc3d9828dc94c2d7dcd68854cdb57153f2c6d16703849cde8894692.=1, file-hash-drift: Target file hash sha256:a8282b9b197d34c88f14e6d76713346e6a702bea209c3456862ecd904328b39f does not match proposal fileBeforeHash sha256:dc46cdf932a44df2086e764e526e6a6bd95905829493c72be7faa89d0ee49845.=1, file-hash-drift: Target file hash sha256:095150c0536b0302fa0daa0554d3b577b82c8e4152e65a0ebd37f8b441037565 does not match proposal fileBeforeHash sha256:2e9d5359d6eb3373a746a6e9f523dcf163db01ba1f43278585fd98c6e073d4a2.=1, file-hash-drift: Target file hash sha256:315d2a390cd98e58aafab98d52a8fd6cdbd2697611bf0b4f7de4d63e12963313 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:d4b3841f9a4982b368f34b3ce144c250c6cadb18bf1b72359dfc19e37ac3735d does not match proposal fileBeforeHash sha256:0f21a67d3af16a650b6a5a4ffbd753e6283a112474e25447c2fb7a5b9ca45613.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=15, composer_merge=8, hot_provisional=5 |
| no_conflict | composer_merge=3, hot_provisional=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=159907, duration_ms=693.32
