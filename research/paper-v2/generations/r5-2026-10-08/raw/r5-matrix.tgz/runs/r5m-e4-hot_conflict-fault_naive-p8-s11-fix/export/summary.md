# atm-bench export — r5m-e4-hot_conflict-fault_naive-p8-s11-fix

- run_id: `r5m-e4-hot_conflict-fault_naive-p8-s11-fix` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 158500 | — |
| duration_ms | 594.08 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 22 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 593.96 | — |
| throughput intents/s | 60.61 | — |
| goodput oracle-pass/s | 60.61 | — |
| latency_ms mean / p50 / p95 | 14.43 / 13.94 / 32.6 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 79.63 / 23.17 / 307.75 | — |
| total_ms mean / p50 / p95 | 112.82 / 55.54 / 344.39 | — |
| overhead_ms mean / p50 / p95 | 94.57 / 41.84 / 328.51 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| hot_provisional | 5 | 0 | 0 |
| cold_queue | 22 | 0 | 0 |
| composer_merge | 9 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=16, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=4, atm_provisional_write_lease=3, file-hash-drift: Target file hash sha256:9de6229ae6beb907b0af5bb84b987050a404615ff0af580c1e5d7de563da1e33 does not match proposal fileBeforeHash sha256:2a345654a7bbcd4ca29723ad8d30e93a2f3d737bc43d24a33ec1905c0e94d4b8.=2, file-hash-drift: Target file hash sha256:3af016da508d32f03dff34ab993bfc25b85184c13fb6ba47fe88ef53f5c03041 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:3af016da508d32f03dff34ab993bfc25b85184c13fb6ba47fe88ef53f5c03041 does not match proposal fileBeforeHash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79.=1, file-hash-drift: Target file hash sha256:e64f16062798806a54396780e045c8f63489db6c2a363225eb73763a60f711d1 does not match proposal fileBeforeHash sha256:0acf78809fe0bb7e6f5e823673982efe85577a57b447657455264a6baf461ca1.=1, atm_compose=1, file-hash-drift: Target file hash sha256:5cccb5186df4875ed08004e4fce6c2f7e8e71519265f4b31410a8cb82ff64f91 does not match proposal fileBeforeHash sha256:245fdaf5ee692093ebdae79a67c20f8379866c47f0ad5f135ec19284640d7647.=1, file-hash-drift: Target file hash sha256:a82c137c0f2f285fa5665007d2d47364eec1902ad227d131f9b914c991b208dc does not match proposal fileBeforeHash sha256:9de6229ae6beb907b0af5bb84b987050a404615ff0af580c1e5d7de563da1e33.=1, file-hash-drift: Target file hash sha256:0f21a67d3af16a650b6a5a4ffbd753e6283a112474e25447c2fb7a5b9ca45613 does not match proposal fileBeforeHash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79.=1, file-hash-drift: Target file hash sha256:ddc59502be5c789a86f52f1135b0b175853fd062858439244b3432dcf6c002d9 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=1, file-hash-drift: Target file hash sha256:df6df3684dcf75df8656de2815230ed0bedadd1024ed8241267d833baa69d002 does not match proposal fileBeforeHash sha256:ddc59502be5c789a86f52f1135b0b175853fd062858439244b3432dcf6c002d9.=1, file-hash-drift: Target file hash sha256:2a345654a7bbcd4ca29723ad8d30e93a2f3d737bc43d24a33ec1905c0e94d4b8 does not match proposal fileBeforeHash sha256:21793508a73f0b68cfc67780ec7ca23385fc0a63888fac036f9cbecb4467cced.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | hot_provisional=1, composer_merge=1, cold_queue=1 |
| hot_provisional | cold_queue=20, composer_merge=5, hot_provisional=3 |
| no_conflict | composer_merge=3, hot_provisional=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=158500, duration_ms=594.08
