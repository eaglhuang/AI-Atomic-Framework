# atm-bench export — r5m-e4-hot_conflict-fault_naive-p8-s11-q

- run_id: `r5m-e4-hot_conflict-fault_naive-p8-s11-q` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-37847584/AI-Atomic-Framework-37847584e24afc08ea58cfe380bb5b1220fbe335/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 155371 | — |
| duration_ms | 874.57 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 2 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 875.31 | — |
| throughput intents/s | 41.13 | — |
| goodput oracle-pass/s | 41.13 | — |
| latency_ms mean / p50 / p95 | 15.68 / 15.32 / 31.33 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 101.71 / 113.79 / 311.35 | — |
| total_ms mean / p50 / p95 | 136.34 / 132.04 / 364.54 | — |
| overhead_ms mean / p50 / p95 | 117.84 / 121.01 / 347.08 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| hot_provisional | 5 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |
| composer_merge | 14 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_compose=6, atm_provisional_write_lease=5, steward-final-patch-required: proposal 'prop-s11-t002-i4' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i4]=1, steward-final-patch-required: proposal 'prop-s11-t000-i2' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i2]=1, steward-final-patch-required: proposal 'prop-s11-t001-i2' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t001-i2]=1, steward-final-patch-required: proposal 'prop-s11-t000-i5' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i5]=1, steward-final-patch-required: proposal 'prop-s11-t002-i5' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i5]=1, steward-final-patch-required: proposal 'prop-s11-t003-i4' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i4]=1, steward-final-patch-required: proposal 'prop-s11-t004-i5' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t004-i5]=1, steward-final-patch-required: proposal 'prop-s11-t000-i0' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i0]=1, steward-final-patch-required: proposal 'prop-s11-t001-i3' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t001-i3]=1, steward-final-patch-required: proposal 'prop-s11-t002-i3' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i3]=1, steward-final-patch-required: proposal 'prop-s11-t004-i3' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t004-i3]=1, steward-final-patch-required: proposal 'prop-s11-t000-i6' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i6]=1, steward-final-patch-required: proposal 'prop-s11-t002-i7' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i7]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=15, composer_merge=10, hot_provisional=3 |
| no_conflict | composer_merge=2, cold_queue=2, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=155371, duration_ms=874.57
