# atm-bench export — r5m-e4-hot_conflict-steward-p2-s17-nq

- run_id: `r5m-e4-hot_conflict-steward-p2-s17-nq` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-37847584/AI-Atomic-Framework-37847584e24afc08ea58cfe380bb5b1220fbe335/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 145645 | — |
| duration_ms | 575.05 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=25, blocked=9 | — |
| committed | 25 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 136% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 17 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 574.07 | — |
| throughput intents/s | 59.23 | — |
| goodput oracle-pass/s | 59.23 | — |
| latency_ms mean / p50 / p95 | 6.62 / 4.5 / 17.92 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 37.21 / 18.21 / 127.94 | — |
| total_ms mean / p50 / p95 | 91.59 / 53.77 / 200.83 | — |
| overhead_ms mean / p50 / p95 | 44.77 / 24.29 / 152.93 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 16 | 0 | 0 |
| composer_merge | 9 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=8, steward-final-patch-required: proposal 'prop-s17-t001-i1' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t001-i1]=3, atm_compose=3, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, steward-final-patch-required: proposal 'prop-s17-t000-i0' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t000-i0]=1, steward-final-patch-required: proposal 'prop-s17-t004-i0' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t004-i0]=1, atm_compose+cas_rebase=1, steward-final-patch-required: proposal 'prop-s17-t003-i3' overlaps region 'users', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t003-i3]=1, steward-final-patch-required: proposal 'prop-s17-t002-i5' overlaps region 'cache', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t002-i5]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=16, composer_merge=5, hot_provisional=5 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=145645, duration_ms=575.05
