# atm-bench export — r5m-e4-hot_conflict-steward-p2-s17-fix

- run_id: `r5m-e4-hot_conflict-steward-p2-s17-fix` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 149036 | — |
| duration_ms | 514.99 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 161.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 514.49 | — |
| throughput intents/s | 66.08 | — |
| goodput oracle-pass/s | 66.08 | — |
| latency_ms mean / p50 / p95 | 5.27 / 3.41 / 17.48 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 39.68 / 13.97 / 128.94 | — |
| total_ms mean / p50 / p95 | 90.17 / 53.4 / 265.51 | — |
| overhead_ms mean / p50 / p95 | 45.59 / 18.89 / 144.89 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:81c86fd1643af193f89ad5499afecb606f696096ef8876192528d68ac90322b3 does not match proposal fileBeforeHash sha256:1466db735a2c933611c7f055a9f2860be1a84c3864bda9b5eabc450a2ed2cf3c.=3, file-hash-drift: Target file hash sha256:3d662a3b8f47bf5e9651964cf78121be7271b06d63f68e328dee39ef1f2cbe90 does not match proposal fileBeforeHash sha256:83c22af2d74b26f156ce37ce66c271819ba4c97f51c7e94bd12a7c476ae4003e.=2, file-hash-drift: Target file hash sha256:cf42b038ef9d878ef3beb542c07aac88120ee8131e7ae7001d816f6ea5838a81 does not match proposal fileBeforeHash sha256:f768a22b48ca347c2db5c728ed35e368abeba71b5af76c09f77467b799bab623.=2, atm_compose=2, file-hash-drift: Target file hash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=2, steward-final-patch-required: proposals 'prop-s17-t004-i0' and 'prop-s17-t004-i5' change overlapping base line 10 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t004-i0, prop-s17-t004-i5]=2, file-hash-drift: Target file hash sha256:1466db735a2c933611c7f055a9f2860be1a84c3864bda9b5eabc450a2ed2cf3c does not match proposal fileBeforeHash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd.=1, compose-context-mismatch: proposal 'prop-s17-t000-i6' context mismatch at base line 8: expected "// </region:reducers>", found "// atm-edit s17-t000-i0 by cursor:mock-s0" [proposals: prop-s17-t000-i6]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=14, composer_merge=7, hot_provisional=5 |
| no_conflict | hot_provisional=2, composer_merge=1, cold_queue=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=149036, duration_ms=514.99
