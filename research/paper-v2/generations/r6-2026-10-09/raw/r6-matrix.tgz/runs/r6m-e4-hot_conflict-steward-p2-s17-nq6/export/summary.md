# atm-bench export — r6m-e4-hot_conflict-steward-p2-s17-nq6

- run_id: `r6m-e4-hot_conflict-steward-p2-s17-nq6` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-b35a6141/AI-Atomic-Framework-b35a6141bd5bfbaec654f1cd3079323581b04074/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 146822 | — |
| duration_ms | 513.78 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=11 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 147.8% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 16 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 512.19 | — |
| throughput intents/s | 66.38 | — |
| goodput oracle-pass/s | 66.38 | — |
| latency_ms mean / p50 / p95 | 6.58 / 4.94 / 15.11 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 36.57 / 18.63 / 116.1 | — |
| total_ms mean / p50 / p95 | 85.03 / 52.44 / 167.69 | — |
| overhead_ms mean / p50 / p95 | 43.88 / 23.48 / 130.53 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 16 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| composer_merge | 11 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=5, atm_compose+cas_rebase=3, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, steward-final-patch-required: proposal 'prop-s17-t002-i2' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t002-i2]=2, steward-final-patch-required: proposal 'prop-s17-t002-i4' overlaps region 'cache', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t002-i4]=2, steward-final-patch-required: proposal 'prop-s17-t003-i5' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t003-i5]=2, steward-final-patch-required: proposal 'prop-s17-t004-i2' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t004-i2]=1, atm_compose=1, steward-final-patch-required: proposal 'prop-s17-t001-i2' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t001-i2]=1, steward-final-patch-required: proposal 'prop-s17-t000-i6' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t000-i6]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=14, composer_merge=7, hot_provisional=5 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | cold_queue=2, composer_merge=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=146822, duration_ms=513.78
