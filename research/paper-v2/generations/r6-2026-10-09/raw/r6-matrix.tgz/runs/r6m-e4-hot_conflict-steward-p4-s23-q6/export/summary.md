# atm-bench export — r6m-e4-hot_conflict-steward-p4-s23-q6

- run_id: `r6m-e4-hot_conflict-steward-p4-s23-q6` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-b35a6141/AI-Atomic-Framework-b35a6141bd5bfbaec654f1cd3079323581b04074/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 159694 | — |
| duration_ms | 598.66 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 9 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 595.53 | — |
| throughput intents/s | 60.45 | — |
| goodput oracle-pass/s | 60.45 | — |
| latency_ms mean / p50 / p95 | 11.4 / 7.22 / 30.33 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 53.84 / 20.71 / 143.78 | — |
| total_ms mean / p50 / p95 | 98.84 / 61.92 / 251.49 | — |
| overhead_ms mean / p50 / p95 | 66.67 / 36.85 / 163.29 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=6, steward-final-patch-required: proposal 'prop-s23-t001-i5' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t001-i5]=2, steward-final-patch-required: proposals 'prop-s23-t003-i0' and 'prop-s23-t003-i4' change overlapping base line 10 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t003-i0, prop-s23-t003-i4]=2, steward-final-patch-required: proposals 'prop-s23-t001-i2' and 'prop-s23-t001-i6' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i2, prop-s23-t001-i6]=2, steward-final-patch-required: proposals 'prop-s23-t002-i2' and 'prop-s23-t003-i6' both edit region 'db' of src/config.ts; overlapping region edits stay blocked [proposals: prop-s23-t002-i2, prop-s23-t003-i6]=2, steward-final-patch-required: proposals 'prop-s23-t004-i2' and 'prop-s23-t004-i6' change overlapping base line 16 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s23-t004-i2, prop-s23-t004-i6]=2, atm_compose=2, steward-final-patch-required: proposals 'prop-s23-t000-i5' and 'prop-s23-t002-i3' both edit region 'cache' of src/config.ts; overlapping region edits stay blocked [proposals: prop-s23-t000-i5, prop-s23-t002-i3]=2, atm_compose+cas_rebase=2, steward-final-patch-required: proposal 'prop-s23-t004-i1' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t004-i1]=1, steward-final-patch-required: proposal 'prop-s23-t002-i5' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t002-i5]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, hot_provisional=1 |
| no_conflict | hot_provisional=3, cold_queue=3, composer_merge=1 |
| hot_provisional | cold_queue=14, composer_merge=9, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=159694, duration_ms=598.66
