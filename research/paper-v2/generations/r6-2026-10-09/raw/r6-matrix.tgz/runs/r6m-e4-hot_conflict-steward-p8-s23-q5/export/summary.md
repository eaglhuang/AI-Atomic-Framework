# atm-bench export — r6m-e4-hot_conflict-steward-p8-s23-q5

- run_id: `r6m-e4-hot_conflict-steward-p8-s23-q5` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-37847584/AI-Atomic-Framework-37847584e24afc08ea58cfe380bb5b1220fbe335/packages/core)`
- label: REAL ATM steward MP procs=8 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 152725 | — |
| duration_ms | 665.45 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=26, blocked=10 | — |
| committed | 26 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 138.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 11 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 662.67 | — |
| throughput intents/s | 54.33 | — |
| goodput oracle-pass/s | 54.33 | — |
| latency_ms mean / p50 / p95 | 13.09 / 8.45 / 33.52 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 79.5 / 21.44 / 232.54 | — |
| total_ms mean / p50 / p95 | 109.53 / 58.49 / 273.13 | — |
| overhead_ms mean / p50 / p95 | 92.97 / 43.33 / 254.93 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=15, atm_provisional_write_lease=7, atm_compose=3, steward-final-patch-required: proposal 'prop-s23-t000-i0' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t000-i0]=1, steward-final-patch-required: proposal 'prop-s23-t002-i2' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t002-i2]=1, steward-final-patch-required: proposal 'prop-s23-t002-i5' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t002-i5]=1, steward-final-patch-required: proposal 'prop-s23-t003-i5' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t003-i5]=1, atm_compose+cas_rebase=1, steward-final-patch-required: proposal 'prop-s23-t001-i0' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t001-i0]=1, steward-final-patch-required: proposal 'prop-s23-t001-i3' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t001-i3]=1, steward-final-patch-required: proposal 'prop-s23-t001-i6' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t001-i6]=1, steward-final-patch-required: proposal 'prop-s23-t004-i6' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t004-i6]=1, steward-final-patch-required: proposal 'prop-s23-t000-i5' overlaps region 'cache', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t000-i5]=1, steward-final-patch-required: proposal 'prop-s23-t002-i6' overlaps region 'cache', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t002-i6]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, hot_provisional=1 |
| no_conflict | hot_provisional=3, cold_queue=3, composer_merge=1 |
| hot_provisional | cold_queue=14, composer_merge=8, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=152725, duration_ms=665.45
