# atm-bench export — r6m-e4-hot_conflict-steward-p2-s23-q5

- run_id: `r6m-e4-hot_conflict-steward-p2-s23-q5` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-37847584/AI-Atomic-Framework-37847584e24afc08ea58cfe380bb5b1220fbe335/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 164204 | — |
| duration_ms | 621.79 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 15 | — |
| CAS rebase on apply | 9 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 619.64 | — |
| throughput intents/s | 58.1 | — |
| goodput oracle-pass/s | 58.1 | — |
| latency_ms mean / p50 / p95 | 6.95 / 5.47 / 15.94 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 41.84 / 20.9 / 128.03 | — |
| total_ms mean / p50 / p95 | 93.26 / 58.46 / 188.29 | — |
| overhead_ms mean / p50 / p95 | 49.96 / 29.71 / 137.37 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 15 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 13 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=8, atm_serial_queue=6, steward-final-patch-required: proposals 'prop-s23-t001-i3' and 'prop-s23-t001-i5' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i3, prop-s23-t001-i5]=3, steward-final-patch-required: proposals 'prop-s23-t002-i0' and 'prop-s23-t003-i6' change overlapping base line 13 of src/config.ts; a steward-authored final patch is required [proposals: prop-s23-t002-i0, prop-s23-t003-i6]=3, steward-final-patch-required: proposals 'prop-s23-t003-i0' and 'prop-s23-t003-i4' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t003-i0, prop-s23-t003-i4]=3, atm_compose=3, steward-final-patch-required: proposals 'prop-s23-t001-i4' and 'prop-s23-t001-i6' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i4, prop-s23-t001-i6]=2, steward-final-patch-required: proposals 'prop-s23-t004-i2' and 'prop-s23-t004-i6' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s23-t004-i2, prop-s23-t004-i6]=2, atm_compose+cas_rebase=2, steward-final-patch-required: proposals 'prop-s23-t000-i4' and 'prop-s23-t001-i0' change overlapping base line 12 of src/config.ts; a steward-authored final patch is required [proposals: prop-s23-t000-i4, prop-s23-t001-i0]=2, steward-final-patch-required: proposals 'prop-s23-t002-i3' and 'prop-s23-t002-i6' change overlapping base line 22 of src/config.ts; a steward-authored final patch is required [proposals: prop-s23-t002-i3, prop-s23-t002-i6]=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=5, cold_queue=2 |
| hot_provisional | cold_queue=11, composer_merge=11, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=164204, duration_ms=621.79
