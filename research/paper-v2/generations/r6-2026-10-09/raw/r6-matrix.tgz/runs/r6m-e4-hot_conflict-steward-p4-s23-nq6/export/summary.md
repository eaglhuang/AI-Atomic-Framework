# atm-bench export — r6m-e4-hot_conflict-steward-p4-s23-nq6

- run_id: `r6m-e4-hot_conflict-steward-p4-s23-nq6` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-b35a6141/AI-Atomic-Framework-b35a6141bd5bfbaec654f1cd3079323581b04074/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154059 | — |
| duration_ms | 732.18 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=27, blocked=9 | — |
| committed | 27 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 133.3% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 14 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 728.84 | — |
| throughput intents/s | 49.39 | — |
| goodput oracle-pass/s | 49.39 | — |
| latency_ms mean / p50 / p95 | 10.71 / 8.47 / 30.53 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 57.08 / 18.83 / 190.83 | — |
| total_ms mean / p50 / p95 | 95.29 / 67.89 / 229.8 | — |
| overhead_ms mean / p50 / p95 | 68.44 / 35.5 / 198.91 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| hot_provisional | 10 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=10, atm_compose=4, steward-final-patch-required: proposal 'prop-s23-t002-i0' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t002-i0]=2, steward-final-patch-required: proposals 'prop-s23-t001-i6' and 'prop-s23-t003-i2' both edit region 'actions' of src/store.ts; overlapping region edits stay blocked [proposals: prop-s23-t001-i6, prop-s23-t003-i2]=2, steward-final-patch-required: proposals 'prop-s23-t004-i2' and 'prop-s23-t004-i6' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s23-t004-i2, prop-s23-t004-i6]=2, atm_compose+cas_rebase=2, steward-final-patch-required: proposal 'prop-s23-t000-i3' overlaps region 'cache', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t000-i3]=1, steward-final-patch-required: proposal 'prop-s23-t001-i5' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t001-i5]=1, steward-final-patch-required: proposal 'prop-s23-t002-i5' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t002-i5]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, hot_provisional=1 |
| no_conflict | hot_provisional=5, cold_queue=2 |
| hot_provisional | cold_queue=13, composer_merge=8, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154059, duration_ms=732.18
