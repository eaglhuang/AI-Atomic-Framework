# atm-bench export — r6v-e4-p2-s17-q6-r14

- run_id: `r6v-e4-p2-s17-q6-r14` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-b35a6141/AI-Atomic-Framework-b35a6141bd5bfbaec654f1cd3079323581b04074/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 146746 | — |
| duration_ms | 751.11 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 16 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 750.33 | — |
| throughput intents/s | 45.31 | — |
| goodput oracle-pass/s | 45.31 | — |
| latency_ms mean / p50 / p95 | 6.58 / 4.83 / 17.52 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 50.87 / 22.46 / 149.04 | — |
| total_ms mean / p50 / p95 | 109.13 / 65.39 / 223.97 | — |
| overhead_ms mean / p50 / p95 | 58.33 / 29.66 / 167.84 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 15 | 0 | 0 |
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=10, atm_provisional_write_lease=6, atm_compose+cas_rebase=4, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' both edit region 'cache' of src/config.ts; overlapping region edits stay blocked [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, steward-final-patch-required: proposal 'prop-s17-t002-i2' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t002-i2]=2, steward-final-patch-required: proposal 'prop-s17-t004-i2' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t004-i2]=2, steward-final-patch-required: proposal 'prop-s17-t003-i3' overlaps region 'users', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t003-i3]=2, steward-final-patch-required: proposal 'prop-s17-t004-i1' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t004-i1]=1, steward-final-patch-required: proposal 'prop-s17-t001-i2' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t001-i2]=1, steward-final-patch-required: proposal 'prop-s17-t003-i5' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t003-i5]=1, steward-final-patch-required: proposal 'prop-s17-t000-i6' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t000-i6]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, composer_merge=8, hot_provisional=5 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | cold_queue=2, composer_merge=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=146746, duration_ms=751.11
