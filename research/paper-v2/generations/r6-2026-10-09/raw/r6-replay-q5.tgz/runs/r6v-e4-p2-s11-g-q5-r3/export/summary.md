# atm-bench export — r6v-e4-p2-s11-g-q5-r3

- run_id: `r6v-e4-p2-s11-g-q5-r3` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-37847584/AI-Atomic-Framework-37847584e24afc08ea58cfe380bb5b1220fbe335/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 153510 | — |
| duration_ms | 787.49 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=26, blocked=10 | — |
| committed | 26 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 138.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 19 | — |
| composer co-writes | 8 | — |
| CAS rebase on apply | 17 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 787.28 | — |
| throughput intents/s | 45.73 | — |
| goodput oracle-pass/s | 45.73 | — |
| latency_ms mean / p50 / p95 | 10.41 / 5.42 / 22.04 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 40.96 / 18.75 / 136.62 | — |
| total_ms mean / p50 / p95 | 111.39 / 102.04 / 211.29 | — |
| overhead_ms mean / p50 / p95 | 52.11 / 26.95 / 162.67 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 8 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| cold_queue | 19 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=15, atm_provisional_write_lease=9, steward-final-patch-required: proposals 'prop-s11-t001-i3' and 'prop-s11-t001-i5' both edit region 'orders' of src/routes.ts; overlapping region edits stay blocked [proposals: prop-s11-t001-i3, prop-s11-t001-i5]=3, atm_compose+cas_rebase=2, steward-final-patch-required: proposal 'prop-s11-t000-i2' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i2]=2, steward-final-patch-required: proposals 'prop-s11-t002-i2' and 'prop-s11-t003-i5' change overlapping base line 15 of src/store.ts; a steward-authored final patch is required [proposals: prop-s11-t002-i2, prop-s11-t003-i5]=2, steward-final-patch-required: proposals 'prop-s11-t004-i0' and 'prop-s11-t004-i2' change overlapping base line 22 of src/config.ts; a steward-authored final patch is required [proposals: prop-s11-t004-i0, prop-s11-t004-i2]=2, steward-final-patch-required: proposal 'prop-s11-t004-i4' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t004-i4]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=17, composer_merge=6, hot_provisional=5 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=153510, duration_ms=787.49
