# atm-bench export — r6v-e4-p2-s11-g-nq6-r6

- run_id: `r6v-e4-p2-s11-g-nq6-r6` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-b35a6141/AI-Atomic-Framework-b35a6141bd5bfbaec654f1cd3079323581b04074/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157776 | — |
| duration_ms | 482.87 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 171.4% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 22 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 22 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 483.09 | — |
| throughput intents/s | 74.52 | — |
| goodput oracle-pass/s | 74.52 | — |
| latency_ms mean / p50 / p95 | 5.47 / 3.97 / 12.67 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 26.72 / 14.68 / 111.69 | — |
| total_ms mean / p50 / p95 | 80 / 52.25 / 187.27 | — |
| overhead_ms mean / p50 / p95 | 33.09 / 20.73 / 125.54 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 9 | 0 | 0 |
| cold_queue | 22 | 0 | 0 |
| hot_provisional | 5 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=15, atm_provisional_write_lease=5, steward-final-patch-required: proposals 'prop-s11-t001-i3' and 'prop-s11-t001-i5' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t001-i3, prop-s11-t001-i5]=3, steward-final-patch-required: proposals 'prop-s11-t004-i1' and 'prop-s11-t004-i5' both edit region 'flags' of src/config.ts; overlapping region edits stay blocked [proposals: prop-s11-t004-i1, prop-s11-t004-i5]=3, steward-final-patch-required: proposal 'prop-s11-t003-i2' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i2]=3, steward-final-patch-required: proposals 'prop-s11-t002-i2' and 'prop-s11-t003-i5' both edit region 'selectors' of src/store.ts; overlapping region edits stay blocked [proposals: prop-s11-t002-i2, prop-s11-t003-i5]=2, steward-final-patch-required: proposals 'prop-s11-t000-i0' and 'prop-s11-t002-i6' change overlapping base line 24 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t000-i0, prop-s11-t002-i6]=2, steward-final-patch-required: proposal 'prop-s11-t002-i4' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i4]=1, steward-final-patch-required: proposal 'prop-s11-t000-i2' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i2]=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=20, composer_merge=7, hot_provisional=1 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157776, duration_ms=482.87
