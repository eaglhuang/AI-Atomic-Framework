/** App config (HOT) — writable via ATM WriteIntent bounded regions. */
export interface DbConfig { host: string; port: number; name: string }
export interface CacheConfig { ttlSec: number; backend: 'memory' | 'redis' }
export interface FeatureFlags { billingV2: boolean; experimentalSearch: boolean }

// <region:db>
export const dbConfig: DbConfig = {
  host: 'localhost',
  port: 5432,
  name: 'app',
};
// atm-edit s11-t004-i6 by other:mock-s6
// atm-edit s11-t004-i7 by other:mock-s7
// </region:db>

// <region:cache>
export const cacheConfig: CacheConfig = {
  ttlSec: 60,
  backend: 'memory',
};
// atm-edit s11-t000-i4 by claude:mock-s4
// atm-edit s11-t004-i2 by codex:mock-s2
// atm-edit s11-t004-i0 by cursor:mock-s0
// </region:cache>

// <region:flags>
export const featureFlags: FeatureFlags = {
  billingV2: false,
  experimentalSearch: false,
};
// atm-edit s11-t001-i2 by codex:mock-s2
// atm-edit s11-t004-i5 by codex:mock-s5
// atm-edit s11-t004-i4 by claude:mock-s4
// </region:flags>
