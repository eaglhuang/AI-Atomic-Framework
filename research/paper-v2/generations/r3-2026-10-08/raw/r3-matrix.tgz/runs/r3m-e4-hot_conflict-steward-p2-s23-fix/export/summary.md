# atm-bench export — r3m-e4-hot_conflict-steward-p2-s23-fix

- run_id: `r3m-e4-hot_conflict-steward-p2-s23-fix` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 161251 | — |
| duration_ms | 629.82 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 626.93 | — |
| throughput intents/s | 57.42 | — |
| goodput oracle-pass/s | 57.42 | — |
| latency_ms mean / p50 / p95 | 5.23 / 3.61 / 13.78 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 39.83 / 17.12 / 117.99 | — |
| total_ms mean / p50 / p95 | 87.54 / 56.58 / 176.85 | — |
| overhead_ms mean / p50 / p95 | 45.81 / 23.84 / 135.52 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 14 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| cold_queue | 13 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=9, atm_serial_queue=7, steward-final-patch-required: proposals 'prop-s23-t001-i3' and 'prop-s23-t001-i5' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i3, prop-s23-t001-i5]=3, steward-final-patch-required: proposals 'prop-s23-t004-i1' and 'prop-s23-t004-i7' change overlapping base line 25 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s23-t004-i1, prop-s23-t004-i7]=2, steward-final-patch-required: proposals 'prop-s23-t001-i4' and 'prop-s23-t001-i6' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i4, prop-s23-t001-i6]=2, steward-final-patch-required: proposals 'prop-s23-t003-i0' and 'prop-s23-t003-i4' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t003-i0, prop-s23-t003-i4]=2, file-hash-drift: Target file hash sha256:1d5a7fe2af4234741a601bd571757746c33031e26f4bb6d8632dd93d8fba2c5c does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, atm_compose+cas_rebase=2, atm_compose=2, steward-final-patch-required: proposals 'prop-s23-t002-i3' and 'prop-s23-t002-i6' change overlapping base line 22 of src/config.ts; a steward-authored final patch is required [proposals: prop-s23-t002-i3, prop-s23-t002-i6]=2, file-hash-drift: Target file hash sha256:810ef060282b061e44ed5e93d324ef8a83f5172cc0bc4f6eefb1510a06090fcd does not match proposal fileBeforeHash sha256:fffdf4bb573ca238ceeb56e30e099cf2401a03c68c5e9e50c19141b258616079.=1, file-hash-drift: Target file hash sha256:9415050ef4ec46d6521f68b87ee11a84f46e696888ba5ae166c3469c199b27a7 does not match proposal fileBeforeHash sha256:adfdfcc53436c1b40faf316bd8ea17d19bbf94cd6ec50c99611b5e6f7d9f1c9d.=1, file-hash-drift: Target file hash sha256:beb243a8d225b9124794f3f9c5588bc0979bab396a3ba5441e5ea5dbf59d7a98 does not match proposal fileBeforeHash sha256:908dc4a1dd47c9928582ec2989571d70f84b3ac491fdfd7b31c3bd887a3997c9.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=4, cold_queue=2, composer_merge=1 |
| hot_provisional | cold_queue=11, composer_merge=9, hot_provisional=5 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=161251, duration_ms=629.82
