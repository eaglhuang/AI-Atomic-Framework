# atm-bench export — r3m-e4-hot_conflict-steward-p4-s23-fixlock

- run_id: `r3m-e4-hot_conflict-steward-p4-s23-fixlock` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=4 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 159277 | — |
| duration_ms | 754.26 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 171.4% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 12 | — |
| composer co-writes | 15 | — |
| CAS rebase on apply | 11 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 751.47 | — |
| throughput intents/s | 47.91 | — |
| goodput oracle-pass/s | 47.91 | — |
| latency_ms mean / p50 / p95 | 8.1 / 5.27 / 20.04 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 66.08 / 32.05 / 160.31 | — |
| total_ms mean / p50 / p95 | 109.65 / 72.24 / 266.91 | — |
| overhead_ms mean / p50 / p95 | 74.8 / 47.89 / 181.04 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 15 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| cold_queue | 12 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=9, atm_serial_queue=9, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:a01e6a6977d7924fa79b883dbc8148f8b38cbfe4bf21d3ac1070ba4332af36b5 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=2, file-hash-drift: Target file hash sha256:9c95c6921ea352e2a07eb989137679d1c2caa5f3f22499307e0768ae8c145f37 does not match proposal fileBeforeHash sha256:a01e6a6977d7924fa79b883dbc8148f8b38cbfe4bf21d3ac1070ba4332af36b5.=2, steward-final-patch-required: proposals 'prop-s23-t002-i3' and 'prop-s23-t002-i6' change overlapping base line 22 of src/config.ts; a steward-authored final patch is required [proposals: prop-s23-t002-i3, prop-s23-t002-i6]=2, file-hash-drift: Target file hash sha256:bf9f0404127eaa08746d836475f95cbea826fa00cb28787ac27341ff2e87cf83 does not match proposal fileBeforeHash sha256:570afb7c26a366f6df9d82d6fdb96dcce539d25a91d7c1f046a39fe1b462c3a3.=2, atm_compose=1, file-hash-drift: Target file hash sha256:cec90d04def0e12c9ea49fdd2cf0c442197ee1b52e4b99545fe9134abb161f73 does not match proposal fileBeforeHash sha256:8753454e45e475c656c1b3d6f08a7bb1ca8d34af76358bb0c86b00eb1ca874f7.=1, file-hash-drift: Target file hash sha256:1d5a7fe2af4234741a601bd571757746c33031e26f4bb6d8632dd93d8fba2c5c does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:cec90d04def0e12c9ea49fdd2cf0c442197ee1b52e4b99545fe9134abb161f73 does not match proposal fileBeforeHash sha256:898abeda850665f438ce1ccdfef731922a15f9892d3ace31711d2146c9b73e34.=1, file-hash-drift: Target file hash sha256:f7447f6e1e0b2d8ab56eed35f160198954e6ca504ea1b932a874d0458702eb0e does not match proposal fileBeforeHash sha256:1d5a7fe2af4234741a601bd571757746c33031e26f4bb6d8632dd93d8fba2c5c.=1, file-hash-drift: Target file hash sha256:9ec2cf30bdcf3e64803ff368ed011677d6f9d035cb259749921a5781ca8555ab does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:a01e6a6977d7924fa79b883dbc8148f8b38cbfe4bf21d3ac1070ba4332af36b5 does not match proposal fileBeforeHash sha256:ace53f474b6fd83f97e256c051494b1cfd2d5065d7632eebcbe540bb5a868314.=1, file-hash-drift: Target file hash sha256:f7447f6e1e0b2d8ab56eed35f160198954e6ca504ea1b932a874d0458702eb0e does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, hot_provisional=1 |
| no_conflict | hot_provisional=4, cold_queue=3 |
| hot_provisional | composer_merge=12, cold_queue=9, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=159277, duration_ms=754.26
