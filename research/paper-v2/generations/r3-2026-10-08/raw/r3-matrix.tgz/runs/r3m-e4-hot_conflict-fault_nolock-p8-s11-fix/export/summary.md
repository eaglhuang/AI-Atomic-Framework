# atm-bench export — r3m-e4-hot_conflict-fault_nolock-p8-s11-fix

- run_id: `r3m-e4-hot_conflict-fault_nolock-p8-s11-fix` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156129 | — |
| duration_ms | 588.67 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 588.42 | — |
| throughput intents/s | 61.18 | — |
| goodput oracle-pass/s | 61.18 | — |
| latency_ms mean / p50 / p95 | 15.25 / 7.79 / 58.04 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 70.74 / 18.92 / 230.57 | — |
| total_ms mean / p50 / p95 | 104.64 / 48.2 / 264.17 | — |
| overhead_ms mean / p50 / p95 | 86.39 / 30.62 / 247.93 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 9 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=9, file-hash-drift: Target file hash sha256:e691b8cd85d8bf178c0fc74f79b3d178ab248ceba1aa73159c8c80c66a19c638 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=3, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, canonical target base hash is stale: src/store.ts=2, file-hash-drift: Target file hash sha256:197551467c44c040d4b2d3fab3ec039900c79f6ca742dd667c8f8973a1bf3e06 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:da8d0339f84424f2fa7b482d93253c118e441b170a397e1f73869a2001a1c892 does not match proposal fileBeforeHash sha256:fa8d4542781c11539c372c7b537d3c5fb8ccdd76c0f67df157b7eb2d74c13796.=1, file-hash-drift: Target file hash sha256:caa1627f015e34350683e9a1516d072ceb50acf8931fd614b07a930ce71da99b does not match proposal fileBeforeHash sha256:d83425a5428acae3d9048d9bdbb6e36e5953d05757dc97e5ecdee830ae300906.=1, file-hash-drift: Target file hash sha256:12f201ac30ad00d3611e92271854fd6f0c9bb67b1da8b87d428d11d851b06592 does not match proposal fileBeforeHash sha256:04a7ffa0a6145fb0fdecb15d89ddc0e81eb385e663aca52a643953056320d5b3.=1, file-hash-drift: Target file hash sha256:caa1627f015e34350683e9a1516d072ceb50acf8931fd614b07a930ce71da99b does not match proposal fileBeforeHash sha256:60707e664b8297ca7137c78093822603fb0cafec4564c6be6c1f72f83e10a87a.=1, file-hash-drift: Target file hash sha256:12f201ac30ad00d3611e92271854fd6f0c9bb67b1da8b87d428d11d851b06592 does not match proposal fileBeforeHash sha256:64854e362ef5ac3f6929cc465fcc3f6659b6594a92b62b79182913cc7f4ef6a6.=1, file-hash-drift: Target file hash sha256:8a8b6a272ead21c144d3040583125d9ecaa4d74af293810c7797a952dfae8e0b does not match proposal fileBeforeHash sha256:e691b8cd85d8bf178c0fc74f79b3d178ab248ceba1aa73159c8c80c66a19c638.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, cold_queue=1 |
| hot_provisional | cold_queue=15, composer_merge=7, hot_provisional=6 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156129, duration_ms=588.67
