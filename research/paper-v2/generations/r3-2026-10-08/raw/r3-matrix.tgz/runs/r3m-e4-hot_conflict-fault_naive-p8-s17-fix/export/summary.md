# atm-bench export — r3m-e4-hot_conflict-fault_naive-p8-s17-fix

- run_id: `r3m-e4-hot_conflict-fault_naive-p8-s17-fix` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 147938 | — |
| duration_ms | 729.41 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 19 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 5 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 728.86 | — |
| throughput intents/s | 46.65 | — |
| goodput oracle-pass/s | 46.65 | — |
| latency_ms mean / p50 / p95 | 12.19 / 9.88 / 30.37 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 80 / 20.73 / 244.37 | — |
| total_ms mean / p50 / p95 | 107.47 / 51.18 / 272.13 | — |
| overhead_ms mean / p50 / p95 | 92.62 / 33.4 / 263.15 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 19 | 0 | 0 |
| composer_merge | 10 | 0 | 0 |
| hot_provisional | 5 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=4, file-hash-drift: Target file hash sha256:b507b03bc5850ddd851b93f1d048778442591030d78a001651938b18753f86a7 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:50138f0577a6e9d274a45973e05d2f6f8f61ff5e4429c7db77bbe7cdeb537461 does not match proposal fileBeforeHash sha256:d02aadf71d4cc3297590a4f540d1d5341affcdd39d58df279fc6e8f20c8c41c5.=2, file-hash-drift: Target file hash sha256:c2aef694961185eee8494ea2ff04017642428a8c65198f22f812cc340a3558dc does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, atm_compose=2, canonical target base hash is stale: src/config.ts=1, file-hash-drift: Target file hash sha256:67477a5540ae184d236764ed60f112bd60d0b506c50bbcb7f8dfca35cc639684 does not match proposal fileBeforeHash sha256:1cfd9c7476d40065f6bc9d89d336d3c1a59808793d82d010f465281b7ebc4d44.=1, file-hash-drift: Target file hash sha256:d7d200b39f56cb7578783759157c846a66e812d9104781284d362513e0e41cdc does not match proposal fileBeforeHash sha256:1d3464a6a880a5848c511eb8ba2e776a943ec7fdbf2aa1bbdabcd798ed12e591.=1, file-hash-drift: Target file hash sha256:545919a9f01cc23e452d69027620824e7b90938a4c8754d72834ae5cc8358538 does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:69ce6d0f3c4f4bd8296aa790d0690f8ddfb039e4aeadc9f025714ea8aa371bff does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:50138f0577a6e9d274a45973e05d2f6f8f61ff5e4429c7db77bbe7cdeb537461 does not match proposal fileBeforeHash sha256:e88762955c844b8a9c778f9847d1af66a18b8d13a6c8af8ca0c89832f15dd7e6.=1, file-hash-drift: Target file hash sha256:1d3464a6a880a5848c511eb8ba2e776a943ec7fdbf2aa1bbdabcd798ed12e591 does not match proposal fileBeforeHash sha256:c2aef694961185eee8494ea2ff04017642428a8c65198f22f812cc340a3558dc.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=15, composer_merge=7, hot_provisional=4 |
| no_conflict | cold_queue=2, hot_provisional=1, composer_merge=1 |
| composer_cowrite | cold_queue=2, composer_merge=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=147938, duration_ms=729.41
