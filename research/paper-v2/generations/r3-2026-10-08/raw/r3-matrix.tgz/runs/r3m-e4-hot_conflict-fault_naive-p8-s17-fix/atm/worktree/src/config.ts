/** App config (HOT) — writable via ATM WriteIntent bounded regions. */
export interface DbConfig { host: string; port: number; name: string }
export interface CacheConfig { ttlSec: number; backend: 'memory' | 'redis' }
export interface FeatureFlags { billingV2: boolean; experimentalSearch: boolean }

// <region:db>
export const dbConfig: DbConfig = {
  host: 'localhost',
  port: 5432,
  name: 'app',
};
// atm-edit s17-t001-i6 by other:mock-s7
// atm-edit s17-t002-i0 by cursor:mock-s0
// atm-edit s17-t002-i6 by other:mock-s7
// </region:db>

// <region:cache>
export const cacheConfig: CacheConfig = {
  ttlSec: 60,
  backend: 'memory',
};
// atm-edit s17-t002-i5 by other:mock-s6
// atm-edit s17-t002-i4 by codex:mock-s5
// </region:cache>

// <region:flags>
export const featureFlags: FeatureFlags = {
  billingV2: false,
  experimentalSearch: false,
};
// atm-edit s17-t001-i3 by claude:mock-s4
// atm-edit s17-t001-i5 by other:mock-s6
// </region:flags>
