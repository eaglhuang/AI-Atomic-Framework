# atm-bench export — r3m-e4-hot_conflict-steward-p4-s11-fixlock

- run_id: `r3m-e4-hot_conflict-steward-p4-s11-fixlock` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=4 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157004 | — |
| duration_ms | 732.79 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 20 | — |
| composer co-writes | 8 | — |
| CAS rebase on apply | 15 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 732.45 | — |
| throughput intents/s | 49.15 | — |
| goodput oracle-pass/s | 49.15 | — |
| latency_ms mean / p50 / p95 | 7.94 / 5.39 / 22.94 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 67.73 / 15.39 / 405.99 | — |
| total_ms mean / p50 / p95 | 116.16 / 50.33 / 454.46 | — |
| overhead_ms mean / p50 / p95 | 76.13 / 21.19 / 419.71 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 8 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 20 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:1806cc344d68fc74569992c666ad3be4705b988739b1799918f311e82e4e9a1b does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, atm_compose=2, file-hash-drift: Target file hash sha256:571d8224f9465615b8a859f2eefdc1e56e590703c7e24026debf4f5c32ccb041 does not match proposal fileBeforeHash sha256:d83425a5428acae3d9048d9bdbb6e36e5953d05757dc97e5ecdee830ae300906.=2, file-hash-drift: Target file hash sha256:bf3df02a0c5808f9539f44cd28e59539c3ccb1f37bf800cfa24f3758eda36b1e does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=2, file-hash-drift: Target file hash sha256:1fdf5aa5228cbe217707c1a3c8baf501689ce256ffdc49b4d966724778ee9cf6 does not match proposal fileBeforeHash sha256:9b32edd4b58f9e1dc5f9a24749c972ffcd014f339c030ede377158d8c1479b7f.=2, file-hash-drift: Target file hash sha256:57765ff63e2d8cacdc8ea24c233ed922bfb4c357dea5deb7127b3e9a5b25ffbd does not match proposal fileBeforeHash sha256:08bf0dd6569e9e5f8fae168718f28795b8c3ba151593a1d3ce08b9ea157af1ce.=1, file-hash-drift: Target file hash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:c5742926ea8bd1bbf117a259cac3d0b7e5d47f82ae4c34e872f3400e5841eca0 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=1, file-hash-drift: Target file hash sha256:1806cc344d68fc74569992c666ad3be4705b988739b1799918f311e82e4e9a1b does not match proposal fileBeforeHash sha256:bf3df02a0c5808f9539f44cd28e59539c3ccb1f37bf800cfa24f3758eda36b1e.=1, file-hash-drift: Target file hash sha256:9b32edd4b58f9e1dc5f9a24749c972ffcd014f339c030ede377158d8c1479b7f does not match proposal fileBeforeHash sha256:c5742926ea8bd1bbf117a259cac3d0b7e5d47f82ae4c34e872f3400e5841eca0.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, cold_queue=1 |
| hot_provisional | cold_queue=18, hot_provisional=6, composer_merge=4 |
| no_conflict | hot_provisional=2, composer_merge=2, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157004, duration_ms=732.79
