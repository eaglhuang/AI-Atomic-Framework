# atm-bench export — r3m-e4-hot_conflict-fault_naive-p8-s11-fix

- run_id: `r3m-e4-hot_conflict-fault_naive-p8-s11-fix` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156761 | — |
| duration_ms | 600.42 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 7 | — |
| CAS rebase on apply | 10 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 600.95 | — |
| throughput intents/s | 59.91 | — |
| goodput oracle-pass/s | 59.91 | — |
| latency_ms mean / p50 / p95 | 11.34 / 6.62 / 31.58 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 65.83 / 18.34 / 251.35 | — |
| total_ms mean / p50 / p95 | 96.05 / 46.08 / 309.4 | — |
| overhead_ms mean / p50 / p95 | 77.59 / 27.57 / 275.62 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 7 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |
| hot_provisional | 11 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=9, file-hash-drift: Target file hash sha256:68c8896b4eb9f68976bc38798ae4b3db4096e737009115ca6980ac549c4092b7 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=3, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:a99feb810b86ad9ab4b172dc144e885430335bc866c37af8372c986fb662e87a does not match proposal fileBeforeHash sha256:68c8896b4eb9f68976bc38798ae4b3db4096e737009115ca6980ac549c4092b7.=1, file-hash-drift: Target file hash sha256:b9ca0f47f9f938dafaa89aa35445488a07c6b9fb14e9bef93bd69cc8d18aa981 does not match proposal fileBeforeHash sha256:73985c75636a532a3bf4e004fe33d0cb4e9956371e0be4e41a09bc58594ad9c9.=1, file-hash-drift: Target file hash sha256:9e63db13923faa2ade50be088c6897f3574e77814ec393385c132a65507b3e5c does not match proposal fileBeforeHash sha256:ed54b6c369e09196f0ec628b98ee8cf16ab9349daf0677b6bdbdcb61800c695b.=1, file-hash-drift: Target file hash sha256:9f8766c9227113593b35248cb325de8d01e2749ba6719d2f70096b7607713429 does not match proposal fileBeforeHash sha256:73985c75636a532a3bf4e004fe33d0cb4e9956371e0be4e41a09bc58594ad9c9.=1, file-hash-drift: Target file hash sha256:571d8224f9465615b8a859f2eefdc1e56e590703c7e24026debf4f5c32ccb041 does not match proposal fileBeforeHash sha256:d83425a5428acae3d9048d9bdbb6e36e5953d05757dc97e5ecdee830ae300906.=1, file-hash-drift: Target file hash sha256:c7f056a5ccb5396fd9d5989faabb6089aeb5dd8692921f441c7d3c82066874ab does not match proposal fileBeforeHash sha256:2c20f5a5629164446a24a8245438791b787f9f86819ed932f0bc24c3c822cb4f.=1, compose-context-mismatch: proposal 'prop-s11-t002-i3' context mismatch at base line 15: expected "// </region:selectors>", found "// atm-edit s11-t002-i7 by other:mock-s7" [proposals: prop-s11-t002-i3]=1, file-hash-drift: Target file hash sha256:9f8766c9227113593b35248cb325de8d01e2749ba6719d2f70096b7607713429 does not match proposal fileBeforeHash sha256:9e63db13923faa2ade50be088c6897f3574e77814ec393385c132a65507b3e5c.=1, file-hash-drift: Target file hash sha256:0f21a67d3af16a650b6a5a4ffbd753e6283a112474e25447c2fb7a5b9ca45613 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, cold_queue=1 |
| hot_provisional | cold_queue=16, hot_provisional=8, composer_merge=4 |
| no_conflict | hot_provisional=3, composer_merge=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156761, duration_ms=600.42
