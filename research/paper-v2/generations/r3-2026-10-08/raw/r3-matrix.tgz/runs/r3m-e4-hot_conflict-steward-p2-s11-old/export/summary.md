# atm-bench export — r3m-e4-hot_conflict-steward-p2-s11-old

- run_id: `r3m-e4-hot_conflict-steward-p2-s11-old` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156292 | — |
| duration_ms | 595.38 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=24, blocked=12 | — |
| committed | 24 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 150% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 16 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 595.12 | — |
| throughput intents/s | 60.49 | — |
| goodput oracle-pass/s | 60.49 | — |
| latency_ms mean / p50 / p95 | 5.04 / 3.23 / 14.41 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 38.69 / 14.63 / 118.11 | — |
| total_ms mean / p50 / p95 | 87.6 / 52.69 / 171.9 | — |
| overhead_ms mean / p50 / p95 | 44.52 / 21.88 / 136.87 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=7, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:1f5d58761fc1ddeaac4764012417ad4d00968f610cf8b7a88af72854347e5547 does not match proposal fileBeforeHash sha256:44357a99e51a87c7588edb5718e2e0f697e27bc31a890487269760cda2c6c041.=3, file-hash-drift: Target file hash sha256:b7b22d4b881f8f1bace886777be07ad1b89fcd26ad414741811c7811493bd089 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=2, file-hash-drift: Target file hash sha256:5864bfd226f2a186433693256939d8f6f35c6c7dba401297e528a7fd380888ab does not match proposal fileBeforeHash sha256:88b2d0f06285e7fdb75fffce0d8c75e1aac31654fd86ab35725e398be86929a0.=2, file-hash-drift: Target file hash sha256:3038289f914a3090be47e68fff94401c7058175f1823523534afa67cd27a4755 does not match proposal fileBeforeHash sha256:d99e5e85da084aeae432d3559da480044e5df796d88bcb0ab29b8a2541f40196.=2, file-hash-drift: Target file hash sha256:063e6bb7d5487973d566cf87d7bb8448cd3afd867d7798530376ee73c8c85ef8 does not match proposal fileBeforeHash sha256:7cf12d4c27310123fc1a3de26fd958be666187a55758a90349a57ce893365ead.=1, file-hash-drift: Target file hash sha256:7cf12d4c27310123fc1a3de26fd958be666187a55758a90349a57ce893365ead does not match proposal fileBeforeHash sha256:37e0355b8822690406aad410eaa45b7089b5698c62df95632ca861392988d987.=1, canonical target base hash is stale: src/routes.ts=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=14, composer_merge=9, hot_provisional=5 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156292, duration_ms=595.38
