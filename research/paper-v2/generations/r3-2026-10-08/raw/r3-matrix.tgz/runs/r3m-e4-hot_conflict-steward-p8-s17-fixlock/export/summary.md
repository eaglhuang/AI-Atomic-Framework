# atm-bench export — r3m-e4-hot_conflict-steward-p8-s17-fixlock

- run_id: `r3m-e4-hot_conflict-steward-p8-s17-fixlock` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=8 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 144508 | — |
| duration_ms | 805.19 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=25, blocked=9 | — |
| committed | 25 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 136% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 10 | — |
| composer co-writes | 2 | — |
| CAS rebase on apply | 2 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 804.62 | — |
| throughput intents/s | 42.26 | — |
| goodput oracle-pass/s | 42.26 | — |
| latency_ms mean / p50 / p95 | 10.64 / 4.88 / 33.21 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 117.23 / 17.67 / 566.22 | — |
| total_ms mean / p50 / p95 | 143.11 / 42.97 / 593.78 | — |
| overhead_ms mean / p50 / p95 | 128.31 / 24.69 / 584.58 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 10 | 0 | 0 |
| hot_provisional | 22 | 0 | 0 |
| composer_merge | 2 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=22, file-hash-drift: Target file hash sha256:9e030139eebf9f168f303fa613a429cc21251e3d428de6f3d20ce59005ea7156 does not match proposal fileBeforeHash sha256:6aa75188017621d6e7068194d41776b8411d78751ec1084cf58aa60732a2479e.=3, atm_serial_queue=3, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:6aa75188017621d6e7068194d41776b8411d78751ec1084cf58aa60732a2479e does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:6aa75188017621d6e7068194d41776b8411d78751ec1084cf58aa60732a2479e does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=1, file-hash-drift: Target file hash sha256:9e030139eebf9f168f303fa613a429cc21251e3d428de6f3d20ce59005ea7156 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | hot_provisional=16, cold_queue=9, composer_merge=1 |
| no_conflict | hot_provisional=3, cold_queue=1 |
| composer_cowrite | hot_provisional=3, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=144508, duration_ms=805.19
