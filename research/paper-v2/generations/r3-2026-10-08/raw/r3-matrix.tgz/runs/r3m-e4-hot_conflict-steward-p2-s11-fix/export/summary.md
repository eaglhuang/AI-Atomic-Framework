# atm-bench export — r3m-e4-hot_conflict-steward-p2-s11-fix

- run_id: `r3m-e4-hot_conflict-steward-p2-s11-fix` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 158054 | — |
| duration_ms | 635.47 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 19 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 20 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 635.89 | — |
| throughput intents/s | 56.61 | — |
| goodput oracle-pass/s | 56.61 | — |
| latency_ms mean / p50 / p95 | 5.04 / 3.89 / 13.43 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 32.32 / 13.81 / 117.43 | — |
| total_ms mean / p50 / p95 | 83.42 / 49.52 / 199.84 | — |
| overhead_ms mean / p50 / p95 | 38.25 / 19.26 / 133.51 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| cold_queue | 19 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:c6ad7e714d5fdcf8dd3794a9fcfb20850c77bbb105a8a37aabdfaaa669cb7332 does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=4, steward-final-patch-required: proposals 'prop-s11-t004-i1' and 'prop-s11-t004-i5' change overlapping base line 31 of src/config.ts; a steward-authored final patch is required [proposals: prop-s11-t004-i1, prop-s11-t004-i5]=3, file-hash-drift: Target file hash sha256:1397a75b60e477402cd2081ac9bb4f3a65b3c14dcf781d7fdff7dc7943c08e42 does not match proposal fileBeforeHash sha256:d2437fb5f172c288889d72a7934e5fac555265a0f4491422bd24a48f34e80c89.=2, file-hash-drift: Target file hash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, atm_compose+cas_rebase=2, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:ddc59502be5c789a86f52f1135b0b175853fd062858439244b3432dcf6c002d9 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=1, file-hash-drift: Target file hash sha256:94d90bde12d1e29ac65d04869d7f6535737b596a5896a268b0443c562debee50 does not match proposal fileBeforeHash sha256:3fa15a3a5f5844df795e36287e6b926e0ae34ff6e6b1f8adc1ec9d56cc70f02e.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=16, composer_merge=7, hot_provisional=5 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=158054, duration_ms=635.47
