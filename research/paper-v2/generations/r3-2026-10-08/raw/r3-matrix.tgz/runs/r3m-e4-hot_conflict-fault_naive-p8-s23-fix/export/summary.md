# atm-bench export — r3m-e4-hot_conflict-fault_naive-p8-s23-fix

- run_id: `r3m-e4-hot_conflict-fault_naive-p8-s23-fix` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 159544 | — |
| duration_ms | 715.48 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 15 | — |
| CAS rebase on apply | 6 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 712.79 | — |
| throughput intents/s | 50.51 | — |
| goodput oracle-pass/s | 50.51 | — |
| latency_ms mean / p50 / p95 | 12.82 / 9.6 / 32.45 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 89.78 / 110.53 / 270.35 | — |
| total_ms mean / p50 / p95 | 119.34 / 129.91 / 315.45 | — |
| overhead_ms mean / p50 / p95 | 102.99 / 116.38 / 297.19 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 15 | 0 | 0 |
| hot_provisional | 4 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=15, atm_provisional_write_lease=3, file-hash-drift: Target file hash sha256:9e0cb6a9fd2b17759cc925a278805a14265c73d87a1ff9b0e6f5d718bb322a04 does not match proposal fileBeforeHash sha256:6ce1968f305980f13877edd0f1c81cead1e1543cb3ba857442a033caff005313.=2, file-hash-drift: Target file hash sha256:372cd22dab86289d6da86eed3765082a67d7d49903f3ac6728bd1a0ef2043e87 does not match proposal fileBeforeHash sha256:3cc774f3147fdd58d2c5fd3de677663a68ed353eac54ba0fb195d2d32904c5ca.=2, file-hash-drift: Target file hash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:a1d6cfcea7fe7c5e8a1d389e4e71dbebad9f79d4d4200ec44140f100fff5365b does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=2, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:3f3cbb3cbe65b1f3e8bbe1e688ec3170f38dc400c5e864bacf0427e0de0e7476 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:372cd22dab86289d6da86eed3765082a67d7d49903f3ac6728bd1a0ef2043e87 does not match proposal fileBeforeHash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9.=1, file-hash-drift: Target file hash sha256:3cc774f3147fdd58d2c5fd3de677663a68ed353eac54ba0fb195d2d32904c5ca does not match proposal fileBeforeHash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9.=1, file-hash-drift: Target file hash sha256:6695f3e6c8b490288f9eee99007aa6dd1f6c16c77e01437e972c2b4c7d58fe08 does not match proposal fileBeforeHash sha256:1718dfb87b8b7bc6267f9cb0b9454e1410c9ba4094d3e7f9d2e76aebf1cd3a89.=1, file-hash-drift: Target file hash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9 does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=1, file-hash-drift: Target file hash sha256:6ce1968f305980f13877edd0f1c81cead1e1543cb3ba857442a033caff005313 does not match proposal fileBeforeHash sha256:e47a6b11ed6bc63bc0ad4fe8a8bcca77e214f62b4f6cd758f2dcbcaad142b1a3.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, cold_queue=2 |
| no_conflict | hot_provisional=3, cold_queue=2, composer_merge=2 |
| hot_provisional | cold_queue=13, composer_merge=11, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=159544, duration_ms=715.48
