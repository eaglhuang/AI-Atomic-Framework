# atm-bench export — r3m-e4-hot_conflict-steward-p4-s17-fixlock

- run_id: `r3m-e4-hot_conflict-steward-p4-s17-fixlock` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=4 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 152821 | — |
| duration_ms | 580.05 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=18, commit=16 | — |
| committed | 16 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 212.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 10 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 578.67 | — |
| throughput intents/s | 58.76 | — |
| goodput oracle-pass/s | 58.76 | — |
| latency_ms mean / p50 / p95 | 8.33 / 5.51 / 29.51 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 65.19 / 18.31 / 275.02 | — |
| total_ms mean / p50 / p95 | 104.09 / 48.27 / 338.61 | — |
| overhead_ms mean / p50 / p95 | 74.37 / 26.31 / 286.61 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 16 | 0 | 0 |
| composer_merge | 10 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:94cdad271f84d86408059bc10d9b947bae922e7ce822e40fd31b2ccebf03f546 does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=2, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 21 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=2, steward-final-patch-required: proposals 'prop-s17-t003-i1' and 'prop-s17-t003-i4' change overlapping base line 19 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s17-t003-i1, prop-s17-t003-i4]=2, file-hash-drift: Target file hash sha256:a482e4b4bd932652d53d7e1ef2f17a4aa48fc3b0bba6a73da15c00b21a26fbbf does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:54523b44fa565b86b8ace57def8afde804ccf528052dd9cc0f16e9ec4b7eba79 does not match proposal fileBeforeHash sha256:553aecebed3b00dd2d067f3571e129681ac23113c9cda78eb786bc1b94b54609.=2, file-hash-drift: Target file hash sha256:fad2f3db80ff2a8226c9b365e5f83625ab1da80f80d75af10e045ba0acbbb08a does not match proposal fileBeforeHash sha256:adeefa2f558ff3c1d176d6c1be00ef034b91d930c53428d4720ae7df7ab97a77.=2, file-hash-drift: Target file hash sha256:a482e4b4bd932652d53d7e1ef2f17a4aa48fc3b0bba6a73da15c00b21a26fbbf does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=2, file-hash-drift: Target file hash sha256:4522f6ec17ae3fbe00dac6d3864a365c2cdf475f050cd8d3a7e7a849e67e1b26 does not match proposal fileBeforeHash sha256:94cdad271f84d86408059bc10d9b947bae922e7ce822e40fd31b2ccebf03f546.=1, file-hash-drift: Target file hash sha256:9c627d66c0e011852c87c81ad4abc2488f05710cb83876b1b9a5a05018c7d4ac does not match proposal fileBeforeHash sha256:adeefa2f558ff3c1d176d6c1be00ef034b91d930c53428d4720ae7df7ab97a77.=1, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:1de58ac7eabcf0ed337cddec96961bdfdc0ea641dcc6f6d4652934f3bab37cd9 does not match proposal fileBeforeHash sha256:94cdad271f84d86408059bc10d9b947bae922e7ce822e40fd31b2ccebf03f546.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=15, composer_merge=7, hot_provisional=4 |
| no_conflict | hot_provisional=3, cold_queue=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=152821, duration_ms=580.05
