# atm-bench export — r3m-e4-hot_conflict-fault_naive-p8-s17-old

- run_id: `r3m-e4-hot_conflict-fault_naive-p8-s17-old` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 147681 | — |
| duration_ms | 722.96 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=13, error=1 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 722.22 | — |
| throughput intents/s | 47.08 | — |
| goodput oracle-pass/s | 47.08 | — |
| latency_ms mean / p50 / p95 | 14.32 / 12.88 / 29.66 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 81.42 / 23.97 / 265.14 | — |
| total_ms mean / p50 / p95 | 111.11 / 59.07 / 294.94 | — |
| overhead_ms mean / p50 / p95 | 96.19 / 45.05 / 285.76 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 13 | 0 | 0 |
| composer_merge | 10 | 0 | 0 |
| hot_provisional | 11 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=3, file-hash-drift: Target file hash sha256:d926521369e0760b1efb758b57b46741c6409482b97a854a925492801842ec1d does not match proposal fileBeforeHash sha256:86b909417abb8dac40d6ce7e499bdf9a4f6576a270fbd9867f7b4dc1686c6605.=2, file-hash-drift: Target file hash sha256:0c053a565ebe7f3262e0c1db608a79073d25d1abdba73d71d74e61a1493210eb does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, atm_compose=2, file-hash-drift: Target file hash sha256:e40fdb5999f47e01799f248d384c6260bec6adb9c9c1158338aac830f3e8dfc0 does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, REGION_MISSING=1, file-hash-drift: Target file hash sha256:9d390c19ac41f7a09a4b2646dc47fd4dafa2f1ebf4eb4f713ddbba81ddb49ec2 does not match proposal fileBeforeHash sha256:e0d2e7bad43aad9b8e5923b36c458b1ad22ed704bf5ea748488049907bf9eee9.=1, file-hash-drift: Target file hash sha256:86b909417abb8dac40d6ce7e499bdf9a4f6576a270fbd9867f7b4dc1686c6605 does not match proposal fileBeforeHash sha256:7def02c286644bcac414c0f952c0cc3f5ec31ef822de020821ee7dc9365b9dc0.=1, atm_provisional_write_lease+cas_rebase=1, file-hash-drift: Target file hash sha256:fcb13dcebddc31be0a5cd880e9e5878497c05e543d01d738ad315b23c8b21ce7 does not match proposal fileBeforeHash sha256:d7c8c12ac84cf3330ea7a37a8b14ce46b3e34ae2c6e1cfb6653263f2e8e440ed.=1, file-hash-drift: Target file hash sha256:e6db55f42de829eb640897be5ab7a69738ae7d70b050cec496f2cd40b9edbc67 does not match proposal fileBeforeHash sha256:e0d2e7bad43aad9b8e5923b36c458b1ad22ed704bf5ea748488049907bf9eee9.=1, file-hash-drift: Target file hash sha256:61be26939ea67ad12786d1b295b149b4cfa2b991a0ba5dc5ab12142ac004ff4f does not match proposal fileBeforeHash sha256:d7c8c12ac84cf3330ea7a37a8b14ce46b3e34ae2c6e1cfb6653263f2e8e440ed.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=12, composer_merge=8, hot_provisional=6 |
| no_conflict | hot_provisional=2, composer_merge=1, cold_queue=1 |
| composer_cowrite | hot_provisional=3, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=147681, duration_ms=722.96
