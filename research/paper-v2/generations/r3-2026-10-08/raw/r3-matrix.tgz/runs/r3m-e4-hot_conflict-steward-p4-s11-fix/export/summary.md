# atm-bench export — r3m-e4-hot_conflict-steward-p4-s11-fix

- run_id: `r3m-e4-hot_conflict-steward-p4-s11-fix` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 159365 | — |
| duration_ms | 574.54 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=18, commit=18 | — |
| committed | 18 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 200% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 11 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 574.15 | — |
| throughput intents/s | 62.7 | — |
| goodput oracle-pass/s | 62.7 | — |
| latency_ms mean / p50 / p95 | 9.62 / 5.87 / 26.67 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 54.41 / 21.61 / 131.3 | — |
| total_ms mean / p50 / p95 | 95.85 / 57.33 / 218.06 | — |
| overhead_ms mean / p50 / p95 | 64.6 / 34.65 / 146.42 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=7, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:ee6a679304228974f21fa2abca6abe06869f4e13a505818617d3d362f9d33dee does not match proposal fileBeforeHash sha256:a2a61ae12feac491b9abc44760e90f3e168e53d24ce7f1d6c42bd62565213818.=2, file-hash-drift: Target file hash sha256:1113169808fd50422370255f2ea51bee822fefc661886c79e435ae14cd4f52d0 does not match proposal fileBeforeHash sha256:8c216388953701b12d61d028759ce591ecc95302af8efa5fcb6972ab0ef82943.=2, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:bc0cd8749ca6e4480039827e7b967b03b65d73daad723aaf15047586edf909d1 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:8c216388953701b12d61d028759ce591ecc95302af8efa5fcb6972ab0ef82943 does not match proposal fileBeforeHash sha256:ac417e9fb1ee8f6d68f20ff1226419e7c425ef92f53098280fee5f6eb522a99d.=2, atm_compose+cas_rebase=2, steward-final-patch-required: proposals 'prop-s11-t001-i3' and 'prop-s11-t001-i5' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t001-i3, prop-s11-t001-i5]=2, file-hash-drift: Target file hash sha256:8b9476f6db48641730d21bebd79505c172bcf7e6fbcbe1d20140393300968242 does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=1, file-hash-drift: Target file hash sha256:e98dbcc88eccbe5e7655ea277127cdaf8669ff780a2716c579071b69ced47ecf does not match proposal fileBeforeHash sha256:8b9476f6db48641730d21bebd79505c172bcf7e6fbcbe1d20140393300968242.=1, file-hash-drift: Target file hash sha256:bc0cd8749ca6e4480039827e7b967b03b65d73daad723aaf15047586edf909d1 does not match proposal fileBeforeHash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8.=1, canonical target base hash is stale: src/store.ts=1, atm_compose=1, file-hash-drift: Target file hash sha256:bdfe953d4669f5d948e4092f7292ab0fc6a4eb6787dc87e7b85de8d6747aba67 does not match proposal fileBeforeHash sha256:ee6a679304228974f21fa2abca6abe06869f4e13a505818617d3d362f9d33dee.=1, canonical target base hash is stale: src/routes.ts=1, atm_provisional_write_lease+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=12, composer_merge=11, hot_provisional=5 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=159365, duration_ms=574.54
