# atm-bench export — r3m-e4-hot_conflict-steward-p4-s23-fix

- run_id: `r3m-e4-hot_conflict-steward-p4-s23-fix` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157455 | — |
| duration_ms | 623.91 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 171.4% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 15 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 621.27 | — |
| throughput intents/s | 57.95 | — |
| goodput oracle-pass/s | 57.95 | — |
| latency_ms mean / p50 / p95 | 8.03 / 4.9 / 22.7 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 64.43 / 42.61 / 129.67 | — |
| total_ms mean / p50 / p95 | 104.53 / 120.42 / 216.26 | — |
| overhead_ms mean / p50 / p95 | 72.93 / 58.88 / 163.05 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 15 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=6, atm_compose=3, steward-final-patch-required: proposals 'prop-s23-t003-i0' and 'prop-s23-t003-i4' change overlapping base line 10 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t003-i0, prop-s23-t003-i4]=2, file-hash-drift: Target file hash sha256:c03c900580db1da6676c1d9f808f8eeda49bcd8eb093fbe0af40b530ae8e9432 does not match proposal fileBeforeHash sha256:5f7f5009a23f76e02add018e52d7f68f12c8c399f742d051f2b317e32b4ed6d1.=2, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:5f7f5009a23f76e02add018e52d7f68f12c8c399f742d051f2b317e32b4ed6d1 does not match proposal fileBeforeHash sha256:bb4f7a30c6eff34677f7b8abcaa03e545ce0af341fb401f863442d0ce52d9aa9.=1, file-hash-drift: Target file hash sha256:ace53f474b6fd83f97e256c051494b1cfd2d5065d7632eebcbe540bb5a868314 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:1785576737d228f787634aac9812933035a6063b4cbac226e0ad2d6e6f11c352 does not match proposal fileBeforeHash sha256:97d19d0940bb26e42ab03a9765858bc9628020b3b8482a825ba98c6b1f6b3cc1.=1, canonical target base hash is stale: src/config.ts=1, file-hash-drift: Target file hash sha256:1785576737d228f787634aac9812933035a6063b4cbac226e0ad2d6e6f11c352 does not match proposal fileBeforeHash sha256:e77d74761e3bd8c94a920c0e3418c34319f84ca8b8df3ed89c5765863680951f.=1, file-hash-drift: Target file hash sha256:10a30d92c50c5f00a3c5ec7476e584b69b303f54b537aa1e94ffa3a329a4cd39 does not match proposal fileBeforeHash sha256:9c95c6921ea352e2a07eb989137679d1c2caa5f3f22499307e0768ae8c145f37.=1, file-hash-drift: Target file hash sha256:ba0c772eb6a9f01775b5894dd19d8da450d394d077e57f6805744efb48309256 does not match proposal fileBeforeHash sha256:c03c900580db1da6676c1d9f808f8eeda49bcd8eb093fbe0af40b530ae8e9432.=1, file-hash-drift: Target file hash sha256:e77d74761e3bd8c94a920c0e3418c34319f84ca8b8df3ed89c5765863680951f does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:a01e6a6977d7924fa79b883dbc8148f8b38cbfe4bf21d3ac1070ba4332af36b5 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:fb0d96fe57cf3dbd000e9552f0cf7611021443e8c008bcaef3a054e4c476fa8a does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:97d19d0940bb26e42ab03a9765858bc9628020b3b8482a825ba98c6b1f6b3cc1 does not match proposal fileBeforeHash sha256:e77d74761e3bd8c94a920c0e3418c34319f84ca8b8df3ed89c5765863680951f.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=4, composer_merge=2, cold_queue=1 |
| hot_provisional | cold_queue=13, composer_merge=9, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157455, duration_ms=623.91
