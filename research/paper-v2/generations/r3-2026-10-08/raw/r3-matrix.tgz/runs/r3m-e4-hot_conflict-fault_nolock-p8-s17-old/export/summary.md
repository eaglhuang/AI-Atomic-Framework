# atm-bench export — r3m-e4-hot_conflict-fault_nolock-p8-s17-old

- run_id: `r3m-e4-hot_conflict-fault_nolock-p8-s17-old` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 151610 | — |
| duration_ms | 634.16 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=19, commit=15 | — |
| committed | 15 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 226.7% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 633.43 | — |
| throughput intents/s | 53.68 | — |
| goodput oracle-pass/s | 53.68 | — |
| latency_ms mean / p50 / p95 | 14.8 / 9.53 / 38.14 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 89.18 / 109.6 / 251.93 | — |
| total_ms mean / p50 / p95 | 119.43 / 128.91 / 287.22 | — |
| overhead_ms mean / p50 / p95 | 104.41 / 115.91 / 272.02 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 16 | 0 | 0 |
| composer_merge | 13 | 0 | 0 |
| hot_provisional | 5 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=10, atm_provisional_write_lease=4, file-hash-drift: Target file hash sha256:d1dcd3c006aed85c3212c918fa8151f2ad03e9772f8c311d56c6dd17b761a5a8 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=4, file-hash-drift: Target file hash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=2, file-hash-drift: Target file hash sha256:3587cdafcf9ce091501b8ceedae6772cf6f6fd7445f619c17265328729daace5 does not match proposal fileBeforeHash sha256:ac7ba9a71f570da5a5dca4ee06d76973a9ba82f23fa60917730800595a403ff3.=1, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:ac7ba9a71f570da5a5dca4ee06d76973a9ba82f23fa60917730800595a403ff3 does not match proposal fileBeforeHash sha256:d1dcd3c006aed85c3212c918fa8151f2ad03e9772f8c311d56c6dd17b761a5a8.=1, file-hash-drift: Target file hash sha256:bd20bfdc70c2939ec0f94d906771c229313f29a170a55099883a531cd8a7ea3a does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e does not match proposal fileBeforeHash sha256:bd20bfdc70c2939ec0f94d906771c229313f29a170a55099883a531cd8a7ea3a.=1, file-hash-drift: Target file hash sha256:a3c5e76771ed28597201300d29a87dca46019f44a9e78a4e66736b296f40fb7f does not match proposal fileBeforeHash sha256:f1b1539c7d070129de4bf318c3414a6836c9058fa2ec0dd9e78d16c7569eee29.=1, canonical target base hash is stale: src/store.ts=1, atm_compose=1, file-hash-drift: Target file hash sha256:3be9dfafb972062c967a8aef27bb66075ce1fbb1f6e40c00102564205e88fab0 does not match proposal fileBeforeHash sha256:a3c5e76771ed28597201300d29a87dca46019f44a9e78a4e66736b296f40fb7f.=1, file-hash-drift: Target file hash sha256:3be9dfafb972062c967a8aef27bb66075ce1fbb1f6e40c00102564205e88fab0 does not match proposal fileBeforeHash sha256:f1b1539c7d070129de4bf318c3414a6836c9058fa2ec0dd9e78d16c7569eee29.=1, file-hash-drift: Target file hash sha256:3587cdafcf9ce091501b8ceedae6772cf6f6fd7445f619c17265328729daace5 does not match proposal fileBeforeHash sha256:c7878cf55980598765faacea23d04011714cb2f6ad240711577ca29797448585.=1, file-hash-drift: Target file hash sha256:e862e37fcaca2c0a5af531039da0d3d5cba3694fab602ae4d3e9409706560a12 does not match proposal fileBeforeHash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e.=1, file-hash-drift: Target file hash sha256:c7878cf55980598765faacea23d04011714cb2f6ad240711577ca29797448585 does not match proposal fileBeforeHash sha256:ac7ba9a71f570da5a5dca4ee06d76973a9ba82f23fa60917730800595a403ff3.=1, file-hash-drift: Target file hash sha256:611366b544a816e39cee88fcf5aa011ad4230842c0b252da889daec1d861bac1 does not match proposal fileBeforeHash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=15, composer_merge=9, hot_provisional=2 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=151610, duration_ms=634.16
