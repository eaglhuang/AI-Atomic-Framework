# atm-bench export — r3m-e4-hot_conflict-fault_nolock-p8-s17-fix

- run_id: `r3m-e4-hot_conflict-fault_nolock-p8-s17-fix` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 150191 | — |
| duration_ms | 642.56 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=17, commit=17 | — |
| committed | 17 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 200% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 3 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 641.73 | — |
| throughput intents/s | 52.98 | — |
| goodput oracle-pass/s | 52.98 | — |
| latency_ms mean / p50 / p95 | 13 / 7.49 / 39.18 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 86.7 / 109.7 / 261.69 | — |
| total_ms mean / p50 / p95 | 114.96 / 124.26 / 299.73 | — |
| overhead_ms mean / p50 / p95 | 100.17 / 114.09 / 284.42 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=10, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=3, file-hash-drift: Target file hash sha256:4333f08be19c3430be94cc6df9762e6682cdd021351e5779630d7f8cba00a7ba does not match proposal fileBeforeHash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e.=2, file-hash-drift: Target file hash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e does not match proposal fileBeforeHash sha256:bd20bfdc70c2939ec0f94d906771c229313f29a170a55099883a531cd8a7ea3a.=2, file-hash-drift: Target file hash sha256:672e74380d7760095ccbfc00d334e8ba108ed2eb01a042a0c3cd280336324e20 does not match proposal fileBeforeHash sha256:5bc6da3db64aa824591a3943cdaaefb88aa9bf7239a77aeaaec2e03b4ac70fa9.=2, canonical target base hash is stale: src/store.ts=2, file-hash-drift: Target file hash sha256:68356786174a925cfad93a10745969f2f28bb69a0abf7a9f146068a0e14e1bba does not match proposal fileBeforeHash sha256:634355c04fa73111b6a23130451340f8c32d41dd15d4f6ce718a65dff091686d.=1, file-hash-drift: Target file hash sha256:96479717f45da06ab1faa46edd010eb212bf64a5d1f5223ad7123951ae0b1813 does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=1, file-hash-drift: Target file hash sha256:611366b544a816e39cee88fcf5aa011ad4230842c0b252da889daec1d861bac1 does not match proposal fileBeforeHash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e.=1, compose-context-mismatch: proposal 'prop-s17-t000-i0' context mismatch at base line 8: expected "// </region:reducers>", found "// atm-edit s17-t000-i6 by other:mock-s7" [proposals: prop-s17-t000-i0]=1, atm_compose=1, file-hash-drift: Target file hash sha256:634355c04fa73111b6a23130451340f8c32d41dd15d4f6ce718a65dff091686d does not match proposal fileBeforeHash sha256:96479717f45da06ab1faa46edd010eb212bf64a5d1f5223ad7123951ae0b1813.=1, file-hash-drift: Target file hash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, composer_merge=8, hot_provisional=5 |
| no_conflict | hot_provisional=2, composer_merge=1, cold_queue=1 |
| composer_cowrite | composer_merge=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=150191, duration_ms=642.56
