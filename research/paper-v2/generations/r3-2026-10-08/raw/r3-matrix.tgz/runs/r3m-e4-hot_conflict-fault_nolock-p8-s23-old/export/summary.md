# atm-bench export — r3m-e4-hot_conflict-fault_nolock-p8-s23-old

- run_id: `r3m-e4-hot_conflict-fault_nolock-p8-s23-old` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 158808 | — |
| duration_ms | 615.57 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 1 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 613.2 | — |
| throughput intents/s | 58.71 | — |
| goodput oracle-pass/s | 58.71 | — |
| latency_ms mean / p50 / p95 | 11.46 / 6.72 / 30.72 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 79.84 / 21.36 / 244.32 | — |
| total_ms mean / p50 / p95 | 108.29 / 53.06 / 296.58 | — |
| overhead_ms mean / p50 / p95 | 91.7 / 40.83 / 275.63 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:47218b7849e12acac700432b394b258352a6da90becb30b556242cf93ca0a038 does not match proposal fileBeforeHash sha256:56921fb5e7b6d04def44b7b709b5f9c5708e22ed344c663437c5f49da71ad49b.=3, file-hash-drift: Target file hash sha256:1235e6d0851c6c249209c4149bc0b86cfbfb96d762cf7d29782759cf63b1be22 does not match proposal fileBeforeHash sha256:b11389d269193d66c879f2b5dc0d9e045c4a2ef3da155b00704df5e2a5448c11.=2, file-hash-drift: Target file hash sha256:9e74f5d57908514b27b7747a43ff1f9e6c348288dd4f0cc5517b5583ac0987bc does not match proposal fileBeforeHash sha256:309c8de6bd6728e73638d24fe8952ebea8d7d3dac32a31b12b0cf72d183f2cb4.=2, file-hash-drift: Target file hash sha256:b20e8d80932401ef43bb0d12f90f3311f93478b2745950b504d6fc1052ef5da3 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:c9fe7064a49fff77caef8468617e2cc2a0c8b1bbf9c66bb1492d4698eb9ad7a9 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:ddd16bda6aa20709720c9769aff5a020ff7f4f7a822390cc53092b0698e50c13 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:fb0d96fe57cf3dbd000e9552f0cf7611021443e8c008bcaef3a054e4c476fa8a does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:47218b7849e12acac700432b394b258352a6da90becb30b556242cf93ca0a038 does not match proposal fileBeforeHash sha256:4f06b27967639be8e05817377d38804da949aa3935a25f7efdf02f51a8084476.=1, file-hash-drift: Target file hash sha256:c9fe7064a49fff77caef8468617e2cc2a0c8b1bbf9c66bb1492d4698eb9ad7a9 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, atm_compose=1, file-hash-drift: Target file hash sha256:4f06b27967639be8e05817377d38804da949aa3935a25f7efdf02f51a8084476 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:ddd16bda6aa20709720c9769aff5a020ff7f4f7a822390cc53092b0698e50c13 does not match proposal fileBeforeHash sha256:c9fe7064a49fff77caef8468617e2cc2a0c8b1bbf9c66bb1492d4698eb9ad7a9.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=4, cold_queue=2, composer_merge=1 |
| hot_provisional | cold_queue=14, composer_merge=7, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=158808, duration_ms=615.57
