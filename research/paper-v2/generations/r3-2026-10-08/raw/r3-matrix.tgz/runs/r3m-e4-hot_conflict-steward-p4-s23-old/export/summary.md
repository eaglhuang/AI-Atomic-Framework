# atm-bench export — r3m-e4-hot_conflict-steward-p4-s23-old

- run_id: `r3m-e4-hot_conflict-steward-p4-s23-old` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 158079 | — |
| duration_ms | 632.79 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 15 | — |
| CAS rebase on apply | 11 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 629.78 | — |
| throughput intents/s | 57.16 | — |
| goodput oracle-pass/s | 57.16 | — |
| latency_ms mean / p50 / p95 | 8.12 / 5.48 / 21.33 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 62.94 / 43.09 / 126.49 | — |
| total_ms mean / p50 / p95 | 102.37 / 127.05 / 182.58 | — |
| overhead_ms mean / p50 / p95 | 71.49 / 51.47 / 149.5 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 15 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 13 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=8, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:48246856572a60577817e2c3340117622924acbf15cf47fc397a1a24241a2e3c does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=2, file-hash-drift: Target file hash sha256:8f42f9cadc09f0b7790cd5150d1bcb07c82919a3984ae949e9677694d54fdf99 does not match proposal fileBeforeHash sha256:5f7f5009a23f76e02add018e52d7f68f12c8c399f742d051f2b317e32b4ed6d1.=2, file-hash-drift: Target file hash sha256:f7447f6e1e0b2d8ab56eed35f160198954e6ca504ea1b932a874d0458702eb0e does not match proposal fileBeforeHash sha256:1d5a7fe2af4234741a601bd571757746c33031e26f4bb6d8632dd93d8fba2c5c.=2, steward-final-patch-required: proposals 'prop-s23-t002-i3' and 'prop-s23-t002-i6' change overlapping base line 23 of src/config.ts; a steward-authored final patch is required [proposals: prop-s23-t002-i3, prop-s23-t002-i6]=2, file-hash-drift: Target file hash sha256:033c24aa6ffd494c7f693bb1acb09b32cd43ccda20880115624c43f052c518c6 does not match proposal fileBeforeHash sha256:73fe0924053358c7c59bef9a12ad82855b645979e7cc618e74a175269e1d1853.=1, file-hash-drift: Target file hash sha256:9ec2cf30bdcf3e64803ff368ed011677d6f9d035cb259749921a5781ca8555ab does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:1d5a7fe2af4234741a601bd571757746c33031e26f4bb6d8632dd93d8fba2c5c does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:fcf8c4af9ab1c470cb7ad3e664bf52fce4e563c22bc668461b279fab443e6955 does not match proposal fileBeforeHash sha256:f7447f6e1e0b2d8ab56eed35f160198954e6ca504ea1b932a874d0458702eb0e.=1, file-hash-drift: Target file hash sha256:a2f60e6f9c2b4d2856497d7040d6deb799d593e7b0921175f8670b0cbe0e39f1 does not match proposal fileBeforeHash sha256:8f42f9cadc09f0b7790cd5150d1bcb07c82919a3984ae949e9677694d54fdf99.=1, file-hash-drift: Target file hash sha256:60961b3f21973baf67c3d0814943acd54ebb012f2be1f1684504f00e9f166ea2 does not match proposal fileBeforeHash sha256:f7447f6e1e0b2d8ab56eed35f160198954e6ca504ea1b932a874d0458702eb0e.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:a2f60e6f9c2b4d2856497d7040d6deb799d593e7b0921175f8670b0cbe0e39f1 does not match proposal fileBeforeHash sha256:a1918a630ab56065a3b286032a8488df4995550ebe25de8462085286e4b3c78c.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=4, cold_queue=2, composer_merge=1 |
| hot_provisional | cold_queue=11, composer_merge=10, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=158079, duration_ms=632.79
