# atm-bench export — r3m-e4-hot_conflict-steward-p2-s23-fixlock

- run_id: `r3m-e4-hot_conflict-steward-p2-s23-fixlock` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 161470 | — |
| duration_ms | 652.7 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 12 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 649.6 | — |
| throughput intents/s | 55.42 | — |
| goodput oracle-pass/s | 55.42 | — |
| latency_ms mean / p50 / p95 | 4.88 / 3.66 / 16.55 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 43.59 / 20.01 / 120.15 | — |
| total_ms mean / p50 / p95 | 93.62 / 61.21 / 178.88 | — |
| overhead_ms mean / p50 / p95 | 49.42 / 23.72 / 137.79 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 14 | 0 | 0 |
| hot_provisional | 10 | 0 | 0 |
| cold_queue | 12 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=10, atm_serial_queue=7, steward-final-patch-required: proposals 'prop-s23-t001-i3' and 'prop-s23-t001-i5' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i3, prop-s23-t001-i5]=3, atm_compose+cas_rebase=3, steward-final-patch-required: proposals 'prop-s23-t004-i1' and 'prop-s23-t004-i7' change overlapping base line 25 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s23-t004-i1, prop-s23-t004-i7]=2, steward-final-patch-required: proposals 'prop-s23-t001-i2' and 'prop-s23-t001-i4' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i2, prop-s23-t001-i4]=2, file-hash-drift: Target file hash sha256:faf5553535185b7c7fb092b2eafbddec8fb70ad7090d6bfcf303adf9a8c21a29 does not match proposal fileBeforeHash sha256:878695031a532d9239e416f08a7b5d3851cf8334ec6e1f9b874a84754c70c165.=2, file-hash-drift: Target file hash sha256:ab83850074b905ab5c998a5ac4ff83cc1c18b7fe398a6b53918ac112f7682546 does not match proposal fileBeforeHash sha256:a92a76c0bceb040a15ddf0c9f4daa24d11432236459d95c6868c3a3b75a2521e.=2, file-hash-drift: Target file hash sha256:911f51014f00ba9dc166ff556e79b2a0198109d49cb0317ba2e41bfce3065296 does not match proposal fileBeforeHash sha256:1d5a7fe2af4234741a601bd571757746c33031e26f4bb6d8632dd93d8fba2c5c.=2, steward-final-patch-required: proposals 'prop-s23-t002-i3' and 'prop-s23-t002-i6' change overlapping base line 23 of src/config.ts; a steward-authored final patch is required [proposals: prop-s23-t002-i3, prop-s23-t002-i6]=2, file-hash-drift: Target file hash sha256:29be271bfe53617c695b459d1c8ece3c497a30b1b69b04c492b55403bf66b30f does not match proposal fileBeforeHash sha256:5763f22292b1198ea4ec5780f6836ba01ae05a12d388bf6f07dacd0371c2fc0e.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=4, cold_queue=3 |
| hot_provisional | composer_merge=10, cold_queue=9, hot_provisional=6 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=161470, duration_ms=652.7
