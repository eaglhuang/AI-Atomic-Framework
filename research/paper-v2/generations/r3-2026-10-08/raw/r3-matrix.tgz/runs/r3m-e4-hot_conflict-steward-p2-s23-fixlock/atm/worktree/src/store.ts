/** In-memory store slices (HOT). */
export type State = { users: string[]; orders: number[]; meta: Record<string, string> };

// <region:reducers>
export function reduceUsers(state: State, user: string): State {
  return { ...state, users: [...state.users, user] };
}
// atm-edit s23-t000-i1 by cursor:mock-s3
// atm-edit s23-t003-i0 by cursor:mock-s0
// </region:reducers>

// <region:selectors>
export function selectUserCount(state: State): number {
  return state.users.length;
}
// atm-edit s23-t003-i3 by cursor:mock-s3
// </region:selectors>

// <region:actions>
export function createOrder(state: State, id: number): State {
  return { ...state, orders: [...state.orders, id] };
}
// atm-edit s23-t001-i6 by other:mock-s6
// atm-edit s23-t003-i1 by claude:mock-s1
// atm-edit s23-t003-i5 by codex:mock-s5
// </region:actions>

export const initialState: State = { users: [], orders: [], meta: {} };
