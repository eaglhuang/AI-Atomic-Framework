# atm-bench export — r3m-e4-hot_conflict-steward-p8-s17-old

- run_id: `r3m-e4-hot_conflict-steward-p8-s17-old` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=8 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 148135 | — |
| duration_ms | 673.26 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 5 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 672.14 | — |
| throughput intents/s | 50.58 | — |
| goodput oracle-pass/s | 50.58 | — |
| latency_ms mean / p50 / p95 | 11.96 / 7.16 / 30.02 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 80.34 / 18.18 / 241.5 | — |
| total_ms mean / p50 / p95 | 107.62 / 44.14 / 283.43 | — |
| overhead_ms mean / p50 / p95 | 92.69 / 26.31 / 268.2 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 13 | 0 | 0 |
| hot_provisional | 10 | 0 | 0 |
| composer_merge | 11 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=10, atm_serial_queue=7, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=5, atm_compose=3, file-hash-drift: Target file hash sha256:d88aeaad209ba5ffc9da6363002d8846edf1f76da3c05c686abe7adf96ad48cb does not match proposal fileBeforeHash sha256:76a83a53996022003ccea3271efb6ee83c85992302712f2d33f5d6c4a95dc9f2.=2, file-hash-drift: Target file hash sha256:e5eb6358d6b735f6faf5c4f456bbbb13000d60690314147d51ac9e53d11b5ba6 does not match proposal fileBeforeHash sha256:7094f1c9f85bfcb2abc8b7ffa086805c58b664e8c56a01012e1a7b2f974c0c63.=1, file-hash-drift: Target file hash sha256:6a0af341e2f60adfb65204ea4865ec57190d9fadf136f35e2a8f97dcdfad39e5 does not match proposal fileBeforeHash sha256:e5eb6358d6b735f6faf5c4f456bbbb13000d60690314147d51ac9e53d11b5ba6.=1, file-hash-drift: Target file hash sha256:6a0af341e2f60adfb65204ea4865ec57190d9fadf136f35e2a8f97dcdfad39e5 does not match proposal fileBeforeHash sha256:7094f1c9f85bfcb2abc8b7ffa086805c58b664e8c56a01012e1a7b2f974c0c63.=1, file-hash-drift: Target file hash sha256:76a83a53996022003ccea3271efb6ee83c85992302712f2d33f5d6c4a95dc9f2 does not match proposal fileBeforeHash sha256:3fff25580e23004e2119348fc0b52f46c243b55f201729c097e471a90f955a4f.=1, file-hash-drift: Target file hash sha256:f751778ced79211651686df0f6f8937a46cb3283ff4f11e1872b541a62f711f7 does not match proposal fileBeforeHash sha256:0a3e38941e65be7c730db8e5a5145fe53cbe0133439820a2ec3a631bbbd0425e.=1, file-hash-drift: Target file hash sha256:6a0af341e2f60adfb65204ea4865ec57190d9fadf136f35e2a8f97dcdfad39e5 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:05ba5e6c4ef2bdc5b848b4aea5ffa45e9f98b8d9c20beb533b1d65563f2481ee does not match proposal fileBeforeHash sha256:6a0af341e2f60adfb65204ea4865ec57190d9fadf136f35e2a8f97dcdfad39e5.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=12, hot_provisional=8, composer_merge=6 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=148135, duration_ms=673.26
