# atm-bench export — r3m-e4-hot_conflict-steward-p8-s11-old

- run_id: `r3m-e4-hot_conflict-steward-p8-s11-old` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=8 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157134 | — |
| duration_ms | 772.49 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 171.4% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 8 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 773.04 | — |
| throughput intents/s | 46.57 | — |
| goodput oracle-pass/s | 46.57 | — |
| latency_ms mean / p50 / p95 | 12.82 / 8.14 / 32.64 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 79.04 / 21.99 / 253.62 | — |
| total_ms mean / p50 / p95 | 110.49 / 58.24 / 300.34 | — |
| overhead_ms mean / p50 / p95 | 92.32 / 41.04 / 276.98 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=10, atm_provisional_write_lease=9, file-hash-drift: Target file hash sha256:5e365f94dc9008c12e3fb0ffc577a75bde1ea89d4ac8ce99f2f8064a4a065c97 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:a666d68e2011c1933292e2b9fccb9568dca7734c5ce6634c5e8ac6cbcc868339 does not match proposal fileBeforeHash sha256:67e69b03454dd62dd4ff6ee0abfd00eb805650b5e98743747a01aa9b4735e714.=2, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:0f21a67d3af16a650b6a5a4ffbd753e6283a112474e25447c2fb7a5b9ca45613 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:d4b3841f9a4982b368f34b3ce144c250c6cadb18bf1b72359dfc19e37ac3735d does not match proposal fileBeforeHash sha256:5e365f94dc9008c12e3fb0ffc577a75bde1ea89d4ac8ce99f2f8064a4a065c97.=1, file-hash-drift: Target file hash sha256:806beed3dec265a57f57ae6acfe2859829f30a62d6f8221e6290c5e1e5a9844e does not match proposal fileBeforeHash sha256:fab39f590e1bd821421dc0ddac18ef6720c57e07bd744e5ad3278a9df5f73570.=1, file-hash-drift: Target file hash sha256:501b1b872b6d84e29ed317633e70d5308fab55d0c578b784eecace4694944ded does not match proposal fileBeforeHash sha256:3a751d4fa21a3be111d2b2f6049eab819c79eebe6137f42a02decced10a18072.=1, file-hash-drift: Target file hash sha256:bcf3cd7893772b7e71a16eaec8fda744741bccc3b6cb727326e5f0dae864cbc3 does not match proposal fileBeforeHash sha256:e3743f555b6ffb5c9b2c7755d0654c8935b453941533728606f4fe1f25b66921.=1, file-hash-drift: Target file hash sha256:3a751d4fa21a3be111d2b2f6049eab819c79eebe6137f42a02decced10a18072 does not match proposal fileBeforeHash sha256:95a739b8355bc19a85b5eb691d59a533709d5549b2da3763d2e039cb043a2268.=1, file-hash-drift: Target file hash sha256:67e69b03454dd62dd4ff6ee0abfd00eb805650b5e98743747a01aa9b4735e714 does not match proposal fileBeforeHash sha256:5170c1b840729b9ebc5215ad87689f006e18b15eb57255b232fbe4e263aba9c1.=1, file-hash-drift: Target file hash sha256:d4b3841f9a4982b368f34b3ce144c250c6cadb18bf1b72359dfc19e37ac3735d does not match proposal fileBeforeHash sha256:0f21a67d3af16a650b6a5a4ffbd753e6283a112474e25447c2fb7a5b9ca45613.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=13, composer_merge=9, hot_provisional=6 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157134, duration_ms=772.49
