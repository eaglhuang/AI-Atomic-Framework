# atm-bench export — r3m-e4-hot_conflict-fault_nolock-p8-s23-fix

- run_id: `r3m-e4-hot_conflict-fault_nolock-p8-s23-fix` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 159018 | — |
| duration_ms | 651.96 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 649.09 | — |
| throughput intents/s | 55.46 | — |
| goodput oracle-pass/s | 55.46 | — |
| latency_ms mean / p50 / p95 | 15.18 / 10.74 / 37.6 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 86.62 / 110.8 / 235.43 | — |
| total_ms mean / p50 / p95 | 118.86 / 129.39 / 276.59 | — |
| overhead_ms mean / p50 / p95 | 102.22 / 116.56 / 254.74 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 14 | 0 | 0 |
| hot_provisional | 5 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=5, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=4, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:1f635c766aa0c0da7509e9ab6cc8eb38b824ac738b61e85d3d9cb94246c5c9ed does not match proposal fileBeforeHash sha256:096ef01757a1c9f99a386771089b91b2a768b021d3a4814ef75bdb129bfca9b5.=3, file-hash-drift: Target file hash sha256:1f2549320fa679d59b2ba7d1e0ce49fcad2df7ec7f3495949ac120c82b5332e3 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:5990d14205e0fce3154ce6a7dd7753a8f407e4a02e311143b7f1a45f2cc951db does not match proposal fileBeforeHash sha256:cc8e2b8e3af93bd8476ff615f29637ed42804df26b2f6e44106d6ac62144f5b2.=1, file-hash-drift: Target file hash sha256:cc8e2b8e3af93bd8476ff615f29637ed42804df26b2f6e44106d6ac62144f5b2 does not match proposal fileBeforeHash sha256:c40de74b5333e80fde0e7fb8dca8ddf00aba07f6328a41cf728ec8703aada46f.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:5b3d222aa48332d0e19f43c30ee16240ac63adbc55ab1e3dee642e2026f92157 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:005a8e606f6236370615384543b64403f817017366acd0d2141cc842310e6937 does not match proposal fileBeforeHash sha256:a1d45c2eefd0e07e0aa107d9a17cab9e673c352a2900abe645663fa34216d4fe.=1, compose-context-mismatch: proposal 'prop-s23-t004-i3' context mismatch at base line 17: expected "// </region:orders>", found "// atm-edit s23-t004-i2 by codex:mock-s2" [proposals: prop-s23-t004-i3]=1, file-hash-drift: Target file hash sha256:a1d45c2eefd0e07e0aa107d9a17cab9e673c352a2900abe645663fa34216d4fe does not match proposal fileBeforeHash sha256:bb4f7a30c6eff34677f7b8abcaa03e545ce0af341fb401f863442d0ce52d9aa9.=1, file-hash-drift: Target file hash sha256:096ef01757a1c9f99a386771089b91b2a768b021d3a4814ef75bdb129bfca9b5 does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=1, file-hash-drift: Target file hash sha256:005a8e606f6236370615384543b64403f817017366acd0d2141cc842310e6937 does not match proposal fileBeforeHash sha256:9a24d95d62d9e828b4b1638c70b4ac5c35361617cfefdc6b6a41bbd1ce4d6708.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=3, cold_queue=3, composer_merge=1 |
| hot_provisional | cold_queue=14, composer_merge=9, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=159018, duration_ms=651.96
