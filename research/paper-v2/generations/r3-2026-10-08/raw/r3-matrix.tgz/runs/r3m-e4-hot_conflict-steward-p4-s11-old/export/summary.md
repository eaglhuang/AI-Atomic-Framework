# atm-bench export — r3m-e4-hot_conflict-steward-p4-s11-old

- run_id: `r3m-e4-hot_conflict-steward-p4-s11-old` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156625 | — |
| duration_ms | 625.31 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 624.83 | — |
| throughput intents/s | 57.62 | — |
| goodput oracle-pass/s | 57.62 | — |
| latency_ms mean / p50 / p95 | 7.49 / 5.35 / 23.71 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 59.46 / 17.92 / 196.44 | — |
| total_ms mean / p50 / p95 | 95.79 / 56.17 / 236.79 | — |
| overhead_ms mean / p50 / p95 | 67.53 / 29.15 / 203.81 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:ccae29ac1d00c2ce8cb4842fe9537e9e607ecadfcea93b56f201aef71878dd8a does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:cb0fd73caf7a5f365c5690fe8a3e6fbac17e8bf04784ba275c31213c5682f497 does not match proposal fileBeforeHash sha256:146e1f35e5ebbecb59e115fb9f850f18c0359275d9fd2ee0737a6d7b1ae67777.=2, atm_compose=2, file-hash-drift: Target file hash sha256:deb7d38d0bd9c9f7478beff2ec4f9c06904d7aa837b588f2b672d6aff21fc08f does not match proposal fileBeforeHash sha256:577f7bcf7bfe5817fa14fe7f23dec2922e85929a269b5cc1653b0bdfa9b4c870.=2, file-hash-drift: Target file hash sha256:44b0f7da3445c0b3a5b3ce059c288abe3bad90a79ca79370c876e4e94ecd2ca1 does not match proposal fileBeforeHash sha256:ccae29ac1d00c2ce8cb4842fe9537e9e607ecadfcea93b56f201aef71878dd8a.=1, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:ac2036a8f57effd48b7d2cb5d20c4894d5646833a6952643e58576a0121b41b6 does not match proposal fileBeforeHash sha256:644a51a9dbc777a6644cb3b6dde3d9140758b662dc7cc8f5cabedcc0cafc9cb0.=1, file-hash-drift: Target file hash sha256:5943b045f898a532b1e43246524367ba2129388bc4983f94701df8d15ef24671 does not match proposal fileBeforeHash sha256:44dddfe22f077dbf0f393f3b48bf4d299f10c2b3ac7b0a1b322408b5e1a9d125.=1, file-hash-drift: Target file hash sha256:44dddfe22f077dbf0f393f3b48bf4d299f10c2b3ac7b0a1b322408b5e1a9d125 does not match proposal fileBeforeHash sha256:ac2036a8f57effd48b7d2cb5d20c4894d5646833a6952643e58576a0121b41b6.=1, file-hash-drift: Target file hash sha256:4d792743fb9f3f1ec670085e544454b9dea58904dac6dac464f91fed02104f3d does not match proposal fileBeforeHash sha256:86ce590c6a97dc21d1515c1528dcef80313f5750cb49812f6bb42fa0a8d141c2.=1, file-hash-drift: Target file hash sha256:644a51a9dbc777a6644cb3b6dde3d9140758b662dc7cc8f5cabedcc0cafc9cb0 does not match proposal fileBeforeHash sha256:4d792743fb9f3f1ec670085e544454b9dea58904dac6dac464f91fed02104f3d.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, cold_queue=1 |
| hot_provisional | cold_queue=12, composer_merge=10, hot_provisional=6 |
| no_conflict | cold_queue=3, hot_provisional=1, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156625, duration_ms=625.31
