# atm-bench export — r3m-e4-hot_conflict-steward-p8-s23-fix

- run_id: `r3m-e4-hot_conflict-steward-p8-s23-fix` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=8 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 158058 | — |
| duration_ms | 699.86 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 697.02 | — |
| throughput intents/s | 51.65 | — |
| goodput oracle-pass/s | 51.65 | — |
| latency_ms mean / p50 / p95 | 15.25 / 12.74 / 35.93 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 84.12 / 110.72 / 237.78 | — |
| total_ms mean / p50 / p95 | 116.23 / 127.34 / 289.52 | — |
| overhead_ms mean / p50 / p95 | 99.79 / 116.27 / 270.12 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 14 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:6ce1968f305980f13877edd0f1c81cead1e1543cb3ba857442a033caff005313 does not match proposal fileBeforeHash sha256:bb4f7a30c6eff34677f7b8abcaa03e545ce0af341fb401f863442d0ce52d9aa9.=3, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=3, atm_compose=2, file-hash-drift: Target file hash sha256:6c3ff8c8cf32d973b8769ee9921d1ea9ef29ad1d9f08d9027c6b2080a45bbc47 does not match proposal fileBeforeHash sha256:6ce1968f305980f13877edd0f1c81cead1e1543cb3ba857442a033caff005313.=2, file-hash-drift: Target file hash sha256:c9fe7064a49fff77caef8468617e2cc2a0c8b1bbf9c66bb1492d4698eb9ad7a9 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:309c8de6bd6728e73638d24fe8952ebea8d7d3dac32a31b12b0cf72d183f2cb4 does not match proposal fileBeforeHash sha256:a67d81b7ae41111ff8b057ee3a1ddab7d5ea04aa15e49f18746f433a12df16e3.=1, file-hash-drift: Target file hash sha256:499694a96ac9ee33330dc2d8add363ff1f225e89d15a4b4773a6cd6d35b61765 does not match proposal fileBeforeHash sha256:5cd6085fbd981f389119f6dce48b05c364399188eff406a4dde67816b13b3acc.=1, file-hash-drift: Target file hash sha256:5cd6085fbd981f389119f6dce48b05c364399188eff406a4dde67816b13b3acc does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=1, file-hash-drift: Target file hash sha256:c9fe7064a49fff77caef8468617e2cc2a0c8b1bbf9c66bb1492d4698eb9ad7a9 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:aea596abc6079b9f2263f704067db3c3eb23d5aa013da1c7dc691365068de568 does not match proposal fileBeforeHash sha256:9e74f5d57908514b27b7747a43ff1f9e6c348288dd4f0cc5517b5583ac0987bc.=1, file-hash-drift: Target file hash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:239e4416c1257fc96fe30b0dc43014f2852bebbfade38088b5c4f3b0dd2a0ecc does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, cold_queue=1 |
| no_conflict | hot_provisional=3, cold_queue=2, composer_merge=2 |
| hot_provisional | cold_queue=13, composer_merge=9, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=158058, duration_ms=699.86
