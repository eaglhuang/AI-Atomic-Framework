# atm-bench export — r3m-e4-hot_conflict-fault_nolock-p8-s11-old

- run_id: `r3m-e4-hot_conflict-fault_nolock-p8-s11-old` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 160086 | — |
| duration_ms | 654.64 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=18, commit=18 | — |
| committed | 18 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 200% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 655.25 | — |
| throughput intents/s | 54.94 | — |
| goodput oracle-pass/s | 54.94 | — |
| latency_ms mean / p50 / p95 | 15.69 / 11.62 / 40.71 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 79.29 / 22.84 / 230.57 | — |
| total_ms mean / p50 / p95 | 113.61 / 69.08 / 288.03 | — |
| overhead_ms mean / p50 / p95 | 95.37 / 53.86 / 262.81 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:1113169808fd50422370255f2ea51bee822fefc661886c79e435ae14cd4f52d0 does not match proposal fileBeforeHash sha256:8c216388953701b12d61d028759ce591ecc95302af8efa5fcb6972ab0ef82943.=3, file-hash-drift: Target file hash sha256:384fbfffc5e2646c66c5666eec260adf7a52805dce49844cc9d3c70e754fbee1 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=3, file-hash-drift: Target file hash sha256:882d51de8a214330e034cd5a44a3a1d097a63f4bef13f1305e8b3e999f14e917 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:cb5ae0ec4af3b73ee66b37cf663cea480bc0b9a4b048ac4b929529a70b158380 does not match proposal fileBeforeHash sha256:7b59fdbea6999a8886581851af8014c165d80350b37c1e74e9d1b73d31d9a4f2.=2, file-hash-drift: Target file hash sha256:36b3c423885be8e26d65f5ba79f4fba81e5360063e596db075318247214f64c7 does not match proposal fileBeforeHash sha256:882d51de8a214330e034cd5a44a3a1d097a63f4bef13f1305e8b3e999f14e917.=1, file-hash-drift: Target file hash sha256:7b59fdbea6999a8886581851af8014c165d80350b37c1e74e9d1b73d31d9a4f2 does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=1, file-hash-drift: Target file hash sha256:214acd25ac768b72cb01dffc75b8643c7b307f8132e8d29269ca2afcf5959885 does not match proposal fileBeforeHash sha256:cb5ae0ec4af3b73ee66b37cf663cea480bc0b9a4b048ac4b929529a70b158380.=1, file-hash-drift: Target file hash sha256:cf43580334c3b394b2315645e2d4b82b5e104b43538a444498d618ea3940f8f1 does not match proposal fileBeforeHash sha256:7b59fdbea6999a8886581851af8014c165d80350b37c1e74e9d1b73d31d9a4f2.=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:86e9c1bca23eed69d0ed54089b6812ace66d4eaa160fa667acc3372fdfc3e954 does not match proposal fileBeforeHash sha256:cf43580334c3b394b2315645e2d4b82b5e104b43538a444498d618ea3940f8f1.=1, file-hash-drift: Target file hash sha256:36b3c423885be8e26d65f5ba79f4fba81e5360063e596db075318247214f64c7 does not match proposal fileBeforeHash sha256:186dc275eed9fe5c247e1569bcb5e4474d13b078b602b594b62f60a39091f1f2.=1, file-hash-drift: Target file hash sha256:186dc275eed9fe5c247e1569bcb5e4474d13b078b602b594b62f60a39091f1f2 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:8c216388953701b12d61d028759ce591ecc95302af8efa5fcb6972ab0ef82943 does not match proposal fileBeforeHash sha256:ac417e9fb1ee8f6d68f20ff1226419e7c425ef92f53098280fee5f6eb522a99d.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=16, composer_merge=10, hot_provisional=2 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=160086, duration_ms=654.64
