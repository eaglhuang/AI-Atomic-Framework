# atm-bench export — r3m-e4-hot_conflict-fault_naive-p8-s11-old

- run_id: `r3m-e4-hot_conflict-fault_naive-p8-s11-old` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157825 | — |
| duration_ms | 678 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 5 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 678.59 | — |
| throughput intents/s | 53.05 | — |
| goodput oracle-pass/s | 53.05 | — |
| latency_ms mean / p50 / p95 | 12.02 / 10 / 29.97 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 80.56 / 19.1 / 251.9 | — |
| total_ms mean / p50 / p95 | 111.26 / 58.67 / 307.39 | — |
| overhead_ms mean / p50 / p95 | 93.01 / 34.93 / 281.62 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 14 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:e691b8cd85d8bf178c0fc74f79b3d178ab248ceba1aa73159c8c80c66a19c638 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=4, file-hash-drift: Target file hash sha256:2472b5cb156d430d0c0e9dd1aadc46b522939c5cbbc8be78b45012a8615a9598 does not match proposal fileBeforeHash sha256:af2a3f003abbb5abc94100527d6d4e2f1d78b590000efc0b42c55f804d2155d6.=2, file-hash-drift: Target file hash sha256:e691b8cd85d8bf178c0fc74f79b3d178ab248ceba1aa73159c8c80c66a19c638 does not match proposal fileBeforeHash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79.=2, file-hash-drift: Target file hash sha256:5c9bd92672505049119a08881eeb0531d152b3b8287fe633538bf903a1d52ae4 does not match proposal fileBeforeHash sha256:e691b8cd85d8bf178c0fc74f79b3d178ab248ceba1aa73159c8c80c66a19c638.=1, atm_compose=1, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:45d2b238e75253b315b990abaf1086b7f10d6eb102b15264a34e448f851e34db does not match proposal fileBeforeHash sha256:e9bdf0576d7f90bbf1ae0cba933662e090b12a08478156e7c1260684b6ef16b4.=1, file-hash-drift: Target file hash sha256:7e6073e3fa4fecdeed65b6e4c0e3dff6d22c8b791c136e0212e1ff5fa0643830 does not match proposal fileBeforeHash sha256:83033cf76f9593b6aba008075a0bf85ad2cf5b7c818021d0bc0a1e4f87ca275f.=1, file-hash-drift: Target file hash sha256:b020ebab995e01eab1afc81cab7fdf994b1daf242954294b90a5422db50c57e4 does not match proposal fileBeforeHash sha256:7e6073e3fa4fecdeed65b6e4c0e3dff6d22c8b791c136e0212e1ff5fa0643830.=1, file-hash-drift: Target file hash sha256:4d729243781ab3efbe593dc5b11b0e15fd6b9807cd16b739cd7dfb05fca8c355 does not match proposal fileBeforeHash sha256:a0267eda2ff7d974f9c1f37a8e7a0acbea4590154e44f554941f63c7a5283761.=1, canonical target base hash is stale: src/routes.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=14, composer_merge=10, hot_provisional=4 |
| no_conflict | hot_provisional=2, composer_merge=2, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157825, duration_ms=678
