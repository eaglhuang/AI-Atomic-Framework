# atm-bench export — r3m-e4-hot_conflict-fault_naive-p8-s23-old

- run_id: `r3m-e4-hot_conflict-fault_naive-p8-s23-old` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157110 | — |
| duration_ms | 691.24 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 35 | — |
| lost updates (oracle fail) | 1 | — |
| integration pass rate of committed | 159.1% | — |
| effective success rate of all intents | 97.2% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 12 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 6 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 688.4 | — |
| throughput intents/s | 52.3 | — |
| goodput oracle-pass/s | 50.84 | — |
| latency_ms mean / p50 / p95 | 11.36 / 6.07 / 31.13 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 82.24 / 18.84 / 250.64 | — |
| total_ms mean / p50 / p95 | 110.42 / 53.2 / 288.4 | — |
| overhead_ms mean / p50 / p95 | 93.98 / 37.01 / 274.29 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 12 | 0 | 0 |
| cold_queue | 12 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=10, atm_serial_queue=10, file-hash-drift: Target file hash sha256:c94c2133c5c676b66e5405b449eda686f555669243f9ead24e502b9b298b8a0a does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=3, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:30553d53bebfcc6b277677d78437e11b810716c8bc9525a09600f73f74bda8ee does not match proposal fileBeforeHash sha256:0a94fa72d1574b484fca21f31871960becab1962b1023db36ad1858a8a591c03.=2, file-hash-drift: Target file hash sha256:68a8ebec96a8af503a43a06bc9dfafa2efe2b5229b3543d6739ce943c8f9b10a does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:68a8ebec96a8af503a43a06bc9dfafa2efe2b5229b3543d6739ce943c8f9b10a does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:c491df7099a2e740eec4d66c402e4925a49df68314817a8ff334b50923f5df19 does not match proposal fileBeforeHash sha256:3644766bab82acac7b5b9924e490022e86769e1afb3ef303aadb98a23d763f5c.=1, file-hash-drift: Target file hash sha256:8215f56f951d6aadddd1bc1facc1c62736f6e81aae419dc8d43edc7b53ac0a74 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:30553d53bebfcc6b277677d78437e11b810716c8bc9525a09600f73f74bda8ee does not match proposal fileBeforeHash sha256:a1c83621ce9692ca4d39b701bb443958cd57235e7e754b66e77d9c3f67032173.=1, file-hash-drift: Target file hash sha256:0a94fa72d1574b484fca21f31871960becab1962b1023db36ad1858a8a591c03 does not match proposal fileBeforeHash sha256:c94c2133c5c676b66e5405b449eda686f555669243f9ead24e502b9b298b8a0a.=1, file-hash-drift: Target file hash sha256:8215f56f951d6aadddd1bc1facc1c62736f6e81aae419dc8d43edc7b53ac0a74 does not match proposal fileBeforeHash sha256:3027d69e788dda1f2c28f8483fe82e4400c6d61d9e23e65be9ea91f58cdc2e72.=1, file-hash-drift: Target file hash sha256:b9824ed27c0934cf6a4c2dcec141cece17b000f92a4670c26536564ad880a5ad does not match proposal fileBeforeHash sha256:c491df7099a2e740eec4d66c402e4925a49df68314817a8ff334b50923f5df19.=1, file-hash-drift: Target file hash sha256:0a94fa72d1574b484fca21f31871960becab1962b1023db36ad1858a8a591c03 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, hot_provisional=1 |
| no_conflict | hot_provisional=5, composer_merge=2 |
| hot_provisional | cold_queue=12, composer_merge=7, hot_provisional=6 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157110, duration_ms=691.24
