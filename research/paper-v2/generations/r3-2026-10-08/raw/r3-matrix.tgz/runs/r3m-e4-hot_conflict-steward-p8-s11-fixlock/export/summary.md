# atm-bench export — r3m-e4-hot_conflict-steward-p8-s11-fixlock

- run_id: `r3m-e4-hot_conflict-steward-p8-s11-fixlock` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=8 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157787 | — |
| duration_ms | 1068.95 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 6 | — |
| CAS rebase on apply | 3 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 1068.63 | — |
| throughput intents/s | 33.69 | — |
| goodput oracle-pass/s | 33.69 | — |
| latency_ms mean / p50 / p95 | 10.74 / 6.66 / 33.66 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 133.05 / 19.15 / 587.18 | — |
| total_ms mean / p50 / p95 | 162.39 / 47.48 / 634.17 | — |
| overhead_ms mean / p50 / p95 | 144.21 / 26.48 / 608.91 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 6 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| hot_provisional | 14 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=14, atm_serial_queue=5, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=4, file-hash-drift: Target file hash sha256:77a9eb4d5d30a4fda1978454739008de53805abdf0afa00704e9b882b416c3b5 does not match proposal fileBeforeHash sha256:315d2a390cd98e58aafab98d52a8fd6cdbd2697611bf0b4f7de4d63e12963313.=2, file-hash-drift: Target file hash sha256:fca18fb7e41be79e6063d8ae364f38bceda81b0c097702ae4a83ea4e1949298f does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:315d2a390cd98e58aafab98d52a8fd6cdbd2697611bf0b4f7de4d63e12963313 does not match proposal fileBeforeHash sha256:0205191f1007d47bd000acb202e5d5269b7759e42e2c45642edd6f31b4508a22.=1, file-hash-drift: Target file hash sha256:d14f411fbeafea1d00319fe392d034f05913962cbbac9f9458948b3f6aa7eb98 does not match proposal fileBeforeHash sha256:600bb99e9d0f5fa748ef56881b85336314f19fbe9bf7b7b2369d532498f84457.=1, file-hash-drift: Target file hash sha256:fca18fb7e41be79e6063d8ae364f38bceda81b0c097702ae4a83ea4e1949298f does not match proposal fileBeforeHash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79.=1, file-hash-drift: Target file hash sha256:600bb99e9d0f5fa748ef56881b85336314f19fbe9bf7b7b2369d532498f84457 does not match proposal fileBeforeHash sha256:cfc355d29894e2edd243889e1fb00fb53bf395794ae53ad20cbdbf1db3e09514.=1, file-hash-drift: Target file hash sha256:0da51d8d1de142d64660ccae93e825d728595a10a4e0eb23f89481577508bbea does not match proposal fileBeforeHash sha256:17b48b95fa6586c6f95c2d5e9bb6ccaf5ef8dfc964872448eb30d69d8ca44b96.=1, atm_compose=1, file-hash-drift: Target file hash sha256:a37401ca7bdc900c5305c5c5cd2131b78d60da00c80814b2b89529668a2e8c83 does not match proposal fileBeforeHash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79.=1, file-hash-drift: Target file hash sha256:0da51d8d1de142d64660ccae93e825d728595a10a4e0eb23f89481577508bbea does not match proposal fileBeforeHash sha256:bc192d09b6bb7a4c65401dbed7173c38d82f986135c08df12b93bcb8209cd34a.=1, file-hash-drift: Target file hash sha256:bc192d09b6bb7a4c65401dbed7173c38d82f986135c08df12b93bcb8209cd34a does not match proposal fileBeforeHash sha256:17b48b95fa6586c6f95c2d5e9bb6ccaf5ef8dfc964872448eb30d69d8ca44b96.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | hot_provisional=2, composer_merge=1 |
| hot_provisional | cold_queue=15, hot_provisional=9, composer_merge=4 |
| no_conflict | hot_provisional=3, composer_merge=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157787, duration_ms=1068.95
