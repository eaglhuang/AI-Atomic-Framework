# atm-bench export — r3m-e4-hot_conflict-steward-p8-s23-fixlock

- run_id: `r3m-e4-hot_conflict-steward-p8-s23-fixlock` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=8 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157456 | — |
| duration_ms | 859.26 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 171.4% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 12 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 3 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 856.91 | — |
| throughput intents/s | 42.01 | — |
| goodput oracle-pass/s | 42.01 | — |
| latency_ms mean / p50 / p95 | 11.86 / 7.28 / 30.41 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 117.81 / 110.14 / 423.52 | — |
| total_ms mean / p50 / p95 | 146.59 / 122.77 / 476.7 | — |
| overhead_ms mean / p50 / p95 | 130.09 / 113.41 / 447.98 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| hot_provisional | 14 | 0 | 0 |
| cold_queue | 12 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=14, atm_serial_queue=6, file-hash-drift: Target file hash sha256:a67d81b7ae41111ff8b057ee3a1ddab7d5ea04aa15e49f18746f433a12df16e3 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=2, file-hash-drift: Target file hash sha256:a6c45eb54812fed190906e5fce5a0895073b92d793f87ed5ee2c133d296e3495 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:a47f9095838e7dbb6798d65a95094f9e98afda38720b3fed663a24938f197c2d does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=2, file-hash-drift: Target file hash sha256:7d808fa92765ea0125d9116545584164066983d40b9f2d4df4c38af9d5d02acd does not match proposal fileBeforeHash sha256:c01b531aa4299fc6c14e84526825b1b918e806816d29112e3df95544474d6c1d.=2, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, atm_compose=1, file-hash-drift: Target file hash sha256:b5af9beddd2a2d3b569dcd3bf10e3f45a980ecc8deaa8d56e2c697ac6e929c6f does not match proposal fileBeforeHash sha256:a7f11191c53d05521e1f75f09a61377145caa82f272182a44c29d7096157b459.=1, file-hash-drift: Target file hash sha256:28feb2d4a5f69496dbb5507c7f8ebe2e16597dd16011546f1240051b832727d2 does not match proposal fileBeforeHash sha256:b5af9beddd2a2d3b569dcd3bf10e3f45a980ecc8deaa8d56e2c697ac6e929c6f.=1, file-hash-drift: Target file hash sha256:a6c45eb54812fed190906e5fce5a0895073b92d793f87ed5ee2c133d296e3495 does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=1, file-hash-drift: Target file hash sha256:a47f9095838e7dbb6798d65a95094f9e98afda38720b3fed663a24938f197c2d does not match proposal fileBeforeHash sha256:a6c45eb54812fed190906e5fce5a0895073b92d793f87ed5ee2c133d296e3495.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=5, cold_queue=2 |
| hot_provisional | cold_queue=10, hot_provisional=9, composer_merge=6 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157456, duration_ms=859.26
