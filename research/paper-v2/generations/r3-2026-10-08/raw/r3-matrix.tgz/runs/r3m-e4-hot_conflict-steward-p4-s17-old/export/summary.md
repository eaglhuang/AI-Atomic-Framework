# atm-bench export — r3m-e4-hot_conflict-steward-p4-s17-old

- run_id: `r3m-e4-hot_conflict-steward-p4-s17-old` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 148707 | — |
| duration_ms | 642.69 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=15 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 178.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 12 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 8 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 641.78 | — |
| throughput intents/s | 52.98 | — |
| goodput oracle-pass/s | 52.98 | — |
| latency_ms mean / p50 / p95 | 8.85 / 5.8 / 22.32 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 67.23 / 73.3 / 127.95 | — |
| total_ms mean / p50 / p95 | 106.48 / 131.62 / 249.64 | — |
| overhead_ms mean / p50 / p95 | 76.41 / 94.94 / 160.33 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 14 | 0 | 0 |
| cold_queue | 12 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=8, atm_serial_queue=7, file-hash-drift: Target file hash sha256:e2a35d288db6ce4669cad008e61ff9a2e039713eb0ad1f140d1b579ed3e0f6c0 does not match proposal fileBeforeHash sha256:83d246f0d84d86e617ae5dd15517ad51b3cb4005da587bc9ecf3114a3e666a16.=3, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:2593170bee40a85ecc1d731e698853ccce7b2d739060f2795ee4e4187063ef61 does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=2, file-hash-drift: Target file hash sha256:16f0d1a08b1f142ccc0166411d74119e266091800e95ba8f2c6c3f8cd60ba928 does not match proposal fileBeforeHash sha256:e2a35d288db6ce4669cad008e61ff9a2e039713eb0ad1f140d1b579ed3e0f6c0.=2, file-hash-drift: Target file hash sha256:6dd5b629756cfec731d678a9ebb6cd153c7ad6a11a2a0df6400b8335bd775348 does not match proposal fileBeforeHash sha256:6506ac404ddcc8871747c656f3b3ebd2637ef02ab001c4652c06d41e4ab667dd.=2, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:ab7bfa3a39d8849e25d6ca26ff3b72fd3509318f3ebf21966b8229c041f752ec does not match proposal fileBeforeHash sha256:5cea537c358f071e2cd29e85cd4c6cd59fe5f8b926e2ad194fbcc9897dcee731.=1, file-hash-drift: Target file hash sha256:8180173467adc5808c1b9454369f5a06f639e4f739e7cd4198a357e228f9dae0 does not match proposal fileBeforeHash sha256:2593170bee40a85ecc1d731e698853ccce7b2d739060f2795ee4e4187063ef61.=1, atm_compose=1, file-hash-drift: Target file hash sha256:5cea537c358f071e2cd29e85cd4c6cd59fe5f8b926e2ad194fbcc9897dcee731 does not match proposal fileBeforeHash sha256:3828a70918f2c7bf047878a63501253555f4ea244a7d7fb1affd4d56d9b08834.=1, canonical target base hash is stale: src/config.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=12, composer_merge=11, hot_provisional=3 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | hot_provisional=2, composer_merge=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=148707, duration_ms=642.69
