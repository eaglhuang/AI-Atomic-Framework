# atm-bench export — r3m-e4-hot_conflict-steward-p2-s23-old

- run_id: `r3m-e4-hot_conflict-steward-p2-s23-old` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 161341 | — |
| duration_ms | 488.97 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=18, commit=18 | — |
| committed | 18 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 200% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 11 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 485.92 | — |
| throughput intents/s | 74.09 | — |
| goodput oracle-pass/s | 74.09 | — |
| latency_ms mean / p50 / p95 | 5.33 / 3.33 / 17.86 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 30.03 / 14.2 / 125.42 | — |
| total_ms mean / p50 / p95 | 79.96 / 48.79 / 188.62 | — |
| overhead_ms mean / p50 / p95 | 36.18 / 20.31 / 140.26 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=8, atm_provisional_write_lease=7, steward-final-patch-required: proposals 'prop-s23-t001-i3' and 'prop-s23-t001-i5' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i3, prop-s23-t001-i5]=3, steward-final-patch-required: proposals 'prop-s23-t004-i1' and 'prop-s23-t004-i7' change overlapping base line 25 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s23-t004-i1, prop-s23-t004-i7]=2, steward-final-patch-required: proposals 'prop-s23-t001-i2' and 'prop-s23-t001-i4' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i2, prop-s23-t001-i4]=2, file-hash-drift: Target file hash sha256:fe196a0a1fb6399876a0e01aa75b8adeba81ce8e0910ca3ac482cd0a27c11b62 does not match proposal fileBeforeHash sha256:9b27528b1658c50259860dc939ba9ded2c8c1f5b943bfeb98dffe1e054376ae3.=2, file-hash-drift: Target file hash sha256:ad5bc66d83e1f0ae89ba6a98e318d1a9107535abb0dc1457accfe1cc2096ab3d does not match proposal fileBeforeHash sha256:1f042a51eadf9bd04c7d9d53931febbc1b53f2bb67c20902e26457d007500100.=2, file-hash-drift: Target file hash sha256:ddfbcbf2a70af2ae50820e7b93da7a17abc62f4a28c5b00153295b1b192934bf does not match proposal fileBeforeHash sha256:bb4f7a30c6eff34677f7b8abcaa03e545ce0af341fb401f863442d0ce52d9aa9.=2, file-hash-drift: Target file hash sha256:fb0d96fe57cf3dbd000e9552f0cf7611021443e8c008bcaef3a054e4c476fa8a does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:9b27528b1658c50259860dc939ba9ded2c8c1f5b943bfeb98dffe1e054376ae3 does not match proposal fileBeforeHash sha256:fb0d96fe57cf3dbd000e9552f0cf7611021443e8c008bcaef3a054e4c476fa8a.=1, atm_provisional_write_lease+cas_rebase=1, file-hash-drift: Target file hash sha256:4898941dd67203880d4d2a075040d7ea91621a05baf31e76296089c4733d2720 does not match proposal fileBeforeHash sha256:1c63e1f876dd389863517bc9eed734bb9a44a8e5ec9a8862779af140e742b53e.=1, file-hash-drift: Target file hash sha256:1c63e1f876dd389863517bc9eed734bb9a44a8e5ec9a8862779af140e742b53e does not match proposal fileBeforeHash sha256:fe196a0a1fb6399876a0e01aa75b8adeba81ce8e0910ca3ac482cd0a27c11b62.=1, atm_compose=1, atm_compose+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, hot_provisional=1 |
| no_conflict | hot_provisional=3, cold_queue=3, composer_merge=1 |
| hot_provisional | cold_queue=14, composer_merge=7, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=161341, duration_ms=488.97
