# atm-bench export — r3m-e4-hot_conflict-steward-p8-s11-fix

- run_id: `r3m-e4-hot_conflict-steward-p8-s11-fix` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=8 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156983 | — |
| duration_ms | 694.7 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 6 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 694.28 | — |
| throughput intents/s | 51.85 | — |
| goodput oracle-pass/s | 51.85 | — |
| latency_ms mean / p50 / p95 | 14.4 / 8.24 / 37.74 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 75.1 / 22.09 / 261.84 | — |
| total_ms mean / p50 / p95 | 108.43 / 58.65 / 315.59 | — |
| overhead_ms mean / p50 / p95 | 89.91 / 42.6 / 286.64 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| hot_provisional | 11 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=10, atm_serial_queue=8, file-hash-drift: Target file hash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=4, file-hash-drift: Target file hash sha256:17c05f0e3c26f09bd697649fd920dcfaee61c75ce0dcde7cab110f87e772b767 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:c9c564b16a085522b748079ddb0093f964abc7b599647d417f57eba23a4ec2b0 does not match proposal fileBeforeHash sha256:498062049b3744cd25204ba97be1238bf6aae79a57a3e54a551bfbb199aa5ed0.=2, file-hash-drift: Target file hash sha256:e02086cb54b95f8d804dbffc2baa2524ffd4eee358ab4c9fa54e51a9cc1686bb does not match proposal fileBeforeHash sha256:17c05f0e3c26f09bd697649fd920dcfaee61c75ce0dcde7cab110f87e772b767.=1, file-hash-drift: Target file hash sha256:5434eba9f7caa401f6885249518688e3947ec2159e7c63f2d38678b0baf56ba9 does not match proposal fileBeforeHash sha256:7ab76c4bc13ea586c46aa5775ea84e242511fd5a7a797351908a77fa3fba5f29.=1, canonical target base hash is stale: src/config.ts=1, compose-context-mismatch: proposal 'prop-s11-t002-i2' context mismatch at base line 16: expected "// </region:selectors>", found "// atm-edit s11-t002-i3 by cursor:mock-s3" [proposals: prop-s11-t002-i2]=1, file-hash-drift: Target file hash sha256:8c216388953701b12d61d028759ce591ecc95302af8efa5fcb6972ab0ef82943 does not match proposal fileBeforeHash sha256:ac417e9fb1ee8f6d68f20ff1226419e7c425ef92f53098280fee5f6eb522a99d.=1, atm_compose+cas_rebase=1, compose-context-mismatch: proposal 'prop-s11-t001-i3' context mismatch at base line 15: expected "// atm-edit s11-t000-i2 by codex:mock-s2", found "};" [proposals: prop-s11-t001-i3]=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:17c05f0e3c26f09bd697649fd920dcfaee61c75ce0dcde7cab110f87e772b767 does not match proposal fileBeforeHash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171.=1, file-hash-drift: Target file hash sha256:7ab76c4bc13ea586c46aa5775ea84e242511fd5a7a797351908a77fa3fba5f29 does not match proposal fileBeforeHash sha256:3852c7ec54e861f9b086c0265245a42e7a67d85cce6d5056918607b91b1fb8c6.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=14, composer_merge=7, hot_provisional=7 |
| no_conflict | hot_provisional=3, composer_merge=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156983, duration_ms=694.7
