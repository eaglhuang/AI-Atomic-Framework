# atm-bench export — r3m-e4-hot_conflict-steward-p4-s17-fix

- run_id: `r3m-e4-hot_conflict-steward-p4-s17-fix` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 150468 | — |
| duration_ms | 657.18 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=15 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 178.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 12 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 656.7 | — |
| throughput intents/s | 51.77 | — |
| goodput oracle-pass/s | 51.77 | — |
| latency_ms mean / p50 / p95 | 8.83 / 5.84 / 23.63 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 58.59 / 17.51 / 139.39 | — |
| total_ms mean / p50 / p95 | 96.22 / 59.31 / 183.23 | — |
| overhead_ms mean / p50 / p95 | 68.29 / 29.87 / 162.43 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 12 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| composer_merge | 14 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=8, atm_serial_queue=7, atm_compose=4, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 20 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=2, steward-final-patch-required: proposals 'prop-s17-t003-i1' and 'prop-s17-t003-i4' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s17-t003-i1, prop-s17-t003-i4]=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 20 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, file-hash-drift: Target file hash sha256:c2871b69c6ac22c66f035d44a61422cd18820f6dd37f251f4a1369089825fd0f does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=2, file-hash-drift: Target file hash sha256:e23a6a4c2b994f1d7aa0b30738390fe146de76813db4232d464fb49c81f37db0 does not match proposal fileBeforeHash sha256:a482e4b4bd932652d53d7e1ef2f17a4aa48fc3b0bba6a73da15c00b21a26fbbf.=1, file-hash-drift: Target file hash sha256:85f71f170adc2a22338b61096ad4e2d77bbe237df8da373040bf2cf2ba07a0ad does not match proposal fileBeforeHash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da.=1, file-hash-drift: Target file hash sha256:a482e4b4bd932652d53d7e1ef2f17a4aa48fc3b0bba6a73da15c00b21a26fbbf does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=1, file-hash-drift: Target file hash sha256:ed8cd9cf7ca20cdc58f8df4b9f18f95bc52c36d13cf1f312f3ebd0fc93b81d49 does not match proposal fileBeforeHash sha256:e23a6a4c2b994f1d7aa0b30738390fe146de76813db4232d464fb49c81f37db0.=1, file-hash-drift: Target file hash sha256:6506ac404ddcc8871747c656f3b3ebd2637ef02ab001c4652c06d41e4ab667dd does not match proposal fileBeforeHash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:0ba7d09c570c2c49198e5c7ed56113aa6cecb1b9f71f58d917fdebf688bdb0b7 does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=12, composer_merge=9, hot_provisional=5 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=150468, duration_ms=657.18
