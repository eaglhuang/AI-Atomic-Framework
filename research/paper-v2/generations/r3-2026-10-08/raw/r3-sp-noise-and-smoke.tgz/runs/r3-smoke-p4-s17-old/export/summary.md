# atm-bench export — r3-smoke-p4-s17-old

- run_id: `r3-smoke-p4-s17-old` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 146516 | — |
| duration_ms | 791.18 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=15 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 178.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 12 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 10 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 789.05 | — |
| throughput intents/s | 43.09 | — |
| goodput oracle-pass/s | 43.09 | — |
| latency_ms mean / p50 / p95 | 16.31 / 6.41 / 76.46 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 80.69 / 25.19 / 256.94 | — |
| total_ms mean / p50 / p95 | 145.07 / 79.17 / 389.94 | — |
| overhead_ms mean / p50 / p95 | 97.6 / 34.88 / 301.17 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| cold_queue | 12 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=9, atm_serial_queue=7, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:948f5ffa597e705ce9a8feb5267cbac76d8ba7199b30b8344d0dc13d8c43d9ff does not match proposal fileBeforeHash sha256:c8d73a3c9a6d2cc305fc00908539024c66273152b37ec0aa75e5d44edd5a017f.=2, steward-final-patch-required: proposals 'prop-s17-t003-i1' and 'prop-s17-t003-i4' change overlapping base line 18 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s17-t003-i1, prop-s17-t003-i4]=2, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:6506ac404ddcc8871747c656f3b3ebd2637ef02ab001c4652c06d41e4ab667dd does not match proposal fileBeforeHash sha256:b3f0a71f47125981dad14761138c3a465a9b41241651c0eaa7b6726388f80b52.=2, file-hash-drift: Target file hash sha256:a96017408335168cf12d71143dab5acdf85a7ccc519ca9522491c73f7d78532b does not match proposal fileBeforeHash sha256:08cea73b6bb1e4b68679c6ed518c7ce88406ed3094e7488d8969d6fb3a76f89e.=2, file-hash-drift: Target file hash sha256:c8d73a3c9a6d2cc305fc00908539024c66273152b37ec0aa75e5d44edd5a017f does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:08cea73b6bb1e4b68679c6ed518c7ce88406ed3094e7488d8969d6fb3a76f89e does not match proposal fileBeforeHash sha256:c25c42d259657b59c4872d127d6666695bb5f265f3bf6c6c4aee78e69d47d689.=1, file-hash-drift: Target file hash sha256:c25c42d259657b59c4872d127d6666695bb5f265f3bf6c6c4aee78e69d47d689 does not match proposal fileBeforeHash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef.=1, file-hash-drift: Target file hash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:c8d73a3c9a6d2cc305fc00908539024c66273152b37ec0aa75e5d44edd5a017f does not match proposal fileBeforeHash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=11, composer_merge=8, hot_provisional=7 |
| no_conflict | composer_merge=2, hot_provisional=1, cold_queue=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=146516, duration_ms=791.18
