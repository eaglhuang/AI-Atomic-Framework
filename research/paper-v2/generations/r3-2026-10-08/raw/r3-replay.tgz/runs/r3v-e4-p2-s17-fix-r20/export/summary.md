# atm-bench export — r3v-e4-p2-s17-fix-r20

- run_id: `r3v-e4-p2-s17-fix-r20` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 145418 | — |
| duration_ms | 549.93 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 8 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 548.83 | — |
| throughput intents/s | 61.95 | — |
| goodput oracle-pass/s | 61.95 | — |
| latency_ms mean / p50 / p95 | 6.11 / 3.94 / 13.68 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 31.24 / 18.41 / 121.6 | — |
| total_ms mean / p50 / p95 | 81.89 / 51.07 / 186.42 | — |
| overhead_ms mean / p50 / p95 | 38.39 / 25.62 / 142.27 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 15 | 0 | 0 |
| composer_merge | 11 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:f7d204f9a38819f475846ea62b1171475e67dc320291dc943f151117a6752825 does not match proposal fileBeforeHash sha256:2a1bfc48d8fbe760b8edcf557cb9730f4fe4b1a1f71d064a866130f5046f896c.=3, atm_compose=3, file-hash-drift: Target file hash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=2, steward-final-patch-required: proposals 'prop-s17-t004-i1' and 'prop-s17-t004-i4' change overlapping base line 10 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t004-i1, prop-s17-t004-i4]=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, canonical target base hash is stale: src/routes.ts=2, canonical target base hash is stale: src/config.ts=1, compose-context-mismatch: proposal 'prop-s17-t000-i0' context mismatch at base line 8: expected "// </region:reducers>", found "// atm-edit s17-t000-i6 by other:mock-s7" [proposals: prop-s17-t000-i0]=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:fa76ff85beb3b6dbe567dd36e5eaf463183e2b837cbba28068e7775ef88e51c2 does not match proposal fileBeforeHash sha256:2fa143f234300d3c307cb08ba884104c029705318378c9871e56e63b9312f4e2.=1, atm_provisional_write_lease+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=14, composer_merge=7, hot_provisional=5 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=145418, duration_ms=549.93
