# atm-bench export — r3v-e4-p2-s11-g-fixlock-r5

- run_id: `r3v-e4-p2-s11-g-fixlock-r5` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 155814 | — |
| duration_ms | 695.98 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 16 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 696.19 | — |
| throughput intents/s | 51.71 | — |
| goodput oracle-pass/s | 51.71 | — |
| latency_ms mean / p50 / p95 | 5.24 / 3.8 / 14.72 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 47.12 / 18.44 / 122.82 | — |
| total_ms mean / p50 / p95 | 106.63 / 55.43 / 266.83 | — |
| overhead_ms mean / p50 / p95 | 53.1 / 25.91 / 140.55 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:ad2d87a57e4b7f570e27bbee43ba584553e42e1384bc6d31ba0038c943aaf646 does not match proposal fileBeforeHash sha256:1e98a9e8125859adabcf747a447b096b3e5f22b3851500ad52a1187fe5ab27f9.=3, file-hash-drift: Target file hash sha256:3b197c6bdc30950dacc14d9621c796153fedaf4363f4d12ad3e2ddd9d221e760 does not match proposal fileBeforeHash sha256:3038289f914a3090be47e68fff94401c7058175f1823523534afa67cd27a4755.=2, atm_compose=2, steward-final-patch-required: proposals 'prop-s11-t002-i2' and 'prop-s11-t002-i4' change overlapping base line 15 of src/store.ts; a steward-authored final patch is required [proposals: prop-s11-t002-i2, prop-s11-t002-i4]=2, file-hash-drift: Target file hash sha256:5864bfd226f2a186433693256939d8f6f35c6c7dba401297e528a7fd380888ab does not match proposal fileBeforeHash sha256:88b2d0f06285e7fdb75fffce0d8c75e1aac31654fd86ab35725e398be86929a0.=2, steward-final-patch-required: proposals 'prop-s11-t000-i0' and 'prop-s11-t002-i6' change overlapping base line 22 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t000-i0, prop-s11-t002-i6]=2, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:bd506f0a8f8f19c4e413569ae6efcd0d3805dc84d99b4066c513cee1b6e85cdc does not match proposal fileBeforeHash sha256:3b197c6bdc30950dacc14d9621c796153fedaf4363f4d12ad3e2ddd9d221e760.=1, file-hash-drift: Target file hash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=14, composer_merge=9, hot_provisional=5 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=155814, duration_ms=695.98
