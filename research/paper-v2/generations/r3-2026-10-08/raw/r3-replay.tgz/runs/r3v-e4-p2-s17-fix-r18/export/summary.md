# atm-bench export — r3v-e4-p2-s17-fix-r18

- run_id: `r3v-e4-p2-s17-fix-r18` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 148956 | — |
| duration_ms | 576.67 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=15 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 178.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 575.84 | — |
| throughput intents/s | 59.04 | — |
| goodput oracle-pass/s | 59.04 | — |
| latency_ms mean / p50 / p95 | 5.95 / 3.86 / 17.34 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 35.47 / 15.74 / 117.56 | — |
| total_ms mean / p50 / p95 | 84.17 / 52.6 / 180.29 | — |
| overhead_ms mean / p50 / p95 | 42.23 / 26.32 / 125.18 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 14 | 0 | 0 |
| composer_merge | 11 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=8, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:8093cc60500b135af7549c34aa4a8612113e2a65a18b4168e382871ac5c4e734 does not match proposal fileBeforeHash sha256:7094f1c9f85bfcb2abc8b7ffa086805c58b664e8c56a01012e1a7b2f974c0c63.=3, steward-final-patch-required: proposals 'prop-s17-t003-i1' and 'prop-s17-t003-i4' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s17-t003-i1, prop-s17-t003-i4]=3, steward-final-patch-required: proposals 'prop-s17-t004-i1' and 'prop-s17-t004-i4' change overlapping base line 10 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t004-i1, prop-s17-t004-i4]=2, file-hash-drift: Target file hash sha256:df0dd3dfc1d96c12507a95e9c03c891376fccd689ecab8d27e5e8f8f99b0b05b does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=2, file-hash-drift: Target file hash sha256:4e3e25f147d1dd6decbb9268a8c469fcc74541dcd0c7fa6ec5142d9f3f9f55f1 does not match proposal fileBeforeHash sha256:01b92172857f35d95a60d061c3de5895d42e213981a27d401cd879c325ab4051.=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:01b92172857f35d95a60d061c3de5895d42e213981a27d401cd879c325ab4051 does not match proposal fileBeforeHash sha256:df0dd3dfc1d96c12507a95e9c03c891376fccd689ecab8d27e5e8f8f99b0b05b.=1, atm_provisional_write_lease+cas_rebase=1, compose-context-mismatch: proposal 'prop-s17-t002-i5' context mismatch at base line 19: expected "};", found "  backend: 'memory'," [proposals: prop-s17-t002-i5]=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, hot_provisional=7, composer_merge=6 |
| no_conflict | composer_merge=2, cold_queue=1, hot_provisional=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=148956, duration_ms=576.67
