# atm-bench export — r3v-e4-p2-s11-g-fix-r2

- run_id: `r3v-e4-p2-s11-g-fix-r2` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154469 | — |
| duration_ms | 548.31 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 171.4% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 20 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 21 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 548.35 | — |
| throughput intents/s | 65.65 | — |
| goodput oracle-pass/s | 65.65 | — |
| latency_ms mean / p50 / p95 | 5.61 / 3.56 / 18.15 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 39.55 / 14.43 / 125.07 | — |
| total_ms mean / p50 / p95 | 91.22 / 56.95 / 182.69 | — |
| overhead_ms mean / p50 / p95 | 45.92 / 19.93 / 140.58 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 20 | 0 | 0 |
| hot_provisional | 5 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=5, steward-final-patch-required: proposals 'prop-s11-t001-i3' and 'prop-s11-t001-i5' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t001-i3, prop-s11-t001-i5]=3, canonical target base hash is stale: src/store.ts=3, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:7ab1c6d1fd6c584cdbbbac642aad4caae4330119a886d1631b1b2bae4a1b0053 does not match proposal fileBeforeHash sha256:756a49e3ea470179bc9be5133ce63e3dc37a8e1059f96f372d0c46738786aafe.=2, steward-final-patch-required: proposals 'prop-s11-t002-i2' and 'prop-s11-t003-i5' change overlapping base line 15 of src/store.ts; a steward-authored final patch is required [proposals: prop-s11-t002-i2, prop-s11-t003-i5]=2, file-hash-drift: Target file hash sha256:173692fcc448fa0a8d0df44050556935ef9179fe928ada304a66276e93bbb8de does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=2, compose-context-mismatch: proposal 'prop-s11-t004-i1' context mismatch at base line 32: expected "// atm-edit s11-t004-i4 by claude:mock-s4", found "// atm-edit s11-t004-i5 by codex:mock-s5" [proposals: prop-s11-t004-i1]=1, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:2850981c9c6720d7c9c07d0d678d6f4629f7fb7128875cabd2969a0dc8f716f0 does not match proposal fileBeforeHash sha256:ac417e9fb1ee8f6d68f20ff1226419e7c425ef92f53098280fee5f6eb522a99d.=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=18, composer_merge=9, hot_provisional=1 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154469, duration_ms=548.31
