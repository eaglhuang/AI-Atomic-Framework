# atm-bench export — r3v-e4-p2-s11-g-old-r4

- run_id: `r3v-e4-p2-s11-g-old-r4` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 153808 | — |
| duration_ms | 552.12 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 21 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 22 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 552.01 | — |
| throughput intents/s | 65.22 | — |
| goodput oracle-pass/s | 65.22 | — |
| latency_ms mean / p50 / p95 | 4.81 / 3.24 / 16.82 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 33.31 / 14.1 / 126.65 | — |
| total_ms mean / p50 / p95 | 81.33 / 53.48 / 178.24 | — |
| overhead_ms mean / p50 / p95 | 38.71 / 17.45 / 145.27 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 9 | 0 | 0 |
| cold_queue | 21 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=15, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:1eeb7e4c9aa0d47e19f58573c6725e066c90b322723b6394a9768e345a07c576 does not match proposal fileBeforeHash sha256:173692fcc448fa0a8d0df44050556935ef9179fe928ada304a66276e93bbb8de.=3, file-hash-drift: Target file hash sha256:855d5ace77de08e363a2fa6eb3d5fa2b0e924ca758333a32511b2dd5f5537c8f does not match proposal fileBeforeHash sha256:e0ba408eeb3018af227261d2c1aa262586a55c6d736b4088129d441f3e00add4.=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8 does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=2, file-hash-drift: Target file hash sha256:37d70a1bb46980284777813af98936ae8c496768102f6a1364e4445d8403c524 does not match proposal fileBeforeHash sha256:ff676eb00fd55db03dc591ae367167be2eaeabb09e44a6def287424ccec3e129.=2, file-hash-drift: Target file hash sha256:ff676eb00fd55db03dc591ae367167be2eaeabb09e44a6def287424ccec3e129 does not match proposal fileBeforeHash sha256:e820b9fb40fa58121ef1a8c692846240c3e1a10c77a7f6c72332aa57300447de.=1, canonical target base hash is stale: src/store.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=19, composer_merge=6, hot_provisional=3 |
| no_conflict | hot_provisional=2, cold_queue=2, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=153808, duration_ms=552.12
