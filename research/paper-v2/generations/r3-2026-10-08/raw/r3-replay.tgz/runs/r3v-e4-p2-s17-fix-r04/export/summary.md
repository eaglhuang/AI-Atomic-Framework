# atm-bench export — r3v-e4-p2-s17-fix-r04

- run_id: `r3v-e4-p2-s17-fix-r04` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 145404 | — |
| duration_ms | 558.66 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 161.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 19 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 557.53 | — |
| throughput intents/s | 60.98 | — |
| goodput oracle-pass/s | 60.98 | — |
| latency_ms mean / p50 / p95 | 6.24 / 4.02 / 16.17 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 34.15 / 16.14 / 126.57 | — |
| total_ms mean / p50 / p95 | 86.17 / 50.01 / 185.01 | — |
| overhead_ms mean / p50 / p95 | 41.61 / 22.75 / 145.51 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 17 | 0 | 0 |
| composer_merge | 9 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:b7bb09f45cb2044f48c94fc8270b0bbc38887e9103b331f036946bab24549dad does not match proposal fileBeforeHash sha256:94cdad271f84d86408059bc10d9b947bae922e7ce822e40fd31b2ccebf03f546.=3, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:fffe59fe6da3f5f8c28b638c2d459dc8c6f9fec000a0d91613042bac8ec43057 does not match proposal fileBeforeHash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef.=2, steward-final-patch-required: proposals 'prop-s17-t002-i0' and 'prop-s17-t002-i2' change overlapping base line 13 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i0, prop-s17-t002-i2]=2, file-hash-drift: Target file hash sha256:62f57e4871312187b27628656f7b6e972dae4ae433885f1d89e240d8e00d27cb does not match proposal fileBeforeHash sha256:7f6627da1d4f97e3f1dc4555b57b1922cda0f50c1494735a28b3df566d1984e6.=2, atm_compose=1, compose-context-mismatch: proposal 'prop-s17-t002-i4' context mismatch at base line 20: expected "// </region:cache>", found "// atm-edit s17-t002-i5 by other:mock-s6" [proposals: prop-s17-t002-i4]=1, compose-context-mismatch: proposal 'prop-s17-t000-i0' context mismatch at base line 8: expected "// </region:reducers>", found "// atm-edit s17-t000-i6 by other:mock-s7" [proposals: prop-s17-t000-i0]=1, file-hash-drift: Target file hash sha256:c13ce33fa02afabc9257ba71a4a36cd8a8f4ac42348a3d2879afea6357cd357d does not match proposal fileBeforeHash sha256:c6d9ec63fcce0c8235a41d999e85ebd1b416ab865c09c6123e5cec225775ec61.=1, canonical target base hash is stale: src/store.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=17, composer_merge=5, hot_provisional=4 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=145404, duration_ms=558.66
