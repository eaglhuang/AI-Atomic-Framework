# atm-bench export — r3v-e4-p2-s17-fix-r13

- run_id: `r3v-e4-p2-s17-fix-r13` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 147193 | — |
| duration_ms | 441.98 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 15 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 441.37 | — |
| throughput intents/s | 77.03 | — |
| goodput oracle-pass/s | 77.03 | — |
| latency_ms mean / p50 / p95 | 6.21 / 5.35 / 17.17 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 28.51 / 15.03 / 117.51 | — |
| total_ms mean / p50 / p95 | 77.15 / 47.12 / 166.6 | — |
| overhead_ms mean / p50 / p95 | 35.72 / 21.11 / 139.47 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 16 | 0 | 0 |
| composer_merge | 9 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:4522f6ec17ae3fbe00dac6d3864a365c2cdf475f050cd8d3a7e7a849e67e1b26 does not match proposal fileBeforeHash sha256:94cdad271f84d86408059bc10d9b947bae922e7ce822e40fd31b2ccebf03f546.=3, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 21 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=2, steward-final-patch-required: proposals 'prop-s17-t004-i1' and 'prop-s17-t004-i4' change overlapping base line 10 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t004-i1, prop-s17-t004-i4]=2, atm_compose+cas_rebase=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, file-hash-drift: Target file hash sha256:7f6627da1d4f97e3f1dc4555b57b1922cda0f50c1494735a28b3df566d1984e6 does not match proposal fileBeforeHash sha256:7def02c286644bcac414c0f952c0cc3f5ec31ef822de020821ee7dc9365b9dc0.=2, file-hash-drift: Target file hash sha256:62f57e4871312187b27628656f7b6e972dae4ae433885f1d89e240d8e00d27cb does not match proposal fileBeforeHash sha256:7f6627da1d4f97e3f1dc4555b57b1922cda0f50c1494735a28b3df566d1984e6.=1, atm_compose=1, file-hash-drift: Target file hash sha256:016c758f318fd9abe3c1b747e8dbd36f2c2a6138311c878554fb0ac3cac89d2f does not match proposal fileBeforeHash sha256:40487af30ccfba267d3a07f0e3c2c998f07e24b97db4ee6694e0ea2aa7c7827c.=1, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=16, composer_merge=5, hot_provisional=5 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=147193, duration_ms=441.98
