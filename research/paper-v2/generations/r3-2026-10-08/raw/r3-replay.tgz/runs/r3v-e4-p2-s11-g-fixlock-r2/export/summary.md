# atm-bench export — r3v-e4-p2-s11-g-fixlock-r2

- run_id: `r3v-e4-p2-s11-g-fixlock-r2` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 155482 | — |
| duration_ms | 709.93 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 19 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 709.61 | — |
| throughput intents/s | 50.73 | — |
| goodput oracle-pass/s | 50.73 | — |
| latency_ms mean / p50 / p95 | 4.62 / 3.59 / 14.08 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 38.66 / 16.12 / 120.44 | — |
| total_ms mean / p50 / p95 | 87.96 / 66.09 / 192.62 | — |
| overhead_ms mean / p50 / p95 | 43.97 / 21.35 / 125.78 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:ec75903974321ceb5189d994348d8609f1d7ad0c21240566b51b756912d5cc1f does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=3, steward-final-patch-required: proposals 'prop-s11-t004-i1' and 'prop-s11-t004-i5' change overlapping base line 31 of src/config.ts; a steward-authored final patch is required [proposals: prop-s11-t004-i1, prop-s11-t004-i5]=3, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:873336ca08ad769bbeedee638f8b3d88afe95212e684fd79f74407e98dd9e119 does not match proposal fileBeforeHash sha256:46ceac13dac83e242bb231b3cf46ab614e95215fad0a777acaf70b46a4f10318.=2, atm_compose=2, file-hash-drift: Target file hash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:ad7b1064f734b1d7b7b5b632ac4eeebf537ee9603a40d1d8aab9a708c972f8f3 does not match proposal fileBeforeHash sha256:484cd4b6aff63fd1639b750b29db7cf60d52d1da5e1f6f068eca86bb6b259ca7.=1, file-hash-drift: Target file hash sha256:a2a61ae12feac491b9abc44760e90f3e168e53d24ce7f1d6c42bd62565213818 does not match proposal fileBeforeHash sha256:bc0cd8749ca6e4480039827e7b967b03b65d73daad723aaf15047586edf909d1.=1, file-hash-drift: Target file hash sha256:46ceac13dac83e242bb231b3cf46ab614e95215fad0a777acaf70b46a4f10318 does not match proposal fileBeforeHash sha256:ec75903974321ceb5189d994348d8609f1d7ad0c21240566b51b756912d5cc1f.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=14, composer_merge=9, hot_provisional=5 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=155482, duration_ms=709.93
