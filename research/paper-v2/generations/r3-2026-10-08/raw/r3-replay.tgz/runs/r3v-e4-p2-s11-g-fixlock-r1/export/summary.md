# atm-bench export — r3v-e4-p2-s11-g-fixlock-r1

- run_id: `r3v-e4-p2-s11-g-fixlock-r1` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156730 | — |
| duration_ms | 696.66 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 171.4% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 19 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 18 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 696.62 | — |
| throughput intents/s | 51.68 | — |
| goodput oracle-pass/s | 51.68 | — |
| latency_ms mean / p50 / p95 | 6.03 / 4.54 / 14.78 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 42.92 / 17.05 / 123.6 | — |
| total_ms mean / p50 / p95 | 105.81 / 53.74 / 292.14 | — |
| overhead_ms mean / p50 / p95 | 49.6 / 21.11 / 139.97 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 19 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:c6ad7e714d5fdcf8dd3794a9fcfb20850c77bbb105a8a37aabdfaaa669cb7332 does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=4, file-hash-drift: Target file hash sha256:ba0cfacfde01a714f277db496ba50186acb15d6667234fad31e676d1b7a7e798 does not match proposal fileBeforeHash sha256:9c3543bd5730a0bf0c02ebea14afb7aef344d5954ccf02cccab0e6ed63770f66.=2, file-hash-drift: Target file hash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:bc0cd8749ca6e4480039827e7b967b03b65d73daad723aaf15047586edf909d1 does not match proposal fileBeforeHash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8.=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:9c3543bd5730a0bf0c02ebea14afb7aef344d5954ccf02cccab0e6ed63770f66 does not match proposal fileBeforeHash sha256:0c1998a1d20690f038cb8ae2326a3c1c27e56549803516b4af019ab24c1f3fbb.=1, file-hash-drift: Target file hash sha256:22d18f017ce4476f38d8826aba0757b9246459c962eddca6563f2f017c10285b does not match proposal fileBeforeHash sha256:58527a588418741ed51c51f1b790f7c9acd5d97a3fa03d27cec857b8792e1990.=1, file-hash-drift: Target file hash sha256:8c4a7fcf309d0509dcd4cd3bf0fa7f8333122fb262764ee69cc0fb53692db436 does not match proposal fileBeforeHash sha256:646e607d675f103abc363b33116490528fc6aea2e9b0207d1a9cb5623ab6b6e5.=1, file-hash-drift: Target file hash sha256:28aacb515cb3aa23754064810dfb32fc1de206cecd76a1c8835a652a28226f0a does not match proposal fileBeforeHash sha256:22d18f017ce4476f38d8826aba0757b9246459c962eddca6563f2f017c10285b.=1, file-hash-drift: Target file hash sha256:267a5b7059d3c74183538f7d633c972fee8faf35c66f279a365f5cf9d2fbc9ba does not match proposal fileBeforeHash sha256:e820b9fb40fa58121ef1a8c692846240c3e1a10c77a7f6c72332aa57300447de.=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=17, composer_merge=9, hot_provisional=2 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156730, duration_ms=696.66
