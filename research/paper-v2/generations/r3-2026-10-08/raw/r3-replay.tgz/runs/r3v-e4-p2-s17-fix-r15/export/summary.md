# atm-bench export — r3v-e4-p2-s17-fix-r15

- run_id: `r3v-e4-p2-s17-fix-r15` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 145828 | — |
| duration_ms | 611.56 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 14 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 611 | — |
| throughput intents/s | 55.65 | — |
| goodput oracle-pass/s | 55.65 | — |
| latency_ms mean / p50 / p95 | 5.22 / 3.84 / 19.62 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 39.8 / 15.86 / 116.51 | — |
| total_ms mean / p50 / p95 | 85.22 / 44.89 / 167.59 | — |
| overhead_ms mean / p50 / p95 | 45.66 / 20.95 / 126.74 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| composer_merge | 12 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=3, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, file-hash-drift: Target file hash sha256:706b7228d17cdd613071aa58ef2cdfb957f2f9e523fe45a477bb1dcecd52926b does not match proposal fileBeforeHash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da.=2, file-hash-drift: Target file hash sha256:06c5a7e75dab9b804d615e5577627169c976a17f819de5485d893c648650a7b8 does not match proposal fileBeforeHash sha256:2339436f0233f6c968fa9c13e7218cc7f39ecbc77bfb0617fe39b70c36f75001.=2, atm_compose=1, compose-context-mismatch: proposal 'prop-s17-t004-i4' context mismatch at base line 12: expected "// </region:reducers>", found "// atm-edit s17-t004-i0 by cursor:mock-s0" [proposals: prop-s17-t004-i4]=1, atm_provisional_write_lease+cas_rebase=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:0b225aab5c8b0e2d3ea0d1106b972d8a0c87f28e7c0292b2f9d61837679b0093 does not match proposal fileBeforeHash sha256:56af38d14eb8ad3996aa76de9ab0fa4cb6c7ddb2e5709053d2901c5efd138e9b.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, composer_merge=7, hot_provisional=6 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=145828, duration_ms=611.56
