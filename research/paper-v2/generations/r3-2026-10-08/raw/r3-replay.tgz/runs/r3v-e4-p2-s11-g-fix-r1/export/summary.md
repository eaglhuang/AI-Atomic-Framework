# atm-bench export — r3v-e4-p2-s11-g-fix-r1

- run_id: `r3v-e4-p2-s11-g-fix-r1` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154543 | — |
| duration_ms | 610.83 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 16 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 610.56 | — |
| throughput intents/s | 58.96 | — |
| goodput oracle-pass/s | 58.96 | — |
| latency_ms mean / p50 / p95 | 5.87 / 4.36 / 14.05 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 40 / 16.04 / 132.93 | — |
| total_ms mean / p50 / p95 | 93.92 / 57.42 / 219.99 | — |
| overhead_ms mean / p50 / p95 | 46.63 / 22.43 / 148.37 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:c3b87d00d596d4a7b5fef2f12e771224985da8414f8077a5c2748102a2a7caaa does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=4, file-hash-drift: Target file hash sha256:2b6eb484c12fbb60463fc1024c7ff42613e55201833eaedbc5115999d8cbff4b does not match proposal fileBeforeHash sha256:a8841c38c8d83962738411f8ccf8c857f7e8d3c55037ccc3d2060f0da0bb7c05.=2, file-hash-drift: Target file hash sha256:f93f419271b578aa6e3b2f97976b74d19cc45a2c2f60b890338462ca9b3f87ff does not match proposal fileBeforeHash sha256:98c57a9ec8af9e3e19680a1404c1c0d76f459275300d9f3057c2e9726b73c379.=2, steward-final-patch-required: proposals 'prop-s11-t003-i6' and 'prop-s11-t004-i3' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s11-t003-i6, prop-s11-t004-i3]=2, file-hash-drift: Target file hash sha256:5f2ca2bee4bb9671c19c39a20f4534f5bab05dd4bafac25b3b5d1360401959ed does not match proposal fileBeforeHash sha256:d1794ee66780d52fdc25ed42f76eeddecbc40f47cdc74369b0947d0c65258e87.=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:8c4a7fcf309d0509dcd4cd3bf0fa7f8333122fb262764ee69cc0fb53692db436 does not match proposal fileBeforeHash sha256:646e607d675f103abc363b33116490528fc6aea2e9b0207d1a9cb5623ab6b6e5.=1, file-hash-drift: Target file hash sha256:98c57a9ec8af9e3e19680a1404c1c0d76f459275300d9f3057c2e9726b73c379 does not match proposal fileBeforeHash sha256:8c216388953701b12d61d028759ce591ecc95302af8efa5fcb6972ab0ef82943.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=15, composer_merge=9, hot_provisional=4 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154543, duration_ms=610.83
