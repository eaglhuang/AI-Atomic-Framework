# atm-bench export — r3v-e4-p2-s11-g-fixlock-r3

- run_id: `r3v-e4-p2-s11-g-fixlock-r3` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 153216 | — |
| duration_ms | 636.9 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=26, blocked=10 | — |
| committed | 26 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 138.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 20 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 637.16 | — |
| throughput intents/s | 56.5 | — |
| goodput oracle-pass/s | 56.5 | — |
| latency_ms mean / p50 / p95 | 5.34 / 3.57 / 17.19 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 39.25 / 16.92 / 127.22 | — |
| total_ms mean / p50 / p95 | 92.67 / 55.64 / 193.55 | — |
| overhead_ms mean / p50 / p95 | 45.27 / 22.15 / 130.83 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=9, atm_compose+cas_rebase=4, file-hash-drift: Target file hash sha256:101940666fe9e14173474d88ce3624a9e53373623222d6b78b431340c86ce1b6 does not match proposal fileBeforeHash sha256:173692fcc448fa0a8d0df44050556935ef9179fe928ada304a66276e93bbb8de.=3, atm_compose=2, file-hash-drift: Target file hash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c does not match proposal fileBeforeHash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79.=2, steward-final-patch-required: proposals 'prop-s11-t004-i0' and 'prop-s11-t004-i2' change overlapping base line 22 of src/config.ts; a steward-authored final patch is required [proposals: prop-s11-t004-i0, prop-s11-t004-i2]=2, file-hash-drift: Target file hash sha256:ae62ff81624ec1e09f67ee547fbff93798d4fcb3fa50919d15860b01fdecac7d does not match proposal fileBeforeHash sha256:8d38c348f4809ca40c15e26faccedb6bf49ac969ff7593a22646cabe8be7838d.=2, file-hash-drift: Target file hash sha256:173692fcc448fa0a8d0df44050556935ef9179fe928ada304a66276e93bbb8de does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=13, composer_merge=8, hot_provisional=7 |
| no_conflict | hot_provisional=2, cold_queue=2, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=153216, duration_ms=636.9
