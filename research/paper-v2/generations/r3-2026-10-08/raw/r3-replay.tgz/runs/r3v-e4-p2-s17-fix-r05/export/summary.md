# atm-bench export — r3v-e4-p2-s17-fix-r05

- run_id: `r3v-e4-p2-s17-fix-r05` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 144923 | — |
| duration_ms | 705.6 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 161.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 8 | — |
| CAS rebase on apply | 19 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 704.79 | — |
| throughput intents/s | 48.24 | — |
| goodput oracle-pass/s | 48.24 | — |
| latency_ms mean / p50 / p95 | 10.93 / 5.23 / 37.79 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 41.09 / 20.47 / 199.86 | — |
| total_ms mean / p50 / p95 | 116.93 / 58.87 / 311.26 | — |
| overhead_ms mean / p50 / p95 | 53.16 / 27.69 / 264.98 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 15 | 0 | 0 |
| composer_merge | 8 | 0 | 0 |
| hot_provisional | 11 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=11, atm_serial_queue=9, file-hash-drift: Target file hash sha256:1de58ac7eabcf0ed337cddec96961bdfdc0ea641dcc6f6d4652934f3bab37cd9 does not match proposal fileBeforeHash sha256:4522f6ec17ae3fbe00dac6d3864a365c2cdf475f050cd8d3a7e7a849e67e1b26.=3, canonical target base hash is stale: src/routes.ts=2, file-hash-drift: Target file hash sha256:d02271bab4a983f119de81ae362e9164c294060391ed44e7851c67042046e68b does not match proposal fileBeforeHash sha256:82158ec9503a73a76e764fe15ece53c6eedc8f754f2455a3d2d3e3a25ee74ff4.=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, file-hash-drift: Target file hash sha256:aa908e83054b02b7922ab8489e0bd886b0275b679c54fec3846461ea4f8459ca does not match proposal fileBeforeHash sha256:7a3c5540cf69f0b488061ea9831796ee0e3d93a7808ec889d43054287b9cc003.=2, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da does not match proposal fileBeforeHash sha256:97c243dc7053b942f2e727f1f649f633a26692e99d6d2c7847a2f71a2ad4b2ff.=1, compose-context-mismatch: proposal 'prop-s17-t000-i6' context mismatch at base line 8: expected "// </region:reducers>", found "// atm-edit s17-t000-i0 by cursor:mock-s0" [proposals: prop-s17-t000-i6]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=14, hot_provisional=7, composer_merge=5 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=2, cold_queue=1, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=144923, duration_ms=705.6
