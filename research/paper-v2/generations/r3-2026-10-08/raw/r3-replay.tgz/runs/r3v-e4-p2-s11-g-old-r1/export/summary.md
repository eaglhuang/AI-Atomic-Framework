# atm-bench export — r3v-e4-p2-s11-g-old-r1

- run_id: `r3v-e4-p2-s11-g-old-r1` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 153168 | — |
| duration_ms | 611.27 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=26, blocked=10 | — |
| committed | 26 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 2 | — |
| integration pass rate of committed | 130.8% | — |
| effective success rate of all intents | 94.4% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 16 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 611.14 | — |
| throughput intents/s | 58.91 | — |
| goodput oracle-pass/s | 55.63 | — |
| latency_ms mean / p50 / p95 | 5.62 / 3.58 / 19.51 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 40.02 / 16.04 / 119.07 | — |
| total_ms mean / p50 / p95 | 89.87 / 50.01 / 173.15 | — |
| overhead_ms mean / p50 / p95 | 46.33 / 22.96 / 141.53 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:ced22eb7aef85524e970467211af9dcd1e47adac188c6195d75fa122b1f67a9b does not match proposal fileBeforeHash sha256:7d16aa65d5970ab90f6941e847b909201b4aa7b5d2f3c93809a465ef2e0e0b49.=3, atm_compose+cas_rebase=2, atm_compose=2, steward-final-patch-required: proposals 'prop-s11-t002-i2' and 'prop-s11-t002-i4' change overlapping base line 15 of src/store.ts; a steward-authored final patch is required [proposals: prop-s11-t002-i2, prop-s11-t002-i4]=2, file-hash-drift: Target file hash sha256:5864bfd226f2a186433693256939d8f6f35c6c7dba401297e528a7fd380888ab does not match proposal fileBeforeHash sha256:88b2d0f06285e7fdb75fffce0d8c75e1aac31654fd86ab35725e398be86929a0.=2, steward-final-patch-required: proposals 'prop-s11-t000-i0' and 'prop-s11-t002-i6' change overlapping base line 23 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t000-i0, prop-s11-t002-i6]=2, file-hash-drift: Target file hash sha256:c16076c4559229b9ed7d65f99e564019e6d3346c9c582d75fda81691afe69ec7 does not match proposal fileBeforeHash sha256:e46b7beebc233e00d1df50154140074e8d4d429445a6377423b564bdf72fd7af.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=14, composer_merge=9, hot_provisional=5 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=153168, duration_ms=611.27
