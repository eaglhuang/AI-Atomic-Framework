/** In-memory store slices (HOT). */
export type State = { users: string[]; orders: number[]; meta: Record<string, string> };

// <region:reducers>
export function reduceUsers(state: State, user: string): State {
  return { ...state, users: [...state.users, user] };
}
// atm-edit s11-t002-i5 by codex:mock-s5
// atm-edit s11-t004-i3 by cursor:mock-s3
// atm-edit s11-t003-i6 by other:mock-s7
// </region:reducers>

// <region:selectors>
export function selectUserCount(state: State): number {
  return state.users.length;
}
// atm-edit s11-t003-i5 by other:mock-s6
// atm-edit s11-t002-i3 by cursor:mock-s3
// atm-edit s11-t002-i7 by other:mock-s7
// atm-edit s11-t002-i1 by claude:mock-s1
// atm-edit s11-t003-i1 by claude:mock-s1
// atm-edit s11-t003-i0 by cursor:mock-s0
// </region:selectors>

// <region:actions>
export function createOrder(state: State, id: number): State {
  return { ...state, orders: [...state.orders, id] };
}
// </region:actions>

export const initialState: State = { users: [], orders: [], meta: {} };
