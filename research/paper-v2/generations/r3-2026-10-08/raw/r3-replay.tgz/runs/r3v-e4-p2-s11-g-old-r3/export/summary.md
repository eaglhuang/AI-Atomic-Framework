# atm-bench export — r3v-e4-p2-s11-g-old-r3

- run_id: `r3v-e4-p2-s11-g-old-r3` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156799 | — |
| duration_ms | 637.64 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 16 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 638.13 | — |
| throughput intents/s | 56.41 | — |
| goodput oracle-pass/s | 56.41 | — |
| latency_ms mean / p50 / p95 | 5.39 / 3.42 / 17.55 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 41.56 / 14.32 / 120.14 | — |
| total_ms mean / p50 / p95 | 91.1 / 53.8 / 174.1 | — |
| overhead_ms mean / p50 / p95 | 47.51 / 20.19 / 133.07 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=5, steward-final-patch-required: proposals 'prop-s11-t001-i3' and 'prop-s11-t001-i5' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t001-i3, prop-s11-t001-i5]=3, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:4590d6b3ab295ccbbe1535ae4c1692c9d017cff50e7b6e91834ae1f64aa997ba does not match proposal fileBeforeHash sha256:f922f45598e5ea65d2e4e58186f32804ab26ce24bc44ca415e6b3b60afad7362.=2, file-hash-drift: Target file hash sha256:612ce24739db7382a853399e28b4c3921fb9189118847f70d2d62d4ca62321a9 does not match proposal fileBeforeHash sha256:146e1f35e5ebbecb59e115fb9f850f18c0359275d9fd2ee0737a6d7b1ae67777.=2, file-hash-drift: Target file hash sha256:3f6a15b867e983272fd58a7a6e3889c2d0036745bafe603c761ec061ea325e1a does not match proposal fileBeforeHash sha256:4590d6b3ab295ccbbe1535ae4c1692c9d017cff50e7b6e91834ae1f64aa997ba.=2, file-hash-drift: Target file hash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:3038289f914a3090be47e68fff94401c7058175f1823523534afa67cd27a4755 does not match proposal fileBeforeHash sha256:d99e5e85da084aeae432d3559da480044e5df796d88bcb0ab29b8a2541f40196.=2, file-hash-drift: Target file hash sha256:ddc59502be5c789a86f52f1135b0b175853fd062858439244b3432dcf6c002d9 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=1, file-hash-drift: Target file hash sha256:146e1f35e5ebbecb59e115fb9f850f18c0359275d9fd2ee0737a6d7b1ae67777 does not match proposal fileBeforeHash sha256:600bb99e9d0f5fa748ef56881b85336314f19fbe9bf7b7b2369d532498f84457.=1, file-hash-drift: Target file hash sha256:f922f45598e5ea65d2e4e58186f32804ab26ce24bc44ca415e6b3b60afad7362 does not match proposal fileBeforeHash sha256:3fa15a3a5f5844df795e36287e6b926e0ae34ff6e6b1f8adc1ec9d56cc70f02e.=1, file-hash-drift: Target file hash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=15, composer_merge=9, hot_provisional=4 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156799, duration_ms=637.64
