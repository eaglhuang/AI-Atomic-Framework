# review-pack — 外部 AI 審核用精簡證據

先讀上層 `REVIEW_PACK_FOR_EXTERNAL_AI.md`（本目錄亦有副本）。

| 子目錄／檔 | 內容 |
|------------|------|
| `EXPERIMENT_CHECKLIST.md` | 梯隊狀態 |
| `VERSION_ANCHORS.md` | pin／CI≠主實驗／candidate final |
| `runs-summaries/` | E1–E5 SUMMARY＋seeds |
| `steward-writer/` | 各階紀要 |
| `baselines/` | D1–D5 |
| `b5-b8/`／`composer-probe/` | B 階 |
| `tables/` | F1／F2 |
| `artifact_manifest.json`／`checksums.sha256`／`reproduce.sh` | F3 封包 |

**DRAFT — 不宣稱勝出。** Raw 150 cells 不在此包；見主樹 `runs/`。
