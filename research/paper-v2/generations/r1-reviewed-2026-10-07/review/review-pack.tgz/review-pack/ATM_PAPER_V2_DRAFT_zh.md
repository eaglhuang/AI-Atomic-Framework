---
title_zh: "ATM 同檔多代理提案的確定性合成與受治理提交"
title_en_tentative: "Deterministic Composition and Governed Commit of Same-File Multi-Agent Proposals in ATM"
subtitle: "proposal 可平行準備；合成以批次、對同一 immutable base 進行；canonical commit 經單一受控寫入路徑完成"
positioning: "ATM v1（arXiv:2607.00041）的續篇；systems-implementation＋實證論文；三項貢獻 C1 受治理合成提交協定／C2 可檢驗保留性契約／C3 安全與進度成本實證。歷史缺口修復定位為『對 v1 承諾的端到端驗證』，不列為新演算法貢獻"
version_date: 2026-10-07
revision: "吸收可行性審閱（ATM_PAPER_V2_FEASIBILITY_REVIEW，2026-10-07）後之修訂稿；修訂前版本備份於 ATM_PAPER_V2_DRAFT_zh_pre_review.md；吸收對照見 ATM_PAPER_V2_REVIEW_ABSORB_NOTES.md"
version_anchors: "v1 framework v0.9.0-alpha.1（tag object 0b31aa86 ≠ peeled source commit a897f144）；歷史問題基準 v0.1.17 commit 8dd6a1c6；本次 main 快照 3b0f7660（審閱核對 2026-10-07 11:49 UTC＝19:49 Asia/Taipei）；修正候選 PR #198 head 65e8aab3（未合併）；最終 frozen commit 尚未定"
harness: "atm-bench 0.3.0-latency（steward 臂與強基線臂待 M2/M3 接線）"
status: "草稿／非正式投稿（DRAFT — NOT FOR SUBMISSION）；主結果〔待 M2/M4〕；舊數字一律為作者報告值"
primary_axis: "同基底確定性合成＋受治理提交（Composer＋中立 steward）"
issue: "#196（https://github.com/eaglhuang/AI-Atomic-Framework/issues/196）"
supersedes: "（1）舊稿『熱檔提案、冷檔排隊』備份為 ATM_PAPER_V2_DRAFT_zh_hotcold_archive.md；（2）審閱前之 Composer＋steward 稿備份為 ATM_PAPER_V2_DRAFT_zh_pre_review.md"
sources: "ATM_PAPER_V2_FEASIBILITY_REVIEW.md（修稿／實驗設計規範）、COMPOSER_STEWARD_IMPL_PLAN.md、runs/composer-probe/probe.out、PAPER_V2_KEY_TABLES.md（T1–T11）、HOT_FILE_LATENCY.md、refs/arxiv-2607.00041.txt（ATM v1 全文）"
---

# ATM 同檔多代理提案的確定性合成與受治理提交

**英文暫定標題**：Deterministic Composition and Governed Commit of Same-File Multi-Agent Proposals in ATM

**一句定位**：多個代理可以**平行準備** proposal，但 canonical 檔只經由**單一受控提交路徑**改變。本文研究 ATM 單一治理域內，對同一 immutable base 的同檔 proposal 如何以批次合成、驗證並受治理地提交——保留可相容的修改、對不相容或過期的提案回傳可對帳的結果——並量化這種安全性相對於鎖定、樂觀 CAS 重試與 Git 三方合併所付出的進度成本。本文**不**宣稱 canonical 檔同時接受多個 writer，也不宣稱任意程式語意正確。

> ⚠ **草稿／非正式投稿**。版本日期 2026-10-07（Asia/Taipei）。
> ⚠ **主結果尚無數據**。本稿的主張一律以「目標主張／待實測」框呈現，結果欄位標〔待 M2/M4〕；在凍結版本與可重現事件紀錄完成前，**不得**當作結果引用。
> ⚠ **舊數字均為作者報告值**：本稿引用的既有 run 數字（Oct 6 core@0.1.2 與 v0.1.17）由作者 harness 產生；外部審閱未取得原始事件與終態工件，無法驗算。正式稿前須自 run 級原始整數重算。

**證據標記**：〔作者報告值〕＝來自本 box 既有 run／彙整檔、未經獨立重算；🟢／🟡＝彙整包原分級（🟢 可用、🟡 有 caveat）；〔待 M2/M4〕＝主結果尚無數據；〔審閱核對 2026-10-07〕＝外部審閱聲稱已核對公開版本狀態，本稿轉述、作者尚需自行確認；〔待核對〕＝尚未逐頁對照原文；「來源未提供」＝本 box 無此數字。數字抄自 `PAPER_V2_KEY_TABLES.md`、`HOT_FILE_LATENCY.md`、`COMPOSER_STEWARD_IMPL_PLAN.md` 與 `runs/composer-probe/probe.out`，未重算（標「推算」者為彙整包以來源數字相除）。

---

## 摘要

多個程式代理對同一檔案提出修改時，**寫入准入**與**最終整合**是兩種不同的正確性責任。本文研究單一治理域內，對同一基底的 patch 如何經過合成、驗證與受控提交，保留可相容的修改，並對不相容或過期的提案回傳可對帳的結果。我們以 ATM 既有的 composer 與 steward 路徑為案例，區分**歷史實作缺口**、**協定假設**與**尚待驗證的安全性質**。

作為動機，我們報告兩組既有觀察。其一是故障注入負面對照：在作者的 atm-bench 熱檔高壓情境中，writer 採用 ATM 准入但刻意省略合成與提交協定、以舊 base 整檔覆寫時，已提交更新的遺失率約 55–65%〔作者報告值〕；這說明缺少該層的後果，而非完整 ATM 或其他正確並行控制方法的能力界線。其二是針對歷史基準 v0.1.17（commit `8dd6a1c6`）的唯讀探針：其文字合成實作為循序套用，同檔不重疊但上方插入一行即可使套用失敗且結果依輸入排序而異；重疊衝突以例外而非結構化拒絕收據結束；提交入口未比對提案者與 steward 角色。這些是對 v1 已承諾機制缺乏端到端驗證的歷史缺口；本次審閱核對之 main 快照尚未含修正，候選修正（PR #198）的契約仍待核定。

我們提出一個具明確 proposal、batch、base、steward 與 commit 語意的**受治理合成提交協定**，並在單一檔案、合作式 writer 與無歧義 patch 子集合的限制下，給出**合成決定性**與**編輯保留性**的證明義務。評估設計以 per-file lock 序列化、樂觀 CAS 重試與 Git 三方合併為正確強基線，另含移除准入的 bare composer 消融，同時量測正確完成率、可處理範圍（eligible coverage）、拒絕、尾端延遲、重提成本與多 process 故障。主要結果須在凍結版本與可重現事件紀錄完成後填入〔待 M2/M4〕；在此之前，本文不主張實驗已證明零遺失更新或任意語意正確。

**關鍵詞**：多代理程式生成、遺失更新、確定性合成、受治理提交、中立 steward、寫入前准入、可重現基準

---

## 1. 問題與範圍

### 1.1 問題：准入之後，誰對最終整合負責

當多個代理同時修改同一個檔案，「不衝突」有兩層意思。第一層是**准入層**：兩份意圖在語意 atom、有界區域、共享面與讀寫依賴上不重疊，可以被允許同時進行。第二層是**提交層**：兩份實際產生的 patch 真的進入 canonical 檔時，每一份被接受的編輯恰好生效一次、沒有一方覆蓋另一方、結果與 proposal 抵達順序無關，而被拒絕者不留下任何副作用。

ATM v1 把第一層做成一條可重播的准入詞彙（`parallel-safe`、`needs-physical-split`、`SERIAL`、`blocked-*`；v1 §3.4、Table 4），並把第二層**交給**確定性 composer 與中立 steward（v1 §3.2、§3.4 Algorithm 1 safety note、§3.5）。「准入不等於提交安全」是一條有用的系統診斷原則，但並非本文首創的一般性定律；本文的工作是把 v1 對第二層的承諾寫成可檢驗的協定與契約，並以公平基線量測其代價。

**名詞釐清**：本文所說的「平行」只指 proposal 的**準備**可以平行。合成以**批次**進行；canonical commit 由**單一受控寫入路徑**完成（圖 1〔待繪〕）。舊稿「真正平行合併」一詞容易被誤讀為 canonical 檔同時接受多個 writer，本稿不再使用。

### 1.2 範圍與威脅模型

最低可行範圍限定為：

- **單機、單一治理域**（沿用 v1 §3.7 的單域定位），單一目標檔；多檔提交僅作為限制與未來工作。
- **合作式程序**：所有 writer 都經由 broker／steward 路徑；不處理惡意 root、直接繞過 broker 的程序、惡意身份偽造或分散式網路分割。
- **可信 steward 與可信檔案系統**。
- **受限 patch 子集合**：文字型 unified diff，支援等長替換、插入、刪除與多 hunk；rename、binary、mode、CRLF 差異、無尾端換行等不支援語法須**明確拒絕**（§4.2）。

在此範圍內，本文**不能**宣稱多代理 sandbox、OS 層權限隔離、crash／斷電耐久性或任意程式語意正確（§3.5、§7.1）。若要主張較強的權限治理，需另加 OS 帳號／容器權限、actor 與 process 身份綁定、canonical 路徑寫入限制，以及 symlink、hardlink、路徑跳脫、TOCTOU 測試——這些不在本文範圍。

### 1.3 研究問題

- **RQ1（保留性與正確拒絕）**：在明定的 patch 子集合與故障模型下，方法是否保持所有已提交的有效編輯，並正確拒絕不相容提案？
- **RQ2（相對強基線的安全進度）**：相對 per-file lock、optimistic CAS retry 與 Git 三方合併，能安全完成多少工作，付出多少延遲、重試及拒絕成本？
- **RQ3（轉折條件）**：哪些 patch 結構、hotness、batch window 與 process 數造成效能或 coverage 的轉折？
- **RQ4（治理可驗證的層級）**：治理收據與寫入入口能驗證到哪一層？哪些保證仍依賴合作式程序或 OS 權限？

RQ 依此順序為主要 RQ 的預先排序；消融與探索性結果另標（§5.6）。

### 1.4 貢獻

| ID | 貢獻 | 內容 | 成立所需（本稿狀態） |
|---|---|---|---|
| **C1** | **受治理的合成提交協定** | 明定 proposal、batch、base、steward 與 commit 的責任與結果；狀態機、batch closure、拒絕與重提語意、收據終態 | 形式化狀態機、信任邊界、與 v1 的精確差異（§3）；**規格草案，待作者核定** |
| **C2** | **可檢驗的保留性契約** | 對受限 patch 集合：決定性輸出（composition determinism）、每個接受編輯恰好生效一次、未編輯片段不變、拒絕前無副作用；**不**宣稱任意語意正確 | 完整假設、命題與證明義務、獨立 oracle、邊界測試（§4）；**證明與測試待 M1** |
| **C3** | **安全與進度成本的實證** | 相對強基線量測 coverage、correct completion、tail latency、retry／reject 成本與跨 process 成本 | 同一 frozen commit、公平強基線、獨立 workload seeds、CI 與 artifact（§5–§6）；**〔待 M2/M4〕** |

**歷史缺口修復不列為新貢獻**。v0.1.17 的四項缺口——（a）行數位移導致套用失敗且結果依排序而異、（b）`permutationStable` 寫死為 `true`、（c）合成失敗缺結構化 blocked 收據、（d）提交入口未比對提案者與 steward 角色——是重要的實作修復，但它們是 v1 已承諾、先前缺乏端到端驗證的機制（§2）。本文把它們寫成「對 v1 承諾的端到端驗證」的起點，並以 C1–C2 說明本篇新增了哪些可泛化的知識：明確的提交協定、可證偽的保留性契約，以及公平基線下的成本取捨。

若最終結果只顯示「修復 v1 已承諾的機制」，而相對 Git 三方合併或鎖定方案的實務差異不明顯，本文應改投修正說明、重現研究或實務經驗報告；此決策點列於 M5（§5.7）。

### 1.5 本稿目前能以資料支撐的範圍

- **動機（作者報告值）**：故障注入負面對照（stale／raw overwrite）與理想 sync 參考的對比（§2.3）。
- **歷史缺口（質性、可重跑）**：綁 v0.1.17 的五情境探針（§2.4）。
- **背景（作者報告值）**：冷熱分級准入成本、冷檔排隊成本、跨 process CAS／apply 互斥負面對照——降為附錄 A，除非它們直接回答 RQ1–RQ4。
- **主結果**：全部〔待 M2/M4〕。

---

## 2. v1 承諾與歷史診斷

### 2.1 v1 對提交層的承諾

ATM v1（Huang，arXiv:2607.00041v1，2026-06-29，cs.SE）的貢獻是帶 virtual-atom 後備的七層寫入前准入閘門、規格到證據的治理基底，以及以 adapter 合約為界的原子化抽象（v1 §1.3）。與本文直接相關的承諾有三：

1. **角色分離**：代理只能提出 proposal；即使兩份 proposal 可組合，仍由中立 steward 執行受治理寫入；中立 steward 是唯一正式套用權威（v1 §3.2）。
2. **同檔不相交 → 組合，不是直接寫**：同檔有界不相交編輯路由到 `needs-physical-split`，由確定性 composer 與中立 steward 產生單一受治理的套用路徑（v1 §3.4，Algorithm 1 safety note；Table 4）。
3. **套用時位移由 composer／steward／CAS 吸收**：v1 §3.5 區分准入時的區域判斷與套用時的行數位移，「套用時產生的行數偏移必須由確定性 composer、中立 steward 與 CAS base-hash 重驗共同吸收」，並以 POS2 現場案例為此同檔寫入鏈的正向證據。

v1 的評估以確定性情境、現場案例（POS2／B-12／BLOCK）、外部採用者研究與 OperationalBench 為主，自述「不支持相對其他並行控制系統的廣泛優越性」（v1 摘要）。v1 **沒有**對「多份真實 patch 經 steward 合成後是否保留全部非衝突變更、是否與順序無關」做系統性量測。

### 2.2 版本分層

歷史 source、現行 main、候選 PR 與量測 artifact 是不同對象；CI 綠燈、PR 合併與小型 fixture 都不等於論文主實驗完成。本稿各表一律標明實際綁定哪一層。

**表 V1　版本錨點與可支持範圍**

| 對象 | 定位 | 本稿如何使用 |
|---|---|---|
| v1 framework | `v0.9.0-alpha.1`；**tag object** `0b31aa86`，peeled **source commit** `a897f144`〔審閱核對 2026-10-07〕 | v1 範圍與承諾的錨點。舊稿把 `0b31aa86` 當作 commit，已更正。後來版本的缺陷不能直接倒推至此版 |
| 歷史問題基準 | tag `v0.1.17`，commit `8dd6a1c6`（`packages/*/package.json` 顯示 0.1.2，以 tag 為準） | 探針（§2.4）與多數背景數字的綁定版本；文字 composer 為 sequential reduce、`permutationStable` 固定 `true` |
| 本次 main 快照 | commit `3b0f7660`，狀態截至 2026-10-07 11:49 UTC（19:49 Asia/Taipei）〔審閱核對 2026-10-07〕 | 已含 FileHeat（PR #197）與 native hot parking（PR #199）；text steward 路徑與 v0.1.17 為同一 blob，**尚未**含 #198 修正 |
| 修正候選 | PR #198（**未合併**），head `65e8aab3`〔審閱核對 2026-10-07〕 | 有 immutable-base 合成與新檢查，但四項契約與本稿草案不同（§2.6）；**不是** final frozen artifact |
| 既有與最終實驗 | 舊數字橫跨 Oct 6（core@0.1.2，HEAD `ed317820`）與 v0.1.17；final SHA 尚未定 | 舊數字一律標作者報告值；所有主比較須在同一最終 frozen commit 上重跑全部臂 |

兩條版本號（v0.9.0-alpha.1 與 v0.1.x）的對應關係來源未提供〔待核對〕。

**狀態一句話**：歷史基準有已知缺口，main 尚未含修正，候選契約待核定，主結果仍待測。

### 2.3 動機：故障注入負面對照（作者報告值）

在 atm-bench 中以真 ATM broker 決策驅動熱檔高壓情境（`overlap=high`、hot_ratio 1.0、8 agents、trials 50、每 rep 354 offered intents），比較兩種 writer：

- **sync writer（理想參考）**：admission 之後，在 apply 當下同步 read-modify-write——等同一個理想化的即時 rebase；它是 harness 正確性參考，**不**代表真實合併的上界。
- **stale writer（ATM admission only／raw overwrite）**：admission 之後先讀 base，hold 結束後把 base＋自己的 edit 整檔寫回——即採用 ATM 准入決策，但**刻意省略** composer／steward 合成與提交協定。

**表 M1　熱檔 stale vs sync 對照（〔作者報告值〕；h1-a8 引自 T6、`HOT_FILE_LATENCY.md`；其餘情境 Oct 6）**

| 情境 | control lost 率 | stale lost 率（native／loop） | sync lost |
|---|---|---|---|
| h1-a8（Oct 6，core@0.1.2） | 71.5% | 64.9%／65.2% | 0 |
| h1-a8（v0.1.17） | 71.5% | 65.0%／63.6% | 0 |
| h1-a6（Oct 6） | 63.9% | 55.5%／54.4% | 0（native／loop） |
| h08-a8（Oct 6） | 68.0% | 64.6%／56.0% | 0（native／loop） |

**解讀與 caveat**：

1. stale／raw overwrite 是**故障注入負面對照**：它故意省略應有的合成與提交協定，只能說明「缺少該層」的後果，**不是** ATM 能力界線的結論，也不構成完整 ATM 與其他正確並行控制方法的公平比較。主比較須相對正確強基線（§5.2）。
2. 舊版 harness 與舊稿的所有「0 lost」都綁 sync writer，從未驅動真正的 `composeBrokerProposals`／steward apply；它量到的是理想 rebase 的正確性，而非 ATM 提交路徑的正確性。
3. 「同一組准入決策」措辭需收斂：sync 與 stale 臂使用相同 seed 與相同准入演算法設定，但 writer 速度、lease 釋放與 retry 會回饋到後續決策，**實際准入序列未必相同**（例：h1-a8 native composer_merge 210/rep vs nativestale 206/rep、reject 84 vs 88）。若要聲稱「同一准入決策」，須另做固定 decision／batch trace replay〔待 M3〕。
4. **分母（A4 已核）**：h1-a8 nativestale「172.7（64.9%）」在原表欄位標為「lost/rep（佔 commit）」；64.9% = **lost／commits**，3 reps **ratio-of-sums** `518/798`（mean-of-ratios ≈ 64.90%，幾乎相同）。顯示 172.7 = mean lost `(169+170+179)/3`。外部審閱 `172.7/354≈48.79%` 為 **lost／offered**，**不替換** 64.9%。原始整數：`T6_R1_DENOMINATOR_AUDIT.md`、`runs/hot-file/t6_r1_raw_counts.json`。不同版本、分母與 aggregation 不得接成單一效能提升百分比。
5. 路由壓力（背景）：h1-a8 native 每 rep 的已提交 intents 中，[admit, release] 區間在同一 path#region 上重疊的 pairs 約 156 對，全部為 composer_merge＋composer_merge〔作者報告值，`HOT_FILE_LATENCY.md` §1.1〕。**156 pairs 不等於 156 個 intents 或 rejected cases**，不得直接推為 blocked 率。

### 2.4 歷史探針（綁 v0.1.17 `8dd6a1c6`）

**方法**：唯讀探針在 `/tmp` 建拋棄式 git repo，只 import v0.1.17 core 原始碼，不修改 ATM 樹（`runs/composer-probe/probe.mts`；Node v24.21.0；`ATM=/workspace/atm-0.1.17/AI-Atomic-Framework-0.1.17 node probe.mts`）。每個情境為兩份 `PatchProposal`、同一個 10 行檔、同一 baseCommit／fileBeforeHash，依序呼叫 compose 與 steward apply，記錄 verdict、例外與最終檔是否保留 A／B 的變更。探針輸出未隨稿附給外部審閱；正式稿須把 `probe.mts`、`probe.out` 與輸入 fixture 放入 artifact（附錄 C）。

**表 P1　v0.1.17 compose／steward apply 探針（`runs/composer-probe/probe.out`；歷史基準，非現行 main、非 #198）**

| # | 情境 | compose verdict／applyMethod | apply 結果 | 保留 A／B |
|---|---|---|---|---|
| 1 | 不重疊，兩邊等長替換（第 2、8 行） | `parallel-safe`／`patch-apply` | `applied` | ✅／✅ |
| 2 | 不重疊，排在前面的 patch 在上方且插入 1 行 | `parallel-safe`／`patch-apply` | **throw** `UnifiedPatchApplicationError: patch context mismatch at line 8: expected "line8", found "line7"` | ❌／❌ |
| 3 | 同 #2 的 patch，但 anchor 讓下方 patch 先排 | `parallel-safe`／`patch-apply` | `applied` | ✅／✅ |
| 4 | 重疊（兩邊都改第 5 行） | `needs-steward`／`steward-authored-final-patch` | **throw** `…context mismatch at line 5: expected "line5", found "A_EDIT"`（非 blocked 收據） | ❌／❌（檔案未變） |
| 5 | `stewardId='agentA'`（即提案者本人） | `parallel-safe` | **`applied`** | — |

### 2.5 歷史缺口的解讀

1. **順序依賴**：#2 與 #3 只差排序，結果就不同。根因是 `steward-transactional-apply.ts:148` 的文字路徑實為 `proposals.reduce((c,p)=>applyUnifiedPatch(c,p.patch), before)`——對**中間檔**循序套用，而非對同一 immutable base 解析；排序鍵為 `targetFile → firstAnchorKey（字串）→ proposalId`（`merge-plan.ts:26-55`），不是檔內位置。這正是 v1 §3.5 所說「准入時不相交、套用時位移」的情況，而 v0.1.17 未吸收它。`serializabilityProof.permutationStable: true`（v0.1.17 欄位名；更名見 §4.5）為寫死值（`:116-121`），不構成任何證明。
2. **拒絕前無副作用，但不可觀測**：#4 未部分寫入（canonical 檔未變），但以例外中斷；CLI／harness 拿不到 `verdict:'blocked'` 與衝突明細，提案者無從據以 re-propose。
3. **角色未比對**：#5 中提案者本人以 steward 身分完成 apply。`checkStewardPermission` 只在 `arbitrateStewardRequest`（`steward.ts:316`）被呼叫；`applyStewardPlan`／`executeBrokerScopedWrite`／CLI `broker steward apply` 均未比對；CLI 可任意帶 `--steward-id`。
4. **`needs-steward` 被放行**：`planStewardApply` 只擋 blocked／human-required（`steward.ts:416-419`），`needs-steward` 進入 apply，但沒有「steward 撰寫最終 patch」的實作。
5. **測試盲點的範圍**：`validate-broker-compose.ts` 只測 compose verdict；`validate-broker-steward.ts` 只測單一 proposal apply（IMPL_PLAN §2.3）。既有多作者 `MutationRequest`（`composeTransactionalMutations`）測試已存在；盲點應限定為**同檔 text `PatchProposal` 多 proposal 真 apply** 路徑。

本節只描述歷史基準 v0.1.17；不構成對現行 main 或 PR #198 的判定（見 §2.6），也不構成「已修正」的主張。

### 2.6 現況分層：main、候選修正與相關功能（〔審閱核對 2026-10-07〕）

- **main `3b0f7660`**：text steward 路徑與 v0.1.17 為同一 blob，探針揭露的缺口在 main 上**尚未**修正（依審閱比對；作者需自行確認）。
- **候選 PR #198（未合併，head `65e8aab3`）**：含 immutable-base 合成與新檢查，但與本稿草案有四項契約差異，**須先選定契約再寫性質**：

| 項目 | 本稿原草案 | #198 候選 | 待決 |
|---|---|---|---|
| context | 任一 context 重疊即拒（保守） | 允許兩份編輯只共享**未修改**的 context | 選定後須量化 false rejection（§4.3） |
| needs-steward | 無 steward final patch 即 blocked | 允許可確定性合成的 text／JSON-pointer 情形通過；此路由標籤不等於真衝突分母 | 真衝突分母須由獨立政策定義（§5.4） |
| permutation | 實際跑 permutation（N≤k 全排列） | n≤4 全排列；n>4 為 rotations＋reversal，共 n+1 次 | 有界檢查不是一般證明（§4.5） |
| identity | `stewardId ∉ actorId` 且 kind=neutral | 僅比對去空白的 actor／steward 標籤；空 steward ID 無該項錯誤；direct API 無 neutral kind 參數 | 只能稱角色一致性檢查（§3.5、§4.7） |

- **FileHeat（#184 所涉）**：已由 **PR #197 合併**；預設 static，hybrid／learned 為 opt-in，**不能**寫成完整 EMA 多訊號模型。
- **Native hot parking（#181 所涉）**：已由 **PR #199 合併**；release／expiry 只給予重新驗證資格，**不會**直接授權舊 patch。審閱稱 #199 合併後的五項 CI 於 11:53:20 UTC（19:53:20 Asia/Taipei）全部通過；CI 綠燈不等於論文實驗完成。
- **issue 狀態 ≠ PR 狀態**：#181、#184 issue 仍 open，不代表相關 PR 未合併。
- **舊 harness 觀察的時間語境**：舊稿「core 無 park／harness 觀察不到 park」「#184 僅設計未 merge」等敘述**綁 v0.1.17／Oct 6 版本**，對 main 已不成立。舊 polling-wait benchmark（nqwait 臂以輪詢 activeIntent file-blocker＋re-eval 實現等待）**不能**回填為 native ticket／resume 的實測。

### 2.7 歷史缺口修復清單（對 v1 承諾的端到端驗證；#196）

下列項目是**修復**，用來讓 C1–C3 能被量測；修正方向為建議，契約以作者核定版本為準（§2.6）。

| ID | 層 | 歷史缺口（v0.1.17） | 修正方向（建議，非定案） | 對應 |
|---|---|---|---|---|
| P0-1 | core | 循序 reduce；位移致失敗、結果依排序 | 對同一 base 解析；選定相容性規則；依 base 位置構造輸出 | C2 §4.4 |
| P0-2 | core | 合成失敗以 throw 結束 | 捕捉 → `ok:false, verdict:'blocked'`＋reason code＋proposalId；拒絕前無副作用 | C1 §3.6 |
| P0-3 | core | `needs-steward` 放行但無最終 patch | 依選定契約：不可確定性合成者即 blocked（`steward-final-patch-required`） | C1 |
| P0-4 | core＋CLI | 提案者可自我 apply | 所有寫入入口做角色一致性檢查；違反 `invalid-steward-identity` | C1 §3.5 |
| P0-5 | harness | atm-bench 未驅動真 compose／steward；0 lost 綁 sync writer | 新增 steward 臂與強基線臂（§5.2） | C3 |
| P0-6 | 測試 | 無同檔 text 多 proposal 真 apply 驗收 | S1–S5 擴充（§4.9）＋property／metamorphic tests | C2 |

---

## 3. 協定與信任模型（C1）

本節是 C1 的規格草案。狀態、欄位與終態語意為本文提議，須由作者與 #198 最終契約對齊後凍結〔待 M0〕。

### 3.1 參與者與責任

| 參與者 | 責任 | 不負責 |
|---|---|---|
| proposer（代理） | 基於某個 base digest 產生 proposal（logical operation ID、actor、patch、anchors／atomRefs） | 寫入 canonical 檔 |
| broker | 准入：路由至 direct／compose／queue／park／blocked（v1 詞彙） | 合成與提交 |
| batch closer | 依明定規則封閉一個 batch（成員集合＋base digest） | 判定相容性 |
| composer | 在 base 上解析所有編輯、檢查相容性、產生唯一候選輸出或拒絕 | 寫入 |
| validator | 依政策驗證候選輸出（語法、scope、語意驗證收據） | 寫入 |
| steward（中立） | 在受互斥保護的區間內重驗 canonical digest、替換、發出提交收據 | 撰寫或修改編輯內容（P2-1 之外） |

### 3.2 狀態機

**表 C1　logical operation 狀態與必要記錄**

| 狀態 | 含義 | 可計為 committed |
|---|---|---|
| proposed | 提案產生；保留 logical operation ID、base digest 與 patch digest | 否 |
| eligible／blocked | 經 scope、base、identity、syntax 與衝突檢查後的結果 | 否 |
| batched → composed | 以 batch ID 封存成員與 base，產生唯一候選輸出 | 否 |
| validated | 完成所要求的驗證；記錄 validator 版本與結果 | 否 |
| **committed** | 在受互斥保護的 compare-and-replace 完成，並取得提交收據 | **是** |
| aborted／retryable | 記錄原因；保持原檔，或進入明定恢復流程 | 否 |
| reproposed／exhausted | 同一 logical operation 在新 base 重提，或超出重試預算 | 否 |

規則：

- **准入不等於提交成功**。每個 logical operation 最多計一次有效完成；重試另計 attempts。
- 取消、超時與未處理項**不能**從分母消失（§5.4）。
- `blocked` 只表示**提交前**拒絕且 canonical 未變。

### 3.3 Batch closure、late joiner 與重提

- **closure 規則**須明定：時間窗、數量閾值或 holder release 三者之一（或組合），以及由誰排程。v0.1.17 只有手動 CLI，沒有在准入之後自動收集 proposal 的機制〔IMPL_PLAN §2.1〕。
- **late joiner**：batch 封閉後到達、仍基於同一 base 的 proposal，須明定進入下一 batch、或因 base 已前進而轉為 retryable。
- **重提**：前一 batch 提交後 canonical digest 改變，後到的 proposal 會遇到 `file-hash-drift`／metadata mismatch；須定義「退回 → 在新 base 重新產生 patch → 重新 compose」，並量 attempts／rounds 與 deadline。
- native hot parking（PR #199）的 release／expiry 只給予**重新驗證資格**，不授權舊 patch；與本節重提語意一致，但其與 batch closure 的交互作用〔待 M2 定義〕。

### 3.4 提交界線

只有在**同一互斥區間內**重新驗證 canonical digest 並完成替換，單檔提交才有機會被視為一個可線性化操作。若比對與寫入之間可被其他 writer 插入，就仍有 TOCTOU 風險；proposal 端攜帶的 hash 本身不會消除此風險。v0.1.17 的 `applyTransactionalStewardPlan` 已檢查 writerRole、digest、scope 與 base hash（stale → blocked），跨 process 情境另需 per-file apply lock（附錄 A.4 的負面對照顯示 apply-lock off 時 composer_merge 路徑會遺失更新〔作者報告值〕）。

### 3.5 信任模型：主張與必要前提

**表 C2　主張、必要前提與本文可接受措辭**

| 主張 | 必要前提或證據 | 本文可接受措辭 |
|---|---|---|
| proposer 無法自我 apply | 可信的 actor 身份綁定；所有寫入入口均檢查；不存在可繞行路徑 | 若僅字串比對（v0.1.17 修正方向與 #198 皆是），稱**角色一致性檢查**，不稱身份保證 |
| proposer 無法直接寫 canonical | OS 權限或 capability 阻止所有未授權寫入；syscall／filesystem 監測只提供觀測證據 | 「**在已監測路徑中未觀測到** proposer 直接寫入」，附監測途徑與覆蓋率；**不**稱「無法寫入」 |
| stale base 不會提交 | 鎖保護 digest 重驗到 replacement；所有合作 writer 遵守 | 「在合作式 writer 與鎖協定下防止 stale commit」 |
| 例外不留下部分更新 | 列舉失敗點、驗證 rollback 完成、收據與檔案狀態一致 | 「例外處理的**補償**保證」 |
| 單檔 crash atomicity | 原子替換原語與平台語意；kill／斷電測試、journal 恢復規則 | 未測前**不主張**；測後限「已測故障模型內保持舊或新版本」 |
| 多檔原子性與耐久性 | 跨檔提交機制、讀者可見性、fsync 與 recovery protocol | 列為限制，不以 rollback 推論 |

process kill 不等於斷電；未驗證 fsync 與檔案系統故障模型前，不主張斷電耐久性。恢復測試設計可參考 SQLite atomic commit 的方法，但不移植其保證。

### 3.6 收據終態

收據應描述**真實終態**：

| 收據 | 意義 |
|---|---|
| `committed` | 互斥區間內 digest 重驗通過並完成替換；附 output digest |
| `blocked` | 提交前拒絕，canonical 未變；附 reason code（如 `compose-context-mismatch`、`steward-final-patch-required`、`invalid-steward-identity`、`file-hash-drift`）與衝突 proposalId |
| `rolled-back` | 曾進入寫入，補償成功、原檔還原 |
| `recovery-required` | 終態待修復（例如 rollback 自身失敗）；**不得**仍回 `blocked` |

收據遺失但寫入成功時，須以 logical operation ID 與 digest 對帳，避免重試造成重複更新。這把 v1 §3.4「blocked 是 containment，而非刪除提案者工作」的語意落到可被 CLI／harness 觀測的層級。

### 3.7 最低事件欄位

`run_id`、`logical_id`、`attempt_id`、`batch_id`、base／patch／output digest、actor／pid、reason code、單調時間戳、ATM／harness／oracle SHA。跨 process 計時須明定可比較的 timebase。舊 harness 的事件欄位（`steward_verdict`、`blocked_reason`、`repropose_rounds`、`proposer_direct_writes`）併入上列，`proposer_direct_writes` 改為附監測覆蓋率的 write authority 指標（§5.4）。

---

## 4. 合成性質與實作（C2）

### 4.1 既有路徑（v0.1.17 `8dd6a1c6`，程式碼層事實）

以下引自 `COMPOSER_STEWARD_IMPL_PLAN.md` §2.1（行號以 v0.1.17 本機樹為準；`compose.ts` 與 `steward-transactional-apply.ts` 在 v0.1.17 與 Oct 6 HEAD `ed317820` 兩樹相同；審閱稱 main `3b0f7660` 的 text steward 亦為同一 blob〔審閱核對 2026-10-07〕）。

| 階段 | 元件 | v0.1.17 行為 |
|---|---|---|
| 准入 → compose | `evaluate-broker-admission.ts:48-49`；`decision.ts:228`、`decision/proposal-overlap.ts:96` | `deterministic-composer`／`neutral-steward` lane → disposition `compose`（`composer-routed`）。准入只決定「要走 compose」；無自動 batch closure |
| compose | `composeBrokerProposals`（`compose.ts:34`） | 排序 → CID 衝突回 `ok:false, blocked-cid-conflict`；baseCommit／fileBeforeHash 不一致、anchor 重疊、hunk 範圍重疊回 `ok:true, needs-steward`；否則 `parallel-safe` |
| 排序 | `merge-plan.ts:26-55` | `targetFile → firstAnchorKey（字串）→ proposalId`，不是檔內位置；`parsePatchHunkRanges` 只讀 `@@ -a,b` 標頭 |
| applyMethod | `merge-plan.ts:75-78` | `parallel-safe → patch-apply`；其他 → `steward-authored-final-patch`（無程式真正產生此 patch） |
| plan | `planStewardApply`（`steward.ts:133`） | schema、blocked、human-required、scope lock、stale-base-commit／file-hash-drift；`needs-steward` 可通過 |
| apply | `applyStewardPlan`（`steward.ts:161`） | `buildPatchProposalComposition` → 語意驗證收據 → `applyTransactionalStewardPlan(writerRole:'neutral-steward')`，寫 evidence |
| 文字合成 | `steward-transactional-apply.ts:143-173` | 名為 "against immutable base"，實為對中間檔循序 reduce（`:148`）；`serializabilityProof.permutationStable: true` 寫死（`:116-121`） |
| 寫入 | `steward-transactional-apply.ts:246-389` | writerRole、digest、scope、base hash（stale → blocked）→ temp → canonical；失敗時 rollback（補償語意見 §4.8） |
| 嚴格套用 | `applyUnifiedPatch`（`unified-patch.ts:79`） | context 不符即 throw `UnifiedPatchApplicationError`（`ATM_UNIFIED_PATCH_CONTEXT_MISMATCH`） |
| 角色 | `checkStewardPermission` | 只在 `arbitrateStewardRequest`（`steward.ts:316`）被呼叫；其餘寫入入口未比對 |

另有一條結構化 composer（`transactional-composer.ts:68 composeTransactionalMutations`；text-range adapter 只支援 `.md/.txt`），吃 `MutationRequest`，具 canMerge／skipped／returnedQueueRequestIds 語意且已有多作者測試；兩條路徑的統一列為 P2-3。

### 4.2 Patch 模型：changed span、context span 與 insertion gap

**更正**：舊稿稱「compose 的 `@@ -a,b` 範圍檢查未涵蓋 context 行」，措辭不精確。依 GNU diffutils 的 unified format 定義，hunk 標頭 `@@ -l,s +l,s @@` 的 **old range 已包含 context 行與刪除行**。因此以 old range 判重疊，其實是以「含 context 的區間」判斷，它既無法區分「真的被改的行」與「只是被引用的 context」，也無法表示純插入的位置。ATM `parsePatchHunkRanges` 的實際行為（含 count 省略、count=0 的處理）〔待核對 parser 實作〕。

本文對每個 hunk 在 base `B` 上分開三種區間（以半開區間 `[a, b)` 表示被消耗的原始行）：

| 區間 | 定義 | 用途 |
|---|---|---|
| **changed span** | 被刪除或替換的原始行（`-` 行） | 判定真寫入衝突 |
| **context span** | hunk 中未改動、用來定位的原始行（空白前綴行） | 判定定位依賴；依契約決定是否可共享 |
| **insertion gap** | 純插入點，位於兩行之間；old length 可為 0 | 判定插入順序歧義 |

規則：

- **同一 gap 的兩個插入**若沒有明定順序，**必須拒絕**；不能因兩者的 changed span 交集為空就判為不衝突。
- 相鄰端點、檔首、檔尾、重複內容與多 hunk 必須有唯一定位規則；不支援的語法明確拒絕。
- 解析器必須驗證 context 內容、old／new counts、合法路徑與支援的檔案格式。

### 4.3 相容性規則：兩個候選契約

| 契約 | 規則 | 優點 | 代價 |
|---|---|---|---|
| **保守（原草案）** | 兩 hunk 的 changed span 與 context span 任一交疊即不相容；同 gap 雙插入不相容 | 凡被接受者，每份 hunk 的 context 在 B 上的驗證都不被他人改動；假設簡單 | 部分語意可合併的相鄰編輯被誤拒；須量化 false rejection |
| **精確（#198 候選）** | changed span 不交疊；允許只共享**未修改**的 context；同 gap 雙插入不相容 | coverage 較高 | 須明確說明解析在 B 上完成而非在中間檔重新驗證；需獨立 oracle 判定應允許／應拒絕 |

本稿**尚未**在兩者間定案（待作者決定，見吸收對照）；§4.4 的命題對兩者皆適用，只要「相容」依所選規則定義。消融 §5.6 比較兩者的安全性、false rejection 與 coverage。

### 4.4 單檔同基底合成命題（證明義務；證明待 M1）

**命題（單檔、同基底）**：設所有有效編輯皆唯一對齊於同一 base `B`；其 changed span、所選契約要求保護的 context 與 insertion gap 依明定規則兩兩相容。若 composer 先在 `B` 上解析所有編輯，再依唯一的基底位置規則輸出未改動片段與替換片段，則：

1. **決定性**：輸出只由 `B` 與編輯集合決定，不依賴 proposal 輸入順序；
2. **保留性**：每個被接受編輯的效果恰好實現一次（含刪除效果）；
3. **frame property**：未被任何編輯觸及的片段 byte 等值保持不變。

**證明拆成三個引理**：

- **L1 唯一解析**：每個 hunk 對應的 base 區間或 gap 唯一，且 context 與長度檢查已通過。
- **L2 無歧義分割**：相容編輯把 `B` 切成不交疊、可排序的保留片段與替換位置；所有插入的邊界規則一致。
- **L3 輸出不變性**：輸出串接只取決於唯一排序後的集合，故重排輸入不改變 bytes；由片段構造得到保留性與 frame property。

**命題不涵蓋**：語意無衝突、liveness、身份可信、crash durability、跨檔 invariant。

**拒絕前無副作用**：在 composer 回傳不相容或解析錯誤時，steward 不進入寫入階段，canonical digest 不變；此性質由 §3.6 收據與 S2 測試檢查，而非由命題推出。

### 4.5 Composition determinism ≠ serializability

**更名**：舊實作與舊稿的 `serializabilityProof.permutationStable` 應更名為 **composition determinism**（合成決定性；建議欄位名如 `compositionDeterminism`，實際命名由作者決定）。

- 排列不變性是**合成函式**的性質。資料庫意義的可序列化關注所有已提交交易的讀寫觀測是否等價於某一序列；讀取集合、跨檔依賴與衝突圖未定義前，不應以 serializability 命名。
- **排列測試不是證明**。小集合全排列可作回歸測試；大集合隨機排列可找反例。#198 候選的「n≤4 全排列、n>4 為 rotations＋reversal 共 n+1 次」是**有界檢查**，不是一般證明。
- n! 枚舉不必放進 production hot path：可用確定的正規化構造（§4.4）保證決定性，在測試時再驗證排列不變性。欄位若保留，應記錄實際檢查的排列數與方法，而非布林常數。

### 4.6 Fail-closed：結構化 blocked 收據

- **合成錯誤 → blocked**：在 `buildPatchProposalComposition` 捕捉解析／context 錯誤；回 `ok:false, verdict:'blocked'`＋reason code＋衝突 proposalId；不部分寫入。
- **不可確定性合成之 `needs-steward` → blocked**（`steward-final-patch-required`）；真正由 steward 解衝突屬 P2-1。依 #198 契約，可確定性合成的 text／JSON-pointer 情形可能放行；`needs-steward` 路由標籤因此**不等於**真衝突分母。
- 收據終態依 §3.6；rollback 失敗須回 `recovery-required`。

### 4.7 角色一致性檢查（原稱 identity gate）

所有寫入入口（core `applyStewardPlan`、`executeBrokerScopedWrite`、CLI `broker steward apply`）一律比對 `stewardId` 與 proposals 的 `actorId`；違反即 `blocked`＋`invalid-steward-identity`，檔案不變。

- 若此比對僅基於字串標籤（v0.1.17 修正方向與 #198 候選皆是），它是**角色一致性檢查**，可被冒用的字串繞過，不是身份保證或 OS 隔離。
- #198 候選的邊界〔審閱核對 2026-10-07〕：僅比對去空白的 actor／steward 標籤；空 steward ID 無該項錯誤；direct API 無 neutral kind 參數。是否補上空 ID 拒絕與 kind 檢查，待作者決定。
- CLI 在無 runtime handshake 時走 `directApplyResult` 是否也應要求 handshake／identity，列為 P1-7〔待核對〕。
- 「proposer 零直接寫入」只能作為**監測路徑觀測**（§3.5、§5.4）。

### 4.8 寫入：拆開四種保證

舊稿把「temp 寫入＋失敗 rollback」稱為交易式寫入並視為原子交易，措辭過強。本文拆成：

| 保證 | v0.1.17 已有 | 本文主張範圍 |
|---|---|---|
| 例外補償 | 失敗 rollback（`failAfterWrites` 回歸測試 S5） | 已測失敗點內「例外不留部分更新」；須列舉失敗點並驗證收據與檔案一致 |
| 單檔替換 | temp → canonical | 替換原語的平台語意〔待核對〕；未測 kill／斷電前**不稱 crash atomicity** |
| crash recovery | 來源未提供 | 不主張；故障矩陣列 kill、寫入失敗、rollback 失敗、收據遺失（§5.3） |
| 多檔可見性 | rollback 還原所有檔 | 不主張多檔原子性或讀者可見性；列為限制 |

### 4.9 驗收場景（M1；S1–S5 保留並擴充）

| ID | 場景 | 期望 | v0.1.17 歷史基準 |
|---|---|---|---|
| **S1a** | 同檔、不重疊、兩個等長替換 | 合成並 committed；A、B 皆在，其餘 byte 不變 | ✅（探針 #1） |
| **S1b** | 同檔、不重疊、上方插入或刪除行；兩種輸入排序各跑一次 | 兩種排序皆 committed、A、B 皆保留、**輸出 byte hash 相同** | ❌（探針 #2 throw；#3 成功 → 順序依賴） |
| **S2** | 同檔、真 overlap（changed span 交疊） | blocked 收據＋conflict 明細＋proposalId；canonical hash 不變；不 throw | ❌（探針 #4：檔案未變，但 throw） |
| **S3** | `stewardId` 等於任一 `actorId`（API 與 CLI 各一次；另加空 ID） | `blocked`＋`invalid-steward-identity`；檔案不變 | ❌（探針 #5：`applied`） |
| S4 | canonical 檔在 compose 之後被改 | `file-hash-drift` → blocked，可重提 | 現有行為（回歸） |
| S5 | 多檔部分失敗（`failAfterWrites`） | `rolled-back`，所有檔還原 | 現有行為（回歸） |
| S1c（新） | 同 gap 雙插入 | blocked（插入順序歧義） | 〔待 M1〕 |
| S1d（新） | context 重疊但 changed span 不交疊 | 依所選契約：保守→blocked；精確→committed 且與獨立 oracle 一致 | 〔待 M1〕 |
| S1e（新） | 檔首／檔尾、相鄰端點、重複 context、多 hunk、無尾端換行 | 唯一定位或明確拒絕 | 〔待 M1〕 |
| S5b（新） | rollback 自身失敗、收據遺失 | `recovery-required`；以 operation ID＋digest 對帳，不重複提交 | 〔待 M1〕 |

另加 **metamorphic／property tests**：重排 proposal 不變、每個 proposal 只計一次、無關片段 byte 等值、拒絕前後 hash 一致、明定政策下重複提交的 idempotency。

### 4.10 與准入路由的關係（背景）

- **冷熱分級准入**決定「誰要走 compose」：熱檔 proposal-first 下，無其他 writer → `provisional-write-lease`；同檔已有非 provisional holder → `composer-routed`；同 region 撞 provisional holder → `true-conflict`。
- **冷檔 serial queue（#180）**處理同 atom 必須序列化的情況；**native hot parking（PR #199，main 已合併）**處理熱檔 late joiner 的重新驗證。
- **合成提交協定**處理同檔不同 region 的 proposal——本文主軸。
- 交互作用：在熱檔情境下，v0.1.17 core 會把**同 region** 的後續 writer 也路由到 composer（`HOT_FILE_LATENCY.md` §1.1）。修正 P0-2／P0-3 後，這些同區撞車會從「在 sync writer 下看起來 0 lost」變成可觀測的 blocked。這是設計還是 bug、是否應在准入層改為 queue／park，列為 P1-4，需作者確認〔待核對〕；論文會同時報正確性與重試成本，而不以壓低 blocked 率為目標。

---

## 5. 評估方法（C3；計畫中）

本節為預先登記的評估設計，**均未執行**。規模數字是建議值，正式 seed 數與 repetitions 由 pilot（M3）調整。

### 5.1 RQ 與量測對應

| RQ | 主要指標 | 主要比較 |
|---|---|---|
| RQ1 | lost among committed、unsafe acceptance、false rejection、frame violations、receipt completeness | 完整 ATM vs 獨立 oracle；保守 vs 精確契約 |
| RQ2 | correct completion／offered、eligible coverage、goodput、p50/p95/p99/max 端到端延遲、attempts、eligible missing | 完整 ATM vs lock、CAS retry、Git three-way、bare composer |
| RQ3 | 上列指標對 patch 形狀、hot ratio、batch window、process 數的轉折 | 定向 sweep |
| RQ4 | write authority（附監測覆蓋率）、收據對帳率、角色檢查繞行測試 | 合作式 vs 刻意繞行的故障注入 |

### 5.2 實驗臂

control、stale 與 sync 保留為**診斷臂**；主效果相對至少兩種正確且可運作的強基線量測，否則只能證明安全方法優於故意不安全的整檔覆寫。

**表 E1　實驗臂**

| 類別 | 實驗臂 | 實作與角色 | 用途 | 狀態 |
|---|---|---|---|---|
| 診斷 | raw overwrite（control） | 無協調；舊 base 整檔覆寫 | 故障注入下界，不作正確性競爭者 | 既有〔作者報告值〕 |
| 診斷 | ATM admission only（stale） | 相同准入演算法與設定，省略 composer／steward | 隔離缺少提交協定的後果 | 既有〔作者報告值〕 |
| 診斷 | ideal sync | apply 當下同步 read-modify-write；列出理想化假設 | harness 正確性參考，**不**冒稱真實合併上界 | 既有〔作者報告值〕 |
| 主基線 | per-file lock | 鎖內讀最新 base、產生或重建變更、驗證並寫回 | 保守且正確的序列化基線 | 〔待 M2〕 |
| 主基線 | optimistic CAS retry | 由 snapshot 產生變更；CAS 失敗即重新產生或 rebase；重試全計入 | 一般 OCC 基線（Kung & Robinson 1981） | 〔待 M2〕 |
| 主基線 | Git three-way | 相同 base 與相同 patches 經 `git merge-file`；採同樣驗證與鎖定提交 | 既有合併能力與衝突偵測 | 〔待 M2；是否立即實作待作者決定〕 |
| 消融 | bare composer | 相同 immutable composer 與 guarded apply，移除 broker 准入 | 隔離合成收益與 ATM 路由治理的成本或增益 | 〔待 M2〕 |
| **方法** | **完整 ATM（composer＋steward）** | 真實 proposal API、batch closure、steward commit 與 retry | 完整方法；所有結果綁同一 frozen commit | 〔待 M2〕 |

**公平性控制**：

- `git merge-file` 是雙側三方合併；n-way 必須披露 fold 順序並測順序敏感性；不以 ours／theirs／union 選項掩蓋衝突。
- OCC 的 validation 與 write 必須共用不可分割的受保護提交區間。
- 相同 logical tasks、base fixtures、到達時間、patch 內容與依賴；優先使用**預先產生的 patch trace**，避免模型隨機性掩蓋合成差異。
- 所有正確基線使用相同 correctness oracle、timeout、retry budget、驗證要求與 durability 設定；不得只給 ATM 額外快取或較寬鬆的衝突政策。
- 若 Git 能合併 context 重疊案例而 ATM 拒絕，分開列**政策差異**與**執行失敗**，並報 eligible coverage；不把不同接受集合壓成單一成功率。
- 以固定到達負載與固定工作量各測一次；並行度、CPU／I/O 配額與 lock granularity 一致；記錄 warmup、執行順序與環境。

### 5.3 工作負載與邊界案例

先區分**文字相容**、**context 假衝突**、**真實寫入衝突**與**語意依賴**；高 hot ratio 與高 overlap 無法單獨代表所有風險。

**表 E2　預先登記的測試維度**

| 維度 | 最低必測 | 擴大實驗 |
|---|---|---|
| patch 形狀 | 等長替換、插入、刪除、多 hunk | rename、binary、mode、CRLF、無尾端換行（不支援者驗證拒絕） |
| 相對位置 | 上方插刪＋下方修改；首尾與相鄰邊界 | 重複 context、空檔、同 gap 純插入、零長區間 |
| 衝突關係 | 不重疊；context 重疊但變更不交疊；真 overlap | 跨 symbol 語意相依、跨檔 invariant、共同讀依賴 |
| 時間與基底 | 同 base；compose 後變更；late joiner | 混合 base、慢 writer、舊 proposal 重播、重複 delivery |
| 併發與熱度 | 1、2、4、8 workers；cold 與全 hot | 16、32 workers；hot ratio 0／0.5／0.8／1.0；偏斜分佈 |
| compose window | 0、短、中三檔；記實際 batch size | timer／count closure、負載自適應；對延遲 SLO |
| 執行環境 | 單 process async；2、4、8 processes | 多核心；多機僅在擴大協定範圍時加入 |
| 故障注入 | context mismatch、stale CAS、validator reject | lock timeout、kill、寫入失敗、rollback 失敗、收據遺失 |

**可知道正解的子集**：人工合成 workload 的每個 logical edit 帶不可重複的語意標識與基底座標；oracle 由**獨立參考實作**產生完整 expected output。context 重疊案例由獨立參考實作或人工規格判定應允許／應拒絕，避免受測 composer 同時充當裁判。另加入數個真實 repository、不同檔案類型（文件、設定、程式）的 patch traces；真 LLM 生成的 patch 屬外部效度補強，於 deterministic trace 主結果完成後另評。

### 5.4 Oracle 與指標分母（先於結果表）

**marker 不足以當唯一裁判**：舊 oracle（committed intent 的 marker 須出現在最終 worktree）會漏掉重複插入、鄰近內容破壞、錯位或語意錯誤；marker 不在也可能是後續合法刪除。最低 oracle 比較**完整 bytes**（或 AST／規格要求），再核對每個操作效果、frame property、唯一性與提交收據。

**表 E3　指標定義**

| 指標 | 分子／分母或量測點 |
|---|---|
| offered／attempted | offered＝唯一 logical operations；attempted 含所有 retry attempts；兩者分開 |
| eligible coverage | 依**預先登記的獨立政策**可處理之 operations／offered；不得以受測方法自己的接受結果循環定義 |
| commit rate | 唯一 committed operations／offered；另報 committed／eligible |
| correct completion | 通過保留、精確輸出與必要語意檢查的唯一 operations／offered |
| lost among committed | 已 acknowledged commit、且未被後續合法操作取代的應存效果中，終態遺失數／應存效果數 |
| eligible missing | 到 deadline 仍未正確完成的 eligible operations／eligible（含 blocked、超時、重試耗盡） |
| unsafe acceptance | 應拒絕卻提交的案例／獨立 oracle 判定應拒絕的案例 |
| false rejection | 依指定政策本可安全合成卻被拒的案例／該政策允許案例 |
| receipt completeness | 具完整可對帳收據的終端 attempts／全部終端 attempts（系統 crash 也列入） |
| goodput／tail latency | 正確完成 logical operations／wall seconds；端到端含排隊、window、retry、驗證與 commit |
| write authority | 已監測 I/O 的 proposer 直接寫入次數；附監測途徑與覆蓋率，不以零事件取代權限證明 |

**reject-all 可揭露**：拒絕全部提案也能得到 zero lost。主表因此必須同時報 offered、eligible、committed、correct、blocked、retry exhausted 與 unresolved，以及 goodput 與延遲。分母為零的格子標「不適用」，**不可**填 0% 當成安全成果。所有率標明 ratio of sums 或 mean of per-run ratios；不同版本、分母與 aggregation 不得接成單一提升百分比。

### 5.5 Seeds、推論單位與統計

- **workload seed 與 scheduler seed 分開**。舊稿「所有情境 `seed=42`、×3」只是同一 workload 的三次交錯重跑，**不是**三個獨立 workload。每個情境先產生多個獨立 workload seeds，再在各 seed 下重跑數個 scheduler seeds；各臂使用**配對**的 traces。
- **推論單位**為 workload（或 repository cluster），不把同一 run 內數百個相關 intents 當獨立樣本來縮窄 CI。主分析報 paired difference／ratio 的 95% CI；必要時用階層 bootstrap，另展示各 run。
- **零事件的解讀**：N 個獨立同分佈機會觀察到零次失敗時，一側 95% 二項上界為 `1 − 0.05^(1/N)`，N 大時約 `3/N`。支持「<1%」約需 299 個獨立零失敗樣本、「<0.1%」約 2,995、「<0.01%」約 29,956；不是 3 次重跑可以支持，且不能直接把同一 process 中高度相關的 intents 數當 N。全零 cluster 的普通 bootstrap 可能退化為 [0,0]，不能據此聲稱無風險。形式化命題（§4.4）處理其明定模型中的所有有效輸入；實驗上界只處理抽樣到的環境，兩者不可互相替代。
- **延遲**：報 p50、p95、p99、max、timeout 與完成率；不只算成功者延遲。354 個樣本的 p99 尾端約只有 3.54 個點，須揭露樣本量與分位數定義；不可平均各 run 的 p95／p99 後稱 pooled quantile。分段報 queue、compose window、validation、lock wait、write、retry；完成集合不同時另報 fixed-workload makespan。
- 先以少量 seed 做 pilot 估計變異，之後固定主要結果、最小實務效果、停止規則與種子集合。

### 5.6 消融（主要 RQ 之外，另標）

| 比較 | 測量重點 | 使用限制 |
|---|---|---|
| 完整方法 vs 舊循序套用（v0.1.17） | 行數位移、輸入排列與成功範圍 | 舊方法可能錯誤，只作機制診斷 |
| broker on vs off（＝bare composer） | 固定 composer 與提交路徑，測准入的淨增益與成本 | 避免把裸合併器收益全歸給 ATM |
| 保守 context vs 精確編輯範圍契約 | 安全性、false rejection、coverage | 精確策略需先有規格與獨立 oracle |
| compose window／batch size | 吞吐、tail latency、stale 與重提率 | 含 0 window 或可比序列基線 |
| 有無 retry／不同 retry budget | correct completion、liveness、額外 work | no retry 是受限臂，不能只報成功者 |
| 有無 registry CAS 與 apply lock | 殘留 lease、TOCTOU、lost effects | 明標 fault injection，與主比較隔離 |
| 有無驗證與角色檢查 | validator 成本、拒絕原因、監測到的寫入 | 移除安全機制的臂不作可部署推薦 |

### 5.7 分階段計畫與停止條件

本稿採用審閱的 M0–M5 分階段（取代 IMPL_PLAN 原 M0–M3 的論文級里程碑；IMPL_PLAN 的 M1 core 修正對應此處 M1，M2 harness 接線對應此處 M2，原 M3 論文級證據拆為此處 M3 pilot 與 M4 主結果）。

| 階段 | 工作與輸出 | 通過條件 |
|---|---|---|
| **M0 規格與校正** | 凍結版本錨點；選定相容性契約；列支援 patch、狀態機、信任模型、oracle 與分母；自 run 級整數重算舊表 | 所有主張有範圍與可測反例；基線與原始資料可定位 |
| **M1 單檔正確性** | S1–S5 加插刪、context、gap、重複 ID、stale base 與錯誤收據；小型枚舉與 property tests；完成 §4.4 證明 | 被接受者完整輸出正確；被拒者未改檔；失敗不被收據掩蓋 |
| **M2 Harness 真接線** | 完整 compose → steward commit；batch、retry、receipt；強基線臂；與獨立 oracle 對帳 | 每個 intent 追到終態；每筆時間可分解；無遺失事件紀錄 |
| **M3 配對 pilot** | 5 主臂（lock、CAS retry、Git、bare composer、完整 ATM）＋3 診斷臂；fixed decision／batch trace replay | 重算表與原始檔一致；找出變異與瓶頸；**不以 pilot 宣稱勝出** |
| **M4 最小主結果** | 預先固定 workload seeds 與 repetitions；單 process 與多 process | 同時報 correctness、coverage、goodput、tail latency 與 CI |
| **M5 重現與決策** | 全新環境重跑；原稿、artifact、版本與 figures 對帳 | 一個入口重建主要表；據結果決定完整論文或經驗報告 |

**建議最小主矩陣（未執行）**：3 workloads（cold／低競爭、hot 且不相交、hot 混合衝突）× 2 拓撲（1 process × 8 workers、8 processes × 1 worker）× 5 主臂 × 10 workload seeds × 3 次重啟＝900 runs；3 診斷臂只跑單 process＝270 runs；合計 1,170。每 run 1,000 offered logical operations，retry 另計。另有 24 類 correctness families × 10 輸入 × API／CLI 雙入口＝480 scenario jobs；故障測試 8 cutpoints × 3 機制 × 10 seeds × 單／多檔＝480 fault runs。三種 jobs 不同質，不加成同一統計樣本數。

**停止規則**：任何 arm 出現資料破壞、oracle 不一致或收據對不上時，不繼續產生效能結論；先保存失敗工件、界定根因與受影響版本，修正後重新凍結 commit，重跑受影響的全部對照臂。

---

## 6. 結果與 tradeoff（預留；〔待 M2/M4〕）

本節只有表格骨架。診斷臂列出的舊數字為**作者報告值**、使用舊 marker oracle 與舊分母、綁 Oct 6 core@0.1.2，**不可**與未來主臂數字直接比較；正式稿須在同一 frozen commit 上以 §5.4 的定義重跑全部臂。

**表 R1　正確性與完成結果（每情境；〔待 M2/M4〕）**

| 情境 | 臂 | offered | eligible | committed | correct | blocked | retry exhausted | unresolved | lost among committed | unsafe acc. | false rej. | receipt compl. |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| h1-a8 | control（診斷） | 354/rep〔作者報告值〕 | 不適用 | 354/rep〔作者報告值〕 | 〔待重算〕（舊 marker oracle pass/offered 28.5%〔作者報告值〕） | — | — | — | 253/rep（71.5%）〔作者報告值，舊 marker oracle〕 | 不適用 | 不適用 | 不適用 |
| h1-a8 | stale／native（診斷） | 354/rep〔作者報告值〕 | 不適用 | 266/rep〔作者報告值〕 | 〔待重算〕（舊 oracle pass/offered 26.4%〔作者報告值〕） | 准入 reject 88/rep〔作者報告值〕 | — | — | 172.7/rep（64.9%，分母＝committed；ratio-of-sums 518/798）〔作者報告值；A4 已核〕 | 不適用 | 不適用 | 不適用 |
| h1-a8 | sync（診斷） | 354/rep〔作者報告值〕 | 不適用 | 270/rep〔作者報告值〕 | 〔待重算〕（舊 oracle pass/offered 76.3%〔作者報告值〕） | 准入 reject 84/rep〔作者報告值〕 | — | — | 0〔作者報告值；理想 rebase〕 | 不適用 | 不適用 | 不適用 |
| 〔M4 workloads〕 | per-file lock | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 |
| 〔M4 workloads〕 | CAS retry | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 |
| 〔M4 workloads〕 | Git three-way | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 |
| 〔M4 workloads〕 | bare composer | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 |
| 〔M4 workloads〕 | **完整 ATM** | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 |

（舊 R1 的 h1-a8 control「253（71.5%）」與 stale「172.7（64.9%）」保留原始計數與原始百分比；64.9%＝lost／commits（A4：ratio-of-sums 518/798），**不改**為以 354 為分母的 48.79%。committed 欄取自 `HOT_FILE_LATENCY.md` TL;DR；「correct」欄括號內為舊 marker oracle 的「有效成功率（oracle pass／intents）」，不等於 §5.4 的 correct completion。詳 `T6_R1_DENOMINATOR_AUDIT.md`。）

**表 R2　成本與進度（〔待 M2/M4〕）**

| 臂 | goodput（correct/s） | 端到端 p50/p95/p99/max | 分段：queue／window／validation／lock wait／write／retry | attempts／offered | fixed-workload makespan |
|---|---|---|---|---|---|
| sync（診斷） | 〔待重算〕 | 〔待重算〕（舊表 wall 2549 ms＝1.01× control、overhead mean/p95 4.21/6.75 ms〔作者報告值〕） | — | — | — |
| per-file lock | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 |
| CAS retry | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 |
| Git three-way | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 |
| bare composer | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 |
| **完整 ATM** | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 | 〔待 M2/M4〕 |

**表 R3　跨 process 與故障注入（〔待 M2/M4〕）**：2／4／8 processes 下的 lost among committed、receipt completeness、registry 殘留、`recovery-required` 次數；故障 cutpoint × 機制矩陣。

**預定圖表**：

- 圖 1　責任與狀態流程：平行 proposal、batch closure、同基底合成、驗證、受控 commit、reject 與 re-propose；標出可信元件邊界〔待繪〕。
- 圖 2　最小反例：上方插入＋下方修改（探針 #2/#3），加同 gap、context 假衝突與 stale base 四例〔待繪〕。
- 圖 3　correct goodput 對 p95 latency 的 tradeoff；各點附 coverage 與 CI〔待 M4〕。
- 圖 4　completion outcomes 堆疊與 delay decomposition，讓 reject-all 與重試成本無處隱藏〔待 M4〕。

**預期的誠實揭露**：修正 P0-2／P0-3 後，熱檔同區撞車將大量轉為 blocked，commit rate 可能下降。這是要揭露的結果：論文同時報正確性（lost、unsafe acceptance、收據）與進度成本（blocked、eligible missing、attempts、tail latency）。若結果顯示完整 ATM 與正確強基線同等安全但成本較高，論文仍可呈現治理收據與責任分離的價值，前提是該價值被定義並量測（RQ4）。

---

## 7. 限制與相關工作

### 7.1 限制

**主張強度**

- **可主張（作者報告值、帶 caveat）**：在故障注入負面對照中，省略合成與提交協定時遺失率約 55–65%，與無協調 control 同量級；舊版所有「0 lost」綁理想 sync writer。
- **可描述但非結果**：v0.1.17 歷史基準的四類缺口（探針，質性、可重跑；artifact 待附）。
- **不可主張（待 M1–M4）**：全域無遺失更新、100% fail-closed、零越權寫入、合成的延遲成本、相對強基線的優劣；排列穩定等同可序列化；抽樣排列構成證明；角色字串構成 OS 隔離；多檔 rollback 等同 crash atomicity。

**設計限制**

- **契約保守性**：保守 context 規則會誤拒部分語意可合併的相鄰編輯；精確規則需獨立 oracle。細化至 symbol／AST-anchored 合成並接 Derived Atoms（CID v2、occupy-both、stale→file-level；v0.1.17 測試通過但無性能數據，T11 🟡）列為 P2-2。措辭沿用 v1 §6.1：adapter-guided，而非 AST-first——**不是**「ATM 不用 AST」。
- **語意衝突不在範圍**：文字相容不代表語意獨立（v1 §3.7 亦自我限定）。v0.1.17 語意驗證收據自簽且 `ok:true` 寫死（`steward-transactional-apply.ts:233-244`），需接 `post-compose-semantic-validation-policy.ts`／proposal validators（P1-1）。
- **不可合成即拒絕**：不做 LLM／人工解衝突（P2-1）；steward-authored final patch 只定義 fail-closed 介面與審核收據需求。
- **同區路由語意未定**（P1-4）。
- **兩條 composer 路徑**（`PatchProposal` vs `MutationRequest`）尚未統一（P2-3）。
- **信任模型**：合作式程序、可信 steward 與檔案系統；不主張 sandbox 或 OS 隔離（§1.2、§3.5）。
- **耐久性**：未測 kill／斷電與 fsync；不主張 crash atomicity 或多檔原子性（§4.8）。

**外部效度**

- 舊數字中，除 mp 臂外，agents 為單 process 內 async worker，共用 event loop；hold 為 20–60 ms 模擬，非真 LLM 秒級思考。
- 單一 fixture（`atm-bench-fixture-v1-ts`）、單機；跨機 registry 未測（符合 v1 單域定位）。
- 舊數字多為同一 seed（42）的 ×3 重跑，屬 scheduler 變異而非獨立 workload；未報 CI。
- 舊數字跨 core@0.1.2（Oct 6）與 v0.1.17；與 main `3b0f7660`（含 FileHeat、native hot parking）的行為差異未量測。

### 7.2 相關工作

**ATM v1**：寫入前准入與角色分離（§2.1）。本文是其提交層的協定化與端到端驗證。

**Claim Plane**：Nikolaev 的 Claim Plane（arXiv:2607.21909v1，*Enforceable Change Intents and Dynamic Scope for Parallel Coding Agents*）與其 confirmatory follow-up（arXiv:2608.00947v1，*Reliability Gains and the Limits of Selective Concurrency for Parallel Coding Agents*）〔書目依審閱轉述，待作者核對原文〕。Claim Plane 以宣告的資源／區域權限為核心，佔位採 contingent → JIT promote；依審閱，其內容**亦含 immutable patch integration**，因此**不能**簡化為「只做准入」。舊稿「Claim Plane 處理誰何時取得寫入權限、與本文屬不同層次」的定位須改寫為：兩者在同基底 patch 整合上有交集，差異在於〔待核對原文後比較：保證範圍、失敗政策、評估方法〕。關於其樣本規模、效能報告與公開時序的說法〔待核對原文〕，正式稿前不以肯定句出現；本文不與 Claim Plane 同表硬比效能。

**三方合併**：`git merge-file` 對共同 base 的雙側三方合併、衝突標記與 exit status 是本文最直接的既有能力基線（§5.2）。差異在於本文的合成只在 broker 准入之後發生、輸入已經過 CID／region 過濾、失敗時**拒絕**並回收據而非輸出衝突標記；n-way 時 Git 需 fold，本文為同基底一次構造。

**樂觀並行控制**：Kung & Robinson（1981，ACM TODS 6(2)）的 OCC 是 CAS retry 基線的理論出處；本文的 base digest 重驗＋互斥替換即為單檔 OCC 的 validation／write 階段（§3.4）。

**OT／CRDT**：Ellis & Gibbs（1989，SIGMOD）的 operational transformation 與 Shapiro 等（2011，SSS）的 CRDT 處理的是不同的操作／複本模型（持續協同編輯、最終收斂）。本文的同基底合成與 OT 的位置轉換技術上相近，但保證與失敗政策不同（本文不可合成即拒絕、不追求自動收斂）；宜比較保證與失敗政策，不做跨模型效能排名。

**v1 所引相鄰工作**：沿用 v1 的「協調粒度 × 介入點」組織（v1 §1.1、§2）：字元級／版本控制基底（CodeCRDT、EvoGit、AgentGit）；檔案／工作流治理（CodeTeam、SEMAP、MPAC）與代理並行控制（CoAgent、S-Bus、ATCC）；交易式工具效果（Atomix、Cordon）；事後 merge 衝突壓力（AgenticFlict）。完整書目〔待補全文對照〕。

**方法學參考**：Kalibera & Jones（2013）分層變異與量測設計；NIST exact binomial bounds 與 percentiles 定義；SQLite atomic commit 的 crash 測試方法（僅方法參考，非 ATM 保證）。

### 7.3 未來工作（依影響排序）

1. 完成 M0–M1：選定契約、完成 §4.4 證明與 S1–S5 擴充測試；核定是否採 #198 契約。
2. M2–M4：真接線、強基線臂、配對 pilot 與最小主結果。
3. Batch closure 與重提協定的正式定義與成本量測（P1-2、P1-3），以及與 native hot parking（PR #199）的整合。
4. 語意驗證接線（P1-1）與 `BROKER_GUIDE.md`「Compose & steward apply」一節（P1-6）——v0.1.17 程式碼行為比文件描述弱（BROKER_GUIDE `:86`、`:123`）。
5. Steward-authored final patch（人或 LLM 解衝突）及其審核收據（P2-1）。
6. Symbol／AST-anchored 合成，接 Derived Atoms 的 atom 邊界（P2-2）。
7. 較強的權限治理：OS 帳號／容器權限、actor–process 綁定、canonical 路徑寫入限制與 symlink／hardlink／TOCTOU 測試。
8. 耐久性：kill／斷電、fsync、journal 恢復；多檔提交協定。
9. 耐久 serial ticket 端到端（`enqueueSerialIntent`＋eligible resume＋官方 position），使 #180 由 partial 推進到 full。
10. FileHeat（PR #197）的 hybrid／learned 模式評估——不得寫成完整 EMA 多訊號模型。
11. 規模：單 JSON registry 瓶頸、kill-9 stale-lock 回收、跨機（P2-4）；真 LLM／多 vendor 並行。

---

## 8. 結論

ATM v1 把寫入前准入立為一級治理問題，並把准入之後的同檔整合交給確定性 composer 與中立 steward。本文把這一半寫成一個受治理的合成提交協定（C1）與一份可檢驗的保留性契約（C2）：proposal 可平行準備，合成以批次對同一 immutable base 進行，canonical commit 經單一受控路徑完成，不可合成或過期的提案以描述真實終態的收據退回。

既有證據只足以支撐動機與歷史診斷：故障注入負面對照顯示，省略該層時遺失率與無協調同量級〔作者報告值〕；歷史基準 v0.1.17 的唯讀探針揭露循序套用造成的順序依賴、例外中斷與角色未比對。這些是對 v1 承諾的端到端驗證缺口，而不是新演算法。歷史基準有已知缺口，main 尚未含修正，候選契約待核定，主結果仍待測。

本文的實證貢獻（C3）——相對 lock、CAS retry 與 Git 三方合併，完整 ATM 能安全完成多少工作、付出多少延遲與重試成本——在本稿中仍是預先登記的設計〔待 M2/M4〕。若最終結果顯示同等安全但成本較高，論文仍可呈現治理收據與責任分離的價值；若相對強基線無實務差異，則應改為修正說明或經驗報告。

---

## 附錄 A：背景結果（冷熱准入、冷檔排隊、每筆成本、跨 process）

本附錄保留舊稿的支撐數字，**全部為作者報告值**，作為背景而非主結果；它們不直接回答 RQ1–RQ4，除非在 M4 以新定義重跑。所有「0 lost」均綁 **sync writer（理想 rebase）** 與舊 marker oracle。版本綁定：core@0.1.2（Oct 6）或 v0.1.17；**不代表** main `3b0f7660`（已含 FileHeat 與 native hot parking）。

### A.1 熱檔准入（T6 🟢，帶 caveat）

**表 A1　熱檔 h1-a8（trials 50、354 offered intents/rep、×3，同 seed）：Oct 6（core@0.1.2）vs v0.1.17〔作者報告值〕**

| 臂 | 指標 | Oct 6 | v0.1.17 |
|---|---|---|---|
| control | wall；lost 率 | 2522；71.5% | 2521；71.5% |
| native（sync） | wall（vs ctrl）；reject/rep；lost；成功率 | 2549（1.01×）；84（23.7%）；0；76.3% | 2557；86.7；0；75.5% |
| loop（harness overlay，sync） | wall；reject；lost；成功率 | 2908（1.15×）；0；0；100% | 3037；0；0；100% |
| nativestale | lost 率（分母＝committed） | 64.9% | 65.0% |
| loopstale | lost 率（分母＝committed） | 65.2% | 63.6% |

其他情境（Oct 6）：h1-a6 stale 55.5%／54.4%（native／loop）、h08-a8 64.6%／56.0%；control 63.9%、68.0%。h1-a8 native 決策分佈 composer_merge 210、hot_provisional 60、reject 84。

**Caveat**：loop 臂的 100% 成功歸功於 harness 的 hot-retry overlay；在 core@0.1.2／v0.1.17 上 core 無原生 park（原生 reject 17–24%）。此觀察**綁舊版本**；main 已合併 native hot parking（PR #199）〔審閱核對 2026-10-07〕，舊 overlay 數字不可回填為 native parking 的實測。

### A.2 冷檔 serial queue（T1–T3 🟢，#180 partial）

**表 A2　冷檔同檔（trials 60、`overlap=cold-same-file`、×3；matrix 2026-10-07 11:33:20–11:35:49 Asia/Taipei）〔作者報告值〕**

| 臂 | agents | wall（vs ctrl） | wait p50/p95/max (ms) | commits／pass／lost（每 rep） |
|---|---|---|---|---|
| control | 8 | 3024.78（1×） | — | 441／62／379 |
| nqwait | 8 | 6208.2（2.05×） | 62/259/350 | 441／441／0 |
| control | 16 | 3027.87（1×） | — | 879／64／815 |
| nqwait | 16 | 9416.48（3.11×） | 105/343/637 | 879／879／0 |
| nqwait 單檔（×1） | 16 | 40368.98（13.32×） | 679/759/794 | 879／879／0 |

control lost 率（推算）85.9%（a8）、92.7%（a16）。**Caveat**：#180 為 partial pass——harness 以輪詢 activeIntent file-blocker＋re-eval 實現等待，**未**呼叫 `enqueueSerialIntent`、未驗證耐久 FIFO ticket；`queue_position` 在 nqwait 臂為常數 1；0 lost 綁 sync writer。此 polling-wait 結果**不能**回填為 native ticket／resume 的實測。Oct 6 overlay 數字（2.03×／3.16×／13.2×，T4）僅為同量級對照（🟡）；V017 loop 臂數字不引用（🔴 T5）。

**與主軸的關係**：排隊以序列化換正確性，代價隨競爭從約 2× 升到最壞 13×〔作者報告值〕；這是 per-file lock 基線成本的粗略參考，但正式比較須以 §5.2 的 lock 臂在同一 frozen commit 重測。

### A.3 每筆准入成本與規模（T7、T9 🟢）

| 情境 | wall（vs ctrl） | overhead mean/p95 (ms) | lost |
|---|---|---|---|
| paced ×5（6 agents、168 intents/rep） | 1.03× | 5.21／7.14 | — |
| S3 1000 trials（7244 intents），sp | 1.001× | 4.77／6.45 | 0（ctrl 41.5%） |
| S3，8 procs | 1.001× | 9.35／20.9 | 0 |
| unpaced ×5（最壞上界，🟡） | 9.14× | 4.29／6.03 | — |

paced 拆解：latency_ms 2.92（p95 4.34）、apply_ms 2.2（p95 3.55）。**核對註記**：overhead mean 5.21 ms 與 2.92＋2.2＝5.12 ms 不完全相等，可能有未列 stage；且 overhead 含 apply_ms，故「約 5 ms／intent」不能稱為純准入成本〔待 M0 核對分段定義〕。unpaced 反映單 JSON registry＋fail-fast lock 的序列化瓶頸。以上為 core@0.1.2 數字。

### A.4 跨 process：CAS 與 apply 互斥（T8 🟢，負面對照）

| 情境／臂（core@0.1.2） | lost/rep | registry 殘留 | overhead mean/p95 |
|---|---|---|---|
| B control 8 procs | 201（71.3%） | — | 0.44／0.62 |
| B ATM 8 procs（CAS） | 0 | 0,0,0 | 8.69／21.63 |
| ⚠ B naive registry 8 procs | 0 | 37, 26, 32（殭屍 lease） | 14.6／36.3 |
| ⚠ B apply-lock off 8 procs | 2（1.0%） | 0,0,0 | 8.68／21.3 |

apply-lock off 的 1.0% lost 全部來自跨 process 的 composer_merge〔作者報告值〕：即使在 sync writer 下，合併路徑的寫入互斥一旦缺席就會丟更新。此為故障注入，與主比較隔離（§5.6）。

---

## 附錄 B：v1 承諾、歷史實現、候選版本與本文貢獻

| v1 承諾 | v1 位置 | 歷史基準 v0.1.17 `8dd6a1c6` | main `3b0f7660`〔審閱核對〕 | 候選 PR #198 `65e8aab3`（未合併） | 本文 |
|---|---|---|---|---|---|
| 同檔有界不相交 → composer＋中立 steward，不直接寫 | §3.4 Alg. 1 safety note；Table 4 | 路徑存在；compose 判定正確（探針 #1–#3 皆 `parallel-safe`） | 同 v0.1.17 | — | 保留；C1 協定化 |
| 套用時位移由 composer／steward／CAS 吸收 | §3.5 | **未吸收**：探針 #2 throw、#3 成功（順序依賴） | text steward 同 blob，未修 | immutable-base 合成；context 契約與本稿不同 | C2 命題＋契約選擇 |
| blocked 是 containment，保留意圖 | §3.4 | 重疊時檔案未變，但 throw、無收據（探針 #4） | 未修 | 新檢查〔細節待核對〕 | §3.6 收據終態 |
| 中立 steward 為唯一正式套用權威 | §3.2 | 提案者可自我 apply（探針 #5） | 未修 | 僅比對去空白標籤；空 ID 無錯；無 kind 參數 | 角色一致性檢查；RQ4 |
| CAS base-hash 重驗 | §3.5 第 6 層 | 寫入已檢查 base hash；rollback 良好 | 同 | — | §3.4 提交界線；S4／S5 回歸 |
| POS2 為同檔寫入鏈正向現場案例 | §3.5、§4.5 | 單例現場證據 | — | — | 系統性量測〔待 M2/M4〕 |
| SERIAL：queue or serialize | Table 4 | 冷檔原生 `queue`（#180 partial） | — | — | 背景（附錄 A.2） |
| Late-joiner park／re-arbitration | §3.5 | 舊 harness 路徑觀察不到 park | native hot parking 已由 PR #199 合併 | — | 與 batch closure 整合待 M2 |

v1 錨點：`v0.9.0-alpha.1` 的 tag object `0b31aa86`，peeled source commit `a897f144`；後來版本的缺陷不倒推至此版。

## 附錄 C：Artifact、重現與待補實驗封包

**已有（box 本機）**

- 歷史基準：tag v0.1.17，commit `8dd6a1c6`（`/workspace/atm-0.1.17/AI-Atomic-Framework-0.1.17`）；Oct 6 baseline HEAD `ed317820`。
- 探針：`runs/composer-probe/probe.mts`、`probe.out`（Node v24.21.0；唯讀 import，不改 ATM 樹）。
- 支撐 runs：`runs/hot-file/`、`runs/v017/`、`runs/v017-q180/`、`runs/compare/`、`runs/multiprocess/`、`runs/scale/`。
- Issue：#196（2026-10-07 開）。本稿撰寫時未修改 ATM monorepo、未開 PR、未 push／publish。

**待補的可核驗實驗封包（投稿前）**

| 資料 | 最低內容 |
|---|---|
| 版本 manifest | ATM 與 harness 完整 SHA、Git dirty 狀態、lockfile、Node／OS／硬體；每個 run ID 的設定 |
| 原始事件與終態 | 逐 proposal／attempt／batch／commit 事件；base 與 patch digest；最後檔案；失敗與 timeout 也保留 |
| 可執行入口 | `probe.mts`、產生器、獨立 oracle、彙整腳本與一鍵重建主表命令 |
| 舊表來源 | `PAPER_V2_KEY_TABLES`、`HOT_FILE_LATENCY`、composer probe 輸出，以及 T6／R1 每 run 的分子分母 |
| 重現清單 | workload／scheduler seed pairs、運行順序、warmup、timeout／retry、Git flags、expected fixtures 與 raw checksums |

## 附錄 D：本稿刻意降調處一覽

| 處 | 降調方式 |
|---|---|
| 題名 | 「真正平行合併」改為「確定性合成與受治理提交」；proposal 平行、commit 單一路徑 |
| 貢獻 | 收斂為 C1–C3；四項歷史缺口修復不列為新演算法 |
| 主結果 | 一律〔待 M2/M4〕；不寫已證明零 lost |
| stale／raw overwrite | 故障注入負面對照，非 ATM 能力界線；主比較改為強基線 |
| 既有「0 lost」 | 綁 sync writer 與舊 marker oracle；作者報告值 |
| 「同一組准入決策」 | 改為相同 seed 與設定；實際序列未必相同，需 trace replay |
| `permutationStable` | 寫死值，非證明；更名 composition determinism；排列測試≠可序列化 |
| `@@` old range | 依 GNU 更正為含 context＋刪除行；分 changed／context／gap |
| identity gate | 改稱角色一致性檢查；零直接寫入＝監測路徑觀測 |
| temp／rollback | 拆成例外補償／單檔替換／crash／多檔可見性；不稱 crash atomicity |
| 「全部尚未修好」 | 改為版本分層句（§2.2） |
| #184／park | 改為 PR #197／#199 已合併的分層敘述；舊 polling-wait 不回填 |
| R1 分母 | 保留 64.9%（分母 committed，A4 已核 ratio-of-sums）；不改 48.79% |
| seed 42 ×3 | 改稱 scheduler 變異；推論單位為獨立 workload |
| 約 5 ms／intent | 標註含 apply_ms 且分段不相加 |
| 156 pairs | 不等於 intents 或 blocked 數 |
| Claim Plane | 同引 2607.21909 與 2608.00947；不簡化為只做准入；〔待核對原文〕 |
| Derived Atoms | 僅 future work |

---

## 參考文獻

[1] Eagl Huang. *ATM: CID-Brokered Pre-Write Admission for Multi-Agent Code Co-Synthesis — A Specification-Grounded Governance Substrate for Software Agents*. arXiv:2607.00041v1 [cs.SE], 2026-06-29.（本稿引用：摘要、§1.1、§1.3、§1.4、§2、§3.2、§3.4 Algorithm 1 safety note、Table 4、§3.5、§3.7、§4.5、§6.1；全文 `refs/arxiv-2607.00041.txt`；逐頁頁碼〔待補全文對照〕）
[2] AI-Atomic-Framework v1 framework annotated tag `v0.9.0-alpha.1`：tag object `0b31aa8683b44b3a78206132a0bf90a0fde73d1c`；peeled commit `a897f144c84b66bb39f4f783c67e48ef75b7db78`〔審閱核對 2026-10-07〕。
[3] AI-Atomic-Framework 歷史基準 tag `v0.1.17`，commit `8dd6a1c6d169bf0421a55d3954a0a299b0bd582b`；issue #196。https://github.com/eaglhuang/AI-Atomic-Framework
[4] AI-Atomic-Framework main 快照 commit `3b0f7660b6673ba6c7570ee31fa776c0fac89bb5`（狀態截至 2026-10-07 11:49 UTC）〔審閱核對〕。
[5] AI-Atomic-Framework PR #198（未合併），head `65e8aab36f79c335d542151133e931f7dd71e7c0`：候選同基底 composer 與輸入檢查〔審閱核對〕。
[6] AI-Atomic-Framework PR #197：FileHeat（已合併；預設 static，hybrid／learned opt-in）〔審閱核對〕。
[7] AI-Atomic-Framework PR #199：native hot parking（已合併；ticket 與 resume 流程）〔審閱核對〕。
[8] Git 官方文件：`git merge-file`（共同 base 三方合併、衝突與 exit status）。
[9] H. T. Kung, J. T. Robinson. On Optimistic Methods for Concurrency Control. *ACM TODS* 6(2):213–226, 1981.
[10] NIST/SEMATECH. Exact binomial confidence bounds.（零事件上界方法）
[11] T. Kalibera, R. Jones. Rigorous Benchmarking in Reasonable Time. 2013.
[12] NIST/SEMATECH. Percentiles.（分位數定義）
[13] Maxim Nikolaev. Claim Plane: Enforceable Change Intents and Dynamic Scope for Parallel Coding Agents. arXiv:2607.21909v1, 2026.〔書目依審閱轉述，待核對原文〕
[14] Maxim Nikolaev. Reliability Gains and the Limits of Selective Concurrency for Parallel Coding Agents. arXiv:2608.00947v1, 2026（Claim Plane confirmatory follow-up）.〔書目依審閱轉述，待核對原文〕
[15] C. A. Ellis, S. J. Gibbs. Concurrency Control in Groupware Systems. *SIGMOD* 1989, 399–407.
[16] M. Shapiro, N. Preguiça, C. Baquero, M. Zawirski. Conflict-free Replicated Data Types. *SSS* 2011.
[17] GNU Diffutils manual: Unified Format（old hunk count 含 context 與刪除行）。
[18] SQLite: Atomic Commit in SQLite（方法參考，非 ATM 保證）。
[19] ATM v1 所引相鄰工作（CodeCRDT arXiv:2510.18893、EvoGit、AgentGit、CodeTeam、SEMAP、MPAC、CoAgent、S-Bus、ATCC、Atomix、Cordon、AgenticFlict 等）：完整書目沿用 v1 參考文獻表〔待補全文對照〕。
