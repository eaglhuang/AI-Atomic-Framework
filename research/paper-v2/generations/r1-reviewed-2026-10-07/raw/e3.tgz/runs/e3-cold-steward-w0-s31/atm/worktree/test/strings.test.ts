/** Tiny oracle-friendly test module (COLD). */
import { slugify, trim } from '../src/utils/strings.ts';

// <region:body>
export function runStringsSelfTest(): boolean {
  return trim('  x  ') === 'x' && slugify('Hello World') === 'hello-world';
}
// atm-edit s31-t000-i2 by codex:mock-s2
// atm-edit s31-t002-i0 by cursor:mock-s0
// atm-edit s31-t003-i1 by claude:mock-s1
// atm-edit s31-t003-i0 by cursor:mock-s0
// </region:body>
