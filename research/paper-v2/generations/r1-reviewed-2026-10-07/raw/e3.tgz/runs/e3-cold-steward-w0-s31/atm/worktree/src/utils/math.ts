/** Math helpers (COLD). */
// <region:body>
export function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}
export function sum(xs: readonly number[]): number {
  return xs.reduce((a, b) => a + b, 0);
}
// atm-edit s31-t001-i0 by cursor:mock-s0
// atm-edit s31-t002-i1 by claude:mock-s1
// atm-edit s31-t004-i1 by claude:mock-s1
// </region:body>
