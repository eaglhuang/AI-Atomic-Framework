/** Build stub (COLD) — lists entry modules. */
import { boot } from '../src/index.ts';

// <region:body>
export function buildSummary(): string {
  const b = boot();
  return `routes=${b.routes};db=${b.db}`;
}
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log(buildSummary());
}
// atm-edit s31-t000-i0 by cursor:mock-s0
// atm-edit s31-t001-i1 by claude:mock-s1
// atm-edit s31-t004-i0 by cursor:mock-s0
// </region:body>
