/** Billing service (COLD). */
export interface LineItem { sku: string; qty: number; unitCents: number }

// <region:body>
export function totalCents(items: readonly LineItem[]): number {
  return items.reduce((s, i) => s + i.qty * i.unitCents, 0);
}
export function formatMoney(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}
// atm-edit s23-t001-i1 by codex:mock-s2
// atm-edit s23-t004-i1 by claude:mock-s1
// atm-edit s23-t003-i1 by codex:mock-s2
// </region:body>
