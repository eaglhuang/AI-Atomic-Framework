/** Tiny oracle-friendly test module (COLD). */
import { slugify, trim } from '../src/utils/strings.ts';

// <region:body>
export function runStringsSelfTest(): boolean {
  return trim('  x  ') === 'x' && slugify('Hello World') === 'hello-world';
}
// atm-edit s23-t000-i0 by cursor:mock-s0
// atm-edit s23-t002-i2 by codex:mock-s2
// </region:body>
