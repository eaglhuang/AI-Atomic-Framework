/** Date helpers (COLD). */
// <region:body>
export function isoDay(d: Date = new Date()): string {
  return d.toISOString().slice(0, 10);
}
export function addDays(d: Date, n: number): Date {
  const x = new Date(d.getTime());
  x.setUTCDate(x.getUTCDate() + n);
  return x;
}
// atm-edit s11-t000-i2 by codex:mock-s2
// atm-edit s11-t001-i2 by codex:mock-s2
// atm-edit s11-t002-i1 by claude:mock-s1
// atm-edit s11-t003-i1 by claude:mock-s1
// atm-edit s11-t004-i1 by codex:mock-s2
// </region:body>
