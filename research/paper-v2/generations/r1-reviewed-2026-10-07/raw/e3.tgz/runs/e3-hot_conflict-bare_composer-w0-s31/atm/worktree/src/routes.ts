/** HTTP route table (HOT). */
export type Handler = (req: { path: string }) => { status: number; body: string };

// <region:users>
export const usersRoutes: Record<string, Handler> = {
  'GET /users': () => ({ status: 200, body: '[]' }),
  'POST /users': () => ({ status: 201, body: '{}' }),
};
// atm-edit s31-t000-i1 by claude:mock-s1
// atm-edit s31-t000-i0 by cursor:mock-s0
// atm-edit s31-t002-i1 by claude:mock-s1
// </region:users>

// <region:orders>
export const ordersRoutes: Record<string, Handler> = {
  'GET /orders': () => ({ status: 200, body: '[]' }),
};
// </region:orders>

// <region:admin>
export const adminRoutes: Record<string, Handler> = {
  'GET /admin/health': () => ({ status: 200, body: 'ok' }),
};
// atm-edit s31-t000-i2 by codex:mock-s2
// atm-edit s31-t003-i1 by claude:mock-s1
// </region:admin>

export function allRoutes(): Record<string, Handler> {
  return { ...usersRoutes, ...ordersRoutes, ...adminRoutes };
}
