/** String helpers (COLD). */
// <region:body>
export function trim(s: string): string {
  return s.trim();
}
export function slugify(s: string): string {
  return trim(s).toLowerCase().replace(/\s+/g, '-');
}
// atm-edit s17-t000-i1 by claude:mock-s1
// atm-edit s17-t002-i0 by claude:mock-s1
// </region:body>
