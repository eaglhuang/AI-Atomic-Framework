/** Math helpers (COLD). */
// <region:body>
export function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}
export function sum(xs: readonly number[]): number {
  return xs.reduce((a, b) => a + b, 0);
}
// atm-edit s29-t000-i0 by cursor:mock-s0
// atm-edit s29-t003-i1 by claude:mock-s1
// </region:body>
