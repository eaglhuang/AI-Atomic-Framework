/** String helpers (COLD). */
// <region:body>
export function trim(s: string): string {
  return s.trim();
}
export function slugify(s: string): string {
  return trim(s).toLowerCase().replace(/\s+/g, '-');
}
// atm-edit s29-t003-i0 by cursor:mock-s0
// atm-edit s29-t004-i1 by claude:mock-s1
// </region:body>
