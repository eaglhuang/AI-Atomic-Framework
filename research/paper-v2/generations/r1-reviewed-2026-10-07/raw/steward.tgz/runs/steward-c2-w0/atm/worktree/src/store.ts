/** In-memory store slices (HOT). */
export type State = { users: string[]; orders: number[]; meta: Record<string, string> };

// <region:reducers>
export function reduceUsers(state: State, user: string): State {
  return { ...state, users: [...state.users, user] };
}
// atm-edit s7-t001-i1 by claude:mock-s1
// atm-edit s7-t002-i0 by cursor:mock-s0
// atm-edit s7-t002-i1 by claude:mock-s1
// </region:reducers>

// <region:selectors>
export function selectUserCount(state: State): number {
  return state.users.length;
}
// atm-edit s7-t002-i2 by codex:mock-s2
// atm-edit s7-t003-i1 by claude:mock-s1
// </region:selectors>

// <region:actions>
export function createOrder(state: State, id: number): State {
  return { ...state, orders: [...state.orders, id] };
}
// atm-edit s7-t001-i0 by cursor:mock-s0
// atm-edit s7-t001-i2 by codex:mock-s2
// </region:actions>

export const initialState: State = { users: [], orders: [], meta: {} };
