/** Tiny oracle-friendly test module (COLD). */
import { slugify, trim } from '../src/utils/strings.ts';

// <region:body>
export function runStringsSelfTest(): boolean {
  return trim('  x  ') === 'x' && slugify('Hello World') === 'hello-world';
}
// atm-edit s3-t001-i0 by cursor:mock-s0
// atm-edit s3-t002-i1 by claude:mock-s1
// </region:body>
