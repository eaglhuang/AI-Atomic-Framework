# atm-bench export — e4-hot_conflict-steward-p2-s11

- run_id: `e4-hot_conflict-steward-p2-s11` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 155621 | — |
| duration_ms | 679.04 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 20 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 678.87 | — |
| throughput intents/s | 53.03 | — |
| goodput oracle-pass/s | 53.03 | — |
| latency_ms mean / p50 / p95 | 10.36 / 8.21 / 24.27 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 43.33 / 19.79 / 130.31 | — |
| total_ms mean / p50 / p95 | 108.14 / 78 / 210.7 | — |
| overhead_ms mean / p50 / p95 | 55.07 / 34.48 / 150.23 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=5, steward-final-patch-required: proposals 'prop-s11-t001-i3' and 'prop-s11-t001-i5' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t001-i3, prop-s11-t001-i5]=3, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:1c3b6fca120ae9839c70a3d5b6bf0502e003b98d2fe2c2a18b7944410ffc140b does not match proposal fileBeforeHash sha256:eb50a795fee6687ae46d55b75bf5496678b5ca34e7f0b37b8f83a849ba166431.=2, file-hash-drift: Target file hash sha256:0238ff70622a2d80660fe9d899ba345031ce018ea8a83ab74423f291fe92098c does not match proposal fileBeforeHash sha256:1c3b6fca120ae9839c70a3d5b6bf0502e003b98d2fe2c2a18b7944410ffc140b.=2, atm_compose=2, file-hash-drift: Target file hash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8 does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=2, file-hash-drift: Target file hash sha256:d99e5e85da084aeae432d3559da480044e5df796d88bcb0ab29b8a2541f40196 does not match proposal fileBeforeHash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171.=2, file-hash-drift: Target file hash sha256:e971c87c755d2253ed8b99b64ce16078da7dd6ad7a20bf4b467dcd2eea31dc51 does not match proposal fileBeforeHash sha256:ac417e9fb1ee8f6d68f20ff1226419e7c425ef92f53098280fee5f6eb522a99d.=1, file-hash-drift: Target file hash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=16, composer_merge=10, hot_provisional=2 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=155621, duration_ms=679.04
