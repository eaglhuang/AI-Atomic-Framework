# atm-bench export — e4-smoke-sync-p2-s11

- run_id: `e4-smoke-sync-p2-s11` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM (monorepo broker APIs) — multi-process shared registry
- params: `{"n_agents":4,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":2,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","arm":"ideal_sync"}`
- scenario reproducibility: **false** (`1cf1af2ce17b2524…`)
- alignment: 0 both / atm_only=8 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 2 | — |
| intents (decision events) | 8 | — |
| contended intents | 7 | — |
| events_total | 24 | — |
| event types | submit=8, decision=8, oracle=8 | — |
| bytes (JSONL) | 27302 | — |
| duration_ms | 268.65 | — |
| distinct agents / vendors | 4 / claude,codex,cursor | — |
| outcomes | commit=8 | — |
| committed | 8 | — |
| oracle pass (marker survives) | 8 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 2 | — |
| composer co-writes | 3 | — |
| CAS rebase on apply | 5 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 268.98 | — |
| throughput intents/s | 29.74 | — |
| goodput oracle-pass/s | 29.74 | — |
| latency_ms mean / p50 / p95 | 53.49 / 5.25 / 191.8 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 3.22 / 2.97 / 4.8 | — |
| total_ms mean / p50 / p95 | 76.51 / 31.56 / 215.8 | — |
| overhead_ms mean / p50 / p95 | 57.2 / 7.7 / 196.55 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 3 | 0 | 0 |
| hot_provisional | 3 | 0 | 0 |
| cold_queue | 2 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=2, atm_provisional_write_lease=2, atm_serial_queue=2, atm_compose=1, atm_provisional_write_lease+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | hot_provisional=2, cold_queue=2 |
| no_conflict | composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=24, bytes=27302, duration_ms=268.65
