# atm-bench export — e4-hot_conflict-fault_naive-p8-s17

- run_id: `e4-hot_conflict-fault_naive-p8-s17` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 147782 | — |
| duration_ms | 708.51 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=18, blocked=16 | — |
| committed | 18 | — |
| oracle pass (marker survives) | 33 | — |
| lost updates (oracle fail) | 1 | — |
| integration pass rate of committed | 183.3% | — |
| effective success rate of all intents | 97.1% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 5 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 707.49 | — |
| throughput intents/s | 48.06 | — |
| goodput oracle-pass/s | 46.64 | — |
| latency_ms mean / p50 / p95 | 17.3 / 14.83 / 38.44 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 90.52 / 111.68 / 205.24 | — |
| total_ms mean / p50 / p95 | 123.37 / 131.34 / 262.64 | — |
| overhead_ms mean / p50 / p95 | 108.34 / 119.56 / 247.62 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 15 | 0 | 0 |
| composer_merge | 11 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=4, atm_compose=3, file-hash-drift: Target file hash sha256:311ee81e4a3c756956d5baf28b00718fc6e459c0d31786ce82f2a2781668a71c does not match proposal fileBeforeHash sha256:077d918a726ba329a0786b51278219b35187d5f9bae46d174dbb4a28a0654a20.=2, canonical target base hash is stale: src/store.ts=2, file-hash-drift: Target file hash sha256:5475a3d8d72b96a63263ab572bca10cc9d7ccbd54082d4cb9747ce76290916fb does not match proposal fileBeforeHash sha256:7094f1c9f85bfcb2abc8b7ffa086805c58b664e8c56a01012e1a7b2f974c0c63.=1, file-hash-drift: Target file hash sha256:e0039134990c69d6534af97469287077ddea2016b056d08b333528ce7be221d5 does not match proposal fileBeforeHash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da.=1, file-hash-drift: Target file hash sha256:077d918a726ba329a0786b51278219b35187d5f9bae46d174dbb4a28a0654a20 does not match proposal fileBeforeHash sha256:0c053a565ebe7f3262e0c1db608a79073d25d1abdba73d71d74e61a1493210eb.=1, file-hash-drift: Target file hash sha256:8093cc60500b135af7549c34aa4a8612113e2a65a18b4168e382871ac5c4e734 does not match proposal fileBeforeHash sha256:7094f1c9f85bfcb2abc8b7ffa086805c58b664e8c56a01012e1a7b2f974c0c63.=1, file-hash-drift: Target file hash sha256:93d208270ccd8f51e5c59aacc332db7d94686bd765fa16488a0d1b4e4360aa7c does not match proposal fileBeforeHash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da.=1, file-hash-drift: Target file hash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:8093cc60500b135af7549c34aa4a8612113e2a65a18b4168e382871ac5c4e734 does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:5475a3d8d72b96a63263ab572bca10cc9d7ccbd54082d4cb9747ce76290916fb does not match proposal fileBeforeHash sha256:8093cc60500b135af7549c34aa4a8612113e2a65a18b4168e382871ac5c4e734.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=15, composer_merge=7, hot_provisional=4 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | hot_provisional=2, composer_merge=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=147782, duration_ms=708.51
