# atm-bench export — e4-hot_conflict-fault_nolock-p8-s23

- run_id: `e4-hot_conflict-fault_nolock-p8-s23` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 158728 | — |
| duration_ms | 733.98 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=18, commit=18 | — |
| committed | 18 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 200% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 8 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 730.5 | — |
| throughput intents/s | 49.28 | — |
| goodput oracle-pass/s | 49.28 | — |
| latency_ms mean / p50 / p95 | 25.44 / 17.66 / 60.91 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 98.59 / 112.05 / 264.85 | — |
| total_ms mean / p50 / p95 | 141.1 / 132.08 / 303.53 | — |
| overhead_ms mean / p50 / p95 | 124.51 / 117.83 / 291.23 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 14 | 0 | 0 |
| hot_provisional | 4 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=4, file-hash-drift: Target file hash sha256:c94c2133c5c676b66e5405b449eda686f555669243f9ead24e502b9b298b8a0a does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=4, file-hash-drift: Target file hash sha256:d662ca4ebc1c79b923975655b5f2528b59bc4afc426e3083e8f7f7042fbc87c0 does not match proposal fileBeforeHash sha256:25da2892dc2fc0035d3bfe73ae368a5f76820b4cddab5148c62208118a6afdbf.=2, file-hash-drift: Target file hash sha256:1dda42faea03349d2772f9b01ad6cf77701437009affd68b762259e115001cf6 does not match proposal fileBeforeHash sha256:1f042a51eadf9bd04c7d9d53931febbc1b53f2bb67c20902e26457d007500100.=2, file-hash-drift: Target file hash sha256:1dda42faea03349d2772f9b01ad6cf77701437009affd68b762259e115001cf6 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:9e0cb6a9fd2b17759cc925a278805a14265c73d87a1ff9b0e6f5d718bb322a04 does not match proposal fileBeforeHash sha256:bb4f7a30c6eff34677f7b8abcaa03e545ce0af341fb401f863442d0ce52d9aa9.=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:1dda42faea03349d2772f9b01ad6cf77701437009affd68b762259e115001cf6 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:8fa5fa22a66babef45629c6ec66388f3927ac42f3b83a1a998e34a2924eb11c8 does not match proposal fileBeforeHash sha256:1dda42faea03349d2772f9b01ad6cf77701437009affd68b762259e115001cf6.=1, file-hash-drift: Target file hash sha256:da4c20205df285259fc00b98604347c06d3af62a36a3ca6d86c3375ff8b68baf does not match proposal fileBeforeHash sha256:6ce1968f305980f13877edd0f1c81cead1e1543cb3ba857442a033caff005313.=1, file-hash-drift: Target file hash sha256:25da2892dc2fc0035d3bfe73ae368a5f76820b4cddab5148c62208118a6afdbf does not match proposal fileBeforeHash sha256:c94c2133c5c676b66e5405b449eda686f555669243f9ead24e502b9b298b8a0a.=1, file-hash-drift: Target file hash sha256:8fa5fa22a66babef45629c6ec66388f3927ac42f3b83a1a998e34a2924eb11c8 does not match proposal fileBeforeHash sha256:5ca4cb5f0e89250cbe8a527aee255f5e9b16e7a6ee30450902d0cc6e401a12ee.=1, file-hash-drift: Target file hash sha256:bb4f7a30c6eff34677f7b8abcaa03e545ce0af341fb401f863442d0ce52d9aa9 does not match proposal fileBeforeHash sha256:e47a6b11ed6bc63bc0ad4fe8a8bcca77e214f62b4f6cd758f2dcbcaad142b1a3.=1, file-hash-drift: Target file hash sha256:d662ca4ebc1c79b923975655b5f2528b59bc4afc426e3083e8f7f7042fbc87c0 does not match proposal fileBeforeHash sha256:c94c2133c5c676b66e5405b449eda686f555669243f9ead24e502b9b298b8a0a.=1, file-hash-drift: Target file hash sha256:6ce1968f305980f13877edd0f1c81cead1e1543cb3ba857442a033caff005313 does not match proposal fileBeforeHash sha256:bb4f7a30c6eff34677f7b8abcaa03e545ce0af341fb401f863442d0ce52d9aa9.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, cold_queue=1 |
| no_conflict | hot_provisional=3, cold_queue=3, composer_merge=1 |
| hot_provisional | cold_queue=14, composer_merge=10, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=158728, duration_ms=733.98
