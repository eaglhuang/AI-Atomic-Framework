# atm-bench export — e4-hot_conflict-steward-p8-s17

- run_id: `e4-hot_conflict-steward-p8-s17` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=8 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 146372 | — |
| duration_ms | 1003.03 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 5 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 1001.64 | — |
| throughput intents/s | 33.94 | — |
| goodput oracle-pass/s | 33.94 | — |
| latency_ms mean / p50 / p95 | 38.56 / 26.27 / 107.28 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 124.88 / 115.2 / 311.51 | — |
| total_ms mean / p50 / p95 | 179.18 / 156.48 / 424.88 | — |
| overhead_ms mean / p50 / p95 | 163.97 / 133.85 / 415.65 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 13 | 0 | 0 |
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=9, atm_serial_queue=7, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=4, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:ae7ead4d88727b7516e78b9b0d797e642e69cf6d01d7dcc72d84aab0a67d3fdd does not match proposal fileBeforeHash sha256:50a27a5b76abf71451d904e7627fa6df34487162d14632d436012298f5c9ad9f.=2, atm_compose=2, file-hash-drift: Target file hash sha256:50a27a5b76abf71451d904e7627fa6df34487162d14632d436012298f5c9ad9f does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:988eac119ef3d655b605621a356a29ad67274e7003fead65559743ff352ab356 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, canonical target base hash is stale: src/config.ts=1, file-hash-drift: Target file hash sha256:98d216d06f538a22eee31d04abca09296bf479af01f107007c4e10d34bcc3e28 does not match proposal fileBeforeHash sha256:36125700d2cb9d7050418ceb7a2625604454ae38b29681a9a0a788cb9cb79c44.=1, file-hash-drift: Target file hash sha256:f38d359285cd47a1159d83168ec02399081f677a906285c69775daab0057574d does not match proposal fileBeforeHash sha256:4b2f5fdd814c9310b5b3ba51e2e256066de63951e8cd9d8cd1cefa4e71215180.=1, file-hash-drift: Target file hash sha256:36125700d2cb9d7050418ceb7a2625604454ae38b29681a9a0a788cb9cb79c44 does not match proposal fileBeforeHash sha256:821c8d30afc00f27a29712c72c46fc0cba9f1754d0c7f782f2363d5347a9f82c.=1, file-hash-drift: Target file hash sha256:e11e77fa33178e531bfec2d1e7e19b6c1317ab864c65b947dbbbb56c81c07534 does not match proposal fileBeforeHash sha256:533a204e0ae4a8bc844276275a79e736dac493754dd142549b64a1e6f8374cd8.=1, file-hash-drift: Target file hash sha256:83d246f0d84d86e617ae5dd15517ad51b3cb4005da587bc9ecf3114a3e666a16 does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, hot_provisional=7, composer_merge=6 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | composer_merge=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=146372, duration_ms=1003.03
