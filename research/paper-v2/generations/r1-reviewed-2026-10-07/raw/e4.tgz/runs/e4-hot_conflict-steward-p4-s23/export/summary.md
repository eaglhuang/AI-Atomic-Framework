# atm-bench export — e4-hot_conflict-steward-p4-s23

- run_id: `e4-hot_conflict-steward-p4-s23` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156662 | — |
| duration_ms | 791.41 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 15 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 788.73 | — |
| throughput intents/s | 45.64 | — |
| goodput oracle-pass/s | 45.64 | — |
| latency_ms mean / p50 / p95 | 16.91 / 10 / 60.97 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 72.16 / 42.43 / 158.84 | — |
| total_ms mean / p50 / p95 | 126.71 / 134.82 / 238.81 | — |
| overhead_ms mean / p50 / p95 | 89.92 / 79.07 / 198.74 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 15 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:1f042a51eadf9bd04c7d9d53931febbc1b53f2bb67c20902e26457d007500100 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=2, atm_compose=2, file-hash-drift: Target file hash sha256:3de535448ab73af889cbe5e0f467713e2772f1f3267c132ada2a93205e412440 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=2, steward-final-patch-required: proposals 'prop-s23-t003-i0' and 'prop-s23-t003-i4' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t003-i0, prop-s23-t003-i4]=2, file-hash-drift: Target file hash sha256:d1e64eb096de6f54164c1aa356b68b1883733a6e6c7243a886d5685dbc912b18 does not match proposal fileBeforeHash sha256:1e43ae2642cb631ecb14603b7a4ef8eb83768bf44b99b7066579b2bb7703fa9b.=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:8f42f9cadc09f0b7790cd5150d1bcb07c82919a3984ae949e9677694d54fdf99 does not match proposal fileBeforeHash sha256:5f7f5009a23f76e02add018e52d7f68f12c8c399f742d051f2b317e32b4ed6d1.=1, file-hash-drift: Target file hash sha256:f7447f6e1e0b2d8ab56eed35f160198954e6ca504ea1b932a874d0458702eb0e does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:d1e64eb096de6f54164c1aa356b68b1883733a6e6c7243a886d5685dbc912b18 does not match proposal fileBeforeHash sha256:8a373102cb3c4a93defc4ac9770e9b14799ac219d06e4e50f028d1e81ea01bb7.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:f148ef854ac0d202e36f3a8d3cb7c9cd352fc4f39ae3225d568de65bf9a62822 does not match proposal fileBeforeHash sha256:fc2d1c2f888e55f823ebdb22281bb7205e6a876344b175564df1f79b44bb3afa.=1, file-hash-drift: Target file hash sha256:f7447f6e1e0b2d8ab56eed35f160198954e6ca504ea1b932a874d0458702eb0e does not match proposal fileBeforeHash sha256:1d5a7fe2af4234741a601bd571757746c33031e26f4bb6d8632dd93d8fba2c5c.=1, file-hash-drift: Target file hash sha256:1e43ae2642cb631ecb14603b7a4ef8eb83768bf44b99b7066579b2bb7703fa9b does not match proposal fileBeforeHash sha256:f7447f6e1e0b2d8ab56eed35f160198954e6ca504ea1b932a874d0458702eb0e.=1, file-hash-drift: Target file hash sha256:fc2d1c2f888e55f823ebdb22281bb7205e6a876344b175564df1f79b44bb3afa does not match proposal fileBeforeHash sha256:5f7f5009a23f76e02add018e52d7f68f12c8c399f742d051f2b317e32b4ed6d1.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=4, cold_queue=2, composer_merge=1 |
| hot_provisional | cold_queue=12, composer_merge=10, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156662, duration_ms=791.41
