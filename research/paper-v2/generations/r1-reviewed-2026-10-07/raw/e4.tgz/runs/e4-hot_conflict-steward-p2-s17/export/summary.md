# atm-bench export — e4-hot_conflict-steward-p2-s17

- run_id: `e4-hot_conflict-steward-p2-s17` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 147845 | — |
| duration_ms | 621.11 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 33 | — |
| lost updates (oracle fail) | 1 | — |
| integration pass rate of committed | 157.1% | — |
| effective success rate of all intents | 97.1% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 15 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 619.53 | — |
| throughput intents/s | 54.88 | — |
| goodput oracle-pass/s | 53.27 | — |
| latency_ms mean / p50 / p95 | 9.73 / 8.46 / 19.41 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 38.84 / 20.06 / 134.71 | — |
| total_ms mean / p50 / p95 | 97.58 / 61.04 / 197.55 | — |
| overhead_ms mean / p50 / p95 | 50.01 / 29.22 / 152.18 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 10 | 0 | 0 |
| composer_merge | 10 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=9, file-hash-drift: Target file hash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e does not match proposal fileBeforeHash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd.=3, file-hash-drift: Target file hash sha256:2238d54f0a62ccd7bec141b94c91ea719ad349153bb3b90dcbeb5c7a04614854 does not match proposal fileBeforeHash sha256:99bf4fdabbc79cff29d3c6e9ebdc4ad7e4aa5aeced581fe0bd40ac61bba04609.=3, file-hash-drift: Target file hash sha256:9009fd973069a2bf0dd907e9891fd276008d1c3e8a3da8849e0f3caa79de8707 does not match proposal fileBeforeHash sha256:2339436f0233f6c968fa9c13e7218cc7f39ecbc77bfb0617fe39b70c36f75001.=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, canonical target base hash is stale: src/routes.ts=1, atm_compose=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da does not match proposal fileBeforeHash sha256:97c243dc7053b942f2e727f1f649f633a26692e99d6d2c7847a2f71a2ad4b2ff.=1, file-hash-drift: Target file hash sha256:878dddbac6ea26e92f20d293cf08b288d1939d4be7702d7f8b26cb3f87e0d07c does not match proposal fileBeforeHash sha256:de80537036f76fb2d60c54e1e1c48e58257b90885c82f9a2ae88a6cdb31d8e5f.=1, atm_provisional_write_lease+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, hot_provisional=8, composer_merge=5 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=147845, duration_ms=621.11
