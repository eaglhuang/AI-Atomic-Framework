# atm-bench export — e4-hot_conflict-steward-p8-s23

- run_id: `e4-hot_conflict-steward-p8-s23` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=8 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157001 | — |
| duration_ms | 788.24 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=18, commit=18 | — |
| committed | 18 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 200% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 3 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 785.31 | — |
| throughput intents/s | 45.84 | — |
| goodput oracle-pass/s | 45.84 | — |
| latency_ms mean / p50 / p95 | 35.48 / 24.8 / 95.02 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 101.34 / 51.12 / 316.53 | — |
| total_ms mean / p50 / p95 | 154.05 / 142.48 / 366.17 | — |
| overhead_ms mean / p50 / p95 | 137.32 / 121.62 / 343.63 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=4, file-hash-drift: Target file hash sha256:20e3fdebd44b6def5b856350710a1979757debee1ef5680229dfde8a655cfc8f does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:8b0e0269a8359763bef57d2c6043e655cece550624e179fd1bea3cfaf4e29afc does not match proposal fileBeforeHash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9.=1, file-hash-drift: Target file hash sha256:60dfc047ea02696d76077c9e29b14f1d140f8f7859c6f8db37b6852c61cb34b4 does not match proposal fileBeforeHash sha256:beeb79bc0ade66bd774510489eb6af6237d49513186eafb13aaffee834d89326.=1, file-hash-drift: Target file hash sha256:f334c15f75257840e51b3d1320327cb220d47159e4ab06e260e075cea63757ff does not match proposal fileBeforeHash sha256:a67d81b7ae41111ff8b057ee3a1ddab7d5ea04aa15e49f18746f433a12df16e3.=1, file-hash-drift: Target file hash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9 does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=1, file-hash-drift: Target file hash sha256:d386625c875cb493a8c1a14a223886bba72ebc1602faf45fb82131a9e89404e9 does not match proposal fileBeforeHash sha256:92b4fad0ef504cbfa1b3778565d6aa4c943f68b1a08499e07db5fa753cf64d32.=1, file-hash-drift: Target file hash sha256:f334c15f75257840e51b3d1320327cb220d47159e4ab06e260e075cea63757ff does not match proposal fileBeforeHash sha256:20e3fdebd44b6def5b856350710a1979757debee1ef5680229dfde8a655cfc8f.=1, canonical target base hash is stale: src/config.ts=1, file-hash-drift: Target file hash sha256:20e3fdebd44b6def5b856350710a1979757debee1ef5680229dfde8a655cfc8f does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:d386625c875cb493a8c1a14a223886bba72ebc1602faf45fb82131a9e89404e9 does not match proposal fileBeforeHash sha256:ae9b1e55339b28f26d6b88ae0d9b34a73d516a02eb0e44b3692c37cd728e33a6.=1, file-hash-drift: Target file hash sha256:60dfc047ea02696d76077c9e29b14f1d140f8f7859c6f8db37b6852c61cb34b4 does not match proposal fileBeforeHash sha256:b13ae9b448bd02edf954cb66f90d33aa5a08cf86283b0963bab42fef4cc12a33.=1, file-hash-drift: Target file hash sha256:1448c9437f99a1836d2be63924b07468bffc4d67d6d1cb4760e6e60dd7ce5b64 does not match proposal fileBeforeHash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9.=1, file-hash-drift: Target file hash sha256:b13ae9b448bd02edf954cb66f90d33aa5a08cf86283b0963bab42fef4cc12a33 does not match proposal fileBeforeHash sha256:beeb79bc0ade66bd774510489eb6af6237d49513186eafb13aaffee834d89326.=1, file-hash-drift: Target file hash sha256:7df146317de46963076bc5fd717bb75d69eb1749689394ad48cbc7dbcc9bcfdc does not match proposal fileBeforeHash sha256:beeb79bc0ade66bd774510489eb6af6237d49513186eafb13aaffee834d89326.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, cold_queue=1 |
| no_conflict | hot_provisional=3, cold_queue=2, composer_merge=2 |
| hot_provisional | cold_queue=14, composer_merge=7, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157001, duration_ms=788.24
