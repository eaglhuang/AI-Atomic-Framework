# atm-bench export — e4-hot_conflict-steward-p4-s11

- run_id: `e4-hot_conflict-steward-p4-s11` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 155030 | — |
| duration_ms | 667.67 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 171.4% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 668.16 | — |
| throughput intents/s | 53.88 | — |
| goodput oracle-pass/s | 53.88 | — |
| latency_ms mean / p50 / p95 | 15.72 / 9.48 / 50.68 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 61.55 / 22.78 / 216.77 | — |
| total_ms mean / p50 / p95 | 113.13 / 71.64 / 258.89 | — |
| overhead_ms mean / p50 / p95 | 78.05 / 44.97 / 227.13 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:0dd5bc0e36620a31b750c5de219996c46ae616aa914b2596bd9787ae23ffa92a does not match proposal fileBeforeHash sha256:60707e664b8297ca7137c78093822603fb0cafec4564c6be6c1f72f83e10a87a.=3, file-hash-drift: Target file hash sha256:959310b6a7d7078fb0cd73778d6a4c2213c9d09e62220d2117afef9e95572db3 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:8ca299b54ebd6523536ff83a7a4c94548c4f8fb0bb12d62e120e15abf332a0a4 does not match proposal fileBeforeHash sha256:31dab18eccb482bb01b9a39aae4fae700e31106d578b39a57730bb2ed466023b.=2, file-hash-drift: Target file hash sha256:31dab18eccb482bb01b9a39aae4fae700e31106d578b39a57730bb2ed466023b does not match proposal fileBeforeHash sha256:6fdea5bbbf472d6f73a8a1e7f8ba364418161a5a1efec67a7deb4cea71b1c3e7.=2, file-hash-drift: Target file hash sha256:99649ec825b559572f30bb192f55cd1d955e31e417865548d0ce5a3665a62bd4 does not match proposal fileBeforeHash sha256:959310b6a7d7078fb0cd73778d6a4c2213c9d09e62220d2117afef9e95572db3.=1, file-hash-drift: Target file hash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, canonical target base hash is stale: src/routes.ts=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:577f7bcf7bfe5817fa14fe7f23dec2922e85929a269b5cc1653b0bdfa9b4c870 does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=1, file-hash-drift: Target file hash sha256:6fdea5bbbf472d6f73a8a1e7f8ba364418161a5a1efec67a7deb4cea71b1c3e7 does not match proposal fileBeforeHash sha256:6c0b0e3ebbb5ce2a4a1a68b94eaba02ab0039643fb44d6641103335000c50851.=1, canonical target base hash is stale: src/store.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=16, composer_merge=7, hot_provisional=5 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=155030, duration_ms=667.67
