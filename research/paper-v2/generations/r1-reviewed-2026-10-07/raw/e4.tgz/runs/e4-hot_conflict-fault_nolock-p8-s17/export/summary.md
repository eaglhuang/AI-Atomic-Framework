# atm-bench export — e4-hot_conflict-fault_nolock-p8-s17

- run_id: `e4-hot_conflict-fault_nolock-p8-s17` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 146319 | — |
| duration_ms | 719.24 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 33 | — |
| lost updates (oracle fail) | 1 | — |
| integration pass rate of committed | 157.1% | — |
| effective success rate of all intents | 97.1% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 9 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 717.82 | — |
| throughput intents/s | 47.37 | — |
| goodput oracle-pass/s | 45.97 | — |
| latency_ms mean / p50 / p95 | 23.93 / 15.13 / 72.88 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 91.22 / 32.5 / 290.25 | — |
| total_ms mean / p50 / p95 | 130.52 / 76.57 / 331.38 | — |
| overhead_ms mean / p50 / p95 | 115.63 / 63.21 / 315.48 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 15 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| composer_merge | 10 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=4, file-hash-drift: Target file hash sha256:2eb8ec37bb9978abab5806b9921c4b1835ac02ca4ecdd952dfea8bb43fb69f0d does not match proposal fileBeforeHash sha256:6a89a42783c3c01b792cb57f76f43b0298df40b85241ac563c4046083b77a2f9.=2, compose-context-mismatch: proposal 'prop-s17-t001-i3' context mismatch at base line 26: expected "// </region:flags>", found "// atm-edit s17-t001-i1 by claude:mock-s1" [proposals: prop-s17-t001-i3]=1, atm_compose=1, file-hash-drift: Target file hash sha256:2a5940c3ad83358a80091dc7e0de54168bdda3cf15b70cba33918abb52060104 does not match proposal fileBeforeHash sha256:9fad848cb2feda55a05c2bb70e2192b09f5252b495e27d997f65e01320cffaed.=1, file-hash-drift: Target file hash sha256:9fad848cb2feda55a05c2bb70e2192b09f5252b495e27d997f65e01320cffaed does not match proposal fileBeforeHash sha256:3fff25580e23004e2119348fc0b52f46c243b55f201729c097e471a90f955a4f.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:2a5940c3ad83358a80091dc7e0de54168bdda3cf15b70cba33918abb52060104 does not match proposal fileBeforeHash sha256:76a83a53996022003ccea3271efb6ee83c85992302712f2d33f5d6c4a95dc9f2.=1, file-hash-drift: Target file hash sha256:7b733abb0184c3551402f9116940ea685cbf791da8c6a9d41180c2946536d4a2 does not match proposal fileBeforeHash sha256:6c6ace3fe529a2b037d6bec283134ca0e67499d4091adf72914ab4cb28eb889f.=1, file-hash-drift: Target file hash sha256:bb766f92b8fd85a637878445ed49836fc46dbb4df7a3e1793f2f4f715be4d1a8 does not match proposal fileBeforeHash sha256:116af106c0d4d932a1e83f314e39e8d8ffb8eef9900392e89a321e57b6e52ec5.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=14, hot_provisional=7, composer_merge=5 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=146319, duration_ms=719.24
