# atm-bench export — e4-hot_conflict-steward-p8-s11

- run_id: `e4-hot_conflict-steward-p8-s11` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=8 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156625 | — |
| duration_ms | 1054.87 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=18, commit=18 | — |
| committed | 18 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 200% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 20 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 1053.99 | — |
| throughput intents/s | 34.16 | — |
| goodput oracle-pass/s | 34.16 | — |
| latency_ms mean / p50 / p95 | 34.24 / 21.11 / 118.95 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 141.82 / 73.63 / 544.85 | — |
| total_ms mean / p50 / p95 | 195.25 / 151.73 / 611.49 | — |
| overhead_ms mean / p50 / p95 | 176.64 / 128.42 / 593.72 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 20 | 0 | 0 |
| hot_provisional | 4 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, file-hash-drift: Target file hash sha256:e7a2cc6187addb7f57927001e0e3674d9320a8bb9adbd0fe25350b3218f98a1e does not match proposal fileBeforeHash sha256:e21cbc3d78b0f77d938be9965bbd13dda1d82818fc656b0abaf35ad4e8f7ba71.=3, atm_provisional_write_lease=3, file-hash-drift: Target file hash sha256:076dd9216ca14df6a11c6304e63b9fd3bc535e10592aa5abe98ba3d470bd25b0 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:1da0cef03cb8d50a5bf9fc217d0deb7de2f083b919baf903ba0fa333498fe683 does not match proposal fileBeforeHash sha256:36d67d1a2ac05f39a747a949825d524d19d66bbab002de2d09e1b9ee6e588346.=2, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, atm_compose=2, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:21793508a73f0b68cfc67780ec7ca23385fc0a63888fac036f9cbecb4467cced does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:dfc799673b7ca9156cc812627303e6a786fd3ab9c9f632feac1250d3658fc295 does not match proposal fileBeforeHash sha256:5170c1b840729b9ebc5215ad87689f006e18b15eb57255b232fbe4e263aba9c1.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:d5f5b82a49a26f8dd61cbd6a62c2898b5b6b9ccef386713547260b2718d906f8 does not match proposal fileBeforeHash sha256:36d67d1a2ac05f39a747a949825d524d19d66bbab002de2d09e1b9ee6e588346.=1, file-hash-drift: Target file hash sha256:dfc799673b7ca9156cc812627303e6a786fd3ab9c9f632feac1250d3658fc295 does not match proposal fileBeforeHash sha256:442d39ae3454993ee67fb7d65407f9bde133504fbf8451e988523d6b4f30cd42.=1, file-hash-drift: Target file hash sha256:0f21a67d3af16a650b6a5a4ffbd753e6283a112474e25447c2fb7a5b9ca45613 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:5170c1b840729b9ebc5215ad87689f006e18b15eb57255b232fbe4e263aba9c1 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:442d39ae3454993ee67fb7d65407f9bde133504fbf8451e988523d6b4f30cd42 does not match proposal fileBeforeHash sha256:5170c1b840729b9ebc5215ad87689f006e18b15eb57255b232fbe4e263aba9c1.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, cold_queue=1 |
| hot_provisional | cold_queue=17, composer_merge=8, hot_provisional=3 |
| no_conflict | composer_merge=2, cold_queue=2, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156625, duration_ms=1054.87
