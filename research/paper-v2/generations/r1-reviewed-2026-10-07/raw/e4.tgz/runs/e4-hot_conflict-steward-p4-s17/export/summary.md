# atm-bench export — e4-hot_conflict-steward-p4-s17

- run_id: `e4-hot_conflict-steward-p4-s17` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 147235 | — |
| duration_ms | 722.3 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=15 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 178.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 9 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 720.77 | — |
| throughput intents/s | 47.17 | — |
| goodput oracle-pass/s | 47.17 | — |
| latency_ms mean / p50 / p95 | 17.24 / 15.28 / 39.79 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 64.67 / 31.6 / 154.22 | — |
| total_ms mean / p50 / p95 | 115.37 / 62.33 / 230.56 | — |
| overhead_ms mean / p50 / p95 | 83.75 / 48.54 / 181.32 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 14 | 0 | 0 |
| composer_merge | 11 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:6e4b0637637389639a0f458ac36a2f701e04e95712aba45c6a6a6ddcb8ea017b does not match proposal fileBeforeHash sha256:1de58ac7eabcf0ed337cddec96961bdfdc0ea641dcc6f6d4652934f3bab37cd9.=2, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 22 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=2, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, canonical target base hash is stale: src/store.ts=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:4a26e388fcbcaba80444a9a365d16b5c3d956fa61dd6b03ba36bf8e776bd0927 does not match proposal fileBeforeHash sha256:a482e4b4bd932652d53d7e1ef2f17a4aa48fc3b0bba6a73da15c00b21a26fbbf.=2, file-hash-drift: Target file hash sha256:f1b1539c7d070129de4bf318c3414a6836c9058fa2ec0dd9e78d16c7569eee29 does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=1, atm_compose=1, file-hash-drift: Target file hash sha256:dcd67fad4f6553bc68cc12a73f92d884fa1d2c036aaff8619f79b6256c1d39e6 does not match proposal fileBeforeHash sha256:553aecebed3b00dd2d067f3571e129681ac23113c9cda78eb786bc1b94b54609.=1, file-hash-drift: Target file hash sha256:a482e4b4bd932652d53d7e1ef2f17a4aa48fc3b0bba6a73da15c00b21a26fbbf does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=1, file-hash-drift: Target file hash sha256:6555ddd62d08247ed9eaa65f4bf124d56055cbb1129f21e47025d6206f1df69f does not match proposal fileBeforeHash sha256:553aecebed3b00dd2d067f3571e129681ac23113c9cda78eb786bc1b94b54609.=1, file-hash-drift: Target file hash sha256:1de58ac7eabcf0ed337cddec96961bdfdc0ea641dcc6f6d4652934f3bab37cd9 does not match proposal fileBeforeHash sha256:94cdad271f84d86408059bc10d9b947bae922e7ce822e40fd31b2ccebf03f546.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, composer_merge=8, hot_provisional=5 |
| no_conflict | hot_provisional=2, composer_merge=1, cold_queue=1 |
| composer_cowrite | hot_provisional=2, composer_merge=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=147235, duration_ms=722.3
