# atm-bench export — e4-hot_conflict-fault_nolock-p8-s11

- run_id: `e4-hot_conflict-fault_nolock-p8-s11` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 158840 | — |
| duration_ms | 849.2 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=18, commit=18 | — |
| committed | 18 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 200% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 16 | — |
| CAS rebase on apply | 2 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 848.66 | — |
| throughput intents/s | 42.42 | — |
| goodput oracle-pass/s | 42.42 | — |
| latency_ms mean / p50 / p95 | 20.17 / 14.1 / 57.75 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 103.52 / 113.18 / 301.82 | — |
| total_ms mean / p50 / p95 | 142.53 / 138.13 / 348.8 | — |
| overhead_ms mean / p50 / p95 | 124.18 / 121.23 / 325.79 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 16 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 13 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=8, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=4, atm_compose=3, file-hash-drift: Target file hash sha256:8a1cef037a37e6457ca70e40ab1cdec19d8d10e3adc090b6c5acf507c41e0bea does not match proposal fileBeforeHash sha256:022c13f71698b012dd8d8d03acd37af834e0d061329fb0afad2cd2a51b74fc4e.=3, file-hash-drift: Target file hash sha256:e691b8cd85d8bf178c0fc74f79b3d178ab248ceba1aa73159c8c80c66a19c638 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:89d9349c58dc4a8f96b4930a2e1ceeb7c9371cf9373c1cf4afc46772fe1f5e02 does not match proposal fileBeforeHash sha256:8a1cef037a37e6457ca70e40ab1cdec19d8d10e3adc090b6c5acf507c41e0bea.=2, file-hash-drift: Target file hash sha256:5824cab554b226261236b369282e518adb4024b82741c43ad3efa60eb9c8d70e does not match proposal fileBeforeHash sha256:32391ae01d5f9fc54b14c6333aeb852a49b7503f728aebf063757d1b2b8cfce8.=2, file-hash-drift: Target file hash sha256:32391ae01d5f9fc54b14c6333aeb852a49b7503f728aebf063757d1b2b8cfce8 does not match proposal fileBeforeHash sha256:37d70a1bb46980284777813af98936ae8c496768102f6a1364e4445d8403c524.=1, file-hash-drift: Target file hash sha256:ff676eb00fd55db03dc591ae367167be2eaeabb09e44a6def287424ccec3e129 does not match proposal fileBeforeHash sha256:e820b9fb40fa58121ef1a8c692846240c3e1a10c77a7f6c72332aa57300447de.=1, file-hash-drift: Target file hash sha256:ef9bb993992a0179ea1afd89b3e6e27cd94e8bb40b30f89d1c39a75648f6d750 does not match proposal fileBeforeHash sha256:197551467c44c040d4b2d3fab3ec039900c79f6ca742dd667c8f8973a1bf3e06.=1, file-hash-drift: Target file hash sha256:197551467c44c040d4b2d3fab3ec039900c79f6ca742dd667c8f8973a1bf3e06 does not match proposal fileBeforeHash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79.=1, compose-context-mismatch: proposal 'prop-s11-t003-i5' context mismatch at base line 16: expected "// </region:selectors>", found "// atm-edit s11-t002-i4 by claude:mock-s4" [proposals: prop-s11-t003-i5]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | composer_merge=13, cold_queue=11, hot_provisional=4 |
| no_conflict | hot_provisional=2, cold_queue=2, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=158840, duration_ms=849.2
