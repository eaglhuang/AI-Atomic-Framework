# atm-bench export — e4-hot_conflict-fault_naive-p8-s11

- run_id: `e4-hot_conflict-fault_naive-p8-s11` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 155220 | — |
| duration_ms | 631.5 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 35 | — |
| lost updates (oracle fail) | 1 | — |
| integration pass rate of committed | 175% | — |
| effective success rate of all intents | 97.2% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 21 | — |
| composer co-writes | 8 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 631.75 | — |
| throughput intents/s | 56.98 | — |
| goodput oracle-pass/s | 55.4 | — |
| latency_ms mean / p50 / p95 | 15.41 / 13.88 / 31.24 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 80.26 / 24.23 / 270.7 | — |
| total_ms mean / p50 / p95 | 114.74 / 61.51 / 330.23 | — |
| overhead_ms mean / p50 / p95 | 96.17 / 47.12 / 303.34 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 8 | 0 | 0 |
| cold_queue | 21 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=15, atm_provisional_write_lease=5, file-hash-drift: Target file hash sha256:384fbfffc5e2646c66c5666eec260adf7a52805dce49844cc9d3c70e754fbee1 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=3, file-hash-drift: Target file hash sha256:3f0d71981950d5e6963fe3a82f4a1f56e0756c2e658bfb1a10dfc2023fcf35f5 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:14a363bc5baf4076e4d123be53351f74c57e17007212e8711e139afd223f37ae does not match proposal fileBeforeHash sha256:498062049b3744cd25204ba97be1238bf6aae79a57a3e54a551bfbb199aa5ed0.=2, canonical target base hash is stale: src/store.ts=2, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:ff676eb00fd55db03dc591ae367167be2eaeabb09e44a6def287424ccec3e129 does not match proposal fileBeforeHash sha256:e820b9fb40fa58121ef1a8c692846240c3e1a10c77a7f6c72332aa57300447de.=1, file-hash-drift: Target file hash sha256:9db85540540f4fb74468c4c8136f494bb1f37e1ca914bbea8e799c52ea005fc9 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:01094c98b6e972b8d14ad98e604ef1c20a611cf0575112a1ef5fa70a566ac6e4 does not match proposal fileBeforeHash sha256:37d70a1bb46980284777813af98936ae8c496768102f6a1364e4445d8403c524.=1, file-hash-drift: Target file hash sha256:93e61889d5910a466bc34bf162aaba705486854295c588881f002e446dd86b43 does not match proposal fileBeforeHash sha256:498062049b3744cd25204ba97be1238bf6aae79a57a3e54a551bfbb199aa5ed0.=1, file-hash-drift: Target file hash sha256:6c137db7041500eac800af95805956c770f7f4468d78f0aef175cd58dea4fb28 does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=1, file-hash-drift: Target file hash sha256:01094c98b6e972b8d14ad98e604ef1c20a611cf0575112a1ef5fa70a566ac6e4 does not match proposal fileBeforeHash sha256:ff676eb00fd55db03dc591ae367167be2eaeabb09e44a6def287424ccec3e129.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=20, composer_merge=4, hot_provisional=4 |
| no_conflict | hot_provisional=2, composer_merge=2, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=155220, duration_ms=631.5
