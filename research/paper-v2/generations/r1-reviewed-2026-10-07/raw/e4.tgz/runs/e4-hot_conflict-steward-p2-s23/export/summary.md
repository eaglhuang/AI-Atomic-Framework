# atm-bench export — e4-hot_conflict-steward-p2-s23

- run_id: `e4-hot_conflict-steward-p2-s23` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 159304 | — |
| duration_ms | 766.18 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 15 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 763.98 | — |
| throughput intents/s | 47.12 | — |
| goodput oracle-pass/s | 47.12 | — |
| latency_ms mean / p50 / p95 | 10.15 / 9.6 / 19.53 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 49.83 / 23.46 / 143.94 | — |
| total_ms mean / p50 / p95 | 114.42 / 78.47 / 211.86 | — |
| overhead_ms mean / p50 / p95 | 61.86 / 35.67 / 168.21 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 15 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 13 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=8, atm_serial_queue=7, steward-final-patch-required: proposals 'prop-s23-t001-i3' and 'prop-s23-t001-i5' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i3, prop-s23-t001-i5]=3, atm_compose=3, steward-final-patch-required: proposals 'prop-s23-t001-i4' and 'prop-s23-t001-i6' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i4, prop-s23-t001-i6]=2, steward-final-patch-required: proposals 'prop-s23-t003-i0' and 'prop-s23-t003-i4' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t003-i0, prop-s23-t003-i4]=2, file-hash-drift: Target file hash sha256:e6e6ab5150e6781904154d4d55910b6ae060878a8a8e2deec2aabe28446ae6f1 does not match proposal fileBeforeHash sha256:bb4f7a30c6eff34677f7b8abcaa03e545ce0af341fb401f863442d0ce52d9aa9.=2, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:92ec86684671cef0423d211e9e08aa331192e8c95ca82b99e87ba9ea9b86b6c0 does not match proposal fileBeforeHash sha256:1815669d445a8bc4d1e50ea3357dfd98ad38364b83600650b746ca4bb35f2a5b.=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:810ef060282b061e44ed5e93d324ef8a83f5172cc0bc4f6eefb1510a06090fcd does not match proposal fileBeforeHash sha256:fffdf4bb573ca238ceeb56e30e099cf2401a03c68c5e9e50c19141b258616079.=1, file-hash-drift: Target file hash sha256:a9cf3fa731e497108a5c96e30a6fcf21a4c9b146ad7ccfd7c046a53aa55659ba does not match proposal fileBeforeHash sha256:8b62bc96ad1e5b721fbdea025a5acaec1e0bca8b8838a50605b094952ee0c5af.=1, file-hash-drift: Target file hash sha256:064eeaf1dc872306b59ce80775ae325d51085908664d720e531781bc5173902e does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=3, cold_queue=2, composer_merge=2 |
| hot_provisional | cold_queue=11, composer_merge=9, hot_provisional=5 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=159304, duration_ms=766.18
