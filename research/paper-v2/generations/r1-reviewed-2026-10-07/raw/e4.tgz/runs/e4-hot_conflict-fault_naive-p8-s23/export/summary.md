# atm-bench export — e4-hot_conflict-fault_naive-p8-s23

- run_id: `e4-hot_conflict-fault_naive-p8-s23` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157339 | — |
| duration_ms | 762.22 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 5 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 759.62 | — |
| throughput intents/s | 47.39 | — |
| goodput oracle-pass/s | 47.39 | — |
| latency_ms mean / p50 / p95 | 16.27 / 11.91 / 34.12 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 92.59 / 112.37 / 281.39 | — |
| total_ms mean / p50 / p95 | 126.02 / 132.23 / 334.85 | — |
| overhead_ms mean / p50 / p95 | 109.31 / 117.9 / 313.75 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 14 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=5, file-hash-drift: Target file hash sha256:c595cbe2046c4f2169ab14c6c86f1227cc8743d53a55231b46211408f3dda061 does not match proposal fileBeforeHash sha256:4b3c7f8192aa8c66b27d411edc4b0e318de50c8cf046bb79ee47d514fae38135.=2, file-hash-drift: Target file hash sha256:0c5831b8a1380412da788cbe17d82cf2fcedba86af9e0a1a2372a6cfb4adebaa does not match proposal fileBeforeHash sha256:55ad84085545f355188b638296768d763a50d0e9a1de1d666a45f200d2cea6df.=2, file-hash-drift: Target file hash sha256:096ef01757a1c9f99a386771089b91b2a768b021d3a4814ef75bdb129bfca9b5 does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=2, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:006d427bfc25c227f1aa5fc3cb58365a4f4b4d3d99aaa730489da46dd2c39141 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:146fe1bdf47f692e68f014a3477b0008d3eaae6353baffc8e2ca13bb2486bd01 does not match proposal fileBeforeHash sha256:a67d81b7ae41111ff8b057ee3a1ddab7d5ea04aa15e49f18746f433a12df16e3.=1, atm_compose=1, file-hash-drift: Target file hash sha256:096ef01757a1c9f99a386771089b91b2a768b021d3a4814ef75bdb129bfca9b5 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:4b55d1746c824a8e28bebdc21d12fd4d505d82e8ddc6f7ad6b7986f6b1726f45 does not match proposal fileBeforeHash sha256:c595cbe2046c4f2169ab14c6c86f1227cc8743d53a55231b46211408f3dda061.=1, file-hash-drift: Target file hash sha256:faf5b97872a80516fb5b6aece58b649fa2f625449e2a8f38e5d4e4b10daedffb does not match proposal fileBeforeHash sha256:146fe1bdf47f692e68f014a3477b0008d3eaae6353baffc8e2ca13bb2486bd01.=1, file-hash-drift: Target file hash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:faf5b97872a80516fb5b6aece58b649fa2f625449e2a8f38e5d4e4b10daedffb does not match proposal fileBeforeHash sha256:006d427bfc25c227f1aa5fc3cb58365a4f4b4d3d99aaa730489da46dd2c39141.=1, atm_provisional_write_lease+cas_rebase=1, file-hash-drift: Target file hash sha256:4b3c7f8192aa8c66b27d411edc4b0e318de50c8cf046bb79ee47d514fae38135 does not match proposal fileBeforeHash sha256:9a24d95d62d9e828b4b1638c70b4ac5c35361617cfefdc6b6a41bbd1ce4d6708.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, hot_provisional=1 |
| no_conflict | hot_provisional=4, cold_queue=3 |
| hot_provisional | cold_queue=11, composer_merge=11, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157339, duration_ms=762.22
