/** String helpers (COLD). */
// <region:body>
export function trim(s: string): string {
  return s.trim();
}
export function slugify(s: string): string {
  return trim(s).toLowerCase().replace(/\s+/g, '-');
}
// atm-edit s41-t002-i2 by codex:mock-s2
// </region:body>
