/** String helpers (COLD). */
// <region:body>
export function trim(s: string): string {
  return s.trim();
}
export function slugify(s: string): string {
  return trim(s).toLowerCase().replace(/\s+/g, '-');
}
// atm-edit s37-t002-i0 by cursor:mock-s0
// atm-edit s37-t004-i0 by claude:mock-s1
// </region:body>
