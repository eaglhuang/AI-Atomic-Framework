/** Tiny oracle-friendly test module (COLD). */
import { slugify, trim } from '../src/utils/strings.ts';

// <region:body>
export function runStringsSelfTest(): boolean {
  return trim('  x  ') === 'x' && slugify('Hello World') === 'hello-world';
}
// atm-edit s37-t002-i2 by codex:mock-s2
// atm-edit s37-t003-i2 by codex:mock-s2
// </region:body>
