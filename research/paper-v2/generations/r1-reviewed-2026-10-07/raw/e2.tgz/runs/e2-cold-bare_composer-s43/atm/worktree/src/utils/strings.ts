/** String helpers (COLD). */
// <region:body>
export function trim(s: string): string {
  return s.trim();
}
export function slugify(s: string): string {
  return trim(s).toLowerCase().replace(/\s+/g, '-');
}
// atm-edit s43-t000-i2 by codex:mock-s2
// atm-edit s43-t001-i0 by cursor:mock-s0
// </region:body>
