/** Tiny oracle-friendly test module (COLD). */
import { slugify, trim } from '../src/utils/strings.ts';

// <region:body>
export function runStringsSelfTest(): boolean {
  return trim('  x  ') === 'x' && slugify('Hello World') === 'hello-world';
}
// atm-edit s43-t001-i1 by claude:mock-s1
// atm-edit s43-t002-i0 by cursor:mock-s0
// atm-edit s43-t003-i2 by codex:mock-s2
// </region:body>
