/** Math helpers (COLD). */
// <region:body>
export function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}
export function sum(xs: readonly number[]): number {
  return xs.reduce((a, b) => a + b, 0);
}
// atm-edit s43-t001-i2 by codex:mock-s2
// </region:body>
