/** Build stub (COLD) — lists entry modules. */
import { boot } from '../src/index.ts';

// <region:body>
export function buildSummary(): string {
  const b = boot();
  return `routes=${b.routes};db=${b.db}`;
}
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log(buildSummary());
}
// atm-edit s43-t000-i0 by cursor:mock-s0
// atm-edit s43-t002-i2 by codex:mock-s2
// atm-edit s43-t003-i0 by cursor:mock-s0
// </region:body>
