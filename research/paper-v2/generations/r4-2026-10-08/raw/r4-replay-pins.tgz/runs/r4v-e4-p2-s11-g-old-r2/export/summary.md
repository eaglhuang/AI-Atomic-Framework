# atm-bench export — r4v-e4-p2-s11-g-old-r2

- run_id: `r4v-e4-p2-s11-g-old-r2` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154921 | — |
| duration_ms | 545.41 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 2 | — |
| integration pass rate of committed | 147.8% | — |
| effective success rate of all intents | 94.4% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 15 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 545.16 | — |
| throughput intents/s | 66.04 | — |
| goodput oracle-pass/s | 62.37 | — |
| latency_ms mean / p50 / p95 | 5.27 / 3.86 / 14.79 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 40.53 / 16.31 / 124.04 | — |
| total_ms mean / p50 / p95 | 91.63 / 58.07 / 182.28 | — |
| overhead_ms mean / p50 / p95 | 46.49 / 22.25 / 143.45 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=6, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:146e1f35e5ebbecb59e115fb9f850f18c0359275d9fd2ee0737a6d7b1ae67777 does not match proposal fileBeforeHash sha256:600bb99e9d0f5fa748ef56881b85336314f19fbe9bf7b7b2369d532498f84457.=3, file-hash-drift: Target file hash sha256:b34546f5e33aa03a974c2a985f03b9c0271d3def443b583e359dd256c7ce5e61 does not match proposal fileBeforeHash sha256:bdc39144302499f2e041704bfe5aa1e109bca717881dbadb77b9e9ae78fd005c.=2, file-hash-drift: Target file hash sha256:72158b0b477ef71ac1bab8a81ee412edb35ce271d65d994fe22303080a804c47 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=2, steward-final-patch-required: proposals 'prop-s11-t000-i0' and 'prop-s11-t002-i6' change overlapping base line 22 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t000-i0, prop-s11-t002-i6]=2, file-hash-drift: Target file hash sha256:0fa13448853df878d77930ffcd6082099aee81711cfa33093714471dc3678d1c does not match proposal fileBeforeHash sha256:72158b0b477ef71ac1bab8a81ee412edb35ce271d65d994fe22303080a804c47.=2, file-hash-drift: Target file hash sha256:7e652ca583f3636f5a9d1a7986665a40e782acfc7802b7181df26afecac8f7cd does not match proposal fileBeforeHash sha256:bd506f0a8f8f19c4e413569ae6efcd0d3805dc84d99b4066c513cee1b6e85cdc.=1, file-hash-drift: Target file hash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=15, composer_merge=8, hot_provisional=5 |
| no_conflict | hot_provisional=2, cold_queue=2, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154921, duration_ms=545.41
