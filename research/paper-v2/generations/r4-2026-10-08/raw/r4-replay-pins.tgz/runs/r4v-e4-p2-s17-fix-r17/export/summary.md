# atm-bench export — r4v-e4-p2-s17-fix-r17

- run_id: `r4v-e4-p2-s17-fix-r17` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 146569 | — |
| duration_ms | 522.81 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 161.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 11 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 522.11 | — |
| throughput intents/s | 65.12 | — |
| goodput oracle-pass/s | 65.12 | — |
| latency_ms mean / p50 / p95 | 5.52 / 4.16 / 14.01 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 39.03 / 14.57 / 117.97 | — |
| total_ms mean / p50 / p95 | 86.77 / 48.16 / 246.7 | — |
| overhead_ms mean / p50 / p95 | 45.3 / 19.8 / 134.61 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 10 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=8, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 20 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=3, file-hash-drift: Target file hash sha256:cb1bab3e26b39141919c2cd07ebb9c25e90ee0a2233996d02c41cb92a932804a does not match proposal fileBeforeHash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef.=2, steward-final-patch-required: proposals 'prop-s17-t003-i1' and 'prop-s17-t003-i4' change overlapping base line 19 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s17-t003-i1, prop-s17-t003-i4]=2, atm_compose=2, file-hash-drift: Target file hash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=2, file-hash-drift: Target file hash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:9b29344335569f11bfa6718ffe9ca8ce664c27407113bab1577fc66966741ff1 does not match proposal fileBeforeHash sha256:7834a774228fc59255f557f6fa4216786e3bc6e899c807f16675df79b46dc819.=1, file-hash-drift: Target file hash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=1, file-hash-drift: Target file hash sha256:1466db735a2c933611c7f055a9f2860be1a84c3864bda9b5eabc450a2ed2cf3c does not match proposal fileBeforeHash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, hot_provisional=7, composer_merge=6 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=146569, duration_ms=522.81
