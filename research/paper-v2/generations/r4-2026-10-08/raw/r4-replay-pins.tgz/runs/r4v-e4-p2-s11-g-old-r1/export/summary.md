# atm-bench export — r4v-e4-p2-s11-g-old-r1

- run_id: `r4v-e4-p2-s11-g-old-r1` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156867 | — |
| duration_ms | 538.8 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 21 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 19 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 538.92 | — |
| throughput intents/s | 66.8 | — |
| goodput oracle-pass/s | 66.8 | — |
| latency_ms mean / p50 / p95 | 5.07 / 3.87 / 16.87 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 30.34 / 13.93 / 132.82 | — |
| total_ms mean / p50 / p95 | 80.51 / 49.75 / 181.07 | — |
| overhead_ms mean / p50 / p95 | 36.15 / 18.61 / 148.39 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 9 | 0 | 0 |
| cold_queue | 21 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:1eeb7e4c9aa0d47e19f58573c6725e066c90b322723b6394a9768e345a07c576 does not match proposal fileBeforeHash sha256:173692fcc448fa0a8d0df44050556935ef9179fe928ada304a66276e93bbb8de.=3, steward-final-patch-required: proposals 'prop-s11-t004-i1' and 'prop-s11-t004-i5' change overlapping base line 30 of src/config.ts; a steward-authored final patch is required [proposals: prop-s11-t004-i1, prop-s11-t004-i5]=3, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8 does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=2, steward-final-patch-required: proposals 'prop-s11-t004-i0' and 'prop-s11-t004-i2' change overlapping base line 22 of src/config.ts; a steward-authored final patch is required [proposals: prop-s11-t004-i0, prop-s11-t004-i2]=2, compose-context-mismatch: proposal 'prop-s11-t003-i6' context mismatch at base line 9: expected "// </region:reducers>", found "// atm-edit s11-t003-i2 by codex:mock-s2" [proposals: prop-s11-t003-i6]=2, file-hash-drift: Target file hash sha256:3eebf73deac533232cc303cbb4104ff68f0f96086b16f4f374fa71778342920d does not match proposal fileBeforeHash sha256:d11624565d0fcb2f04310150953ac56cbfe27decec1eebc5ef056e55f15bff4a.=1, file-hash-drift: Target file hash sha256:bc0cd8749ca6e4480039827e7b967b03b65d73daad723aaf15047586edf909d1 does not match proposal fileBeforeHash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=19, composer_merge=7, hot_provisional=2 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156867, duration_ms=538.8
