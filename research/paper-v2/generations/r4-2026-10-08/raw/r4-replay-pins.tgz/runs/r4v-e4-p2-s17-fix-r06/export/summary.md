# atm-bench export — r4v-e4-p2-s17-fix-r06

- run_id: `r4v-e4-p2-s17-fix-r06` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 145265 | — |
| duration_ms | 633.74 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=12 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 154.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 10 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 632.84 | — |
| throughput intents/s | 53.73 | — |
| goodput oracle-pass/s | 53.73 | — |
| latency_ms mean / p50 / p95 | 5.25 / 3.55 / 13.97 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 38.51 / 15.82 / 124.26 | — |
| total_ms mean / p50 / p95 | 88.57 / 54.54 / 192.49 | — |
| overhead_ms mean / p50 / p95 | 44.55 / 23.52 / 136.13 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 10 | 0 | 0 |
| hot_provisional | 13 | 0 | 0 |
| composer_merge | 11 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=12, atm_serial_queue=7, file-hash-drift: Target file hash sha256:1466db735a2c933611c7f055a9f2860be1a84c3864bda9b5eabc450a2ed2cf3c does not match proposal fileBeforeHash sha256:7094f1c9f85bfcb2abc8b7ffa086805c58b664e8c56a01012e1a7b2f974c0c63.=3, steward-final-patch-required: proposals 'prop-s17-t003-i1' and 'prop-s17-t003-i4' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s17-t003-i1, prop-s17-t003-i4]=3, file-hash-drift: Target file hash sha256:83d5cd8596c6df3d3b4f87374f44280ffb7dacc64e93130c4d5c4b27fffef484 does not match proposal fileBeforeHash sha256:a482e4b4bd932652d53d7e1ef2f17a4aa48fc3b0bba6a73da15c00b21a26fbbf.=2, file-hash-drift: Target file hash sha256:909bee629f92e7abdc7c0ff5410e03a9f0f1549044b1eee299d5a56c2ffa2fc2 does not match proposal fileBeforeHash sha256:83d5cd8596c6df3d3b4f87374f44280ffb7dacc64e93130c4d5c4b27fffef484.=2, file-hash-drift: Target file hash sha256:90218ad2da78a0ef715c62b01630bcc74ecd360f3e89bc2b756477da4ec5532c does not match proposal fileBeforeHash sha256:8093cc60500b135af7549c34aa4a8612113e2a65a18b4168e382871ac5c4e734.=2, atm_compose+cas_rebase=2, atm_provisional_write_lease+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=10, hot_provisional=10, composer_merge=6 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=145265, duration_ms=633.74
