# atm-bench export — r4v-e4-p2-s11-g-fix-r3

- run_id: `r4v-e4-p2-s11-g-fix-r3` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154760 | — |
| duration_ms | 544.84 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=15 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 171.4% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 18 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 544.86 | — |
| throughput intents/s | 66.07 | — |
| goodput oracle-pass/s | 66.07 | — |
| latency_ms mean / p50 / p95 | 5.55 / 4.21 / 13.57 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 37.06 / 15.44 / 124.42 | — |
| total_ms mean / p50 / p95 | 89.39 / 48.47 / 207.19 | — |
| overhead_ms mean / p50 / p95 | 43.43 / 21.52 / 139.41 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:c3b87d00d596d4a7b5fef2f12e771224985da8414f8077a5c2748102a2a7caaa does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=4, file-hash-drift: Target file hash sha256:2b203d3bf1fdb0bd6a0715532014eda30bf9699aae25e6fee7ace12613037b2a does not match proposal fileBeforeHash sha256:2158ce8a133af64ccfc09288635d3cca4a08523d11f1edffeffddad632f3e079.=2, file-hash-drift: Target file hash sha256:4f1d73fb88a9fb60785c381683d89288850bfe8bf00f0fe3f2895c5ae2282f3a does not match proposal fileBeforeHash sha256:8c216388953701b12d61d028759ce591ecc95302af8efa5fcb6972ab0ef82943.=2, file-hash-drift: Target file hash sha256:8c216388953701b12d61d028759ce591ecc95302af8efa5fcb6972ab0ef82943 does not match proposal fileBeforeHash sha256:ac417e9fb1ee8f6d68f20ff1226419e7c425ef92f53098280fee5f6eb522a99d.=2, file-hash-drift: Target file hash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8 does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=2, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:2158ce8a133af64ccfc09288635d3cca4a08523d11f1edffeffddad632f3e079 does not match proposal fileBeforeHash sha256:6e8f887fc62295781edd1704d0534dbbd6e0201add6422d803000377ac29a6ff.=1, file-hash-drift: Target file hash sha256:8c4a7fcf309d0509dcd4cd3bf0fa7f8333122fb262764ee69cc0fb53692db436 does not match proposal fileBeforeHash sha256:646e607d675f103abc363b33116490528fc6aea2e9b0207d1a9cb5623ab6b6e5.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=16, composer_merge=9, hot_provisional=3 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154760, duration_ms=544.84
