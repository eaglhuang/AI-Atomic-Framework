# atm-bench export — r4v-e4-p2-s11-g-fix-r5

- run_id: `r4v-e4-p2-s11-g-fix-r5` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 152204 | — |
| duration_ms | 572.53 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=25, blocked=11 | — |
| committed | 25 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 144% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 20 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 572.3 | — |
| throughput intents/s | 62.9 | — |
| goodput oracle-pass/s | 62.9 | — |
| latency_ms mean / p50 / p95 | 5.4 / 4.17 / 13.85 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 35.78 / 14.92 / 129.21 | — |
| total_ms mean / p50 / p95 | 90.98 / 51.3 / 242.37 | — |
| overhead_ms mean / p50 / p95 | 42.19 / 20.86 / 153.24 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:57f61136df009061b7d35c4e65c0e2eb7145319e3dd37dab8299c9f6cfff2b64 does not match proposal fileBeforeHash sha256:2ae8ff375315d04ccb97614b18fdaeceee1b5ed8f7a01c700d058fe12ae1d147.=4, atm_compose+cas_rebase=3, file-hash-drift: Target file hash sha256:ddc3aa6974379cc30c90b33dbe735694ee98949f6caa03a83b2d6e80ab1e50c4 does not match proposal fileBeforeHash sha256:ffc61920a0b3b753096c3104f548424c87274bb04d6d4d41f9b64c95477e8a14.=3, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:76b425cddc3e73de881c27c6d27a7961a7a52c68d629395ff4c2aa4ad7a5f651 does not match proposal fileBeforeHash sha256:6ffdc0566c7e8bb1f9260307cdcf2775f500e23168b8b98ab2679b836d78d754.=1, file-hash-drift: Target file hash sha256:2ae8ff375315d04ccb97614b18fdaeceee1b5ed8f7a01c700d058fe12ae1d147 does not match proposal fileBeforeHash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171.=1, atm_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=15, composer_merge=7, hot_provisional=6 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=152204, duration_ms=572.53
