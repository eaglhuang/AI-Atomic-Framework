# atm-bench export — r4v-e4-p2-s17-fix-r04

- run_id: `r4v-e4-p2-s17-fix-r04` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 143815 | — |
| duration_ms | 575.72 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=11 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 147.8% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 574.95 | — |
| throughput intents/s | 59.14 | — |
| goodput oracle-pass/s | 59.14 | — |
| latency_ms mean / p50 / p95 | 5.41 / 3.9 / 15.88 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 48.2 / 19.02 / 125.64 | — |
| total_ms mean / p50 / p95 | 93.64 / 59.35 / 186.82 | — |
| overhead_ms mean / p50 / p95 | 54.49 / 25.6 / 142.92 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=7, atm_compose=4, steward-final-patch-required: proposals 'prop-s17-t001-i4' and 'prop-s17-t002-i1' change overlapping base line 19 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t001-i4, prop-s17-t002-i1]=3, canonical target base hash is stale: src/store.ts=2, file-hash-drift: Target file hash sha256:a3c5e76771ed28597201300d29a87dca46019f44a9e78a4e66736b296f40fb7f does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=2, file-hash-drift: Target file hash sha256:c39d921cc0bf4846ecb6f000baf6f2929b90b6d49b18aaa8d468e688cd203b5f does not match proposal fileBeforeHash sha256:44584e4d0009e2b501d0a50bce71f037971c4a14dc29e78654dd77d4be335c56.=2, file-hash-drift: Target file hash sha256:b3941d7e2ad29c7e013560dc962d679946b6004c6ec7df3b0611274db592da32 does not match proposal fileBeforeHash sha256:c9184847d72e8765a31b77c95fe412df135d5b2f63bbd62c7b2e32b78aef9020.=1, file-hash-drift: Target file hash sha256:3d662a3b8f47bf5e9651964cf78121be7271b06d63f68e328dee39ef1f2cbe90 does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=1, atm_compose+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, composer_merge=8, hot_provisional=5 |
| no_conflict | hot_provisional=2, composer_merge=1, cold_queue=1 |
| composer_cowrite | composer_merge=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=143815, duration_ms=575.72
