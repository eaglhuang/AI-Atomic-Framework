# atm-bench export — r4v-e4-p2-s11-g-fix-r2

- run_id: `r4v-e4-p2-s11-g-fix-r2` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154685 | — |
| duration_ms | 636.73 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 15 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 636.16 | — |
| throughput intents/s | 56.59 | — |
| goodput oracle-pass/s | 56.59 | — |
| latency_ms mean / p50 / p95 | 5.17 / 3.61 / 13.44 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 40.44 / 17.09 / 142.3 | — |
| total_ms mean / p50 / p95 | 89.04 / 50.02 / 197.11 | — |
| overhead_ms mean / p50 / p95 | 46.4 / 21.68 / 155.68 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| hot_provisional | 10 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=10, atm_serial_queue=9, atm_compose=3, file-hash-drift: Target file hash sha256:ef73cd5b9bd670e3faffc5af87d9b9928d607eae7fde49009a7f907e1bdfbca6 does not match proposal fileBeforeHash sha256:72158b0b477ef71ac1bab8a81ee412edb35ce271d65d994fe22303080a804c47.=3, file-hash-drift: Target file hash sha256:6c8df05d942b459ae61d122a2fabbf5ea04d95b44c3be5084f4f4633d4f47686 does not match proposal fileBeforeHash sha256:600bb99e9d0f5fa748ef56881b85336314f19fbe9bf7b7b2369d532498f84457.=3, file-hash-drift: Target file hash sha256:78c326859c49b994d779b898d4aeb7d805251119d1b3ec7ef5f6100565e4318e does not match proposal fileBeforeHash sha256:365b9c96ea1ccd5264376549a38d7f5973fe1e69c0b48026d9d8e0aeec326762.=2, file-hash-drift: Target file hash sha256:72158b0b477ef71ac1bab8a81ee412edb35ce271d65d994fe22303080a804c47 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=2, file-hash-drift: Target file hash sha256:2ade1d0adeaefa1a5c2c1962bfcc08b9f47acf0ccf471ad38c342f4a9add1456 does not match proposal fileBeforeHash sha256:ef73cd5b9bd670e3faffc5af87d9b9928d607eae7fde49009a7f907e1bdfbca6.=1, file-hash-drift: Target file hash sha256:f29f19f1b6877a63f8b88d7011e8f7bf5ec4b0a7477a94e122fb7992c68e4277 does not match proposal fileBeforeHash sha256:78c326859c49b994d779b898d4aeb7d805251119d1b3ec7ef5f6100565e4318e.=1, file-hash-drift: Target file hash sha256:2ae8ff375315d04ccb97614b18fdaeceee1b5ed8f7a01c700d058fe12ae1d147 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:57f61136df009061b7d35c4e65c0e2eb7145319e3dd37dab8299c9f6cfff2b64 does not match proposal fileBeforeHash sha256:2ae8ff375315d04ccb97614b18fdaeceee1b5ed8f7a01c700d058fe12ae1d147.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=13, composer_merge=9, hot_provisional=6 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154685, duration_ms=636.73
