# atm-bench export — r4v-e4-p2-s17-fix-r07

- run_id: `r4v-e4-p2-s17-fix-r07` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 146563 | — |
| duration_ms | 582.57 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 161.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 12 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 581.66 | — |
| throughput intents/s | 58.45 | — |
| goodput oracle-pass/s | 58.45 | — |
| latency_ms mean / p50 / p95 | 5.44 / 3.83 / 15.77 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 51.85 / 21.19 / 125.78 | — |
| total_ms mean / p50 / p95 | 99.44 / 89.06 / 253.93 | — |
| overhead_ms mean / p50 / p95 | 58.33 / 25.2 / 143.24 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 14 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 12 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:948f5ffa597e705ce9a8feb5267cbac76d8ba7199b30b8344d0dc13d8c43d9ff does not match proposal fileBeforeHash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e.=3, atm_compose=3, file-hash-drift: Target file hash sha256:cb1bab3e26b39141919c2cd07ebb9c25e90ee0a2233996d02c41cb92a932804a does not match proposal fileBeforeHash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef.=2, steward-final-patch-required: proposals 'prop-s17-t003-i1' and 'prop-s17-t003-i4' change overlapping base line 19 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s17-t003-i1, prop-s17-t003-i4]=2, file-hash-drift: Target file hash sha256:12f400a56eac92f888e15aebc98fc6c61a6b2b28897bfbe3cb7618920450cd4e does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=2, file-hash-drift: Target file hash sha256:c1a6c2e3dc2efd8ef930d449b2d85947d6c77fba6b7fb0b7efd76a6653df0f81 does not match proposal fileBeforeHash sha256:253f2ab9a28b71b995e38f8861bee09b1a7f307e6b53a0f0865d8b0ea8996970.=2, atm_compose+cas_rebase=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:bd4aae0498e49263729f518e1fe1bc29957354116657e71844c6cb4954abbfd7 does not match proposal fileBeforeHash sha256:6506ac404ddcc8871747c656f3b3ebd2637ef02ab001c4652c06d41e4ab667dd.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=11, composer_merge=10, hot_provisional=5 |
| no_conflict | hot_provisional=2, composer_merge=1, cold_queue=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=146563, duration_ms=582.57
