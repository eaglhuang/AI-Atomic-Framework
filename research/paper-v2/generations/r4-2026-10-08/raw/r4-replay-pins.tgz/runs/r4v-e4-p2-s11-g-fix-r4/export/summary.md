# atm-bench export — r4v-e4-p2-s11-g-fix-r4

- run_id: `r4v-e4-p2-s11-g-fix-r4` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157427 | — |
| duration_ms | 536.87 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 19 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 18 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 537.23 | — |
| throughput intents/s | 67.01 | — |
| goodput oracle-pass/s | 67.01 | — |
| latency_ms mean / p50 / p95 | 5.5 / 3.66 / 13.97 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 36.95 / 15.3 / 131.86 | — |
| total_ms mean / p50 / p95 | 84.23 / 49.94 / 196.83 | — |
| overhead_ms mean / p50 / p95 | 43.21 / 21.25 / 146.92 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 19 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:3b197c6bdc30950dacc14d9621c796153fedaf4363f4d12ad3e2ddd9d221e760 does not match proposal fileBeforeHash sha256:3038289f914a3090be47e68fff94401c7058175f1823523534afa67cd27a4755.=3, file-hash-drift: Target file hash sha256:8f20d449758e5814d4ae720e1dcd0b2bdf1016683fc7b0f8e036e62a5ed577cd does not match proposal fileBeforeHash sha256:6c137db7041500eac800af95805956c770f7f4468d78f0aef175cd58dea4fb28.=3, file-hash-drift: Target file hash sha256:0094bd963edfb3d50e6371425791728b570b1b6331c3e49fd587de95efdc1a7c does not match proposal fileBeforeHash sha256:23412beeb20140f78c38c94cdbb7c59505fe41e22fd62f3c6be409c263a0ce79.=3, file-hash-drift: Target file hash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:d99e5e85da084aeae432d3559da480044e5df796d88bcb0ab29b8a2541f40196 does not match proposal fileBeforeHash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171.=2, atm_compose=1, file-hash-drift: Target file hash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:267a5b7059d3c74183538f7d633c972fee8faf35c66f279a365f5cf9d2fbc9ba does not match proposal fileBeforeHash sha256:e820b9fb40fa58121ef1a8c692846240c3e1a10c77a7f6c72332aa57300447de.=1, file-hash-drift: Target file hash sha256:e9618ebe92ab7819d9eb9b5cae4a98f22a68aec5ac6e0c4a3be19f9acfadbd0b does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=1, file-hash-drift: Target file hash sha256:737e7f14829ab22785f7e047f8a9f4cf7d0eb8d87dc3053df3b021e7dcdba418 does not match proposal fileBeforeHash sha256:498062049b3744cd25204ba97be1238bf6aae79a57a3e54a551bfbb199aa5ed0.=1, atm_compose+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=17, composer_merge=9, hot_provisional=2 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157427, duration_ms=536.87
