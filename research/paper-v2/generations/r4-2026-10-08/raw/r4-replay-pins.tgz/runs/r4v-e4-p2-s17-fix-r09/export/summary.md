# atm-bench export — r4v-e4-p2-s17-fix-r09

- run_id: `r4v-e4-p2-s17-fix-r09` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 143382 | — |
| duration_ms | 575.47 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=24, blocked=10 | — |
| committed | 24 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 141.7% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 11 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 573.91 | — |
| throughput intents/s | 59.24 | — |
| goodput oracle-pass/s | 59.24 | — |
| latency_ms mean / p50 / p95 | 6.53 / 3.98 / 23.03 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 37.09 / 16.24 / 127.85 | — |
| total_ms mean / p50 / p95 | 87.93 / 52.12 / 180.64 | — |
| overhead_ms mean / p50 / p95 | 44.33 / 22.09 / 148.97 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 10 | 0 | 0 |
| composer_merge | 10 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=10, atm_provisional_write_lease=9, atm_compose=3, file-hash-drift: Target file hash sha256:a482e4b4bd932652d53d7e1ef2f17a4aa48fc3b0bba6a73da15c00b21a26fbbf does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=2, file-hash-drift: Target file hash sha256:406e0592b6d145e2f8a8b90ed98c13e75cce260d90d75297ba5256695dc90c33 does not match proposal fileBeforeHash sha256:56af38d14eb8ad3996aa76de9ab0fa4cb6c7ddb2e5709053d2901c5efd138e9b.=2, file-hash-drift: Target file hash sha256:0685a785578fe908f82836984c43d794d483c295e8e2113de96a677cb3466202 does not match proposal fileBeforeHash sha256:9579140ef78a9c41265ed571a7c3da61acba44b58457cedcfa9cce5937482f85.=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:6e2ff2b0c8e636ec10f873aa15f35417bc41614695cb4a4d823376c24ad0908b does not match proposal fileBeforeHash sha256:0685a785578fe908f82836984c43d794d483c295e8e2113de96a677cb3466202.=1, file-hash-drift: Target file hash sha256:56af38d14eb8ad3996aa76de9ab0fa4cb6c7ddb2e5709053d2901c5efd138e9b does not match proposal fileBeforeHash sha256:a482e4b4bd932652d53d7e1ef2f17a4aa48fc3b0bba6a73da15c00b21a26fbbf.=1, file-hash-drift: Target file hash sha256:9579140ef78a9c41265ed571a7c3da61acba44b58457cedcfa9cce5937482f85 does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, hot_provisional=8, composer_merge=5 |
| no_conflict | composer_merge=2, cold_queue=1, hot_provisional=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=143382, duration_ms=575.47
