# atm-bench export — r4v-e4-p2-s17-g-optr0-r2

- run_id: `r4v-e4-p2-s17-g-optr0-r2` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-2118bc66/AI-Atomic-Framework-2118bc66efb3ac3bc0ddaede6a2f7cb18526b030/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 144334 | — |
| duration_ms | 521.5 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=25, blocked=9 | — |
| committed | 25 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 136% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 15 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 520.77 | — |
| throughput intents/s | 65.29 | — |
| goodput oracle-pass/s | 65.29 | — |
| latency_ms mean / p50 / p95 | 4.93 / 3.64 / 16.59 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 39.5 / 14.63 / 119.42 | — |
| total_ms mean / p50 / p95 | 86.97 / 46.79 / 250.39 | — |
| overhead_ms mean / p50 / p95 | 45.12 / 19.2 / 133.72 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |
| hot_provisional | 10 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=9, steward-final-patch-required: proposal 'prop-s17-t001-i6' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t001-i6]=3, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 20 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=3, atm_compose=3, steward-final-patch-required: proposal 'prop-s17-t000-i1' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t000-i1]=2, steward-final-patch-required: proposal 'prop-s17-t000-i0' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t000-i0]=1, atm_compose+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, hot_provisional=7, composer_merge=6 |
| no_conflict | hot_provisional=2, composer_merge=1, cold_queue=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=144334, duration_ms=521.5
