# atm-bench export — r4v-e4-p2-s17-g-optr1-r3

- run_id: `r4v-e4-p2-s17-g-optr1-r3` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-2118bc66/AI-Atomic-Framework-2118bc66efb3ac3bc0ddaede6a2f7cb18526b030/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 141456 | — |
| duration_ms | 588.15 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=27, blocked=7 | — |
| committed | 27 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 125.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 587.16 | — |
| throughput intents/s | 57.91 | — |
| goodput oracle-pass/s | 57.91 | — |
| latency_ms mean / p50 / p95 | 5.03 / 3.45 / 13.52 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 44.54 / 18.34 / 120.68 | — |
| total_ms mean / p50 / p95 | 92.63 / 49.06 / 265.57 | — |
| overhead_ms mean / p50 / p95 | 50.18 / 22.6 / 153.3 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 13 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=8, atm_compose=5, steward-final-patch-required: proposal 'prop-s17-t000-i1' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t000-i1]=2, steward-final-patch-required: proposal 'prop-s17-t002-i2' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t002-i2]=2, steward-final-patch-required: proposal 'prop-s17-t003-i1' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t003-i1]=1, atm_compose+cas_rebase=1, steward-final-patch-required: proposal 'prop-s17-t004-i4' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t004-i4]=1, steward-final-patch-required: proposal 'prop-s17-t000-i6' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t000-i6]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, composer_merge=8, hot_provisional=5 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=141456, duration_ms=588.15
