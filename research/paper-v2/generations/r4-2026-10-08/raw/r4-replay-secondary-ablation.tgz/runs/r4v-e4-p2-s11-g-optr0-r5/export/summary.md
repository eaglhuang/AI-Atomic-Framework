# atm-bench export — r4v-e4-p2-s11-g-optr0-r5

- run_id: `r4v-e4-p2-s11-g-optr0-r5` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-2118bc66/AI-Atomic-Framework-2118bc66efb3ac3bc0ddaede6a2f7cb18526b030/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156593 | — |
| duration_ms | 669.65 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 19 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 20 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 669.02 | — |
| throughput intents/s | 53.81 | — |
| goodput oracle-pass/s | 53.81 | — |
| latency_ms mean / p50 / p95 | 5.07 / 3.76 / 13.97 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 40.93 / 15.31 / 117.76 | — |
| total_ms mean / p50 / p95 | 93.35 / 66.19 / 206.39 | — |
| overhead_ms mean / p50 / p95 | 46.75 / 20.46 / 136.73 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 19 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=6, steward-final-patch-required: proposals 'prop-s11-t001-i3' and 'prop-s11-t001-i5' both edit region 'orders' of src/routes.ts; overlapping region edits stay blocked [proposals: prop-s11-t001-i3, prop-s11-t001-i5]=4, steward-final-patch-required: proposal 'prop-s11-t004-i1' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t004-i1]=2, steward-final-patch-required: proposal 'prop-s11-t003-i0' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i0]=2, steward-final-patch-required: proposal 'prop-s11-t002-i7' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i7]=2, atm_compose+cas_rebase=2, re-compose attempts exhausted after 1 of 1: re-compose: canonical target base hash is stale: src/routes.ts (expected sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4, observed sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79). Re-read the file and compose again against the current bytes.=1, re-compose attempts exhausted after 1 of 1: re-compose: canonical target base hash is stale: src/store.ts (expected sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e, observed sha256:ddc59502be5c789a86f52f1135b0b175853fd062858439244b3432dcf6c002d9). Re-read the file and compose again against the current bytes.=1, atm_compose=1, steward-final-patch-required: proposal 'prop-s11-t002-i0' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i0]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=16, composer_merge=8, hot_provisional=4 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156593, duration_ms=669.65
