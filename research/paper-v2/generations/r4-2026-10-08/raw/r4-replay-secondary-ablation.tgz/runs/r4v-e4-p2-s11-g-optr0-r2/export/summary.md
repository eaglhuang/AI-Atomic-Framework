# atm-bench export — r4v-e4-p2-s11-g-optr0-r2

- run_id: `r4v-e4-p2-s11-g-optr0-r2` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-2118bc66/AI-Atomic-Framework-2118bc66efb3ac3bc0ddaede6a2f7cb18526b030/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156027 | — |
| duration_ms | 543.5 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=24, blocked=12 | — |
| committed | 24 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 150% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 19 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 19 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 543.33 | — |
| throughput intents/s | 66.26 | — |
| goodput oracle-pass/s | 66.26 | — |
| latency_ms mean / p50 / p95 | 5.45 / 3.62 / 16.71 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 37.91 / 15.85 / 125.09 | — |
| total_ms mean / p50 / p95 | 89.9 / 51.79 / 181.54 | — |
| overhead_ms mean / p50 / p95 | 44.2 / 22.52 / 143.1 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 11 | 0 | 0 |
| cold_queue | 19 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=6, steward-final-patch-required: proposals 'prop-s11-t001-i3' and 'prop-s11-t001-i5' change overlapping base line 17 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s11-t001-i3, prop-s11-t001-i5]=3, atm_compose+cas_rebase=3, atm_compose=3, steward-final-patch-required: proposal 'prop-s11-t003-i6' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i6]=2, re-compose attempts exhausted after 1 of 1: re-compose: canonical target base hash is stale: src/config.ts (expected sha256:95a739b8355bc19a85b5eb691d59a533709d5549b2da3763d2e039cb043a2268, observed sha256:5864bfd226f2a186433693256939d8f6f35c6c7dba401297e528a7fd380888ab). Re-read the file and compose again against the current bytes.=2, steward-final-patch-required: proposals 'prop-s11-t000-i0' and 'prop-s11-t002-i6' both edit region 'admin' of src/routes.ts; overlapping region edits stay blocked [proposals: prop-s11-t000-i0, prop-s11-t002-i6]=2, re-compose attempts exhausted after 1 of 1: re-compose: canonical target base hash is stale: src/store.ts (expected sha256:d759c97cf5b28c6d310ccc3489e2dafcbd721cbed155ada5ee61242adbe6ce5c, observed sha256:89742cf3954211903401bc4c0ffa186e9a16d15d49cd12e3eee190c89b2b64a7). Re-read the file and compose again against the current bytes.=1, re-compose attempts exhausted after 1 of 1: re-compose: canonical target base hash changed before commit: src/routes.ts (expected sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4, observed sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79). Re-read the file and compose again against the current bytes.=1, steward-final-patch-required: proposal 'prop-s11-t002-i3' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i3]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=16, composer_merge=8, hot_provisional=4 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156027, duration_ms=543.5
