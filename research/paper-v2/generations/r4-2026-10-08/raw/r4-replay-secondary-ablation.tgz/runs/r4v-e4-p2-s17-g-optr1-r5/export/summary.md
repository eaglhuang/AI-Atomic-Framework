# atm-bench export — r4v-e4-p2-s17-g-optr1-r5

- run_id: `r4v-e4-p2-s17-g-optr1-r5` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-2118bc66/AI-Atomic-Framework-2118bc66efb3ac3bc0ddaede6a2f7cb18526b030/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 147986 | — |
| duration_ms | 567.12 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 14 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 565.6 | — |
| throughput intents/s | 60.11 | — |
| goodput oracle-pass/s | 60.11 | — |
| latency_ms mean / p50 / p95 | 5.34 / 3.94 / 14.34 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 35.49 / 16.84 / 121.67 | — |
| total_ms mean / p50 / p95 | 83.55 / 48.16 / 179.32 | — |
| overhead_ms mean / p50 / p95 | 41.53 / 23.21 / 141.19 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 15 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| composer_merge | 10 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=10, atm_provisional_write_lease=6, steward-final-patch-required: proposals 'prop-s17-t001-i4' and 'prop-s17-t002-i1' change overlapping base line 20 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t001-i4, prop-s17-t002-i1]=3, steward-final-patch-required: proposal 'prop-s17-t004-i6' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t004-i6]=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, steward-final-patch-required: proposal 'prop-s17-t001-i5' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t001-i5]=2, atm_compose=2, steward-final-patch-required: proposals 'prop-s17-t004-i0' and 'prop-s17-t004-i5' both edit region 'reducers' of src/store.ts; overlapping region edits stay blocked [proposals: prop-s17-t004-i0, prop-s17-t004-i5]=2, atm_compose+cas_rebase=2, steward-final-patch-required: proposal 'prop-s17-t003-i1' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t003-i1]=1, steward-final-patch-required: proposal 'prop-s17-t003-i0' overlaps region 'users', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t003-i0]=1, steward-final-patch-required: proposal 'prop-s17-t000-i6' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s17-t000-i6]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=14, hot_provisional=6, composer_merge=6 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | composer_merge=2, hot_provisional=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=147986, duration_ms=567.12
