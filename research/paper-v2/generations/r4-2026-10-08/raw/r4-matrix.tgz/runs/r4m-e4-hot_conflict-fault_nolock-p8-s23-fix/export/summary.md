# atm-bench export — r4m-e4-hot_conflict-fault_nolock-p8-s23-fix

- run_id: `r4m-e4-hot_conflict-fault_nolock-p8-s23-fix` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 160618 | — |
| duration_ms | 682.11 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=20, commit=16 | — |
| committed | 16 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 225% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 18 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 3 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 678.83 | — |
| throughput intents/s | 53.03 | — |
| goodput oracle-pass/s | 53.03 | — |
| latency_ms mean / p50 / p95 | 14.27 / 10.72 / 36.5 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 83.67 / 20.45 / 271.62 | — |
| total_ms mean / p50 / p95 | 114.84 / 70.57 / 312.7 | — |
| overhead_ms mean / p50 / p95 | 98.36 / 48.78 / 301.18 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 18 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=10, atm_provisional_write_lease=5, file-hash-drift: Target file hash sha256:9ee00f1819f1171524279cddbf45845475b26eb39af267f074c4fbede5b07674 does not match proposal fileBeforeHash sha256:20ae11bc581aa802a6ccc7e6cdac4f56045184ab60e8d41a4be2576fdc2ac6eb.=3, file-hash-drift: Target file hash sha256:3027d69e788dda1f2c28f8483fe82e4400c6d61d9e23e65be9ea91f58cdc2e72 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=3, file-hash-drift: Target file hash sha256:c94c2133c5c676b66e5405b449eda686f555669243f9ead24e502b9b298b8a0a does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=3, file-hash-drift: Target file hash sha256:0a94fa72d1574b484fca21f31871960becab1962b1023db36ad1858a8a591c03 does not match proposal fileBeforeHash sha256:c94c2133c5c676b66e5405b449eda686f555669243f9ead24e502b9b298b8a0a.=2, file-hash-drift: Target file hash sha256:3027d69e788dda1f2c28f8483fe82e4400c6d61d9e23e65be9ea91f58cdc2e72 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:0ba95cb3923e7de9ab9a8d1342274d017373091eb46a2fac469385c4246b2cd1 does not match proposal fileBeforeHash sha256:9ee00f1819f1171524279cddbf45845475b26eb39af267f074c4fbede5b07674.=1, file-hash-drift: Target file hash sha256:fc8f6d62be182a58e6026a97f48c671b9580a436fb2571ea8d93fa1f6c05e0f2 does not match proposal fileBeforeHash sha256:3027d69e788dda1f2c28f8483fe82e4400c6d61d9e23e65be9ea91f58cdc2e72.=1, file-hash-drift: Target file hash sha256:1d638acc0d4ff1d28bd827dd5f74f88bf48575545c98e1ba4d8ce083e645d1b1 does not match proposal fileBeforeHash sha256:fc8f6d62be182a58e6026a97f48c671b9580a436fb2571ea8d93fa1f6c05e0f2.=1, file-hash-drift: Target file hash sha256:64105a84a29bd3d8254085ce57708365f302998bffe068a194dba13a788e20b0 does not match proposal fileBeforeHash sha256:0ba95cb3923e7de9ab9a8d1342274d017373091eb46a2fac469385c4246b2cd1.=1, compose-context-mismatch: proposal 'prop-s23-t000-i3' context mismatch at base line 18: expected "};", found "  backend: 'memory'," [proposals: prop-s23-t000-i3]=1, file-hash-drift: Target file hash sha256:89978ca31efa5378948c71479887180f6a9e7fbbf8e9d11a740b42f22f682535 does not match proposal fileBeforeHash sha256:d9526b09bb21f59a4a08384019f7ea99ec32bfa5780df10239d140ee5f748e51.=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:d9526b09bb21f59a4a08384019f7ea99ec32bfa5780df10239d140ee5f748e51 does not match proposal fileBeforeHash sha256:c94c2133c5c676b66e5405b449eda686f555669243f9ead24e502b9b298b8a0a.=1, canonical target base hash is stale: src/store.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, cold_queue=1 |
| no_conflict | cold_queue=3, composer_merge=2, hot_provisional=2 |
| hot_provisional | cold_queue=14, composer_merge=7, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=160618, duration_ms=682.11
