# atm-bench export — r4m-e4-hot_conflict-steward-p2-s23-fix

- run_id: `r4m-e4-hot_conflict-steward-p2-s23-fix` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 161843 | — |
| duration_ms | 570.07 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 15 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 567.4 | — |
| throughput intents/s | 63.45 | — |
| goodput oracle-pass/s | 63.45 | — |
| latency_ms mean / p50 / p95 | 5.2 / 3.8 / 13.38 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 40.05 / 16.84 / 117.42 | — |
| total_ms mean / p50 / p95 | 87.35 / 53.49 / 177.47 | — |
| overhead_ms mean / p50 / p95 | 46.16 / 22.76 / 132.08 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 15 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 13 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=8, atm_serial_queue=7, steward-final-patch-required: proposals 'prop-s23-t001-i3' and 'prop-s23-t001-i5' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i3, prop-s23-t001-i5]=3, steward-final-patch-required: proposals 'prop-s23-t003-i0' and 'prop-s23-t003-i4' change overlapping base line 9 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t003-i0, prop-s23-t003-i4]=3, atm_compose=3, steward-final-patch-required: proposals 'prop-s23-t001-i2' and 'prop-s23-t001-i4' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s23-t001-i2, prop-s23-t001-i4]=2, file-hash-drift: Target file hash sha256:aa79b5053cf2a81bcb54d0d6674ad8e7ea144f6f550e3a98d053a318134181c6 does not match proposal fileBeforeHash sha256:9a24d95d62d9e828b4b1638c70b4ac5c35361617cfefdc6b6a41bbd1ce4d6708.=2, file-hash-drift: Target file hash sha256:1d5a7fe2af4234741a601bd571757746c33031e26f4bb6d8632dd93d8fba2c5c does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:e11585a0e915553093fd728b73c3abbc0fe29726d21b43e13d7fdd6d4c641f27 does not match proposal fileBeforeHash sha256:aa79b5053cf2a81bcb54d0d6674ad8e7ea144f6f550e3a98d053a318134181c6.=2, steward-final-patch-required: proposals 'prop-s23-t002-i3' and 'prop-s23-t002-i6' change overlapping base line 22 of src/config.ts; a steward-authored final patch is required [proposals: prop-s23-t002-i3, prop-s23-t002-i6]=2, file-hash-drift: Target file hash sha256:ff6e8c1f81310a2e3e96749b15f60c97818ff4d33cc3d47becd2b5925a6fac5a does not match proposal fileBeforeHash sha256:908dc4a1dd47c9928582ec2989571d70f84b3ac491fdfd7b31c3bd887a3997c9.=1, atm_compose+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=4 |
| no_conflict | hot_provisional=5, cold_queue=2 |
| hot_provisional | cold_queue=11, composer_merge=11, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=161843, duration_ms=570.07
