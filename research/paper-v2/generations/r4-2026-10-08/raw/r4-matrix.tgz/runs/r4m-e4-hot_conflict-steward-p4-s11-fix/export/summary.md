# atm-bench export — r4m-e4-hot_conflict-steward-p4-s11-fix

- run_id: `r4m-e4-hot_conflict-steward-p4-s11-fix` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156100 | — |
| duration_ms | 619.91 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 11 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 619.91 | — |
| throughput intents/s | 58.07 | — |
| goodput oracle-pass/s | 58.07 | — |
| latency_ms mean / p50 / p95 | 7.8 / 6.13 / 22.06 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 58.34 / 15.07 / 191.69 | — |
| total_ms mean / p50 / p95 | 94.36 / 56.86 / 233.02 | — |
| overhead_ms mean / p50 / p95 | 66.7 / 27.05 / 199.58 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:8b9476f6db48641730d21bebd79505c172bcf7e6fbcbe1d20140393300968242 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, atm_compose+cas_rebase=2, atm_compose=2, file-hash-drift: Target file hash sha256:9d8cfd179337b1e9dad09836fba016bf3abcf05a90cba571361adbab2c6a99b8 does not match proposal fileBeforeHash sha256:612ce24739db7382a853399e28b4c3921fb9189118847f70d2d62d4ca62321a9.=2, file-hash-drift: Target file hash sha256:c3b87d00d596d4a7b5fef2f12e771224985da8414f8077a5c2748102a2a7caaa does not match proposal fileBeforeHash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c.=2, file-hash-drift: Target file hash sha256:e98dbcc88eccbe5e7655ea277127cdaf8669ff780a2716c579071b69ced47ecf does not match proposal fileBeforeHash sha256:8b9476f6db48641730d21bebd79505c172bcf7e6fbcbe1d20140393300968242.=1, file-hash-drift: Target file hash sha256:2f6511ea1d617ee944a8411a8371ac231e4e5b5a56683e01274d2b72f2fedee7 does not match proposal fileBeforeHash sha256:98d6f7f38398704876130fc1fdd926007be65e6239252e6227ffda7607a3cbc5.=1, file-hash-drift: Target file hash sha256:d8f0e6f3acad99a523ee04b569cd7dff515dad38a84f9359105ca4e432839e86 does not match proposal fileBeforeHash sha256:2f6511ea1d617ee944a8411a8371ac231e4e5b5a56683e01274d2b72f2fedee7.=1, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:2f6511ea1d617ee944a8411a8371ac231e4e5b5a56683e01274d2b72f2fedee7 does not match proposal fileBeforeHash sha256:2048bc9ca389e784d1a8f63021359e80f4c7e7c6acb43ef5091ef7a79421d58f.=1, atm_provisional_write_lease+cas_rebase=1, file-hash-drift: Target file hash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c does not match proposal fileBeforeHash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79.=1, file-hash-drift: Target file hash sha256:98d6f7f38398704876130fc1fdd926007be65e6239252e6227ffda7607a3cbc5 does not match proposal fileBeforeHash sha256:f9df541f359c5964dc779774f23c3f86ddfead632a0cb8e2960a31768ca5f73b.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, cold_queue=1 |
| hot_provisional | cold_queue=12, composer_merge=10, hot_provisional=6 |
| no_conflict | hot_provisional=2, cold_queue=2, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156100, duration_ms=619.91
