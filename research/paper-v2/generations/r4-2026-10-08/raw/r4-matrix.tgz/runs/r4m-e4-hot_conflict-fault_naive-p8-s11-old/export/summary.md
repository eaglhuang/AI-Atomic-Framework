# atm-bench export — r4m-e4-hot_conflict-fault_naive-p8-s11-old

- run_id: `r4m-e4-hot_conflict-fault_naive-p8-s11-old` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157983 | — |
| duration_ms | 744.23 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=17 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 189.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 20 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 8 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 744.11 | — |
| throughput intents/s | 48.38 | — |
| goodput oracle-pass/s | 48.38 | — |
| latency_ms mean / p50 / p95 | 12.29 / 8.83 / 32.45 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 69.55 / 17.66 / 249.5 | — |
| total_ms mean / p50 / p95 | 100.86 / 49.07 / 308.39 | — |
| overhead_ms mean / p50 / p95 | 82.26 / 29.19 / 284.35 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 9 | 0 | 0 |
| cold_queue | 20 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=5, file-hash-drift: Target file hash sha256:92702094e99f6a46604ca81d37f2bb2071830314cf1e5fecf8469b2a75d1d12c does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=3, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=3, atm_compose=2, file-hash-drift: Target file hash sha256:ddc59502be5c789a86f52f1135b0b175853fd062858439244b3432dcf6c002d9 does not match proposal fileBeforeHash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e.=2, file-hash-drift: Target file hash sha256:92702094e99f6a46604ca81d37f2bb2071830314cf1e5fecf8469b2a75d1d12c does not match proposal fileBeforeHash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79.=1, file-hash-drift: Target file hash sha256:8e42417e9be101c4348e5baa15a0174c2a5b421a3c69bb40c4c3638f26339f8a does not match proposal fileBeforeHash sha256:ecba4d8363ea592eaf3a6c1ecd9602c76722d67db570a6e723159f475322ef48.=1, file-hash-drift: Target file hash sha256:60707e664b8297ca7137c78093822603fb0cafec4564c6be6c1f72f83e10a87a does not match proposal fileBeforeHash sha256:ff676eb00fd55db03dc591ae367167be2eaeabb09e44a6def287424ccec3e129.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:cd9e5f2eec209a85a02031d1f17a73ee515245024b651bb9509a276fba5a78a6 does not match proposal fileBeforeHash sha256:60707e664b8297ca7137c78093822603fb0cafec4564c6be6c1f72f83e10a87a.=1, file-hash-drift: Target file hash sha256:033d83dbcd549456c9b8065304fa21ca1d29277322a637b37cd3f85a740b331e does not match proposal fileBeforeHash sha256:92702094e99f6a46604ca81d37f2bb2071830314cf1e5fecf8469b2a75d1d12c.=1, file-hash-drift: Target file hash sha256:ce5e85b3e33b3ce92d0d99719eda6f6187943c4a8c08c96946bf2a207c3cc51c does not match proposal fileBeforeHash sha256:ecba4d8363ea592eaf3a6c1ecd9602c76722d67db570a6e723159f475322ef48.=1, file-hash-drift: Target file hash sha256:8e42417e9be101c4348e5baa15a0174c2a5b421a3c69bb40c4c3638f26339f8a does not match proposal fileBeforeHash sha256:ce5e85b3e33b3ce92d0d99719eda6f6187943c4a8c08c96946bf2a207c3cc51c.=1, canonical target base hash is stale: src/config.ts=1, atm_provisional_write_lease+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, cold_queue=1 |
| hot_provisional | cold_queue=17, composer_merge=7, hot_provisional=4 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157983, duration_ms=744.23
