# atm-bench export — r4m-e4-hot_conflict-steward-p4-s11-old

- run_id: `r4m-e4-hot_conflict-steward-p4-s11-old` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157758 | — |
| duration_ms | 538.38 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 20 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 14 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 538.15 | — |
| throughput intents/s | 66.9 | — |
| goodput oracle-pass/s | 66.9 | — |
| latency_ms mean / p50 / p95 | 9.31 / 7.64 / 22.07 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 47.08 / 14.13 / 194.24 | — |
| total_ms mean / p50 / p95 | 85.96 / 52.77 / 233.05 | — |
| overhead_ms mean / p50 / p95 | 57.02 / 24.15 / 204.11 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 9 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 20 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=13, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:548433f024118e2b977b0ad25cf44ee7963269e15f7c4b7cb0960cf9afd3a8df does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, file-hash-drift: Target file hash sha256:25c547664d88c043b5dc2ad7b378407e954fc2c3647a39e76cb2554bc84740c2 does not match proposal fileBeforeHash sha256:fda9cd78d3fb29cd1843cc3024ac33448341411cd04982610ebd3abdba2a7677.=2, file-hash-drift: Target file hash sha256:25c547664d88c043b5dc2ad7b378407e954fc2c3647a39e76cb2554bc84740c2 does not match proposal fileBeforeHash sha256:ec6b99a26fea415d29a69505dba9416ca8229712aeda7ab83736ed88823f86c7.=2, file-hash-drift: Target file hash sha256:25d571a488be049d44fad02be97b575e2f3f8b29e547ea4513f687e66e8f9cb3 does not match proposal fileBeforeHash sha256:455ed08b9be143b47ff3e21e9f246d761ae626ab90abcf815ea9bb0b63ca882e.=2, file-hash-drift: Target file hash sha256:037acc7b9ffc5436f049169aa78fd609e1aba7e42df514454ab23f1907f00f0d does not match proposal fileBeforeHash sha256:577f7bcf7bfe5817fa14fe7f23dec2922e85929a269b5cc1653b0bdfa9b4c870.=2, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 does not match proposal fileBeforeHash sha256:ec6b99a26fea415d29a69505dba9416ca8229712aeda7ab83736ed88823f86c7.=1, file-hash-drift: Target file hash sha256:126d9a7c397e05e97f1d59f724a4246b7164287c464d3201e43de8921acf417c does not match proposal fileBeforeHash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79.=1, file-hash-drift: Target file hash sha256:3f2dd90d959e1856aa0db4a71222578a43cb2f36c5510d7eb4fb1b212a955b41 does not match proposal fileBeforeHash sha256:8c2aa8ff9eb08c4db054dfcf6908103eb5bf6d104b4efdc19fe410c3c22c0914.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:455ed08b9be143b47ff3e21e9f246d761ae626ab90abcf815ea9bb0b63ca882e does not match proposal fileBeforeHash sha256:ff676eb00fd55db03dc591ae367167be2eaeabb09e44a6def287424ccec3e129.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=17, composer_merge=6, hot_provisional=5 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157758, duration_ms=538.38
