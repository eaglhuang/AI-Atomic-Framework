# atm-bench export — r4m-e4-hot_conflict-fault_naive-p8-s23-fix

- run_id: `r4m-e4-hot_conflict-fault_naive-p8-s23-fix` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157566 | — |
| duration_ms | 706.18 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 7 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 703.47 | — |
| throughput intents/s | 51.17 | — |
| goodput oracle-pass/s | 51.17 | — |
| latency_ms mean / p50 / p95 | 11.54 / 7.21 / 29.01 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 83.17 / 109.93 / 239.56 | — |
| total_ms mean / p50 / p95 | 111.62 / 121.95 / 285.73 | — |
| overhead_ms mean / p50 / p95 | 95.12 / 114.14 / 265.06 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| hot_provisional | 9 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=3, file-hash-drift: Target file hash sha256:5704b09eab34a329ba3642a2273dc8d26e5f156fb5c9cc2cfcf0984817e915ef does not match proposal fileBeforeHash sha256:9a24d95d62d9e828b4b1638c70b4ac5c35361617cfefdc6b6a41bbd1ce4d6708.=2, canonical target base hash is stale: src/store.ts=2, file-hash-drift: Target file hash sha256:9b32ba2d6909eccca98dc460deb1fdf338893cab8581606443828991984318f0 does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=2, file-hash-drift: Target file hash sha256:3027d69e788dda1f2c28f8483fe82e4400c6d61d9e23e65be9ea91f58cdc2e72 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:2eecab2ea3829bf2bf59009cbe6c70c2a6936e0714d5fba8fb19e56254c1ea53 does not match proposal fileBeforeHash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9.=1, atm_compose+cas_rebase=1, atm_compose=1, file-hash-drift: Target file hash sha256:8cf8299986dd3a73b19f8b56e689502fde33e42f189f9abe2289ac5930007a48 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:5704b09eab34a329ba3642a2273dc8d26e5f156fb5c9cc2cfcf0984817e915ef does not match proposal fileBeforeHash sha256:8af1586f371c73d35dd9044838250c6039654059e2a1a6fa173519f9aa07eb7d.=1, file-hash-drift: Target file hash sha256:8cf8299986dd3a73b19f8b56e689502fde33e42f189f9abe2289ac5930007a48 does not match proposal fileBeforeHash sha256:3027d69e788dda1f2c28f8483fe82e4400c6d61d9e23e65be9ea91f58cdc2e72.=1, file-hash-drift: Target file hash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:5cd6085fbd981f389119f6dce48b05c364399188eff406a4dde67816b13b3acc does not match proposal fileBeforeHash sha256:9b32ba2d6909eccca98dc460deb1fdf338893cab8581606443828991984318f0.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3, hot_provisional=1 |
| no_conflict | hot_provisional=4, cold_queue=2, composer_merge=1 |
| hot_provisional | cold_queue=12, composer_merge=9, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157566, duration_ms=706.18
