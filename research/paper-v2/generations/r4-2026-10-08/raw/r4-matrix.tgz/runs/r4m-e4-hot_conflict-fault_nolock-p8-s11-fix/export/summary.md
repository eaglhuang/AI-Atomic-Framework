# atm-bench export — r4m-e4-hot_conflict-fault_nolock-p8-s11-fix

- run_id: `r4m-e4-hot_conflict-fault_nolock-p8-s11-fix` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 158314 | — |
| duration_ms | 705.08 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=16 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 180% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 8 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 704.59 | — |
| throughput intents/s | 51.09 | — |
| goodput oracle-pass/s | 51.09 | — |
| latency_ms mean / p50 / p95 | 14.92 / 11.04 / 44.65 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 82.36 / 23.24 / 268.4 | — |
| total_ms mean / p50 / p95 | 116.1 / 50.75 / 329.06 | — |
| overhead_ms mean / p50 / p95 | 97.68 / 33.04 / 301.27 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |
| cold_queue | 17 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=3, file-hash-drift: Target file hash sha256:a12d66f1d41581011b6c4665f285b3da0edfbf1981fbac613f6efe938bf36e8e does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=2, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:9022810c2584ddddefa9ccf58eb9025508a8d8c44b4e8652f6e1f9a15edd2344 does not match proposal fileBeforeHash sha256:a12d66f1d41581011b6c4665f285b3da0edfbf1981fbac613f6efe938bf36e8e.=1, file-hash-drift: Target file hash sha256:ffac71ae114ca00e0b7fe5d7041a244b912ddc312f454a7db70f785a7b527e78 does not match proposal fileBeforeHash sha256:c37a29f91041a88409f1730bea1ea23cd443cb9686ec2f6050e79d4608a56fff.=1, file-hash-drift: Target file hash sha256:c37a29f91041a88409f1730bea1ea23cd443cb9686ec2f6050e79d4608a56fff does not match proposal fileBeforeHash sha256:0e361b9f97c59a727e8280b63ef09bee72f68f9bf6dce05804177f03a4b77112.=1, file-hash-drift: Target file hash sha256:bc67d8fd34d7c75c5f5a3920290d6352b9698d4f69eb56e8a749c2f1c87fa4d8 does not match proposal fileBeforeHash sha256:153e43b61904f217ed75eaf11e24e4ccb2dd418bb15432c9fa1e4370abe79969.=1, atm_compose=1, file-hash-drift: Target file hash sha256:3785d6f8f5bdd1793bc914d15d441780cd9bb7155bfe6ce2076ddbb0b102ad50 does not match proposal fileBeforeHash sha256:0c161b49b4f4f09c1ded3d3a41e3c4bc663855f44e24255537f68e7c39910acd.=1, file-hash-drift: Target file hash sha256:0e361b9f97c59a727e8280b63ef09bee72f68f9bf6dce05804177f03a4b77112 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:17c05f0e3c26f09bd697649fd920dcfaee61c75ce0dcde7cab110f87e772b767 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:af2a3f003abbb5abc94100527d6d4e2f1d78b590000efc0b42c55f804d2155d6 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:d275fa8c4e5481df76b4e7354623573eae58bf4615c9563431d11f0b0e9a21ff does not match proposal fileBeforeHash sha256:21793508a73f0b68cfc67780ec7ca23385fc0a63888fac036f9cbecb4467cced.=1, file-hash-drift: Target file hash sha256:17c05f0e3c26f09bd697649fd920dcfaee61c75ce0dcde7cab110f87e772b767 does not match proposal fileBeforeHash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171.=1, canonical target base hash is stale: src/store.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=14, composer_merge=8, hot_provisional=6 |
| no_conflict | cold_queue=3, hot_provisional=1, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=158314, duration_ms=705.08
