# atm-bench export — r4m-e4-hot_conflict-fault_naive-p8-s17-fix

- run_id: `r4m-e4-hot_conflict-fault_naive-p8-s17-fix` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 147577 | — |
| duration_ms | 669.06 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=20, blocked=14 | — |
| committed | 20 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 170% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 9 | — |
| CAS rebase on apply | 5 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 668.05 | — |
| throughput intents/s | 50.89 | — |
| goodput oracle-pass/s | 50.89 | — |
| latency_ms mean / p50 / p95 | 10.08 / 6.63 / 28.13 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 76.57 / 19.2 / 265.79 | — |
| total_ms mean / p50 / p95 | 101.87 / 43.91 / 313.78 | — |
| overhead_ms mean / p50 / p95 | 87.11 / 26.78 / 298.48 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 13 | 0 | 0 |
| hot_provisional | 12 | 0 | 0 |
| composer_merge | 9 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=9, atm_provisional_write_lease=9, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=3, file-hash-drift: Target file hash sha256:563c9d4807ebef9773a32e020a058ef36c9a009fe4bbc15c9927dbc7d86a63ca does not match proposal fileBeforeHash sha256:bd20bfdc70c2939ec0f94d906771c229313f29a170a55099883a531cd8a7ea3a.=2, atm_compose=2, canonical target base hash is stale: src/config.ts=1, file-hash-drift: Target file hash sha256:563c9d4807ebef9773a32e020a058ef36c9a009fe4bbc15c9927dbc7d86a63ca does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:404e69b20644e316513626754956fcad14ede3d24d519c5517e0aa3b1f4c265e does not match proposal fileBeforeHash sha256:f3b6a417814848bdd538559f4a223fb9aabf965787a9790ccaceed68c483ef0f.=1, file-hash-drift: Target file hash sha256:404e69b20644e316513626754956fcad14ede3d24d519c5517e0aa3b1f4c265e does not match proposal fileBeforeHash sha256:563c9d4807ebef9773a32e020a058ef36c9a009fe4bbc15c9927dbc7d86a63ca.=1, file-hash-drift: Target file hash sha256:89bdcdc145896444b5fc544cca5da9f955bc9f33ad296cf0895521b70ccdf293 does not match proposal fileBeforeHash sha256:f751778ced79211651686df0f6f8937a46cb3283ff4f11e1872b541a62f711f7.=1, compose-context-mismatch: proposal 'prop-s17-t003-i3' context mismatch at base line 9: expected "// </region:users>", found "// atm-edit s17-t003-i0 by cursor:mock-s0" [proposals: prop-s17-t003-i3]=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:7169e94f2e66123f33afe2a01493bb6a2c6b33abe716b266173d3f6f4f140913 does not match proposal fileBeforeHash sha256:0c053a565ebe7f3262e0c1db608a79073d25d1abdba73d71d74e61a1493210eb.=1, file-hash-drift: Target file hash sha256:0c053a565ebe7f3262e0c1db608a79073d25d1abdba73d71d74e61a1493210eb does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=10, hot_provisional=10, composer_merge=6 |
| no_conflict | hot_provisional=2, cold_queue=1, composer_merge=1 |
| composer_cowrite | cold_queue=2, composer_merge=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=147577, duration_ms=669.06
