# atm-bench export — r4m-e4-hot_conflict-steward-p4-s17-fix

- run_id: `r4m-e4-hot_conflict-steward-p4-s17-fix` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 151604 | — |
| duration_ms | 587.05 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=17, blocked=17 | — |
| committed | 17 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 200% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 17 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 12 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 585.76 | — |
| throughput intents/s | 58.04 | — |
| goodput oracle-pass/s | 58.04 | — |
| latency_ms mean / p50 / p95 | 8.75 / 5.73 / 30.42 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 52.86 / 15.58 / 144.52 | — |
| total_ms mean / p50 / p95 | 90.61 / 45.06 / 219.15 | — |
| overhead_ms mean / p50 / p95 | 62.25 / 24 / 163.14 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 17 | 0 | 0 |
| composer_merge | 12 | 0 | 0 |
| hot_provisional | 5 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=5, file-hash-drift: Target file hash sha256:8b97e60e626b4ea1ff8e6e39babcf458761e971a7ed1cbf00610320d94c7aa23 does not match proposal fileBeforeHash sha256:94cdad271f84d86408059bc10d9b947bae922e7ce822e40fd31b2ccebf03f546.=3, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 21 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 20 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, file-hash-drift: Target file hash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:f1b1539c7d070129de4bf318c3414a6836c9058fa2ec0dd9e78d16c7569eee29 does not match proposal fileBeforeHash sha256:97c243dc7053b942f2e727f1f649f633a26692e99d6d2c7847a2f71a2ad4b2ff.=2, file-hash-drift: Target file hash sha256:5025857c445f455bbfd0b0ba2038c3bf4964321bdc44544e530e72cf64893935 does not match proposal fileBeforeHash sha256:56c43e5a18e2b4ee77d64f473b8b4fdb9b1ecb712bec63883e0f87c2c1b6caef.=2, file-hash-drift: Target file hash sha256:1e27e4cb2cbabb564ed95b59d66eca5066a4342c1e6add5988a4b713972371af does not match proposal fileBeforeHash sha256:6737b84ce10f5bde5ed5a1a09a4fafb43f1514fb11206ab627064b396d6ad8b8.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:29f2f576b96ac26690e907cd10e2017f39e4504e968473d6bf20428747136f5a does not match proposal fileBeforeHash sha256:a3c5e76771ed28597201300d29a87dca46019f44a9e78a4e66736b296f40fb7f.=1, atm_compose=1, file-hash-drift: Target file hash sha256:679165a3c4971d56f7dd7da22f5fa7fa25c99c9502d55e71375921855abe0fce does not match proposal fileBeforeHash sha256:6737b84ce10f5bde5ed5a1a09a4fafb43f1514fb11206ab627064b396d6ad8b8.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, composer_merge=9, hot_provisional=4 |
| no_conflict | cold_queue=2, hot_provisional=1, composer_merge=1 |
| composer_cowrite | composer_merge=2, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=151604, duration_ms=587.05
