# atm-bench export — r4m-e4-hot_conflict-steward-p4-s11-optlock

- run_id: `r4m-e4-hot_conflict-steward-p4-s11-optlock` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-2118bc66/AI-Atomic-Framework-2118bc66efb3ac3bc0ddaede6a2f7cb18526b030/packages/core)`
- label: REAL ATM steward MP procs=4 cas+steward-lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"on","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157410 | — |
| duration_ms | 662.09 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 21 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 15 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 662.48 | — |
| throughput intents/s | 54.34 | — |
| goodput oracle-pass/s | 54.34 | — |
| latency_ms mean / p50 / p95 | 8.69 / 4.92 / 25.67 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 72.73 / 20.4 / 286.91 | — |
| total_ms mean / p50 / p95 | 114.47 / 49.68 / 358.06 | — |
| overhead_ms mean / p50 / p95 | 82.06 / 26.78 / 309.32 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| cold_queue | 21 | 0 | 0 |
| hot_provisional | 5 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=5, atm_compose=3, steward-final-patch-required: proposals 'prop-s11-t004-i1' and 'prop-s11-t004-i5' both edit region 'flags' of src/config.ts; overlapping region edits stay blocked [proposals: prop-s11-t004-i1, prop-s11-t004-i5]=2, steward-final-patch-required: proposal 'prop-s11-t001-i4' overlaps region 'users', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t001-i4]=2, steward-final-patch-required: proposals 'prop-s11-t002-i2' and 'prop-s11-t003-i5' both edit region 'selectors' of src/store.ts; overlapping region edits stay blocked [proposals: prop-s11-t002-i2, prop-s11-t003-i5]=2, steward-final-patch-required: proposal 'prop-s11-t002-i1' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i1]=1, steward-final-patch-required: proposal 'prop-s11-t003-i1' overlaps region 'selectors', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i1]=1, steward-final-patch-required: proposal 'prop-s11-t000-i2' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i2]=1, steward-final-patch-required: proposal 'prop-s11-t004-i2' overlaps region 'cache', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t004-i2]=1, steward-final-patch-required: proposal 'prop-s11-t003-i4' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i4]=1, steward-final-patch-required: proposal 'prop-s11-t000-i0' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i0]=1, steward-final-patch-required: proposal 'prop-s11-t002-i6' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t002-i6]=1, steward-final-patch-required: proposal 'prop-s11-t003-i6' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i6]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=20, composer_merge=7, hot_provisional=1 |
| no_conflict | hot_provisional=3, composer_merge=1, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157410, duration_ms=662.09
