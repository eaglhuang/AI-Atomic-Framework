# atm-bench export — r4m-e4-hot_conflict-steward-p2-s17-fix

- run_id: `r4m-e4-hot_conflict-steward-p2-s17-fix` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 149608 | — |
| duration_ms | 675.09 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=21, blocked=13 | — |
| committed | 21 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 161.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 10 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 13 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 674.06 | — |
| throughput intents/s | 50.44 | — |
| goodput oracle-pass/s | 50.44 | — |
| latency_ms mean / p50 / p95 | 5.33 / 3.45 / 20.61 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 42.73 / 18.28 / 118.27 | — |
| total_ms mean / p50 / p95 | 89.79 / 47.16 / 182.59 | — |
| overhead_ms mean / p50 / p95 | 48.88 / 23.21 / 140.29 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 10 | 0 | 0 |
| hot_provisional | 10 | 0 | 0 |
| composer_merge | 14 | 0 | 0 |

## Reason codes

- atm: atm_provisional_write_lease=10, atm_serial_queue=5, atm_compose+cas_rebase=5, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 21 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=3, file-hash-drift: Target file hash sha256:cf9c5ce916acf63c7c561c68f62d3287c920adca43e3a75a5bd21c834780d0da does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=3, file-hash-drift: Target file hash sha256:4522f6ec17ae3fbe00dac6d3864a365c2cdf475f050cd8d3a7e7a849e67e1b26 does not match proposal fileBeforeHash sha256:94cdad271f84d86408059bc10d9b947bae922e7ce822e40fd31b2ccebf03f546.=2, steward-final-patch-required: proposals 'prop-s17-t000-i2' and 'prop-s17-t000-i5' change overlapping base line 21 of src/store.ts; a steward-authored final patch is required [proposals: prop-s17-t000-i2, prop-s17-t000-i5]=2, file-hash-drift: Target file hash sha256:956ec302161afff4acac6df6a368e7fdc336e6f1d61845bac006ca62377e8440 does not match proposal fileBeforeHash sha256:56af38d14eb8ad3996aa76de9ab0fa4cb6c7ddb2e5709053d2901c5efd138e9b.=2, atm_compose=1, compose-context-mismatch: proposal 'prop-s17-t000-i6' context mismatch at base line 8: expected "// </region:reducers>", found "// atm-edit s17-t000-i0 by cursor:mock-s0" [proposals: prop-s17-t000-i6]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=10, cold_queue=9, hot_provisional=7 |
| no_conflict | hot_provisional=2, composer_merge=2 |
| composer_cowrite | composer_merge=2, cold_queue=1, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=149608, duration_ms=675.09
