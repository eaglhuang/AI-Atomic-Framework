# atm-bench export — r4m-e4-hot_conflict-fault_naive-p8-s23-old

- run_id: `r4m-e4-hot_conflict-fault_naive-p8-s23-old` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 155661 | — |
| duration_ms | 666.61 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 35 | — |
| lost updates (oracle fail) | 1 | — |
| integration pass rate of committed | 159.1% | — |
| effective success rate of all intents | 97.2% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 14 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 10 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 663.62 | — |
| throughput intents/s | 54.25 | — |
| goodput oracle-pass/s | 52.74 | — |
| latency_ms mean / p50 / p95 | 10.47 / 8.39 / 27.31 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 81.58 / 109.02 / 190.45 | — |
| total_ms mean / p50 / p95 | 109.04 / 126.82 / 233.95 | — |
| overhead_ms mean / p50 / p95 | 92.46 / 112.72 / 214.72 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| hot_provisional | 10 | 0 | 0 |
| cold_queue | 14 | 0 | 0 |
| composer_merge | 12 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=10, atm_provisional_write_lease=7, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:7022b4c9560e0eb7ae2f9d6c7fc8bf7cc58862376863d4539bf149c4155c0293 does not match proposal fileBeforeHash sha256:5d904b103b6f94221f9afb2caeae8d0f6995cb078b8193914a5e3f3174d75086.=2, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, atm_compose=2, file-hash-drift: Target file hash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, atm_provisional_write_lease+cas_rebase=1, canonical target base hash is stale: src/routes.ts=1, canonical target base hash is stale: src/config.ts=1, file-hash-drift: Target file hash sha256:f40ce70811977aa6a4d5ec42f5afcfa867da7aa8bc5e158c56014813305da105 does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:b4e84931ca2641b3d71d6ff7dd1a8892e31ff895e71efcbe31c7907096a62210 does not match proposal fileBeforeHash sha256:f65daef97e7d5c1efeea55041730bc6db9c22a283d8cbdec566365b1cf22fe43.=1, file-hash-drift: Target file hash sha256:a7133ba230392804b60a284a463e6831a1958a04ee1867e33ebc4b13f96f66af does not match proposal fileBeforeHash sha256:8b276034a1c7158c9bbc52f809982a3b3824a726f105c01a45299d2e8c9c2448.=1, file-hash-drift: Target file hash sha256:11b888fd412013d83e9c55f26b08a0719a655b7a0a26bd8593234732a9d20f2d does not match proposal fileBeforeHash sha256:a8574af5055dd0a7ab9adcfb9f40c3ea8ecf105b5587afe0e5fad34e5944ea70.=1, file-hash-drift: Target file hash sha256:12495e40c41a1af215844fcdf62df557948177f8a1908cd91b8da7ed07db3bb8 does not match proposal fileBeforeHash sha256:ef66bd5d28746853810dbbed740f1dd4ab0f22e957a8f45fef9d97ab5dbb1926.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:ef66bd5d28746853810dbbed740f1dd4ab0f22e957a8f45fef9d97ab5dbb1926 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1, cold_queue=1 |
| no_conflict | hot_provisional=4, cold_queue=2, composer_merge=1 |
| hot_provisional | cold_queue=11, composer_merge=9, hot_provisional=5 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=155661, duration_ms=666.61
