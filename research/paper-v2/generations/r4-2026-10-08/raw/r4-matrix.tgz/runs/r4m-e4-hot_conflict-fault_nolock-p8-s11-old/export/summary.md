# atm-bench export — r4m-e4-hot_conflict-fault_nolock-p8-s11-old

- run_id: `r4m-e4-hot_conflict-fault_nolock-p8-s11-old` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156278 | — |
| duration_ms | 638.27 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 163.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 20 | — |
| composer co-writes | 10 | — |
| CAS rebase on apply | 9 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 638.24 | — |
| throughput intents/s | 56.41 | — |
| goodput oracle-pass/s | 56.41 | — |
| latency_ms mean / p50 / p95 | 16.1 / 12.46 / 42.98 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 74.31 / 20.09 / 236.8 | — |
| total_ms mean / p50 / p95 | 109.04 / 63.37 / 271.17 | — |
| overhead_ms mean / p50 / p95 | 90.85 / 44.19 / 257.97 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 10 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |
| cold_queue | 20 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=16, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:c113d19a938ec64551e3f35829ad9bcd21732d307494be805d472003b47eff43 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=4, file-hash-drift: Target file hash sha256:ec1d1f82b3515b0a835b694f780c2d9caa3c925fe2a2df94c9f4e8135dc3e4f5 does not match proposal fileBeforeHash sha256:4fae92729d83cb33d57d463921b7e95770b875ec060fe376b13019e29bb33fd1.=2, file-hash-drift: Target file hash sha256:09523fc61510d9192b45015ae58e0e2d3a590bd6b2048a00eefb250f7120d9fb does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:9200a17bdee84d58915f9c377e8da5eae66d918dd01d129c2bf381717cc66619 does not match proposal fileBeforeHash sha256:17a41670cdcd0d8f0a5694f030d312b2d0f9c81c9fabd96feae790042ea20f79.=1, file-hash-drift: Target file hash sha256:7a370d812ef11d022dd2b6ad44301b5da9d711c30a7a25a871a3590817b293a4 does not match proposal fileBeforeHash sha256:b96f84c9044106184c45764ba3686912ccfa958ad6209ab7eff84a718ef05952.=1, file-hash-drift: Target file hash sha256:b96f84c9044106184c45764ba3686912ccfa958ad6209ab7eff84a718ef05952 does not match proposal fileBeforeHash sha256:21793508a73f0b68cfc67780ec7ca23385fc0a63888fac036f9cbecb4467cced.=1, canonical target base hash is stale: src/config.ts=1, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:7b6b9fe598cf77ae8811df4cf56213f15100ae2131b168f3af46618bd696c485 does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=1, file-hash-drift: Target file hash sha256:7a370d812ef11d022dd2b6ad44301b5da9d711c30a7a25a871a3590817b293a4 does not match proposal fileBeforeHash sha256:01476000d7fccf69ab33b36c70566f5b71680ea0bacaed46a4ead0980e349fbe.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=2, hot_provisional=1 |
| hot_provisional | cold_queue=18, composer_merge=7, hot_provisional=3 |
| no_conflict | hot_provisional=2, cold_queue=2, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156278, duration_ms=638.27
