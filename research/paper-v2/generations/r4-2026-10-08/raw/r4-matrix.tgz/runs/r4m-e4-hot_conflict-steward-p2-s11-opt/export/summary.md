# atm-bench export — r4m-e4-hot_conflict-steward-p2-s11-opt

- run_id: `r4m-e4-hot_conflict-steward-p2-s11-opt` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-2118bc66/AI-Atomic-Framework-2118bc66efb3ac3bc0ddaede6a2f7cb18526b030/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 154894 | — |
| duration_ms | 507.21 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=28, blocked=8 | — |
| committed | 28 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 128.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 22 | — |
| composer co-writes | 8 | — |
| CAS rebase on apply | 23 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 507.76 | — |
| throughput intents/s | 70.9 | — |
| goodput oracle-pass/s | 70.9 | — |
| latency_ms mean / p50 / p95 | 5.4 / 4.08 / 15.63 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 26.69 / 15.94 / 134.03 | — |
| total_ms mean / p50 / p95 | 81.57 / 53.73 / 222.73 | — |
| overhead_ms mean / p50 / p95 | 32.94 / 21.34 / 151.1 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 8 | 0 | 0 |
| cold_queue | 22 | 0 | 0 |
| hot_provisional | 6 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=18, atm_provisional_write_lease=5, steward-final-patch-required: proposals 'prop-s11-t001-i3' and 'prop-s11-t001-i5' both edit region 'orders' of src/routes.ts; overlapping region edits stay blocked [proposals: prop-s11-t001-i3, prop-s11-t001-i5]=4, steward-final-patch-required: proposal 'prop-s11-t003-i6' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i6]=2, atm_compose+cas_rebase=2, atm_compose=2, steward-final-patch-required: proposal 'prop-s11-t000-i2' overlaps region 'orders', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t000-i2]=1, steward-final-patch-required: proposal 'prop-s11-t003-i4' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s11-t003-i4]=1, atm_provisional_write_lease+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=19, composer_merge=5, hot_provisional=4 |
| no_conflict | cold_queue=3, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=154894, duration_ms=507.21
