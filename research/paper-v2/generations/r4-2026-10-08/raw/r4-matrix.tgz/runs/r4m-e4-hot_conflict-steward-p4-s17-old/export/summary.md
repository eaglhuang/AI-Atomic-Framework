# atm-bench export — r4m-e4-hot_conflict-steward-p4-s17-old

- run_id: `r4m-e4-hot_conflict-steward-p4-s17-old` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=4 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 149648 | — |
| duration_ms | 642.24 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=19, blocked=15 | — |
| committed | 19 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 178.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 13 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 9 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 640.66 | — |
| throughput intents/s | 53.07 | — |
| goodput oracle-pass/s | 53.07 | — |
| latency_ms mean / p50 / p95 | 8.74 / 7.36 / 22.15 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 58.16 / 16.48 / 122.14 | — |
| total_ms mean / p50 / p95 | 96.31 / 49.05 / 244.72 | — |
| overhead_ms mean / p50 / p95 | 67.33 / 26.14 / 145.91 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| cold_queue | 13 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=10, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:2593170bee40a85ecc1d731e698853ccce7b2d739060f2795ee4e4187063ef61 does not match proposal fileBeforeHash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55.=2, steward-final-patch-required: proposals 'prop-s17-t002-i1' and 'prop-s17-t002-i4' change overlapping base line 20 of src/config.ts; a steward-authored final patch is required [proposals: prop-s17-t002-i1, prop-s17-t002-i4]=2, steward-final-patch-required: proposals 'prop-s17-t003-i1' and 'prop-s17-t003-i4' change overlapping base line 18 of src/routes.ts; a steward-authored final patch is required [proposals: prop-s17-t003-i1, prop-s17-t003-i4]=2, file-hash-drift: Target file hash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=2, file-hash-drift: Target file hash sha256:802016c65b9a02ce3d7f7388f6f1889f51a3e39b601bd8ead26d496470decb05 does not match proposal fileBeforeHash sha256:2593170bee40a85ecc1d731e698853ccce7b2d739060f2795ee4e4187063ef61.=1, atm_compose=1, file-hash-drift: Target file hash sha256:3ac311060430f9cd1e2ef9a29391b20f883ffd560323b3d890d308f5b69cef64 does not match proposal fileBeforeHash sha256:85f71f170adc2a22338b61096ad4e2d77bbe237df8da373040bf2cf2ba07a0ad.=1, file-hash-drift: Target file hash sha256:07ed87502b74c3d1970ab654d3a040abf45a925ce3fd8029ec48181ed8016f2a does not match proposal fileBeforeHash sha256:5d4a17dd2492ed3246c8d8f7cde7be46f3bbe594fa45a97d9e848fa24ff0a56f.=1, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:1466db735a2c933611c7f055a9f2860be1a84c3864bda9b5eabc450a2ed2cf3c does not match proposal fileBeforeHash sha256:cc89cd2570b88ad52813c775d8637dfad448213d1dd07209bd63f7948c3eefcd.=1, canonical target base hash is stale: src/store.ts=1, file-hash-drift: Target file hash sha256:ee5a72236e1c82a760aafc5fedfec0fadae0f6ed58f7ba81fa1eccdc052119f8 does not match proposal fileBeforeHash sha256:1466db735a2c933611c7f055a9f2860be1a84c3864bda9b5eabc450a2ed2cf3c.=1, atm_compose+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=13, composer_merge=9, hot_provisional=4 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, hot_provisional=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=149648, duration_ms=642.24
