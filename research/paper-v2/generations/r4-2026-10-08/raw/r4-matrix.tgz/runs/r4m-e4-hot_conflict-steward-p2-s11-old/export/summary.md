# atm-bench export — r4m-e4-hot_conflict-steward-p2-s11-old

- run_id: `r4m-e4-hot_conflict-steward-p2-s11-old` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: REAL ATM steward MP procs=2 cas+lock
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 157576 | — |
| duration_ms | 579.16 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=23, blocked=13 | — |
| committed | 23 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 156.5% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 13 | — |
| CAS rebase on apply | 16 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 579.19 | — |
| throughput intents/s | 62.16 | — |
| goodput oracle-pass/s | 62.16 | — |
| latency_ms mean / p50 / p95 | 5.2 / 4.1 / 14.89 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 35.3 / 16.83 / 119.5 | — |
| total_ms mean / p50 / p95 | 85.13 / 50.86 / 167.59 | — |
| overhead_ms mean / p50 / p95 | 41.4 / 23.3 / 132.94 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 13 | 0 | 0 |
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:3b197c6bdc30950dacc14d9621c796153fedaf4363f4d12ad3e2ddd9d221e760 does not match proposal fileBeforeHash sha256:3038289f914a3090be47e68fff94401c7058175f1823523534afa67cd27a4755.=3, atm_compose=3, steward-final-patch-required: proposals 'prop-s11-t004-i0' and 'prop-s11-t004-i2' change overlapping base line 22 of src/config.ts; a steward-authored final patch is required [proposals: prop-s11-t004-i0, prop-s11-t004-i2]=3, atm_compose+cas_rebase=2, file-hash-drift: Target file hash sha256:91d5efd6a6a57567bfae8f8f522b635863f66efc41229ac9f7fce068e724c63e does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:d99e5e85da084aeae432d3559da480044e5df796d88bcb0ab29b8a2541f40196 does not match proposal fileBeforeHash sha256:4ef39cea069493ba1ef6741e3389a7fa58aaa42fdacf021ede43d076e90f4171.=2, file-hash-drift: Target file hash sha256:9b53619d1f56ec0d53c7565f6bd6a64db917f8f63b78962fd09c1d9998c52191 does not match proposal fileBeforeHash sha256:72158b0b477ef71ac1bab8a81ee412edb35ce271d65d994fe22303080a804c47.=2, compose-context-mismatch: proposal 'prop-s11-t000-i3' hunk at old line 14 starts past the end of a 1-line base [proposals: prop-s11-t000-i3]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | composer_merge=3 |
| hot_provisional | cold_queue=13, composer_merge=9, hot_provisional=6 |
| no_conflict | hot_provisional=2, cold_queue=2, composer_merge=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=157576, duration_ms=579.16
