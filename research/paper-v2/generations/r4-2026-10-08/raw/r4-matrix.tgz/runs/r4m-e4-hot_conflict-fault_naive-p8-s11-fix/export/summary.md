# atm-bench export — r4m-e4-hot_conflict-fault_naive-p8-s11-fix

- run_id: `r4m-e4-hot_conflict-fault_naive-p8-s11-fix` · scenario_seed: **11** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-bea35380/AI-Atomic-Framework-bea35380d7f381f998c9930fa95f01b999c7f208/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`9a24c4620e1f6cc7…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 31 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 159875 | — |
| duration_ms | 590.79 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | blocked=19, commit=17 | — |
| committed | 17 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 211.8% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 11 | — |
| CAS rebase on apply | 9 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 591.21 | — |
| throughput intents/s | 60.89 | — |
| goodput oracle-pass/s | 60.89 | — |
| latency_ms mean / p50 / p95 | 10.45 / 8.1 / 26.41 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 77.45 / 20.66 / 188.64 | — |
| total_ms mean / p50 / p95 | 106.63 / 64.18 / 226.95 | — |
| overhead_ms mean / p50 / p95 | 88.29 / 38.98 / 213.44 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| hot_provisional | 9 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| composer_merge | 11 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=10, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=5, file-hash-drift: Target file hash sha256:284bacf38de8f67d1f369f6f176fcd6654b97899674b46e586154fcd9df4e923 does not match proposal fileBeforeHash sha256:e5b06945aef9a2515ea95a9aec82ad8d1da0a8c3a938fc41b3b604d3e9b4535a.=3, file-hash-drift: Target file hash sha256:924c895489c926a23cbe3c4b6fa9df321d1b4883d362c58f381c282a354d06f7 does not match proposal fileBeforeHash sha256:aa0deaf178149f0fea0bf27a668cf9100c2013a096d8c11081f2120a8763dc79.=2, file-hash-drift: Target file hash sha256:9600acb5207e6e6e9da0eed56199938473ab5e537f605e16b0157c092d3d7f7d does not match proposal fileBeforeHash sha256:5476fa0dd18c350d7d0aa4fa2caa9ba832cc774903bf5d4888ea2b388b03da65.=2, file-hash-drift: Target file hash sha256:7274e5b0f09469356a6a401701edf99a8979a59878e836ddd13ffc2b00c85926 does not match proposal fileBeforeHash sha256:9600acb5207e6e6e9da0eed56199938473ab5e537f605e16b0157c092d3d7f7d.=1, file-hash-drift: Target file hash sha256:36cf26566bda6bec0cc323b1d48fa3906f9a90c86a320d7766caae9999cda282 does not match proposal fileBeforeHash sha256:e5b06945aef9a2515ea95a9aec82ad8d1da0a8c3a938fc41b3b604d3e9b4535a.=1, file-hash-drift: Target file hash sha256:284bacf38de8f67d1f369f6f176fcd6654b97899674b46e586154fcd9df4e923 does not match proposal fileBeforeHash sha256:f3e410fe2860bb17e74d72d00adf22d6577ab17f40986efa7fc20b43594c597d.=1, file-hash-drift: Target file hash sha256:cfc01f40f608e9bd2cd162d66f294d03c53d341e7e8a850eaf77d4aef3f772e8 does not match proposal fileBeforeHash sha256:560817ba0dc526c1bc33c1419c1474e90422d9691bb669c39ea1fdbb9707d87a.=1, file-hash-drift: Target file hash sha256:924c895489c926a23cbe3c4b6fa9df321d1b4883d362c58f381c282a354d06f7 does not match proposal fileBeforeHash sha256:8be5c3ea9042d29872b2feffc39be79fee6ea77856d46f3242d3d39ccbc3fde4.=1, file-hash-drift: Target file hash sha256:e5b06945aef9a2515ea95a9aec82ad8d1da0a8c3a938fc41b3b604d3e9b4535a does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, canonical target base hash is stale: src/config.ts=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | hot_provisional=2, composer_merge=1 |
| hot_provisional | cold_queue=14, composer_merge=10, hot_provisional=4 |
| no_conflict | hot_provisional=3, cold_queue=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=159875, duration_ms=590.79
