# atm-bench export — r4m-e4-hot_conflict-fault_naive-p8-s17-old

- run_id: `r4m-e4-hot_conflict-fault_naive-p8-s17-old` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: naive registry sync (expects zombie leases)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"naive","mp_apply_lock":"on","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 150234 | — |
| duration_ms | 850.08 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=18, blocked=16 | — |
| committed | 18 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 188.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 10 | — |
| composer co-writes | 16 | — |
| CAS rebase on apply | 5 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 848.82 | — |
| throughput intents/s | 40.06 | — |
| goodput oracle-pass/s | 40.06 | — |
| latency_ms mean / p50 / p95 | 9.68 / 6.59 / 25.36 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 95.08 / 111.42 / 242.79 | — |
| total_ms mean / p50 / p95 | 120.23 / 134.85 / 285.54 | — |
| overhead_ms mean / p50 / p95 | 105.23 / 117.73 / 271.97 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 10 | 0 | 0 |
| composer_merge | 16 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=7, atm_provisional_write_lease=6, file-hash-drift: Target file hash sha256:d1dcd3c006aed85c3212c918fa8151f2ad03e9772f8c311d56c6dd17b761a5a8 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=5, atm_compose=4, file-hash-drift: Target file hash sha256:83d246f0d84d86e617ae5dd15517ad51b3cb4005da587bc9ecf3114a3e666a16 does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=3, file-hash-drift: Target file hash sha256:7f6627da1d4f97e3f1dc4555b57b1922cda0f50c1494735a28b3df566d1984e6 does not match proposal fileBeforeHash sha256:e2eeb486a3a3cf4fd059702bfceef6a6c0b504c2f9c690e950d64cd454aafd42.=2, file-hash-drift: Target file hash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, canonical target base hash is stale: src/store.ts=1, atm_compose+cas_rebase=1, file-hash-drift: Target file hash sha256:04e3c7fdebd4a59b649f5267e3ad8510b971d46cb66e42e38f3446de20bd2d85 does not match proposal fileBeforeHash sha256:ededfead6062097b9b9d313ebe9c271af71006b3422ae9f8203c555d91336b5a.=1, file-hash-drift: Target file hash sha256:7f6627da1d4f97e3f1dc4555b57b1922cda0f50c1494735a28b3df566d1984e6 does not match proposal fileBeforeHash sha256:f1b1539c7d070129de4bf318c3414a6836c9058fa2ec0dd9e78d16c7569eee29.=1, file-hash-drift: Target file hash sha256:e9f6b70fcda241e16f5a840b26a78b6ab51e61576e1e9767dfcc7522b5eb22be does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:e9f6b70fcda241e16f5a840b26a78b6ab51e61576e1e9767dfcc7522b5eb22be does not match proposal fileBeforeHash sha256:382a7385d3119e3c58623e866865d5f5c7a0bf47b76d1348fecae5db3b34a681.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=12, cold_queue=9, hot_provisional=5 |
| no_conflict | hot_provisional=3, composer_merge=1 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=150234, duration_ms=850.08
