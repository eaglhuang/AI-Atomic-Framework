# atm-bench export — r4m-e4-hot_conflict-fault_nolock-p8-s23-old

- run_id: `r4m-e4-hot_conflict-fault_nolock-p8-s23-old` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 156856 | — |
| duration_ms | 691.38 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=22, blocked=14 | — |
| committed | 22 | — |
| oracle pass (marker survives) | 35 | — |
| lost updates (oracle fail) | 1 | — |
| integration pass rate of committed | 159.1% | — |
| effective success rate of all intents | 97.2% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 9 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 687.95 | — |
| throughput intents/s | 52.33 | — |
| goodput oracle-pass/s | 50.88 | — |
| latency_ms mean / p50 / p95 | 13.9 / 6.89 / 38.86 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 83.5 / 19.69 / 277.26 | — |
| total_ms mean / p50 / p95 | 114.54 / 68.51 / 327.98 | — |
| overhead_ms mean / p50 / p95 | 97.84 / 52.81 / 306.78 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| hot_provisional | 8 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| composer_merge | 12 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=12, atm_provisional_write_lease=8, file-hash-drift: Target file hash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=2, file-hash-drift: Target file hash sha256:a0d5d90797726eaa405c718dbcd98a480ba2c30c3cd7202c7962399b92d0dbe1 does not match proposal fileBeforeHash sha256:283041852eda2182db9bd4647bb72b29ea1198ca2f0a723ba3438fd7fc6b82bc.=2, atm_compose=2, file-hash-drift: Target file hash sha256:92fc593eb20be6649cdf99b5ffa995d0320c30ed682145e6bbe95a5fa91f2bd2 does not match proposal fileBeforeHash sha256:e6e6ab5150e6781904154d4d55910b6ae060878a8a8e2deec2aabe28446ae6f1.=1, file-hash-drift: Target file hash sha256:f21aaa271cec26822c54b3662668d743d6576434d937d75b9c9359bd0aa7d787 does not match proposal fileBeforeHash sha256:c0b8020e872b5d15f9003e2afefa59c73d0eca3ad553bec9e667de7785b8811c.=1, file-hash-drift: Target file hash sha256:1db7031131dc657eb17aeb3aade3f78aa0f16e6df5bacee542f79029608aafda does not match proposal fileBeforeHash sha256:e337c939cdd2755ecaa56dc7c00cd3ef1a877e82fdd28659e5d2d56a6bbab0e5.=1, canonical target base hash is stale: src/routes.ts=1, file-hash-drift: Target file hash sha256:283041852eda2182db9bd4647bb72b29ea1198ca2f0a723ba3438fd7fc6b82bc does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=1, file-hash-drift: Target file hash sha256:7227ace878abe970f26633e200843eaf4af75f376c5dc67fca928845c9c27dae does not match proposal fileBeforeHash sha256:92fc593eb20be6649cdf99b5ffa995d0320c30ed682145e6bbe95a5fa91f2bd2.=1, file-hash-drift: Target file hash sha256:15667b1ac400938f80a204c565ed315e283ff5ae2426ccdda3f53536a138f00c does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=1, file-hash-drift: Target file hash sha256:bcce3a7ef7e528093c240bb0865b56175058f697b3bbe97431f7fb9eea95149c does not match proposal fileBeforeHash sha256:f21aaa271cec26822c54b3662668d743d6576434d937d75b9c9359bd0aa7d787.=1, file-hash-drift: Target file hash sha256:8d2236b68a047220672203d3ff5d92fde27cffa18f094973b96a18939a8baec9 does not match proposal fileBeforeHash sha256:f56ab5a437b444c35b8d9a4e4403d9b3386ba893628b304ab9a7e8c13cd569b1.=1, file-hash-drift: Target file hash sha256:a47f9095838e7dbb6798d65a95094f9e98afda38720b3fed663a24938f197c2d does not match proposal fileBeforeHash sha256:73f5e3af4ca55f63b9822aa0ff044508de673b5a16363497c142666e0136fb19.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | hot_provisional=2, composer_merge=2 |
| no_conflict | hot_provisional=3, cold_queue=3, composer_merge=1 |
| hot_provisional | cold_queue=13, composer_merge=9, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=156856, duration_ms=691.38
