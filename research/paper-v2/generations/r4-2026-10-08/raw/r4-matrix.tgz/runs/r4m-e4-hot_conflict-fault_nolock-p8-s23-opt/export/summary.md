# atm-bench export — r4m-e4-hot_conflict-fault_nolock-p8-s23-opt

- run_id: `r4m-e4-hot_conflict-fault_nolock-p8-s23-opt` · scenario_seed: **23** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-2118bc66/AI-Atomic-Framework-2118bc66efb3ac3bc0ddaede6a2f7cb18526b030/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`cf73fb615dd39a9f…`)
- alignment: 0 both / atm_only=36 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 36 | — |
| contended intents | 29 | — |
| events_total | 108 | — |
| event types | submit=36, decision=36, oracle=36 | — |
| bytes (JSONL) | 152910 | — |
| duration_ms | 764.97 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=28, blocked=8 | — |
| committed | 28 | — |
| oracle pass (marker survives) | 36 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 128.6% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 16 | — |
| composer co-writes | 14 | — |
| CAS rebase on apply | 10 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 762.32 | — |
| throughput intents/s | 47.22 | — |
| goodput oracle-pass/s | 47.22 | — |
| latency_ms mean / p50 / p95 | 12.84 / 9.52 / 30.6 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 88.55 / 110.01 / 256.76 | — |
| total_ms mean / p50 / p95 | 118.17 / 128.43 / 297.88 | — |
| overhead_ms mean / p50 / p95 | 101.84 / 117.43 / 276.85 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| hot_provisional | 6 | 0 | 0 |
| cold_queue | 16 | 0 | 0 |
| composer_merge | 14 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=14, atm_provisional_write_lease=6, atm_compose=5, atm_compose+cas_rebase=3, steward-final-patch-required: proposal 'prop-s23-t001-i4' overlaps region 'actions', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t001-i4]=1, steward-final-patch-required: proposal 'prop-s23-t004-i4' overlaps region 'admin', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t004-i4]=1, steward-final-patch-required: proposal 'prop-s23-t002-i5' overlaps region 'flags', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t002-i5]=1, steward-final-patch-required: proposal 'prop-s23-t001-i0' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t001-i0]=1, steward-final-patch-required: proposal 'prop-s23-t000-i1' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t000-i1]=1, steward-final-patch-required: proposal 'prop-s23-t001-i3' overlaps region 'reducers', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t001-i3]=1, steward-final-patch-required: proposal 'prop-s23-t000-i4' overlaps region 'db', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t000-i4]=1, steward-final-patch-required: proposal 'prop-s23-t000-i5' overlaps region 'cache', which changed after the proposal was anchored; refusing to overwrite [proposals: prop-s23-t000-i5]=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| composer_cowrite | hot_provisional=2, composer_merge=2 |
| no_conflict | composer_merge=3, hot_provisional=2, cold_queue=2 |
| hot_provisional | cold_queue=14, composer_merge=9, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=108, bytes=152910, duration_ms=764.97
