# atm-bench export — r4m-e4-hot_conflict-fault_nolock-p8-s17-old

- run_id: `r4m-e4-hot_conflict-fault_nolock-p8-s17-old` · scenario_seed: **17** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/atm-main-5692474f/AI-Atomic-Framework-5692474f7db70ab52a7a71c8af4867609e7e4b43/packages/core)`
- label: FAULT: apply-lock off (expects possible lost updates)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":5,"tick_interval_ms":15,"hold_ms_min":8,"hold_ms_max":25,"jitter_ms":6,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"steward","compose_window_ms":100,"occ_max_retries":8,"mp_registry_sync":"cas","mp_apply_lock":"off","mp_steward_apply_lock":"off","arm":"steward"}`
- scenario reproducibility: **false** (`3eec787f301bea01…`)
- alignment: 0 both / atm_only=34 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 5 | — |
| intents (decision events) | 34 | — |
| contended intents | 30 | — |
| events_total | 102 | — |
| event types | submit=34, decision=34, oracle=34 | — |
| bytes (JSONL) | 150541 | — |
| duration_ms | 613.09 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=18, blocked=16 | — |
| committed | 18 | — |
| oracle pass (marker survives) | 34 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 188.9% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 15 | — |
| composer co-writes | 12 | — |
| CAS rebase on apply | 6 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 612.47 | — |
| throughput intents/s | 55.51 | — |
| goodput oracle-pass/s | 55.51 | — |
| latency_ms mean / p50 / p95 | 14.46 / 7.63 / 46.62 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 81.13 / 108.28 / 245.48 | — |
| total_ms mean / p50 / p95 | 110.77 / 122.78 / 273.65 | — |
| overhead_ms mean / p50 / p95 | 95.99 / 113.05 / 264.43 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 12 | 0 | 0 |
| cold_queue | 15 | 0 | 0 |
| hot_provisional | 7 | 0 | 0 |

## Reason codes

- atm: atm_serial_queue=11, atm_provisional_write_lease=7, file-hash-drift: Target file hash sha256:0c053a565ebe7f3262e0c1db608a79073d25d1abdba73d71d74e61a1493210eb does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=3, file-hash-drift: Target file hash sha256:a6574603fc374e3f90ffdea749b2071981c3697bf001c8fdd5cc7f5271dcbb55 does not match proposal fileBeforeHash sha256:3c1ad38dcc9ad560e5ab8a74d71cce056071e7e54b68ffa445dc9e2d0a93c929.=2, file-hash-drift: Target file hash sha256:eb1d7b08a40d66c043fa7147e2009b086a92de719654f54f135adc33b9601888 does not match proposal fileBeforeHash sha256:b7bb09f45cb2044f48c94fc8270b0bbc38887e9103b331f036946bab24549dad.=1, file-hash-drift: Target file hash sha256:628c987be8dfa33e974d0d2b261a044e2d3f0ecedaff9845216a074b48e67ad2 does not match proposal fileBeforeHash sha256:47402b9260ecfe738f57c3be6c4672dbe5a0c99a9897468109c68eabb8c3d29e.=1, file-hash-drift: Target file hash sha256:bd20bfdc70c2939ec0f94d906771c229313f29a170a55099883a531cd8a7ea3a does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:f1b1539c7d070129de4bf318c3414a6836c9058fa2ec0dd9e78d16c7569eee29 does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=1, file-hash-drift: Target file hash sha256:f88bc1dc4857e7a3d571487e1d7c03ffeb1cef7bee92f71667793caca827623e does not match proposal fileBeforeHash sha256:077d918a726ba329a0786b51278219b35187d5f9bae46d174dbb4a28a0654a20.=1, file-hash-drift: Target file hash sha256:eb1d7b08a40d66c043fa7147e2009b086a92de719654f54f135adc33b9601888 does not match proposal fileBeforeHash sha256:bd20bfdc70c2939ec0f94d906771c229313f29a170a55099883a531cd8a7ea3a.=1, file-hash-drift: Target file hash sha256:a0511827a07c3bde379f80fbaa18657f5dfa5f7b143d064e34752c203bc11d70 does not match proposal fileBeforeHash sha256:eb1d7b08a40d66c043fa7147e2009b086a92de719654f54f135adc33b9601888.=1, file-hash-drift: Target file hash sha256:eb1d7b08a40d66c043fa7147e2009b086a92de719654f54f135adc33b9601888 does not match proposal fileBeforeHash sha256:e10716f6c820db035a87512cb2e3e00a65b67e1bccd699474c07f31d5ef194ab.=1, file-hash-drift: Target file hash sha256:47402b9260ecfe738f57c3be6c4672dbe5a0c99a9897468109c68eabb8c3d29e does not match proposal fileBeforeHash sha256:f1b1539c7d070129de4bf318c3414a6836c9058fa2ec0dd9e78d16c7569eee29.=1, file-hash-drift: Target file hash sha256:47402b9260ecfe738f57c3be6c4672dbe5a0c99a9897468109c68eabb8c3d29e does not match proposal fileBeforeHash sha256:d9b0557e7938ca7995a5fc5aa2a1eff93647a1ec5abe1fbde506162bc8a3e2ce.=1, file-hash-drift: Target file hash sha256:64ec15cbd56062fc185188f4679ad1d960300e0e07084d241d0fad366dca83a1 does not match proposal fileBeforeHash sha256:dbc9df69ca4b4a9311575998a1d2ab598e99511e50e1d0e66c8fd871c2e506d1.=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | cold_queue=12, composer_merge=9, hot_provisional=5 |
| no_conflict | hot_provisional=2, cold_queue=2 |
| composer_cowrite | composer_merge=3, cold_queue=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=102, bytes=150541, duration_ms=613.09
