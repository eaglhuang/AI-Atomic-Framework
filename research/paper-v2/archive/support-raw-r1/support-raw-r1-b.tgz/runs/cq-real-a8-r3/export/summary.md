# atm-bench export — cq-real-a8-r3

- run_id: `cq-real-a8-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"region","cold_retry":"loop"}`
- scenario reproducibility: **true** (`75dd85234758f67a…`)
- alignment: 0 both / atm_only=441 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 441 | — |
| contended intents | 441 | — |
| events_total | 1791 | — |
| event types | submit=441, decision=441, oracle=441, enqueue=234, dequeue=234 | — |
| bytes (JSONL) | 3283513 | — |
| duration_ms | 6113 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=441 | — |
| committed | 441 | — |
| oracle pass (marker survives) | 441 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 234 | — |
| composer co-writes | 0 | — |
| CAS rebase on apply | 0 | — |
| mean wait_ms (all intents) | 51 | — |
| mean wait_ms (waited only) | 96.2 (n=234) | — |
| p95 / max wait_ms | 223 / 342 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 6101.2 | — |
| throughput intents/s | 72.28 | — |
| goodput oracle-pass/s | 72.28 | — |
| latency_ms mean / p50 / p95 | 53.52 / 10.32 / 225.52 | — |
| wait_ms mean / p50 / p95 | 51.05 / 8 / 223 | — |
| apply_ms mean / p50 / p95 | 2.29 / 2.1 / 3.68 | — |
| total_ms mean / p50 / p95 | 97.11 / 63.35 / 273.22 | — |
| overhead_ms mean / p50 / p95 | 55.87 / 12.42 / 228.86 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 234 | 0 | 96.2 |
| admit | 207 | 0 | 0 |

## Reason codes

- atm: overlay_wait_on_atm_true-conflict_then_direct=234, atm_direct=207
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | cold_queue=234, admit=207 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1791, bytes=3283513, duration_ms=6113
