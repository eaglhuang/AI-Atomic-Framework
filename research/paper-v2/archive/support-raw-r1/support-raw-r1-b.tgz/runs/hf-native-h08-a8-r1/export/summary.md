# atm-bench export — hf-native-h08-a8-r1

- run_id: `hf-native-h08-a8-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0.8,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync"}`
- scenario reproducibility: **true** (`7422724bbf623e5c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 289 | — |
| events_total | 997 | — |
| event types | submit=354, decision=354, oracle=289 | — |
| bytes (JSONL) | 1918770 | — |
| duration_ms | 2587 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=289, reject=65 | — |
| committed | 289 | — |
| oracle pass (marker survives) | 289 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 81.6% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 204 | — |
| CAS rebase on apply | 203 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2577.97 | — |
| throughput intents/s | 137.32 | — |
| goodput oracle-pass/s | 112.1 | — |
| latency_ms mean / p50 / p95 | 2.64 / 2.75 / 4.26 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.83 / 2.02 / 3.09 | — |
| total_ms mean / p50 / p95 | 39.33 / 44.33 / 66.22 | — |
| overhead_ms mean / p50 / p95 | 4.55 / 4.95 / 6.99 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 204 | 0 | 0 |
| hot_provisional | 59 | 0 | 0 |
| reject | 65 | 0 | 0 |
| admit | 26 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=187, atm_true_conflict=65, atm_provisional_write_lease=48, atm_direct=21, atm_compose=17, atm_provisional_write_lease+cas_rebase=11, atm_direct+cas_rebase=5
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | composer_merge=71, admit=14 |
| no_conflict | hot_provisional=33, admit=12, reject=10, composer_merge=10 |
| hot_provisional | composer_merge=98, reject=55, hot_provisional=19 |
| composer_cowrite | composer_merge=25, hot_provisional=7 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=997, bytes=1918770, duration_ms=2587
