# atm-bench export — hf-loopstale-h08-a8-r3

- run_id: `hf-loopstale-h08-a8-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0.8,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"stale"}`
- scenario reproducibility: **true** (`7422724bbf623e5c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 289 | — |
| events_total | 1206 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=72, dequeue=72 | — |
| bytes (JSONL) | 2305745 | — |
| duration_ms | 2797 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 154 | — |
| lost updates (oracle fail) | 200 | — |
| integration pass rate of committed | 43.5% | — |
| effective success rate of all intents | 43.5% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 72 | — |
| composer co-writes | 253 | — |
| CAS rebase on apply | 246 | — |
| mean wait_ms (all intents) | 6.2 | — |
| mean wait_ms (waited only) | 30.6 (n=72) | — |
| p95 / max wait_ms | 43 / 81 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2788.52 | — |
| throughput intents/s | 126.95 | — |
| goodput oracle-pass/s | 55.23 | — |
| latency_ms mean / p50 / p95 | 9.41 / 3.25 / 46.83 | — |
| wait_ms mean / p50 / p95 | 6.21 / 0 / 43 | — |
| apply_ms mean / p50 / p95 | 2.26 / 2.15 / 3.19 | — |
| total_ms mean / p50 / p95 | 55.29 / 53.43 / 91.57 | — |
| overhead_ms mean / p50 / p95 | 11.76 / 5.63 / 49.19 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 253 | 0 | 7.3 |
| hot_provisional | 62 | 0 | 5.6 |
| admit | 39 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=182, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=55, atm_provisional_write_lease=48, atm_direct=32, atm_compose=12, overlay_wait_on_atm_true-conflict_then_proposal-required=12, atm_direct+cas_rebase=7, overlay_wait_on_atm_true-conflict_then_compose=4, atm_provisional_write_lease+cas_rebase=1, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | composer_merge=57, admit=28 |
| no_conflict | hot_provisional=27, composer_merge=27, admit=11 |
| hot_provisional | composer_merge=142, hot_provisional=30 |
| composer_cowrite | composer_merge=27, hot_provisional=5 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1206, bytes=2305745, duration_ms=2797
