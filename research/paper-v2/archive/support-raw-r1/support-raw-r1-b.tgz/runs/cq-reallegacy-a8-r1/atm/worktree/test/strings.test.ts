/** Tiny oracle-friendly test module (COLD). */
import { slugify, trim } from '../src/utils/strings.ts';

// <region:body>
export function runStringsSelfTest(): boolean {
  return trim('  x  ') === 'x' && slugify('Hello World') === 'hello-world';
}
// atm-edit s42-t006-i2 by codex:mock-s2
// atm-edit s42-t006-i3 by cursor:mock-s3
// atm-edit s42-t006-i1 by claude:mock-s1
// atm-edit s42-t006-i5 by other:mock-s7
// atm-edit s42-t006-i4 by other:mock-s6
// atm-edit s42-t006-i0 by cursor:mock-s0
// atm-edit s42-t014-i3 by cursor:mock-s3
// atm-edit s42-t014-i0 by cursor:mock-s0
// atm-edit s42-t014-i7 by other:mock-s7
// atm-edit s42-t014-i5 by codex:mock-s5
// atm-edit s42-t014-i2 by codex:mock-s2
// atm-edit s42-t014-i1 by claude:mock-s1
// atm-edit s42-t014-i4 by claude:mock-s4
// atm-edit s42-t014-i6 by other:mock-s6
// atm-edit s42-t016-i3 by codex:mock-s5
// atm-edit s42-t016-i2 by claude:mock-s4
// atm-edit s42-t016-i5 by other:mock-s7
// atm-edit s42-t016-i1 by codex:mock-s2
// atm-edit s42-t016-i0 by cursor:mock-s0
// atm-edit s42-t016-i4 by other:mock-s6
// atm-edit s42-t025-i5 by codex:mock-s5
// atm-edit s42-t025-i7 by other:mock-s7
// atm-edit s42-t025-i0 by cursor:mock-s0
// atm-edit s42-t025-i4 by claude:mock-s4
// atm-edit s42-t025-i1 by claude:mock-s1
// atm-edit s42-t025-i2 by codex:mock-s2
// atm-edit s42-t025-i6 by other:mock-s6
// atm-edit s42-t025-i3 by cursor:mock-s3
// </region:body>
