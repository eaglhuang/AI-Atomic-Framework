/** App entry (COLD). */
import { dbConfig, featureFlags } from './config.ts';
import { allRoutes } from './routes.ts';
import { initialState } from './store.ts';

// <region:body>
export function boot(): { ok: true; routes: number; db: string } {
  const routes = allRoutes();
  return {
    ok: true,
    routes: Object.keys(routes).length,
    db: `${dbConfig.host}/${dbConfig.name}`,
  };
}

export function isBillingV2(): boolean {
  return featureFlags.billingV2;
}

export { initialState };
// atm-edit s42-t040-i7 by other:mock-s7
// atm-edit s42-t041-i7 by other:mock-s7
// atm-edit s42-t042-i7 by other:mock-s7
// atm-edit s42-t047-i4 by claude:mock-s4
// atm-edit s42-t050-i0 by cursor:mock-s0
// atm-edit s42-t051-i1 by claude:mock-s1
// </region:body>
