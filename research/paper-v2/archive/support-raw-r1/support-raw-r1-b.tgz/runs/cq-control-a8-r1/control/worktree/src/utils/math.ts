/** Math helpers (COLD). */
// <region:body>
export function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}
export function sum(xs: readonly number[]): number {
  return xs.reduce((a, b) => a + b, 0);
}
// atm-edit s42-t001-i0 by cursor:mock-s0
// atm-edit s42-t004-i5 by other:mock-s6
// atm-edit s42-t005-i6 by other:mock-s6
// atm-edit s42-t009-i2 by cursor:mock-s3
// atm-edit s42-t012-i1 by claude:mock-s1
// atm-edit s42-t026-i2 by cursor:mock-s3
// atm-edit s42-t028-i5 by other:mock-s6
// atm-edit s42-t030-i3 by cursor:mock-s3
// atm-edit s42-t032-i5 by codex:mock-s5
// atm-edit s42-t045-i1 by codex:mock-s2
// atm-edit s42-t053-i0 by cursor:mock-s0
// atm-edit s42-t056-i2 by codex:mock-s2
// </region:body>
