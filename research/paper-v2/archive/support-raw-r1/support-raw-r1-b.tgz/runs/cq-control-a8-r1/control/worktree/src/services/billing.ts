/** Billing service (COLD). */
export interface LineItem { sku: string; qty: number; unitCents: number }

// <region:body>
export function totalCents(items: readonly LineItem[]): number {
  return items.reduce((s, i) => s + i.qty * i.unitCents, 0);
}
export function formatMoney(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}
// atm-edit s42-t013-i2 by codex:mock-s2
// atm-edit s42-t029-i6 by other:mock-s6
// atm-edit s42-t046-i5 by codex:mock-s5
// atm-edit s42-t049-i2 by codex:mock-s2
// atm-edit s42-t052-i5 by codex:mock-s5
// atm-edit s42-t059-i1 by claude:mock-s1
// </region:body>
