/** Build stub (COLD) — lists entry modules. */
import { boot } from '../src/index.ts';

// <region:body>
export function buildSummary(): string {
  const b = boot();
  return `routes=${b.routes};db=${b.db}`;
}
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log(buildSummary());
}
// atm-edit s42-t003-i0 by cursor:mock-s0
// atm-edit s42-t010-i2 by codex:mock-s2
// atm-edit s42-t022-i3 by cursor:mock-s3
// atm-edit s42-t027-i3 by cursor:mock-s3
// atm-edit s42-t037-i1 by claude:mock-s1
// atm-edit s42-t039-i5 by codex:mock-s5
// atm-edit s42-t058-i3 by cursor:mock-s3
// </region:body>
