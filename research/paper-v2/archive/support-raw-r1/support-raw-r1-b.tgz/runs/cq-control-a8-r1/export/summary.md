# atm-bench export — cq-control-a8-r1

- run_id: `cq-control-a8-r1` · scenario_seed: **42** · atm_backend: **none** (none (control-only run)) · writer: mock
- label: CONTROL (no ATM / no broker)
- params: `{"n_agents":8,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once"}`
- scenario reproducibility: **true** (`75dd85234758f67a…`)
- alignment: 0 both / atm_only=0 / control_only=441

## Headline numbers

| metric | atm (none) | control (no ATM) |
|---|---|---|
| trials | — | 60 |
| intents (decision events) | — | 441 |
| contended intents | — | 441 |
| events_total | — | 1323 |
| event types | — | submit=441, decision=441, oracle=441 |
| bytes (JSONL) | — | 783712 |
| duration_ms | — | 3033 |
| distinct agents / vendors | — | 8 / claude,codex,cursor,other |
| outcomes | — | commit=441 |
| committed | — | 441 |
| oracle pass (marker survives) | — | 62 |
| lost updates (oracle fail) | — | 379 |
| integration pass rate of committed | — | 14.1% |
| effective success rate of all intents | — | 14.1% |
| racy_overwrite decisions | — | 387 |
| serialized (queued) | — | 0 |
| composer co-writes | — | 0 |
| CAS rebase on apply | — | 0 |
| mean wait_ms (all intents) | — | 0 |
| mean wait_ms (waited only) | — | 0 (n=0) |
| p95 / max wait_ms | — | 0 / 0 |

## Latency / throughput (performance.now ms)

| metric | atm (none) | control (no ATM) |
|---|---|---|
| timing available | — | true |
| wall_clock_ms (first submit→last decision) | — | 3025.85 |
| throughput intents/s | — | 145.74 |
| goodput oracle-pass/s | — | 20.49 |
| latency_ms mean / p50 / p95 | — | 0 / 0 / 0 |
| wait_ms mean / p50 / p95 | — | 0 / 0 / 0 |
| apply_ms mean / p50 / p95 | — | 0.1 / 0.1 / 0.17 |
| total_ms mean / p50 / p95 | — | 40.27 / 40.45 / 59.1 |
| overhead_ms mean / p50 / p95 | — | 0.18 / 0.17 / 0.28 |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| direct_write | 0 | 441 | — |

## Reason codes

- atm: —
- control: racy_overwrite=387, concurrent_no_clobber=40, clean=14

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|
| control_racy_write | direct_write=441 |

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1323, bytes=783712, duration_ms=3033
