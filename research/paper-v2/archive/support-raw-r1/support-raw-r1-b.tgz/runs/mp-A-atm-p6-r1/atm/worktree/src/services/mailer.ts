/** Mailer service (COLD). */
export interface Mail { to: string; subject: string; body: string }

// <region:body>
export function formatMail(mail: Mail): string {
  return `To: ${mail.to}\nSubject: ${mail.subject}\n\n${mail.body}`;
}
export function isValidAddress(addr: string): boolean {
  return addr.includes('@');
}
// atm-edit s42-t001-i5 by codex:mock-s5
// atm-edit s42-t001-i3 by cursor:mock-s3
// atm-edit s42-t001-i0 by cursor:mock-s0
// atm-edit s42-t001-i2 by codex:mock-s2
// atm-edit s42-t002-i1 by claude:mock-s1
// atm-edit s42-t004-i3 by cursor:mock-s3
// atm-edit s42-t004-i1 by claude:mock-s1
// atm-edit s42-t004-i2 by codex:mock-s2
// atm-edit s42-t007-i2 by cursor:mock-s3
// atm-edit s42-t008-i1 by claude:mock-s1
// atm-edit s42-t015-i5 by codex:mock-s5
// atm-edit s42-t015-i1 by claude:mock-s1
// atm-edit s42-t017-i4 by claude:mock-s4
// atm-edit s42-t017-i3 by cursor:mock-s3
// atm-edit s42-t024-i1 by claude:mock-s1
// atm-edit s42-t026-i2 by cursor:mock-s3
// atm-edit s42-t026-i0 by cursor:mock-s0
// atm-edit s42-t026-i1 by claude:mock-s1
// atm-edit s42-t027-i2 by codex:mock-s2
// atm-edit s42-t026-i4 by codex:mock-s5
// atm-edit s42-t028-i4 by claude:mock-s4
// </region:body>
