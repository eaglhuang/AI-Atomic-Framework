# atm-bench export — cq-control-a16-r2

- run_id: `cq-control-a16-r2` · scenario_seed: **42** · atm_backend: **none** (none (control-only run)) · writer: mock
- label: CONTROL (no ATM / no broker)
- params: `{"n_agents":16,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once"}`
- scenario reproducibility: **true** (`02660e85e1d47ffc…`)
- alignment: 0 both / atm_only=0 / control_only=879

## Headline numbers

| metric | atm (none) | control (no ATM) |
|---|---|---|
| trials | — | 60 |
| intents (decision events) | — | 879 |
| contended intents | — | 879 |
| events_total | — | 2637 |
| event types | — | submit=879, decision=879, oracle=879 |
| bytes (JSONL) | — | 1662722 |
| duration_ms | — | 3043 |
| distinct agents / vendors | — | 16 / claude,codex,cursor,other |
| outcomes | — | commit=879 |
| committed | — | 879 |
| oracle pass (marker survives) | — | 64 |
| lost updates (oracle fail) | — | 815 |
| integration pass rate of committed | — | 7.3% |
| effective success rate of all intents | — | 7.3% |
| racy_overwrite decisions | — | 824 |
| serialized (queued) | — | 0 |
| composer co-writes | — | 0 |
| CAS rebase on apply | — | 0 |
| mean wait_ms (all intents) | — | 0 |
| mean wait_ms (waited only) | — | 0 (n=0) |
| p95 / max wait_ms | — | 0 / 0 |

## Latency / throughput (performance.now ms)

| metric | atm (none) | control (no ATM) |
|---|---|---|
| timing available | — | true |
| wall_clock_ms (first submit→last decision) | — | 3028.25 |
| throughput intents/s | — | 290.27 |
| goodput oracle-pass/s | — | 21.13 |
| latency_ms mean / p50 / p95 | — | 0 / 0 / 0 |
| wait_ms mean / p50 / p95 | — | 0 / 0 / 0 |
| apply_ms mean / p50 / p95 | — | 0.09 / 0.08 / 0.17 |
| total_ms mean / p50 / p95 | — | 40.17 / 40.37 / 58.2 |
| overhead_ms mean / p50 / p95 | — | 0.14 / 0.13 / 0.25 |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| direct_write | 0 | 879 | — |

## Reason codes

- atm: —
- control: racy_overwrite=824, concurrent_no_clobber=37, clean=18

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|
| control_racy_write | direct_write=879 |

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=2637, bytes=1662722, duration_ms=3043
