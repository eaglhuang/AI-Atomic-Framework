/** Date helpers (COLD). */
// <region:body>
export function isoDay(d: Date = new Date()): string {
  return d.toISOString().slice(0, 10);
}
export function addDays(d: Date, n: number): Date {
  const x = new Date(d.getTime());
  x.setUTCDate(x.getUTCDate() + n);
  return x;
}
// atm-edit s42-t002-i8 by codex:mock-s10
// atm-edit s42-t003-i4 by other:mock-s6
// atm-edit s42-t011-i9 by codex:mock-s10
// atm-edit s42-t016-i4 by codex:mock-s5
// atm-edit s42-t019-i3 by cursor:mock-s3
// atm-edit s42-t026-i10 by claude:mock-s12
// atm-edit s42-t040-i0 by cursor:mock-s0
// atm-edit s42-t051-i5 by codex:mock-s5
// </region:body>
