/** In-memory store slices (HOT). */
export type State = { users: string[]; orders: number[]; meta: Record<string, string> };

// <region:reducers>
export function reduceUsers(state: State, user: string): State {
  return { ...state, users: [...state.users, user] };
}
// atm-edit s42-t003-i0 by cursor:mock-s0
// atm-edit s42-t007-i3 by codex:mock-s5
// </region:reducers>

// <region:selectors>
export function selectUserCount(state: State): number {
  return state.users.length;
}
// atm-edit s42-t000-i4 by claude:mock-s4
// atm-edit s42-t003-i3 by cursor:mock-s3
// atm-edit s42-t009-i4 by claude:mock-s4
// atm-edit s42-t011-i2 by codex:mock-s2
// atm-edit s42-t013-i1 by codex:mock-s2
// atm-edit s42-t015-i2 by codex:mock-s2
// atm-edit s42-t020-i0 by cursor:mock-s0
// atm-edit s42-t023-i0 by cursor:mock-s0
// </region:selectors>

// <region:actions>
export function createOrder(state: State, id: number): State {
  return { ...state, orders: [...state.orders, id] };
}
// atm-edit s42-t001-i4 by claude:mock-s4
// atm-edit s42-t003-i2 by codex:mock-s2
// atm-edit s42-t013-i4 by codex:mock-s5
// atm-edit s42-t021-i3 by cursor:mock-s3
// atm-edit s42-t028-i1 by claude:mock-s1
// </region:actions>

export const initialState: State = { users: [], orders: [], meta: {} };
