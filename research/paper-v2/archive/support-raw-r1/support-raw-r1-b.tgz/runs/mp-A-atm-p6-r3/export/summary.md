# atm-bench export — mp-A-atm-p6-r3

- run_id: `mp-A-atm-p6-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs) — multi-process shared registry
- params: `{"n_agents":6,"hot_ratio":0.4,"overlap":"med","cold_policy":"queue","composer_enabled":true,"trial_count":30,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync","mp_registry_sync":"cas","mp_apply_lock":"on"}`
- scenario reproducibility: **true** (`80d54e045f6d9c41…`)
- alignment: 0 both / atm_only=168 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 30 | — |
| intents (decision events) | 168 | — |
| contended intents | 82 | — |
| events_total | 496 | — |
| event types | submit=168, decision=168, oracle=160 | — |
| bytes (JSONL) | 493640 | — |
| duration_ms | 1535.38 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=160, reject=8 | — |
| committed | 160 | — |
| oracle pass (marker survives) | 160 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 95.2% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 60 | — |
| CAS rebase on apply | 57 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 1533.67 | — |
| throughput intents/s | 109.54 | — |
| goodput oracle-pass/s | 104.32 | — |
| latency_ms mean / p50 / p95 | 5.94 / 4.16 / 16.5 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 3.19 / 2.86 / 6.32 | — |
| total_ms mean / p50 / p95 | 47.56 / 50.2 / 67.73 | — |
| overhead_ms mean / p50 / p95 | 9.28 / 7.92 / 21.27 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| reject | 8 | 0 | 0 |
| admit | 62 | 0 | 0 |
| composer_merge | 60 | 0 | 0 |
| hot_provisional | 38 | 0 | 0 |

## Reason codes

- atm: atm_direct=59, atm_compose+cas_rebase=53, atm_provisional_write_lease=37, atm_true_conflict=8, atm_compose=7, atm_direct+cas_rebase=3, atm_provisional_write_lease+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | reject=5, hot_provisional=3, composer_merge=3 |
| no_conflict | admit=41, hot_provisional=31, composer_merge=12, reject=2 |
| cold_queue | composer_merge=41, admit=21 |
| composer_cowrite | composer_merge=4, hot_provisional=4, reject=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=496, bytes=493640, duration_ms=1535.38
