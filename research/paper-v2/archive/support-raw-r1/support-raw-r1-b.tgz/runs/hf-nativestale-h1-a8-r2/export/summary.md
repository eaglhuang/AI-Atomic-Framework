# atm-bench export — hf-nativestale-h1-a8-r2

- run_id: `hf-nativestale-h1-a8-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"stale"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 973 | — |
| event types | submit=354, decision=354, oracle=265 | — |
| bytes (JSONL) | 1893867 | — |
| duration_ms | 2558 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=265, reject=89 | — |
| committed | 265 | — |
| oracle pass (marker survives) | 95 | — |
| lost updates (oracle fail) | 170 | — |
| integration pass rate of committed | 35.8% | — |
| effective success rate of all intents | 26.8% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 203 | — |
| CAS rebase on apply | 200 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2551.77 | — |
| throughput intents/s | 138.73 | — |
| goodput oracle-pass/s | 37.23 | — |
| latency_ms mean / p50 / p95 | 2.41 / 2.54 / 4.16 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.63 / 1.88 / 3.03 | — |
| total_ms mean / p50 / p95 | 36.05 / 41 / 65.78 | — |
| overhead_ms mean / p50 / p95 | 4.13 / 4.69 / 6.97 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 203 | 0 | 0 |
| hot_provisional | 62 | 0 | 0 |
| reject | 89 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=186, atm_true_conflict=89, atm_provisional_write_lease=48, atm_compose=17, atm_provisional_write_lease+cas_rebase=14
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=156, reject=75, hot_provisional=19 |
| no_conflict | hot_provisional=36, composer_merge=10, reject=7 |
| composer_cowrite | composer_merge=37, hot_provisional=7, reject=7 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=973, bytes=1893867, duration_ms=2558
