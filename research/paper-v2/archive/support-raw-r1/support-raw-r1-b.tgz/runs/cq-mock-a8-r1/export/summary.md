# atm-bench export — cq-mock-a8-r1

- run_id: `cq-mock-a8-r1` · scenario_seed: **42** · atm_backend: **mock** (mock broker) · writer: mock
- atm_version: `mock-broker-0.1 (not ATM monorepo)`
- label: MOCK ATM (in-process mock-broker)
- params: `{"n_agents":8,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once"}`
- scenario reproducibility: **true** (`75dd85234758f67a…`)
- alignment: 0 both / atm_only=441 / control_only=0

## Headline numbers

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 441 | — |
| contended intents | 441 | — |
| events_total | 1825 | — |
| event types | submit=441, decision=441, oracle=441, enqueue=251, dequeue=251 | — |
| bytes (JSONL) | 1120361 | — |
| duration_ms | 5450 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=441 | — |
| committed | 441 | — |
| oracle pass (marker survives) | 441 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 251 | — |
| composer co-writes | 0 | — |
| CAS rebase on apply | 0 | — |
| mean wait_ms (all intents) | 47 | — |
| mean wait_ms (waited only) | 82.7 (n=251) | — |
| p95 / max wait_ms | 219 / 278 | — |

## Latency / throughput (performance.now ms)

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 5440.05 | — |
| throughput intents/s | 81.07 | — |
| goodput oracle-pass/s | 81.07 | — |
| latency_ms mean / p50 / p95 | 47.11 / 13.94 / 219.08 | — |
| wait_ms mean / p50 / p95 | 47.05 / 14 / 219 | — |
| apply_ms mean / p50 / p95 | 0.15 / 0.14 / 0.27 | — |
| total_ms mean / p50 / p95 | 87.46 / 59.29 / 255.75 | — |
| overhead_ms mean / p50 / p95 | 47.34 / 14.09 / 219.27 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 251 | 0 | 82.7 |
| admit | 190 | 0 | 0 |

## Reason codes

- atm: cold_queued_then_granted=251, cold_free=190
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | cold_queue=251, admit=190 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1825, bytes=1120361, duration_ms=5450
