# atm-bench export — hf-loopstale-h1-a6-r2

- run_id: `hf-loopstale-h1-a6-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"stale"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=269 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 269 | — |
| contended intents | 219 | — |
| events_total | 937 | — |
| event types | submit=269, decision=269, oracle=269, enqueue=65, dequeue=65 | — |
| bytes (JSONL) | 1797704 | — |
| duration_ms | 2744 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=269 | — |
| committed | 269 | — |
| oracle pass (marker survives) | 121 | — |
| lost updates (oracle fail) | 148 | — |
| integration pass rate of committed | 45% | — |
| effective success rate of all intents | 45% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 65 | — |
| composer co-writes | 200 | — |
| CAS rebase on apply | 193 | — |
| mean wait_ms (all intents) | 6.2 | — |
| mean wait_ms (waited only) | 25.7 (n=65) | — |
| p95 / max wait_ms | 38 / 81 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2737.83 | — |
| throughput intents/s | 98.25 | — |
| goodput oracle-pass/s | 44.2 | — |
| latency_ms mean / p50 / p95 | 9 / 3.01 / 41.81 | — |
| wait_ms mean / p50 / p95 | 6.21 / 0 / 38 | — |
| apply_ms mean / p50 / p95 | 2.27 / 2.18 / 3.35 | — |
| total_ms mean / p50 / p95 | 53.76 / 53.59 / 91.66 | — |
| overhead_ms mean / p50 / p95 | 11.35 / 5.4 / 44.5 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 200 | 0 | 5.6 |
| hot_provisional | 69 | 0 | 8 |

## Reason codes

- atm: atm_compose+cas_rebase=137, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=45, atm_provisional_write_lease=43, overlay_wait_on_atm_true-conflict_then_proposal-required=15, atm_compose=15, atm_provisional_write_lease+cas_rebase=9, overlay_wait_on_atm_true-conflict_then_compose=3, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=128, hot_provisional=23 |
| composer_cowrite | composer_merge=51, hot_provisional=17 |
| no_conflict | hot_provisional=29, composer_merge=21 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=937, bytes=1797704, duration_ms=2744
