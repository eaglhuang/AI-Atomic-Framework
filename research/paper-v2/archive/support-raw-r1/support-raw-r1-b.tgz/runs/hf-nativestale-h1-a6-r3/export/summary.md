# atm-bench export — hf-nativestale-h1-a6-r3

- run_id: `hf-nativestale-h1-a6-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"stale"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=269 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 269 | — |
| contended intents | 219 | — |
| events_total | 750 | — |
| event types | submit=269, decision=269, oracle=212 | — |
| bytes (JSONL) | 1455454 | — |
| duration_ms | 2545 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=212, reject=57 | — |
| committed | 212 | — |
| oracle pass (marker survives) | 93 | — |
| lost updates (oracle fail) | 119 | — |
| integration pass rate of committed | 43.9% | — |
| effective success rate of all intents | 34.6% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 139 | — |
| CAS rebase on apply | 138 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2538.71 | — |
| throughput intents/s | 105.96 | — |
| goodput oracle-pass/s | 36.63 | — |
| latency_ms mean / p50 / p95 | 2.38 / 2.52 / 3.9 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.76 / 1.98 / 3.17 | — |
| total_ms mean / p50 / p95 | 37.26 / 41.53 / 65.53 | — |
| overhead_ms mean / p50 / p95 | 4.25 / 4.72 / 6.55 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 139 | 0 | 0 |
| reject | 57 | 0 | 0 |
| hot_provisional | 73 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=122, atm_true_conflict=57, atm_provisional_write_lease=57, atm_compose=17, atm_provisional_write_lease+cas_rebase=16
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=78, reject=47, hot_provisional=26 |
| composer_cowrite | composer_merge=49, hot_provisional=13, reject=6 |
| no_conflict | hot_provisional=34, composer_merge=12, reject=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=750, bytes=1455454, duration_ms=2545
