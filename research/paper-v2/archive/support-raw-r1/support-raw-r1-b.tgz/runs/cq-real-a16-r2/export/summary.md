# atm-bench export — cq-real-a16-r2

- run_id: `cq-real-a16-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":16,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"region","cold_retry":"loop"}`
- scenario reproducibility: **true** (`02660e85e1d47ffc…`)
- alignment: 0 both / atm_only=879 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 879 | — |
| contended intents | 879 | — |
| events_total | 3867 | — |
| event types | submit=879, decision=879, oracle=879, enqueue=615, dequeue=615 | — |
| bytes (JSONL) | 7075373 | — |
| duration_ms | 9580 | — |
| distinct agents / vendors | 16 / claude,codex,cursor,other | — |
| outcomes | commit=879 | — |
| committed | 879 | — |
| oracle pass (marker survives) | 879 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 615 | — |
| composer co-writes | 0 | — |
| CAS rebase on apply | 0 | — |
| mean wait_ms (all intents) | 95.4 | — |
| mean wait_ms (waited only) | 136.4 (n=615) | — |
| p95 / max wait_ms | 316 / 639 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 9551.44 | — |
| throughput intents/s | 92.03 | — |
| goodput oracle-pass/s | 92.03 | — |
| latency_ms mean / p50 / p95 | 98.18 / 56.81 / 319.02 | — |
| wait_ms mean / p50 / p95 | 95.45 / 54 / 316 | — |
| apply_ms mean / p50 / p95 | 2.37 / 2.2 / 3.71 | — |
| total_ms mean / p50 / p95 | 143.92 / 103.14 / 364.62 | — |
| overhead_ms mean / p50 / p95 | 100.6 / 58.94 / 320.97 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| admit | 264 | 0 | 0 |
| cold_queue | 615 | 0 | 136.4 |

## Reason codes

- atm: overlay_wait_on_atm_true-conflict_then_direct=615, atm_direct=264
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | cold_queue=615, admit=264 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=3867, bytes=7075373, duration_ms=9580
