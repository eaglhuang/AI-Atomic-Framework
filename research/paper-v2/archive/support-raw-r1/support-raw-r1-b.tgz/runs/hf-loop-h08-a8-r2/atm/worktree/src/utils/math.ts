/** Math helpers (COLD). */
// <region:body>
export function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}
export function sum(xs: readonly number[]): number {
  return xs.reduce((a, b) => a + b, 0);
}
// atm-edit s42-t027-i6 by other:mock-s7
// atm-edit s42-t027-i2 by cursor:mock-s3
// atm-edit s42-t027-i3 by claude:mock-s4
// atm-edit s42-t027-i1 by codex:mock-s2
// atm-edit s42-t027-i5 by other:mock-s6
// atm-edit s42-t027-i0 by cursor:mock-s0
// atm-edit s42-t040-i4 by codex:mock-s5
// </region:body>
