/** String helpers (COLD). */
// <region:body>
export function trim(s: string): string {
  return s.trim();
}
export function slugify(s: string): string {
  return trim(s).toLowerCase().replace(/\s+/g, '-');
}
// atm-edit s42-t029-i6 by other:mock-s7
// atm-edit s42-t029-i3 by cursor:mock-s3
// atm-edit s42-t026-i0 by cursor:mock-s0
// atm-edit s42-t029-i4 by claude:mock-s4
// atm-edit s42-t029-i2 by codex:mock-s2
// atm-edit s42-t029-i5 by codex:mock-s5
// atm-edit s42-t029-i0 by cursor:mock-s0
// </region:body>
