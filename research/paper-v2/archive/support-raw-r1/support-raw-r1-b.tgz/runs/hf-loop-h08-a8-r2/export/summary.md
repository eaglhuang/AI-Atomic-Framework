# atm-bench export — hf-loop-h08-a8-r2

- run_id: `hf-loop-h08-a8-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0.8,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"sync"}`
- scenario reproducibility: **true** (`7422724bbf623e5c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 289 | — |
| events_total | 1196 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=67, dequeue=67 | — |
| bytes (JSONL) | 2277701 | — |
| duration_ms | 2808 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 354 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 67 | — |
| composer co-writes | 253 | — |
| CAS rebase on apply | 248 | — |
| mean wait_ms (all intents) | 5.1 | — |
| mean wait_ms (waited only) | 27 (n=67) | — |
| p95 / max wait_ms | 37 / 96 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2799.36 | — |
| throughput intents/s | 126.46 | — |
| goodput oracle-pass/s | 126.46 | — |
| latency_ms mean / p50 / p95 | 8.19 / 3.17 / 40.34 | — |
| wait_ms mean / p50 / p95 | 5.11 / 0 / 37 | — |
| apply_ms mean / p50 / p95 | 2.25 / 2.1 / 3.25 | — |
| total_ms mean / p50 / p95 | 53.91 / 52.18 / 88.36 | — |
| overhead_ms mean / p50 / p95 | 10.51 / 5.6 / 43.14 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 253 | 0 | 5.6 |
| hot_provisional | 62 | 0 | 6.1 |
| admit | 39 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=183, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=53, atm_provisional_write_lease=44, atm_direct=36, atm_compose=15, overlay_wait_on_atm_true-conflict_then_proposal-required=9, atm_provisional_write_lease+cas_rebase=6, atm_direct+cas_rebase=3, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=3, overlay_wait_on_atm_true-conflict_then_compose=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | composer_merge=58, admit=27 |
| no_conflict | hot_provisional=27, composer_merge=26, admit=12 |
| hot_provisional | composer_merge=140, hot_provisional=32 |
| composer_cowrite | composer_merge=29, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1196, bytes=2277701, duration_ms=2808
