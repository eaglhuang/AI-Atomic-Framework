# atm-bench export — hf-native-h08-a8-r3

- run_id: `hf-native-h08-a8-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0.8,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync"}`
- scenario reproducibility: **true** (`7422724bbf623e5c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 289 | — |
| events_total | 990 | — |
| event types | submit=354, decision=354, oracle=282 | — |
| bytes (JSONL) | 1906215 | — |
| duration_ms | 2572 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=282, reject=72 | — |
| committed | 282 | — |
| oracle pass (marker survives) | 282 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 79.7% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 197 | — |
| CAS rebase on apply | 196 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2563.52 | — |
| throughput intents/s | 138.09 | — |
| goodput oracle-pass/s | 110 | — |
| latency_ms mean / p50 / p95 | 2.55 / 2.65 / 4.31 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.72 / 1.88 / 3.07 | — |
| total_ms mean / p50 / p95 | 37.91 / 43.56 / 64.46 | — |
| overhead_ms mean / p50 / p95 | 4.35 / 4.8 / 6.96 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 197 | 0 | 0 |
| hot_provisional | 59 | 0 | 0 |
| reject | 72 | 0 | 0 |
| admit | 26 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=179, atm_true_conflict=72, atm_provisional_write_lease=47, atm_direct=21, atm_compose=18, atm_provisional_write_lease+cas_rebase=12, atm_direct+cas_rebase=5
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | composer_merge=71, admit=14 |
| no_conflict | hot_provisional=32, admit=12, reject=11, composer_merge=10 |
| hot_provisional | composer_merge=90, reject=61, hot_provisional=21 |
| composer_cowrite | composer_merge=26, hot_provisional=6 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=990, bytes=1906215, duration_ms=2572
