# atm-bench export — hf-loop-h1-a8-r2

- run_id: `hf-loop-h1-a8-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"sync"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 1280 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=109, dequeue=109 | — |
| bytes (JSONL) | 2442864 | — |
| duration_ms | 2844 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 354 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 109 | — |
| composer co-writes | 302 | — |
| CAS rebase on apply | 295 | — |
| mean wait_ms (all intents) | 7.4 | — |
| mean wait_ms (waited only) | 23.9 (n=109) | — |
| p95 / max wait_ms | 40 / 80 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2833.77 | — |
| throughput intents/s | 124.92 | — |
| goodput oracle-pass/s | 124.92 | — |
| latency_ms mean / p50 / p95 | 10.28 / 3.29 / 42.36 | — |
| wait_ms mean / p50 / p95 | 7.35 / 0 / 40 | — |
| apply_ms mean / p50 / p95 | 2.2 / 2.1 / 3.18 | — |
| total_ms mean / p50 / p95 | 55.74 / 54.1 / 92.6 | — |
| overhead_ms mean / p50 / p95 | 12.55 / 5.79 / 44.45 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 302 | 0 | 7.6 |
| hot_provisional | 52 | 0 | 5.9 |

## Reason codes

- atm: atm_compose+cas_rebase=201, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=88, atm_provisional_write_lease=31, overlay_wait_on_atm_true-conflict_then_proposal-required=15, atm_compose=9, atm_provisional_write_lease+cas_rebase=4, overlay_wait_on_atm_true-conflict_then_compose=4, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=224, hot_provisional=26 |
| no_conflict | composer_merge=30, hot_provisional=23 |
| composer_cowrite | composer_merge=48, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1280, bytes=2442864, duration_ms=2844
