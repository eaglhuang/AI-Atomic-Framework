# atm-bench export — hf-native-h1-a8-r3

- run_id: `hf-native-h1-a8-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 982 | — |
| event types | submit=354, decision=354, oracle=274 | — |
| bytes (JSONL) | 1901455 | — |
| duration_ms | 2560 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=274, reject=80 | — |
| committed | 274 | — |
| oracle pass (marker survives) | 274 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 77.4% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 212 | — |
| CAS rebase on apply | 210 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2551.63 | — |
| throughput intents/s | 138.73 | — |
| goodput oracle-pass/s | 107.38 | — |
| latency_ms mean / p50 / p95 | 2.45 / 2.6 / 4.02 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.66 / 1.87 / 3.15 | — |
| total_ms mean / p50 / p95 | 37.18 / 42.15 / 64.51 | — |
| overhead_ms mean / p50 / p95 | 4.18 / 4.69 / 6.58 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 212 | 0 | 0 |
| hot_provisional | 62 | 0 | 0 |
| reject | 80 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=194, atm_true_conflict=80, atm_provisional_write_lease=46, atm_compose=18, atm_provisional_write_lease+cas_rebase=16
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=161, reject=68, hot_provisional=21 |
| no_conflict | hot_provisional=34, composer_merge=13, reject=6 |
| composer_cowrite | composer_merge=38, hot_provisional=7, reject=6 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=982, bytes=1901455, duration_ms=2560
