# atm-bench export — hf-loopstale-h1-a8-r1

- run_id: `hf-loopstale-h1-a8-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"stale"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 1274 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=106, dequeue=106 | — |
| bytes (JSONL) | 2441813 | — |
| duration_ms | 2966 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 129 | — |
| lost updates (oracle fail) | 225 | — |
| integration pass rate of committed | 36.4% | — |
| effective success rate of all intents | 36.4% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 106 | — |
| composer co-writes | 295 | — |
| CAS rebase on apply | 290 | — |
| mean wait_ms (all intents) | 8.1 | — |
| mean wait_ms (waited only) | 27 (n=106) | — |
| p95 / max wait_ms | 41 / 73 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2956.9 | — |
| throughput intents/s | 119.72 | — |
| goodput oracle-pass/s | 43.63 | — |
| latency_ms mean / p50 / p95 | 11.27 / 3.39 / 44.34 | — |
| wait_ms mean / p50 / p95 | 8.07 / 0 / 41 | — |
| apply_ms mean / p50 / p95 | 2.28 / 2.18 / 3.18 | — |
| total_ms mean / p50 / p95 | 57.44 / 54.95 / 95.72 | — |
| overhead_ms mean / p50 / p95 | 13.63 / 5.94 / 46.76 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 295 | 0 | 7.4 |
| hot_provisional | 59 | 0 | 11.4 |

## Reason codes

- atm: atm_compose+cas_rebase=201, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=84, atm_provisional_write_lease=34, overlay_wait_on_atm_true-conflict_then_proposal-required=20, atm_compose=9, atm_provisional_write_lease+cas_rebase=4, overlay_wait_on_atm_true-conflict_then_compose=1, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=219, hot_provisional=31 |
| no_conflict | composer_merge=32, hot_provisional=21 |
| composer_cowrite | composer_merge=44, hot_provisional=7 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1274, bytes=2441813, duration_ms=2966
