/** Billing service (COLD). */
export interface LineItem { sku: string; qty: number; unitCents: number }

// <region:body>
export function totalCents(items: readonly LineItem[]): number {
  return items.reduce((s, i) => s + i.qty * i.unitCents, 0);
}
export function formatMoney(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}
// atm-edit s42-t001-i1 by claude:mock-s1
// atm-edit s42-t006-i3 by claude:mock-s4
// atm-edit s42-t008-i3 by cursor:mock-s3
// atm-edit s42-t009-i3 by cursor:mock-s3
// atm-edit s42-t011-i0 by cursor:mock-s0
// atm-edit s42-t013-i2 by cursor:mock-s3
// atm-edit s42-t017-i1 by claude:mock-s1
// atm-edit s42-t022-i2 by codex:mock-s2
// </region:body>
