/** App config (HOT) — writable via ATM WriteIntent bounded regions. */
export interface DbConfig { host: string; port: number; name: string }
export interface CacheConfig { ttlSec: number; backend: 'memory' | 'redis' }
export interface FeatureFlags { billingV2: boolean; experimentalSearch: boolean }

// <region:db>
export const dbConfig: DbConfig = {
  host: 'localhost',
  port: 5432,
  name: 'app',
};
// atm-edit s42-t000-i3 by cursor:mock-s3
// atm-edit s42-t004-i0 by cursor:mock-s0
// atm-edit s42-t007-i1 by claude:mock-s1
// atm-edit s42-t009-i2 by codex:mock-s2
// atm-edit s42-t014-i0 by cursor:mock-s0
// atm-edit s42-t017-i2 by codex:mock-s2
// atm-edit s42-t021-i1 by claude:mock-s1
// atm-edit s42-t023-i1 by claude:mock-s1
// atm-edit s42-t029-i3 by cursor:mock-s3
// </region:db>

// <region:cache>
export const cacheConfig: CacheConfig = {
  ttlSec: 60,
  backend: 'memory',
};
// atm-edit s42-t022-i4 by codex:mock-s5
// </region:cache>

// <region:flags>
export const featureFlags: FeatureFlags = {
  billingV2: false,
  experimentalSearch: false,
};
// atm-edit s42-t010-i3 by cursor:mock-s3
// atm-edit s42-t012-i2 by codex:mock-s2
// atm-edit s42-t015-i3 by cursor:mock-s3
// atm-edit s42-t019-i5 by codex:mock-s5
// atm-edit s42-t027-i3 by cursor:mock-s3
// </region:flags>
