/** Build stub (COLD) — lists entry modules. */
import { boot } from '../src/index.ts';

// <region:body>
export function buildSummary(): string {
  const b = boot();
  return `routes=${b.routes};db=${b.db}`;
}
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log(buildSummary());
}
// atm-edit s42-t003-i4 by claude:mock-s4
// atm-edit s42-t009-i1 by claude:mock-s1
// atm-edit s42-t010-i0 by cursor:mock-s0
// atm-edit s42-t015-i0 by cursor:mock-s0
// atm-edit s42-t016-i0 by cursor:mock-s0
// atm-edit s42-t019-i1 by claude:mock-s1
// atm-edit s42-t025-i4 by codex:mock-s5
// atm-edit s42-t028-i3 by cursor:mock-s3
// </region:body>
