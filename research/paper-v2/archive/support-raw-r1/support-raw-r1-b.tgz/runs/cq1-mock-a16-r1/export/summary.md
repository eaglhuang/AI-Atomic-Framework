# atm-bench export — cq1-mock-a16-r1

- run_id: `cq1-mock-a16-r1` · scenario_seed: **42** · atm_backend: **mock** (mock broker) · writer: mock
- atm_version: `mock-broker-0.1 (not ATM monorepo)`
- label: MOCK ATM (in-process mock-broker)
- params: `{"n_agents":16,"hot_ratio":0,"overlap":"cold-one-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once"}`
- scenario reproducibility: **true** (`9afad21d9589dc82…`)
- alignment: 0 both / atm_only=879 / control_only=0

## Headline numbers

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 879 | — |
| contended intents | 879 | — |
| events_total | 4393 | — |
| event types | submit=879, decision=879, oracle=879, enqueue=878, dequeue=878 | — |
| bytes (JSONL) | 2654162 | — |
| duration_ms | 35702 | — |
| distinct agents / vendors | 16 / claude,codex,cursor,other | — |
| outcomes | commit=879 | — |
| committed | 879 | — |
| oracle pass (marker survives) | 879 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 878 | — |
| composer co-writes | 0 | — |
| CAS rebase on apply | 0 | — |
| mean wait_ms (all intents) | 588 | — |
| mean wait_ms (waited only) | 588.7 (n=878) | — |
| p95 / max wait_ms | 680 / 721 | — |

## Latency / throughput (performance.now ms)

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 35671.11 | — |
| throughput intents/s | 24.64 | — |
| goodput oracle-pass/s | 24.64 | — |
| latency_ms mean / p50 / p95 | 588.17 / 601.84 / 680.87 | — |
| wait_ms mean / p50 / p95 | 587.99 / 601 / 680 | — |
| apply_ms mean / p50 / p95 | 0.32 / 0.31 / 0.41 | — |
| total_ms mean / p50 / p95 | 628.73 / 641.73 / 723.21 | — |
| overhead_ms mean / p50 / p95 | 588.63 / 602.22 / 681.26 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| admit | 1 | 0 | 0 |
| cold_queue | 878 | 0 | 588.7 |

## Reason codes

- atm: cold_queued_then_granted=878, cold_free=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | cold_queue=878, admit=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=4393, bytes=2654162, duration_ms=35702
