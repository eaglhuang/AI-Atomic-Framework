/** In-memory store slices (HOT). */
export type State = { users: string[]; orders: number[]; meta: Record<string, string> };

// <region:reducers>
export function reduceUsers(state: State, user: string): State {
  return { ...state, users: [...state.users, user] };
}
// atm-edit s42-t003-i3 by cursor:mock-s3
// atm-edit s42-t010-i1 by claude:mock-s1
// atm-edit s42-t013-i3 by claude:mock-s4
// atm-edit s42-t024-i2 by cursor:mock-s3
// atm-edit s42-t031-i1 by claude:mock-s1
// atm-edit s42-t044-i4 by claude:mock-s4
// atm-edit s42-t049-i2 by codex:mock-s2
// </region:reducers>

// <region:selectors>
export function selectUserCount(state: State): number {
  return state.users.length;
}
// atm-edit s42-t006-i1 by claude:mock-s1
// atm-edit s42-t012-i0 by cursor:mock-s0
// atm-edit s42-t016-i4 by claude:mock-s4
// atm-edit s42-t018-i3 by cursor:mock-s3
// atm-edit s42-t019-i1 by codex:mock-s2
// atm-edit s42-t021-i2 by codex:mock-s2
// atm-edit s42-t027-i2 by codex:mock-s2
// atm-edit s42-t028-i2 by codex:mock-s2
// atm-edit s42-t033-i1 by claude:mock-s1
// atm-edit s42-t036-i1 by claude:mock-s1
// atm-edit s42-t039-i4 by claude:mock-s4
// atm-edit s42-t040-i2 by codex:mock-s2
// atm-edit s42-t046-i3 by cursor:mock-s3
// </region:selectors>

// <region:actions>
export function createOrder(state: State, id: number): State {
  return { ...state, orders: [...state.orders, id] };
}
// atm-edit s42-t002-i2 by cursor:mock-s3
// atm-edit s42-t008-i2 by codex:mock-s5
// atm-edit s42-t015-i4 by codex:mock-s5
// atm-edit s42-t023-i2 by cursor:mock-s3
// atm-edit s42-t026-i0 by cursor:mock-s0
// atm-edit s42-t029-i1 by codex:mock-s2
// atm-edit s42-t035-i5 by codex:mock-s5
// atm-edit s42-t041-i3 by claude:mock-s4
// atm-edit s42-t043-i5 by codex:mock-s5
// atm-edit s42-t048-i5 by codex:mock-s5
// </region:actions>

export const initialState: State = { users: [], orders: [], meta: {} };
