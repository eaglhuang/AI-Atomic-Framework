# atm-bench export — hf-control-h1-a6-r2

- run_id: `hf-control-h1-a6-r2` · scenario_seed: **42** · atm_backend: **none** (none (control-only run)) · writer: mock
- label: CONTROL (no ATM / no broker)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=0 / control_only=269

## Headline numbers

| metric | atm (none) | control (no ATM) |
|---|---|---|
| trials | — | 50 |
| intents (decision events) | — | 269 |
| contended intents | — | 219 |
| events_total | — | 807 |
| event types | — | submit=269, decision=269, oracle=269 |
| bytes (JSONL) | — | 463564 |
| duration_ms | — | 2537 |
| distinct agents / vendors | — | 6 / claude,codex,cursor |
| outcomes | — | commit=269 |
| committed | — | 269 |
| oracle pass (marker survives) | — | 96 |
| lost updates (oracle fail) | — | 173 |
| integration pass rate of committed | — | 35.7% |
| effective success rate of all intents | — | 35.7% |
| racy_overwrite decisions | — | 202 |
| serialized (queued) | — | 0 |
| composer co-writes | — | 0 |
| CAS rebase on apply | — | 0 |
| mean wait_ms (all intents) | — | 0 |
| mean wait_ms (waited only) | — | 0 (n=0) |
| p95 / max wait_ms | — | 0 / 0 |

## Latency / throughput (performance.now ms)

| metric | atm (none) | control (no ATM) |
|---|---|---|
| timing available | — | true |
| wall_clock_ms (first submit→last decision) | — | 2531.02 |
| throughput intents/s | — | 106.28 |
| goodput oracle-pass/s | — | 37.93 |
| latency_ms mean / p50 / p95 | — | 0 / 0 / 0 |
| wait_ms mean / p50 / p95 | — | 0 / 0 / 0 |
| apply_ms mean / p50 / p95 | — | 0.11 / 0.11 / 0.18 |
| total_ms mean / p50 / p95 | — | 41.57 / 41.8 / 59.15 |
| overhead_ms mean / p50 / p95 | — | 0.2 / 0.19 / 0.3 |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| direct_write | 0 | 269 | — |

## Reason codes

- atm: —
- control: racy_overwrite=202, clean=50, concurrent_no_clobber=17

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|
| control_racy_write | direct_write=219 |
| no_conflict | direct_write=50 |

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=807, bytes=463564, duration_ms=2537
