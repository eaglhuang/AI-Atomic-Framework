/** In-memory store slices (HOT). */
export type State = { users: string[]; orders: number[]; meta: Record<string, string> };

// <region:reducers>
export function reduceUsers(state: State, user: string): State {
  return { ...state, users: [...state.users, user] };
}
// atm-edit s42-t001-i1 by claude:mock-s1
// atm-edit s42-t002-i1 by claude:mock-s1
// atm-edit s42-t015-i4 by claude:mock-s4
// atm-edit s42-t013-i5 by codex:mock-s5
// atm-edit s42-t030-i3 by other:mock-s7
// atm-edit s42-t030-i1 by codex:mock-s5
// atm-edit s42-t030-i2 by other:mock-s6
// atm-edit s42-t031-i5 by other:mock-s6
// </region:reducers>

// <region:selectors>
export function selectUserCount(state: State): number {
  return state.users.length;
}
// atm-edit s42-t007-i4 by claude:mock-s4
// atm-edit s42-t013-i4 by claude:mock-s4
// atm-edit s42-t031-i6 by other:mock-s7
// atm-edit s42-t037-i5 by other:mock-s7
// atm-edit s42-t038-i5 by other:mock-s7
// atm-edit s42-t039-i7 by other:mock-s7
// atm-edit s42-t044-i4 by codex:mock-s5
// atm-edit s42-t043-i0 by cursor:mock-s0
// atm-edit s42-t046-i3 by claude:mock-s4
// atm-edit s42-t049-i2 by codex:mock-s2
// </region:selectors>

// <region:actions>
export function createOrder(state: State, id: number): State {
  return { ...state, orders: [...state.orders, id] };
}
// atm-edit s42-t004-i4 by claude:mock-s4
// atm-edit s42-t007-i5 by codex:mock-s5
// atm-edit s42-t019-i5 by other:mock-s7
// atm-edit s42-t019-i1 by claude:mock-s1
// atm-edit s42-t020-i0 by cursor:mock-s0
// atm-edit s42-t023-i2 by codex:mock-s2
// atm-edit s42-t024-i4 by claude:mock-s4
// atm-edit s42-t025-i4 by claude:mock-s4
// atm-edit s42-t025-i2 by codex:mock-s2
// atm-edit s42-t026-i5 by codex:mock-s5
// atm-edit s42-t034-i3 by codex:mock-s5
// atm-edit s42-t037-i3 by claude:mock-s4
// atm-edit s42-t034-i4 by other:mock-s6
// atm-edit s42-t045-i2 by cursor:mock-s3
// </region:actions>

export const initialState: State = { users: [], orders: [], meta: {} };
