/** Date helpers (COLD). */
// <region:body>
export function isoDay(d: Date = new Date()): string {
  return d.toISOString().slice(0, 10);
}
export function addDays(d: Date, n: number): Date {
  const x = new Date(d.getTime());
  x.setUTCDate(x.getUTCDate() + n);
  return x;
}
// atm-edit s42-t000-i5 by codex:mock-s5
// atm-edit s42-t004-i3 by cursor:mock-s3
// atm-edit s42-t004-i5 by codex:mock-s5
// atm-edit s42-t046-i0 by cursor:mock-s0
// </region:body>
