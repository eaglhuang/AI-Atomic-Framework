# atm-bench export — hf-loopstale-h08-a8-r1

- run_id: `hf-loopstale-h08-a8-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0.8,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"stale"}`
- scenario reproducibility: **true** (`7422724bbf623e5c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 289 | — |
| events_total | 1202 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=70, dequeue=70 | — |
| bytes (JSONL) | 2298789 | — |
| duration_ms | 2785 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 156 | — |
| lost updates (oracle fail) | 198 | — |
| integration pass rate of committed | 44.1% | — |
| effective success rate of all intents | 44.1% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 70 | — |
| composer co-writes | 257 | — |
| CAS rebase on apply | 245 | — |
| mean wait_ms (all intents) | 6.1 | — |
| mean wait_ms (waited only) | 31.1 (n=70) | — |
| p95 / max wait_ms | 41 / 98 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2774.6 | — |
| throughput intents/s | 127.59 | — |
| goodput oracle-pass/s | 56.22 | — |
| latency_ms mean / p50 / p95 | 9.17 / 3.11 / 45.43 | — |
| wait_ms mean / p50 / p95 | 6.15 / 0 / 41 | — |
| apply_ms mean / p50 / p95 | 2.25 / 2.08 / 3.47 | — |
| total_ms mean / p50 / p95 | 54.91 / 53.17 / 93.28 | — |
| overhead_ms mean / p50 / p95 | 11.5 / 5.39 / 48.15 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 257 | 0 | 6.5 |
| hot_provisional | 58 | 0 | 8.8 |
| admit | 39 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=189, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=47, atm_direct=36, atm_provisional_write_lease=34, overlay_wait_on_atm_true-conflict_then_proposal-required=18, atm_compose=17, atm_provisional_write_lease+cas_rebase=5, overlay_wait_on_atm_true-conflict_then_compose=4, atm_direct+cas_rebase=3, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | composer_merge=58, admit=27 |
| no_conflict | composer_merge=28, hot_provisional=25, admit=12 |
| hot_provisional | composer_merge=142, hot_provisional=30 |
| composer_cowrite | composer_merge=29, hot_provisional=3 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1202, bytes=2298789, duration_ms=2785
