# atm-bench export — hf-native-h1-a6-r2

- run_id: `hf-native-h1-a6-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=269 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 269 | — |
| contended intents | 219 | — |
| events_total | 749 | — |
| event types | submit=269, decision=269, oracle=211 | — |
| bytes (JSONL) | 1447463 | — |
| duration_ms | 2547 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=211, reject=58 | — |
| committed | 211 | — |
| oracle pass (marker survives) | 211 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 78.4% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 143 | — |
| CAS rebase on apply | 138 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2541.45 | — |
| throughput intents/s | 105.85 | — |
| goodput oracle-pass/s | 83.02 | — |
| latency_ms mean / p50 / p95 | 2.39 / 2.47 / 3.95 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.82 / 1.99 / 3.55 | — |
| total_ms mean / p50 / p95 | 37.78 / 42.14 / 64.43 | — |
| overhead_ms mean / p50 / p95 | 4.31 / 4.74 / 7.33 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 143 | 0 | 0 |
| reject | 58 | 0 | 0 |
| hot_provisional | 68 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=125, atm_true_conflict=58, atm_provisional_write_lease=55, atm_compose=18, atm_provisional_write_lease+cas_rebase=13
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=82, reject=48, hot_provisional=21 |
| composer_cowrite | composer_merge=47, hot_provisional=13, reject=8 |
| no_conflict | hot_provisional=34, composer_merge=14, reject=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=749, bytes=1447463, duration_ms=2547
