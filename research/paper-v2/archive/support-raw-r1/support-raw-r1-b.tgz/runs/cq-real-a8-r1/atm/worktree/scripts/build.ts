/** Build stub (COLD) — lists entry modules. */
import { boot } from '../src/index.ts';

// <region:body>
export function buildSummary(): string {
  const b = boot();
  return `routes=${b.routes};db=${b.db}`;
}
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log(buildSummary());
}
// atm-edit s42-t003-i2 by codex:mock-s2
// atm-edit s42-t003-i3 by cursor:mock-s3
// atm-edit s42-t003-i4 by claude:mock-s4
// atm-edit s42-t003-i5 by other:mock-s6
// atm-edit s42-t003-i1 by claude:mock-s1
// atm-edit s42-t003-i0 by cursor:mock-s0
// atm-edit s42-t003-i6 by other:mock-s7
// atm-edit s42-t010-i2 by codex:mock-s2
// atm-edit s42-t010-i6 by other:mock-s6
// atm-edit s42-t010-i3 by cursor:mock-s3
// atm-edit s42-t010-i4 by claude:mock-s4
// atm-edit s42-t010-i5 by codex:mock-s5
// atm-edit s42-t010-i0 by cursor:mock-s0
// atm-edit s42-t010-i1 by claude:mock-s1
// atm-edit s42-t010-i7 by other:mock-s7
// atm-edit s42-t022-i2 by codex:mock-s2
// atm-edit s42-t022-i6 by other:mock-s6
// atm-edit s42-t027-i2 by codex:mock-s2
// atm-edit s42-t022-i5 by codex:mock-s5
// atm-edit s42-t022-i3 by cursor:mock-s3
// atm-edit s42-t027-i5 by other:mock-s6
// atm-edit s42-t022-i7 by other:mock-s7
// atm-edit s42-t022-i4 by claude:mock-s4
// atm-edit s42-t022-i0 by cursor:mock-s0
// atm-edit s42-t022-i1 by claude:mock-s1
// atm-edit s42-t027-i3 by cursor:mock-s3
// atm-edit s42-t037-i2 by codex:mock-s2
// atm-edit s42-t039-i2 by codex:mock-s2
// atm-edit s42-t027-i6 by other:mock-s7
// atm-edit s42-t027-i4 by claude:mock-s4
// atm-edit s42-t037-i5 by codex:mock-s5
// atm-edit s42-t027-i1 by claude:mock-s1
// atm-edit s42-t027-i0 by cursor:mock-s0
// atm-edit s42-t039-i5 by codex:mock-s5
// atm-edit s42-t037-i6 by other:mock-s6
// atm-edit s42-t039-i6 by other:mock-s6
// atm-edit s42-t037-i4 by claude:mock-s4
// atm-edit s42-t037-i7 by other:mock-s7
// atm-edit s42-t039-i4 by claude:mock-s4
// atm-edit s42-t037-i3 by cursor:mock-s3
// atm-edit s42-t037-i1 by claude:mock-s1
// atm-edit s42-t039-i3 by cursor:mock-s3
// atm-edit s42-t058-i2 by codex:mock-s2
// atm-edit s42-t037-i0 by cursor:mock-s0
// atm-edit s42-t039-i1 by claude:mock-s1
// atm-edit s42-t039-i0 by cursor:mock-s0
// atm-edit s42-t058-i5 by codex:mock-s5
// atm-edit s42-t058-i6 by other:mock-s6
// atm-edit s42-t058-i4 by claude:mock-s4
// atm-edit s42-t058-i3 by cursor:mock-s3
// atm-edit s42-t058-i1 by claude:mock-s1
// atm-edit s42-t058-i0 by cursor:mock-s0
// </region:body>
