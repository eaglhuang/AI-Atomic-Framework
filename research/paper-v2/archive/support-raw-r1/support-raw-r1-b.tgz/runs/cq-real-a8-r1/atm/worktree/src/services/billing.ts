/** Billing service (COLD). */
export interface LineItem { sku: string; qty: number; unitCents: number }

// <region:body>
export function totalCents(items: readonly LineItem[]): number {
  return items.reduce((s, i) => s + i.qty * i.unitCents, 0);
}
export function formatMoney(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}
// atm-edit s42-t013-i2 by codex:mock-s2
// atm-edit s42-t013-i6 by other:mock-s6
// atm-edit s42-t013-i3 by cursor:mock-s3
// atm-edit s42-t013-i4 by claude:mock-s4
// atm-edit s42-t013-i5 by codex:mock-s5
// atm-edit s42-t013-i0 by cursor:mock-s0
// atm-edit s42-t013-i1 by claude:mock-s1
// atm-edit s42-t013-i7 by other:mock-s7
// atm-edit s42-t029-i2 by codex:mock-s2
// atm-edit s42-t029-i5 by codex:mock-s5
// atm-edit s42-t029-i6 by other:mock-s6
// atm-edit s42-t029-i3 by cursor:mock-s3
// atm-edit s42-t029-i7 by other:mock-s7
// atm-edit s42-t029-i4 by claude:mock-s4
// atm-edit s42-t029-i1 by claude:mock-s1
// atm-edit s42-t029-i0 by cursor:mock-s0
// atm-edit s42-t046-i2 by codex:mock-s2
// atm-edit s42-t049-i2 by codex:mock-s2
// atm-edit s42-t046-i5 by codex:mock-s5
// atm-edit s42-t046-i6 by other:mock-s6
// atm-edit s42-t052-i2 by codex:mock-s2
// atm-edit s42-t049-i4 by codex:mock-s5
// atm-edit s42-t049-i5 by other:mock-s6
// atm-edit s42-t052-i5 by codex:mock-s5
// atm-edit s42-t059-i2 by codex:mock-s2
// atm-edit s42-t052-i6 by other:mock-s6
// atm-edit s42-t046-i4 by claude:mock-s4
// atm-edit s42-t059-i5 by codex:mock-s5
// atm-edit s42-t046-i7 by other:mock-s7
// atm-edit s42-t049-i3 by claude:mock-s4
// atm-edit s42-t059-i6 by other:mock-s6
// atm-edit s42-t046-i3 by cursor:mock-s3
// atm-edit s42-t052-i4 by claude:mock-s4
// atm-edit s42-t046-i1 by claude:mock-s1
// atm-edit s42-t052-i7 by other:mock-s7
// atm-edit s42-t046-i0 by cursor:mock-s0
// atm-edit s42-t049-i1 by claude:mock-s1
// atm-edit s42-t052-i3 by cursor:mock-s3
// atm-edit s42-t049-i0 by cursor:mock-s0
// atm-edit s42-t052-i1 by claude:mock-s1
// atm-edit s42-t059-i4 by claude:mock-s4
// atm-edit s42-t059-i7 by other:mock-s7
// atm-edit s42-t052-i0 by cursor:mock-s0
// atm-edit s42-t059-i3 by cursor:mock-s3
// atm-edit s42-t059-i1 by claude:mock-s1
// atm-edit s42-t059-i0 by cursor:mock-s0
// </region:body>
