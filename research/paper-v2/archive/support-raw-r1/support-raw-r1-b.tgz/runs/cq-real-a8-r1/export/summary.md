# atm-bench export — cq-real-a8-r1

- run_id: `cq-real-a8-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"region","cold_retry":"loop"}`
- scenario reproducibility: **true** (`75dd85234758f67a…`)
- alignment: 0 both / atm_only=441 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 441 | — |
| contended intents | 441 | — |
| events_total | 1797 | — |
| event types | submit=441, decision=441, oracle=441, enqueue=237, dequeue=237 | — |
| bytes (JSONL) | 3294056 | — |
| duration_ms | 6225 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=441 | — |
| committed | 441 | — |
| oracle pass (marker survives) | 441 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 237 | — |
| composer co-writes | 0 | — |
| CAS rebase on apply | 0 | — |
| mean wait_ms (all intents) | 49.4 | — |
| mean wait_ms (waited only) | 91.9 (n=237) | — |
| p95 / max wait_ms | 224 / 315 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 6214.14 | — |
| throughput intents/s | 70.97 | — |
| goodput oracle-pass/s | 70.97 | — |
| latency_ms mean / p50 / p95 | 51.88 / 11.81 / 225.58 | — |
| wait_ms mean / p50 / p95 | 49.36 / 10 / 224 | — |
| apply_ms mean / p50 / p95 | 2.48 / 2.31 / 3.79 | — |
| total_ms mean / p50 / p95 | 95.63 / 62.97 / 275.28 | — |
| overhead_ms mean / p50 / p95 | 54.43 / 13.42 / 228.1 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 237 | 0 | 91.9 |
| admit | 204 | 0 | 0 |

## Reason codes

- atm: overlay_wait_on_atm_true-conflict_then_direct=237, atm_direct=204
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | cold_queue=237, admit=204 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1797, bytes=3294056, duration_ms=6225
