# atm-bench export — hf-nativestale-h1-a6-r1

- run_id: `hf-nativestale-h1-a6-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"stale"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=269 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 269 | — |
| contended intents | 219 | — |
| events_total | 745 | — |
| event types | submit=269, decision=269, oracle=207 | — |
| bytes (JSONL) | 1446784 | — |
| duration_ms | 2550 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=207, reject=62 | — |
| committed | 207 | — |
| oracle pass (marker survives) | 92 | — |
| lost updates (oracle fail) | 115 | — |
| integration pass rate of committed | 44.4% | — |
| effective success rate of all intents | 34.2% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 137 | — |
| CAS rebase on apply | 132 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2543.91 | — |
| throughput intents/s | 105.74 | — |
| goodput oracle-pass/s | 36.16 | — |
| latency_ms mean / p50 / p95 | 2.31 / 2.43 / 3.86 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.74 / 1.91 / 3.47 | — |
| total_ms mean / p50 / p95 | 36.7 / 41.94 / 65.66 | — |
| overhead_ms mean / p50 / p95 | 4.16 / 4.7 / 6.86 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 137 | 0 | 0 |
| reject | 62 | 0 | 0 |
| hot_provisional | 70 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=121, atm_true_conflict=62, atm_provisional_write_lease=59, atm_compose=16, atm_provisional_write_lease+cas_rebase=11
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=72, reject=51, hot_provisional=28 |
| composer_cowrite | composer_merge=53, hot_provisional=9, reject=6 |
| no_conflict | hot_provisional=33, composer_merge=12, reject=5 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=745, bytes=1446784, duration_ms=2550
