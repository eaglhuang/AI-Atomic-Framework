# atm-bench export — hf-loopstale-h1-a8-r3

- run_id: `hf-loopstale-h1-a8-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"stale"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 1268 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=103, dequeue=103 | — |
| bytes (JSONL) | 2431453 | — |
| duration_ms | 2839 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 118 | — |
| lost updates (oracle fail) | 236 | — |
| integration pass rate of committed | 33.3% | — |
| effective success rate of all intents | 33.3% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 103 | — |
| composer co-writes | 299 | — |
| CAS rebase on apply | 292 | — |
| mean wait_ms (all intents) | 7.4 | — |
| mean wait_ms (waited only) | 25.6 (n=103) | — |
| p95 / max wait_ms | 43 / 84 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2831.41 | — |
| throughput intents/s | 125.03 | — |
| goodput oracle-pass/s | 41.68 | — |
| latency_ms mean / p50 / p95 | 10.57 / 3.37 / 46 | — |
| wait_ms mean / p50 / p95 | 7.44 / 0 / 43 | — |
| apply_ms mean / p50 / p95 | 2.18 / 2.08 / 3.19 | — |
| total_ms mean / p50 / p95 | 56.21 / 54.17 / 92.19 | — |
| overhead_ms mean / p50 / p95 | 12.83 / 5.92 / 49.11 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 299 | 0 | 7.5 |
| hot_provisional | 55 | 0 | 6.9 |

## Reason codes

- atm: atm_compose+cas_rebase=202, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=82, atm_provisional_write_lease=32, overlay_wait_on_atm_true-conflict_then_proposal-required=15, atm_compose=11, atm_provisional_write_lease+cas_rebase=6, overlay_wait_on_atm_true-conflict_then_compose=4, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=218, hot_provisional=32 |
| no_conflict | composer_merge=36, hot_provisional=17 |
| composer_cowrite | composer_merge=45, hot_provisional=6 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1268, bytes=2431453, duration_ms=2839
