/** HTTP route table (HOT). */
export type Handler = (req: { path: string }) => { status: number; body: string };

// <region:users>
export const usersRoutes: Record<string, Handler> = {
  'GET /users': () => ({ status: 200, body: '[]' }),
  'POST /users': () => ({ status: 201, body: '{}' }),
};
// atm-edit s42-t015-i7 by other:mock-s7
// atm-edit s42-t024-i3 by cursor:mock-s3
// atm-edit s42-t027-i1 by claude:mock-s1
// atm-edit s42-t028-i0 by codex:mock-s2
// atm-edit s42-t033-i1 by claude:mock-s1
// atm-edit s42-t035-i1 by claude:mock-s1
// atm-edit s42-t043-i2 by cursor:mock-s3
// atm-edit s42-t040-i7 by other:mock-s7
// atm-edit s42-t041-i5 by codex:mock-s5
// atm-edit s42-t045-i1 by claude:mock-s1
// atm-edit s42-t046-i1 by claude:mock-s1
// atm-edit s42-t045-i4 by codex:mock-s5
// atm-edit s42-t045-i6 by other:mock-s7
// </region:users>

// <region:orders>
export const ordersRoutes: Record<string, Handler> = {
  'GET /orders': () => ({ status: 200, body: '[]' }),
};
// atm-edit s42-t000-i7 by other:mock-s7
// atm-edit s42-t004-i1 by claude:mock-s1
// atm-edit s42-t006-i2 by codex:mock-s2
// atm-edit s42-t010-i3 by cursor:mock-s3
// atm-edit s42-t010-i0 by cursor:mock-s0
// atm-edit s42-t015-i6 by other:mock-s6
// atm-edit s42-t015-i3 by cursor:mock-s3
// atm-edit s42-t016-i3 by cursor:mock-s3
// atm-edit s42-t016-i2 by codex:mock-s2
// atm-edit s42-t020-i4 by claude:mock-s4
// atm-edit s42-t023-i5 by other:mock-s6
// atm-edit s42-t021-i1 by codex:mock-s2
// atm-edit s42-t023-i2 by codex:mock-s2
// atm-edit s42-t049-i3 by codex:mock-s5
// atm-edit s42-t047-i0 by cursor:mock-s0
// atm-edit s42-t049-i2 by claude:mock-s4
// </region:orders>

// <region:admin>
export const adminRoutes: Record<string, Handler> = {
  'GET /admin/health': () => ({ status: 200, body: 'ok' }),
};
// atm-edit s42-t001-i3 by cursor:mock-s3
// atm-edit s42-t001-i0 by cursor:mock-s0
// atm-edit s42-t007-i2 by codex:mock-s2
// atm-edit s42-t006-i7 by other:mock-s7
// atm-edit s42-t008-i2 by codex:mock-s2
// atm-edit s42-t008-i3 by cursor:mock-s3
// atm-edit s42-t010-i6 by other:mock-s7
// atm-edit s42-t016-i0 by cursor:mock-s0
// atm-edit s42-t021-i0 by cursor:mock-s0
// atm-edit s42-t040-i3 by cursor:mock-s3
// atm-edit s42-t036-i3 by claude:mock-s4
// atm-edit s42-t037-i4 by claude:mock-s4
// atm-edit s42-t048-i1 by claude:mock-s1
// atm-edit s42-t048-i0 by cursor:mock-s0
// </region:admin>

export function allRoutes(): Record<string, Handler> {
  return { ...usersRoutes, ...ordersRoutes, ...adminRoutes };
}
