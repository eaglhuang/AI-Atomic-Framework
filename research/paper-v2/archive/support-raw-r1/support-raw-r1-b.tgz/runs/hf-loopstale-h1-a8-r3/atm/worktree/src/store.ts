/** In-memory store slices (HOT). */
export type State = { users: string[]; orders: number[]; meta: Record<string, string> };

// <region:reducers>
export function reduceUsers(state: State, user: string): State {
  return { ...state, users: [...state.users, user] };
}
// atm-edit s42-t001-i1 by claude:mock-s1
// atm-edit s42-t002-i1 by claude:mock-s1
// atm-edit s42-t004-i2 by codex:mock-s2
// atm-edit s42-t011-i6 by other:mock-s6
// atm-edit s42-t011-i7 by other:mock-s7
// atm-edit s42-t014-i7 by other:mock-s7
// atm-edit s42-t011-i0 by cursor:mock-s0
// atm-edit s42-t014-i2 by codex:mock-s2
// atm-edit s42-t023-i1 by claude:mock-s1
// atm-edit s42-t029-i2 by cursor:mock-s3
// atm-edit s42-t022-i0 by cursor:mock-s0
// atm-edit s42-t031-i6 by other:mock-s7
// atm-edit s42-t032-i0 by cursor:mock-s0
// atm-edit s42-t033-i0 by cursor:mock-s0
// atm-edit s42-t042-i4 by other:mock-s6
// atm-edit s42-t044-i6 by other:mock-s6
// atm-edit s42-t044-i0 by cursor:mock-s0
// atm-edit s42-t049-i0 by codex:mock-s2
// </region:reducers>

// <region:selectors>
export function selectUserCount(state: State): number {
  return state.users.length;
}
// atm-edit s42-t005-i5 by other:mock-s7
// atm-edit s42-t012-i0 by cursor:mock-s0
// atm-edit s42-t014-i0 by cursor:mock-s0
// atm-edit s42-t018-i4 by other:mock-s6
// atm-edit s42-t022-i3 by cursor:mock-s3
// atm-edit s42-t029-i4 by codex:mock-s5
// atm-edit s42-t030-i3 by claude:mock-s4
// atm-edit s42-t031-i3 by claude:mock-s4
// atm-edit s42-t035-i0 by cursor:mock-s0
// atm-edit s42-t042-i2 by cursor:mock-s3
// atm-edit s42-t039-i0 by cursor:mock-s0
// atm-edit s42-t039-i5 by other:mock-s6
// </region:selectors>

// <region:actions>
export function createOrder(state: State, id: number): State {
  return { ...state, orders: [...state.orders, id] };
}
// atm-edit s42-t012-i6 by other:mock-s6
// atm-edit s42-t018-i1 by claude:mock-s1
// atm-edit s42-t022-i1 by claude:mock-s1
// atm-edit s42-t024-i1 by claude:mock-s1
// atm-edit s42-t026-i5 by other:mock-s6
// atm-edit s42-t031-i0 by cursor:mock-s0
// atm-edit s42-t038-i1 by claude:mock-s1
// atm-edit s42-t044-i1 by claude:mock-s1
// atm-edit s42-t042-i5 by other:mock-s7
// </region:actions>

export const initialState: State = { users: [], orders: [], meta: {} };
