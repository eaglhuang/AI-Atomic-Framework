/** Math helpers (COLD). */
// <region:body>
export function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}
export function sum(xs: readonly number[]): number {
  return xs.reduce((a, b) => a + b, 0);
}
// atm-edit s42-t020-i8 by codex:mock-s10
// atm-edit s42-t020-i1 by claude:mock-s1
// atm-edit s42-t029-i4 by claude:mock-s4
// atm-edit s42-t020-i5 by other:mock-s6
// atm-edit s42-t029-i10 by codex:mock-s10
// atm-edit s42-t034-i4 by claude:mock-s4
// atm-edit s42-t020-i3 by cursor:mock-s3
// atm-edit s42-t029-i1 by claude:mock-s1
// atm-edit s42-t020-i2 by codex:mock-s2
// atm-edit s42-t020-i4 by codex:mock-s5
// atm-edit s42-t020-i0 by cursor:mock-s0
// atm-edit s42-t034-i1 by claude:mock-s1
// atm-edit s42-t020-i11 by codex:mock-s13
// atm-edit s42-t029-i6 by other:mock-s6
// atm-edit s42-t020-i9 by cursor:mock-s11
// atm-edit s42-t029-i3 by cursor:mock-s3
// atm-edit s42-t020-i12 by other:mock-s14
// atm-edit s42-t020-i10 by claude:mock-s12
// atm-edit s42-t034-i6 by other:mock-s6
// atm-edit s42-t034-i3 by cursor:mock-s3
// atm-edit s42-t029-i2 by codex:mock-s2
// atm-edit s42-t020-i6 by other:mock-s7
// atm-edit s42-t020-i7 by cursor:mock-s8
// atm-edit s42-t029-i9 by claude:mock-s9
// atm-edit s42-t029-i0 by cursor:mock-s0
// atm-edit s42-t034-i2 by codex:mock-s2
// atm-edit s42-t029-i5 by codex:mock-s5
// atm-edit s42-t029-i13 by codex:mock-s13
// atm-edit s42-t029-i14 by other:mock-s14
// atm-edit s42-t034-i9 by claude:mock-s9
// atm-edit s42-t059-i4 by claude:mock-s4
// atm-edit s42-t029-i12 by claude:mock-s12
// atm-edit s42-t034-i12 by codex:mock-s13
// atm-edit s42-t029-i11 by cursor:mock-s11
// atm-edit s42-t034-i0 by cursor:mock-s0
// atm-edit s42-t029-i15 by other:mock-s15
// atm-edit s42-t029-i7 by other:mock-s7
// atm-edit s42-t034-i5 by codex:mock-s5
// atm-edit s42-t029-i8 by cursor:mock-s8
// atm-edit s42-t034-i13 by other:mock-s14
// atm-edit s42-t034-i11 by claude:mock-s12
// atm-edit s42-t034-i10 by cursor:mock-s11
// atm-edit s42-t034-i8 by cursor:mock-s8
// atm-edit s42-t059-i9 by codex:mock-s10
// atm-edit s42-t034-i14 by other:mock-s15
// atm-edit s42-t034-i7 by other:mock-s7
// atm-edit s42-t059-i3 by cursor:mock-s3
// atm-edit s42-t059-i1 by claude:mock-s1
// atm-edit s42-t059-i6 by other:mock-s6
// atm-edit s42-t059-i2 by codex:mock-s2
// atm-edit s42-t059-i8 by claude:mock-s9
// atm-edit s42-t059-i5 by codex:mock-s5
// atm-edit s42-t059-i12 by codex:mock-s13
// atm-edit s42-t059-i11 by claude:mock-s12
// atm-edit s42-t059-i0 by cursor:mock-s0
// atm-edit s42-t059-i13 by other:mock-s14
// atm-edit s42-t059-i10 by cursor:mock-s11
// atm-edit s42-t059-i7 by other:mock-s7
// atm-edit s42-t059-i14 by other:mock-s15
// </region:body>
