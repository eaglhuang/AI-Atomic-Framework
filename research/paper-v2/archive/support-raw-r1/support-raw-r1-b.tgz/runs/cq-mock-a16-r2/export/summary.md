# atm-bench export — cq-mock-a16-r2

- run_id: `cq-mock-a16-r2` · scenario_seed: **42** · atm_backend: **mock** (mock broker) · writer: mock
- atm_version: `mock-broker-0.1 (not ATM monorepo)`
- label: MOCK ATM (in-process mock-broker)
- params: `{"n_agents":16,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once"}`
- scenario reproducibility: **true** (`02660e85e1d47ffc…`)
- alignment: 0 both / atm_only=879 / control_only=0

## Headline numbers

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 879 | — |
| contended intents | 879 | — |
| events_total | 3847 | — |
| event types | submit=879, decision=879, oracle=879, enqueue=605, dequeue=605 | — |
| bytes (JSONL) | 2359329 | — |
| duration_ms | 7967 | — |
| distinct agents / vendors | 16 / claude,codex,cursor,other | — |
| outcomes | commit=879 | — |
| committed | 879 | — |
| oracle pass (marker survives) | 879 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 605 | — |
| composer co-writes | 0 | — |
| CAS rebase on apply | 0 | — |
| mean wait_ms (all intents) | 81.1 | — |
| mean wait_ms (waited only) | 117.9 (n=605) | — |
| p95 / max wait_ms | 257 / 534 | — |

## Latency / throughput (performance.now ms)

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 7944.54 | — |
| throughput intents/s | 110.64 | — |
| goodput oracle-pass/s | 110.64 | — |
| latency_ms mean / p50 / p95 | 81.24 / 46 / 257.79 | — |
| wait_ms mean / p50 / p95 | 81.15 / 46 / 257 | — |
| apply_ms mean / p50 / p95 | 0.13 / 0.13 / 0.2 | — |
| total_ms mean / p50 / p95 | 121.45 / 86.59 / 301.97 | — |
| overhead_ms mean / p50 / p95 | 81.44 / 46.15 / 257.92 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| admit | 274 | 0 | 0 |
| cold_queue | 605 | 0 | 117.9 |

## Reason codes

- atm: cold_queued_then_granted=605, cold_free=274
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | cold_queue=605, admit=274 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=3847, bytes=2359329, duration_ms=7967
