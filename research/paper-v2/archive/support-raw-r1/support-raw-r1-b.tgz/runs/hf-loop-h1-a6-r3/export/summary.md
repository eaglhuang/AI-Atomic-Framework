# atm-bench export — hf-loop-h1-a6-r3

- run_id: `hf-loop-h1-a6-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"sync"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=269 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 269 | — |
| contended intents | 219 | — |
| events_total | 937 | — |
| event types | submit=269, decision=269, oracle=269, enqueue=65, dequeue=65 | — |
| bytes (JSONL) | 1789362 | — |
| duration_ms | 2751 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=269 | — |
| committed | 269 | — |
| oracle pass (marker survives) | 269 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 65 | — |
| composer co-writes | 195 | — |
| CAS rebase on apply | 191 | — |
| mean wait_ms (all intents) | 5.8 | — |
| mean wait_ms (waited only) | 23.8 (n=65) | — |
| p95 / max wait_ms | 36 / 79 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2743.72 | — |
| throughput intents/s | 98.04 | — |
| goodput oracle-pass/s | 98.04 | — |
| latency_ms mean / p50 / p95 | 8.54 / 2.92 / 37.71 | — |
| wait_ms mean / p50 / p95 | 5.76 / 0 / 36 | — |
| apply_ms mean / p50 / p95 | 2.3 / 2.12 / 3.53 | — |
| total_ms mean / p50 / p95 | 53.29 / 52.64 / 87.26 | — |
| overhead_ms mean / p50 / p95 | 10.91 / 5.45 / 39.96 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 195 | 0 | 5.8 |
| hot_provisional | 74 | 0 | 5.7 |

## Reason codes

- atm: atm_compose+cas_rebase=133, atm_provisional_write_lease=50, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=47, atm_compose=14, overlay_wait_on_atm_true-conflict_then_proposal-required=13, atm_provisional_write_lease+cas_rebase=7, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=4, overlay_wait_on_atm_true-conflict_then_compose=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=118, hot_provisional=33 |
| composer_cowrite | composer_merge=55, hot_provisional=13 |
| no_conflict | hot_provisional=28, composer_merge=22 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=937, bytes=1789362, duration_ms=2751
