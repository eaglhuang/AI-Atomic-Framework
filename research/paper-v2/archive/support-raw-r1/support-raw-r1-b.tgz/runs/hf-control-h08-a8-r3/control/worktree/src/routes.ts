/** HTTP route table (HOT). */
export type Handler = (req: { path: string }) => { status: number; body: string };

// <region:users>
export const usersRoutes: Record<string, Handler> = {
  'GET /users': () => ({ status: 200, body: '[]' }),
  'POST /users': () => ({ status: 201, body: '{}' }),
};
// atm-edit s42-t008-i6 by other:mock-s7
// atm-edit s42-t009-i0 by cursor:mock-s0
// atm-edit s42-t018-i2 by cursor:mock-s3
// atm-edit s42-t021-i7 by other:mock-s7
// atm-edit s42-t028-i6 by other:mock-s6
// atm-edit s42-t031-i2 by codex:mock-s2
// atm-edit s42-t033-i5 by codex:mock-s5
// atm-edit s42-t039-i4 by claude:mock-s4
// atm-edit s42-t045-i4 by codex:mock-s5
// atm-edit s42-t046-i1 by claude:mock-s1
// atm-edit s42-t047-i4 by claude:mock-s4
// atm-edit s42-t048-i1 by claude:mock-s1
// </region:users>

// <region:orders>
export const ordersRoutes: Record<string, Handler> = {
  'GET /orders': () => ({ status: 200, body: '[]' }),
};
// atm-edit s42-t001-i2 by codex:mock-s2
// atm-edit s42-t015-i3 by cursor:mock-s3
// atm-edit s42-t016-i5 by codex:mock-s5
// atm-edit s42-t022-i1 by claude:mock-s1
// atm-edit s42-t023-i1 by claude:mock-s1
// atm-edit s42-t025-i3 by cursor:mock-s3
// atm-edit s42-t027-i4 by codex:mock-s5
// atm-edit s42-t030-i0 by claude:mock-s1
// atm-edit s42-t036-i4 by codex:mock-s5
// atm-edit s42-t049-i0 by cursor:mock-s0
// </region:orders>

// <region:admin>
export const adminRoutes: Record<string, Handler> = {
  'GET /admin/health': () => ({ status: 200, body: 'ok' }),
};
// atm-edit s42-t002-i5 by codex:mock-s5
// atm-edit s42-t005-i0 by cursor:mock-s0
// atm-edit s42-t011-i5 by other:mock-s6
// atm-edit s42-t012-i4 by claude:mock-s4
// atm-edit s42-t014-i3 by other:mock-s6
// atm-edit s42-t019-i2 by cursor:mock-s3
// atm-edit s42-t026-i1 by claude:mock-s1
// atm-edit s42-t032-i5 by codex:mock-s5
// atm-edit s42-t041-i3 by cursor:mock-s3
// atm-edit s42-t042-i2 by codex:mock-s2
// </region:admin>

export function allRoutes(): Record<string, Handler> {
  return { ...usersRoutes, ...ordersRoutes, ...adminRoutes };
}
