# atm-bench export — hf-control-h1-a8-r3

- run_id: `hf-control-h1-a8-r3` · scenario_seed: **42** · atm_backend: **none** (none (control-only run)) · writer: mock
- label: CONTROL (no ATM / no broker)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=0 / control_only=354

## Headline numbers

| metric | atm (none) | control (no ATM) |
|---|---|---|
| trials | — | 50 |
| intents (decision events) | — | 354 |
| contended intents | — | 301 |
| events_total | — | 1062 |
| event types | — | submit=354, decision=354, oracle=354 |
| bytes (JSONL) | — | 618414 |
| duration_ms | — | 2528 |
| distinct agents / vendors | — | 8 / claude,codex,cursor,other |
| outcomes | — | commit=354 |
| committed | — | 354 |
| oracle pass (marker survives) | — | 101 |
| lost updates (oracle fail) | — | 253 |
| integration pass rate of committed | — | 28.5% |
| effective success rate of all intents | — | 28.5% |
| racy_overwrite decisions | — | 287 |
| serialized (queued) | — | 0 |
| composer co-writes | — | 0 |
| CAS rebase on apply | — | 0 |
| mean wait_ms (all intents) | — | 0 |
| mean wait_ms (waited only) | — | 0 (n=0) |
| p95 / max wait_ms | — | 0 / 0 |

## Latency / throughput (performance.now ms)

| metric | atm (none) | control (no ATM) |
|---|---|---|
| timing available | — | true |
| wall_clock_ms (first submit→last decision) | — | 2521.03 |
| throughput intents/s | — | 140.42 |
| goodput oracle-pass/s | — | 40.06 |
| latency_ms mean / p50 / p95 | — | 0 / 0 / 0 |
| wait_ms mean / p50 / p95 | — | 0 / 0 / 0 |
| apply_ms mean / p50 / p95 | — | 0.11 / 0.1 / 0.17 |
| total_ms mean / p50 / p95 | — | 40.69 / 41.19 / 58.99 |
| overhead_ms mean / p50 / p95 | — | 0.18 / 0.16 / 0.29 |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| direct_write | 0 | 354 | — |

## Reason codes

- atm: —
- control: racy_overwrite=287, clean=46, concurrent_no_clobber=21

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|
| control_racy_write | direct_write=301 |
| no_conflict | direct_write=53 |

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1062, bytes=618414, duration_ms=2528
