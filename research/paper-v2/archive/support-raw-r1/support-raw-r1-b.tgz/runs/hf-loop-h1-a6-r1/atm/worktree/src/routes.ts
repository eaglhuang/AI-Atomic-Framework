/** HTTP route table (HOT). */
export type Handler = (req: { path: string }) => { status: number; body: string };

// <region:users>
export const usersRoutes: Record<string, Handler> = {
  'GET /users': () => ({ status: 200, body: '[]' }),
  'POST /users': () => ({ status: 201, body: '{}' }),
};
// atm-edit s42-t000-i3 by cursor:mock-s3
// atm-edit s42-t001-i1 by claude:mock-s1
// atm-edit s42-t001-i0 by cursor:mock-s0
// atm-edit s42-t002-i3 by claude:mock-s4
// atm-edit s42-t004-i2 by codex:mock-s2
// atm-edit s42-t004-i0 by cursor:mock-s0
// atm-edit s42-t004-i5 by codex:mock-s5
// atm-edit s42-t007-i4 by claude:mock-s4
// atm-edit s42-t011-i3 by cursor:mock-s3
// atm-edit s42-t011-i4 by claude:mock-s4
// atm-edit s42-t016-i0 by cursor:mock-s0
// atm-edit s42-t017-i3 by claude:mock-s4
// atm-edit s42-t018-i4 by claude:mock-s4
// atm-edit s42-t020-i0 by cursor:mock-s0
// atm-edit s42-t023-i0 by cursor:mock-s0
// atm-edit s42-t025-i4 by claude:mock-s4
// atm-edit s42-t025-i3 by cursor:mock-s3
// atm-edit s42-t025-i1 by claude:mock-s1
// atm-edit s42-t026-i5 by codex:mock-s5
// atm-edit s42-t027-i4 by claude:mock-s4
// atm-edit s42-t027-i0 by cursor:mock-s0
// atm-edit s42-t030-i4 by claude:mock-s4
// atm-edit s42-t030-i0 by cursor:mock-s0
// atm-edit s42-t030-i5 by codex:mock-s5
// atm-edit s42-t032-i0 by cursor:mock-s0
// atm-edit s42-t034-i2 by codex:mock-s2
// atm-edit s42-t034-i4 by claude:mock-s4
// atm-edit s42-t035-i3 by cursor:mock-s3
// atm-edit s42-t036-i2 by codex:mock-s2
// atm-edit s42-t039-i2 by codex:mock-s2
// atm-edit s42-t039-i1 by claude:mock-s1
// atm-edit s42-t045-i2 by codex:mock-s2
// atm-edit s42-t044-i0 by cursor:mock-s0
// </region:users>

// <region:orders>
export const ordersRoutes: Record<string, Handler> = {
  'GET /orders': () => ({ status: 200, body: '[]' }),
};
// atm-edit s42-t000-i2 by codex:mock-s2
// atm-edit s42-t000-i1 by claude:mock-s1
// atm-edit s42-t001-i2 by claude:mock-s4
// atm-edit s42-t002-i1 by codex:mock-s2
// atm-edit s42-t003-i2 by codex:mock-s2
// atm-edit s42-t003-i4 by claude:mock-s4
// atm-edit s42-t004-i3 by cursor:mock-s3
// atm-edit s42-t005-i4 by claude:mock-s4
// atm-edit s42-t007-i3 by cursor:mock-s3
// atm-edit s42-t007-i0 by cursor:mock-s0
// atm-edit s42-t007-i2 by codex:mock-s2
// atm-edit s42-t009-i0 by cursor:mock-s0
// atm-edit s42-t009-i4 by claude:mock-s4
// atm-edit s42-t009-i2 by codex:mock-s2
// atm-edit s42-t011-i0 by cursor:mock-s0
// atm-edit s42-t011-i1 by claude:mock-s1
// atm-edit s42-t013-i2 by cursor:mock-s3
// atm-edit s42-t014-i3 by cursor:mock-s3
// atm-edit s42-t014-i0 by cursor:mock-s0
// atm-edit s42-t014-i4 by codex:mock-s5
// atm-edit s42-t017-i1 by codex:mock-s2
// atm-edit s42-t016-i1 by claude:mock-s1
// atm-edit s42-t018-i2 by codex:mock-s2
// atm-edit s42-t019-i0 by cursor:mock-s0
// atm-edit s42-t017-i4 by codex:mock-s5
// atm-edit s42-t020-i3 by claude:mock-s4
// atm-edit s42-t020-i2 by cursor:mock-s3
// atm-edit s42-t020-i1 by claude:mock-s1
// atm-edit s42-t021-i0 by cursor:mock-s0
// atm-edit s42-t026-i4 by claude:mock-s4
// atm-edit s42-t025-i0 by cursor:mock-s0
// atm-edit s42-t026-i1 by claude:mock-s1
// atm-edit s42-t027-i1 by claude:mock-s1
// atm-edit s42-t030-i2 by codex:mock-s2
// atm-edit s42-t034-i5 by codex:mock-s5
// atm-edit s42-t034-i3 by cursor:mock-s3
// atm-edit s42-t035-i4 by claude:mock-s4
// atm-edit s42-t038-i2 by codex:mock-s2
// atm-edit s42-t039-i5 by codex:mock-s5
// atm-edit s42-t040-i5 by codex:mock-s5
// atm-edit s42-t039-i3 by cursor:mock-s3
// atm-edit s42-t045-i1 by claude:mock-s1
// atm-edit s42-t045-i4 by claude:mock-s4
// atm-edit s42-t047-i1 by codex:mock-s2
// atm-edit s42-t047-i0 by claude:mock-s1
// </region:orders>

// <region:admin>
export const adminRoutes: Record<string, Handler> = {
  'GET /admin/health': () => ({ status: 200, body: 'ok' }),
};
// atm-edit s42-t000-i4 by claude:mock-s4
// atm-edit s42-t000-i5 by codex:mock-s5
// atm-edit s42-t003-i1 by claude:mock-s1
// atm-edit s42-t004-i1 by claude:mock-s1
// atm-edit s42-t004-i4 by claude:mock-s4
// atm-edit s42-t005-i0 by cursor:mock-s0
// atm-edit s42-t005-i3 by cursor:mock-s3
// atm-edit s42-t005-i2 by codex:mock-s2
// atm-edit s42-t007-i1 by claude:mock-s1
// atm-edit s42-t005-i5 by codex:mock-s5
// atm-edit s42-t009-i3 by cursor:mock-s3
// atm-edit s42-t007-i5 by codex:mock-s5
// atm-edit s42-t009-i1 by claude:mock-s1
// atm-edit s42-t009-i5 by codex:mock-s5
// atm-edit s42-t011-i2 by codex:mock-s2
// atm-edit s42-t014-i1 by claude:mock-s1
// atm-edit s42-t016-i2 by codex:mock-s2
// atm-edit s42-t016-i3 by cursor:mock-s3
// atm-edit s42-t016-i5 by codex:mock-s5
// atm-edit s42-t017-i0 by claude:mock-s1
// atm-edit s42-t018-i1 by claude:mock-s1
// atm-edit s42-t025-i2 by codex:mock-s2
// atm-edit s42-t026-i2 by codex:mock-s2
// atm-edit s42-t025-i5 by codex:mock-s5
// atm-edit s42-t026-i3 by cursor:mock-s3
// atm-edit s42-t027-i5 by codex:mock-s5
// atm-edit s42-t030-i1 by claude:mock-s1
// atm-edit s42-t031-i4 by claude:mock-s4
// atm-edit s42-t034-i0 by cursor:mock-s0
// atm-edit s42-t035-i2 by codex:mock-s2
// atm-edit s42-t035-i0 by cursor:mock-s0
// atm-edit s42-t035-i1 by claude:mock-s1
// atm-edit s42-t039-i0 by cursor:mock-s0
// atm-edit s42-t041-i2 by codex:mock-s2
// atm-edit s42-t045-i5 by codex:mock-s5
// atm-edit s42-t045-i3 by cursor:mock-s3
// atm-edit s42-t047-i2 by cursor:mock-s3
// atm-edit s42-t049-i5 by codex:mock-s5
// atm-edit s42-t046-i0 by cursor:mock-s0
// atm-edit s42-t047-i3 by claude:mock-s4
// </region:admin>

export function allRoutes(): Record<string, Handler> {
  return { ...usersRoutes, ...ordersRoutes, ...adminRoutes };
}
