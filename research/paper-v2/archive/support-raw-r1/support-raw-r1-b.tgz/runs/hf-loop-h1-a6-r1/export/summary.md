# atm-bench export — hf-loop-h1-a6-r1

- run_id: `hf-loop-h1-a6-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"sync"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=269 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 269 | — |
| contended intents | 219 | — |
| events_total | 929 | — |
| event types | submit=269, decision=269, oracle=269, enqueue=61, dequeue=61 | — |
| bytes (JSONL) | 1775757 | — |
| duration_ms | 2781 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=269 | — |
| committed | 269 | — |
| oracle pass (marker survives) | 269 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 61 | — |
| composer co-writes | 200 | — |
| CAS rebase on apply | 195 | — |
| mean wait_ms (all intents) | 5.8 | — |
| mean wait_ms (waited only) | 25.6 (n=61) | — |
| p95 / max wait_ms | 34 / 83 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2773.45 | — |
| throughput intents/s | 96.99 | — |
| goodput oracle-pass/s | 96.99 | — |
| latency_ms mean / p50 / p95 | 8.73 / 3.11 / 38.14 | — |
| wait_ms mean / p50 / p95 | 5.81 / 0 / 34 | — |
| apply_ms mean / p50 / p95 | 2.37 / 2.19 / 3.8 | — |
| total_ms mean / p50 / p95 | 53.88 / 53.92 / 89.85 | — |
| overhead_ms mean / p50 / p95 | 11.17 / 5.72 / 40.64 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 200 | 0 | 5.6 |
| hot_provisional | 69 | 0 | 6.4 |

## Reason codes

- atm: atm_compose+cas_rebase=145, atm_provisional_write_lease=45, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=42, overlay_wait_on_atm_true-conflict_then_proposal-required=16, atm_compose=11, atm_provisional_write_lease+cas_rebase=7, overlay_wait_on_atm_true-conflict_then_compose=2, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=123, hot_provisional=28 |
| composer_cowrite | composer_merge=56, hot_provisional=12 |
| no_conflict | hot_provisional=29, composer_merge=21 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=929, bytes=1775757, duration_ms=2781
