/** Mailer service (COLD). */
export interface Mail { to: string; subject: string; body: string }

// <region:body>
export function formatMail(mail: Mail): string {
  return `To: ${mail.to}\nSubject: ${mail.subject}\n\n${mail.body}`;
}
export function isValidAddress(addr: string): boolean {
  return addr.includes('@');
}
// atm-edit s42-t008-i2 by codex:mock-s2
// atm-edit s42-t008-i3 by claude:mock-s4
// atm-edit s42-t008-i4 by codex:mock-s5
// atm-edit s42-t008-i1 by claude:mock-s1
// atm-edit s42-t008-i0 by cursor:mock-s0
// atm-edit s42-t008-i5 by other:mock-s7
// atm-edit s42-t017-i2 by codex:mock-s2
// atm-edit s42-t019-i2 by codex:mock-s2
// atm-edit s42-t020-i2 by codex:mock-s2
// atm-edit s42-t017-i3 by cursor:mock-s3
// atm-edit s42-t019-i5 by other:mock-s6
// atm-edit s42-t017-i5 by codex:mock-s5
// atm-edit s42-t020-i6 by other:mock-s6
// atm-edit s42-t024-i2 by codex:mock-s2
// atm-edit s42-t017-i4 by claude:mock-s4
// atm-edit s42-t019-i3 by cursor:mock-s3
// atm-edit s42-t017-i6 by other:mock-s7
// atm-edit s42-t017-i1 by claude:mock-s1
// atm-edit s42-t020-i5 by codex:mock-s5
// atm-edit s42-t017-i0 by cursor:mock-s0
// atm-edit s42-t019-i4 by claude:mock-s4
// atm-edit s42-t024-i5 by other:mock-s6
// atm-edit s42-t020-i3 by cursor:mock-s3
// atm-edit s42-t019-i6 by other:mock-s7
// atm-edit s42-t019-i1 by claude:mock-s1
// atm-edit s42-t031-i2 by codex:mock-s2
// atm-edit s42-t019-i0 by cursor:mock-s0
// atm-edit s42-t020-i4 by claude:mock-s4
// atm-edit s42-t020-i1 by claude:mock-s1
// atm-edit s42-t024-i3 by cursor:mock-s3
// atm-edit s42-t020-i0 by cursor:mock-s0
// atm-edit s42-t024-i6 by other:mock-s7
// atm-edit s42-t031-i5 by other:mock-s6
// atm-edit s42-t031-i4 by codex:mock-s5
// atm-edit s42-t024-i4 by claude:mock-s4
// atm-edit s42-t024-i1 by claude:mock-s1
// atm-edit s42-t024-i0 by cursor:mock-s0
// atm-edit s42-t031-i3 by cursor:mock-s3
// atm-edit s42-t044-i2 by codex:mock-s2
// atm-edit s42-t031-i6 by other:mock-s7
// atm-edit s42-t044-i5 by other:mock-s6
// atm-edit s42-t031-i1 by claude:mock-s1
// atm-edit s42-t044-i4 by codex:mock-s5
// atm-edit s42-t031-i0 by cursor:mock-s0
// atm-edit s42-t054-i2 by codex:mock-s2
// atm-edit s42-t054-i6 by other:mock-s6
// atm-edit s42-t054-i5 by codex:mock-s5
// atm-edit s42-t044-i6 by other:mock-s7
// atm-edit s42-t044-i3 by claude:mock-s4
// atm-edit s42-t044-i1 by claude:mock-s1
// atm-edit s42-t054-i3 by cursor:mock-s3
// atm-edit s42-t044-i0 by cursor:mock-s0
// atm-edit s42-t054-i7 by other:mock-s7
// atm-edit s42-t054-i4 by claude:mock-s4
// atm-edit s42-t054-i1 by claude:mock-s1
// atm-edit s42-t054-i0 by cursor:mock-s0
// </region:body>
