# atm-bench export — hf-loop-h1-a8-r3

- run_id: `hf-loop-h1-a8-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"sync"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 1294 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=116, dequeue=116 | — |
| bytes (JSONL) | 2466734 | — |
| duration_ms | 2922 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 354 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 116 | — |
| composer co-writes | 294 | — |
| CAS rebase on apply | 290 | — |
| mean wait_ms (all intents) | 8.7 | — |
| mean wait_ms (waited only) | 26.6 (n=116) | — |
| p95 / max wait_ms | 45 / 93 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2911.15 | — |
| throughput intents/s | 121.6 | — |
| goodput oracle-pass/s | 121.6 | — |
| latency_ms mean / p50 / p95 | 11.77 / 3.44 / 48.52 | — |
| wait_ms mean / p50 / p95 | 8.73 / 0 / 45 | — |
| apply_ms mean / p50 / p95 | 2.27 / 2.12 / 3.28 | — |
| total_ms mean / p50 / p95 | 57.5 / 55.34 / 92.96 | — |
| overhead_ms mean / p50 / p95 | 14.11 / 5.89 / 50.66 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 294 | 0 | 8.2 |
| hot_provisional | 60 | 0 | 11.2 |

## Reason codes

- atm: atm_compose+cas_rebase=183, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=96, atm_provisional_write_lease=32, overlay_wait_on_atm_true-conflict_then_proposal-required=17, atm_compose=15, atm_provisional_write_lease+cas_rebase=8, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=3
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=212, hot_provisional=38 |
| no_conflict | composer_merge=35, hot_provisional=18 |
| composer_cowrite | composer_merge=47, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1294, bytes=2466734, duration_ms=2922
