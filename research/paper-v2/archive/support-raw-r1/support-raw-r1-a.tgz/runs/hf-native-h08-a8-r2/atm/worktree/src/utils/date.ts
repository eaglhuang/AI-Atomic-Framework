/** Date helpers (COLD). */
// <region:body>
export function isoDay(d: Date = new Date()): string {
  return d.toISOString().slice(0, 10);
}
export function addDays(d: Date, n: number): Date {
  const x = new Date(d.getTime());
  x.setUTCDate(x.getUTCDate() + n);
  return x;
}
// atm-edit s42-t000-i6 by other:mock-s6
// atm-edit s42-t000-i4 by claude:mock-s4
// atm-edit s42-t000-i3 by cursor:mock-s3
// atm-edit s42-t000-i7 by other:mock-s7
// atm-edit s42-t000-i2 by codex:mock-s2
// atm-edit s42-t000-i0 by cursor:mock-s0
// atm-edit s42-t000-i1 by claude:mock-s1
// atm-edit s42-t000-i5 by codex:mock-s5
// atm-edit s42-t004-i0 by cursor:mock-s0
// atm-edit s42-t004-i5 by codex:mock-s5
// atm-edit s42-t004-i7 by other:mock-s7
// atm-edit s42-t004-i1 by claude:mock-s1
// atm-edit s42-t004-i3 by cursor:mock-s3
// atm-edit s42-t046-i0 by cursor:mock-s0
// </region:body>
