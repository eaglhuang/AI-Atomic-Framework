# atm-bench export — hf-native-h08-a8-r2

- run_id: `hf-native-h08-a8-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0.8,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync"}`
- scenario reproducibility: **true** (`7422724bbf623e5c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 289 | — |
| events_total | 995 | — |
| event types | submit=354, decision=354, oracle=287 | — |
| bytes (JSONL) | 1915454 | — |
| duration_ms | 2576 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=287, reject=67 | — |
| committed | 287 | — |
| oracle pass (marker survives) | 287 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 81.1% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 206 | — |
| CAS rebase on apply | 204 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2567.88 | — |
| throughput intents/s | 137.86 | — |
| goodput oracle-pass/s | 111.77 | — |
| latency_ms mean / p50 / p95 | 2.71 / 2.84 / 4.39 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.89 / 2.03 / 3.31 | — |
| total_ms mean / p50 / p95 | 39.48 / 44.68 / 67.13 | — |
| overhead_ms mean / p50 / p95 | 4.68 / 5.11 / 7.22 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 206 | 0 | 0 |
| hot_provisional | 55 | 0 | 0 |
| reject | 67 | 0 | 0 |
| admit | 26 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=188, atm_true_conflict=67, atm_provisional_write_lease=45, atm_direct=20, atm_compose=18, atm_provisional_write_lease+cas_rebase=10, atm_direct+cas_rebase=6
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | composer_merge=71, admit=14 |
| no_conflict | hot_provisional=30, reject=13, admit=12, composer_merge=10 |
| hot_provisional | composer_merge=99, reject=54, hot_provisional=19 |
| composer_cowrite | composer_merge=26, hot_provisional=6 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=995, bytes=1915454, duration_ms=2576
