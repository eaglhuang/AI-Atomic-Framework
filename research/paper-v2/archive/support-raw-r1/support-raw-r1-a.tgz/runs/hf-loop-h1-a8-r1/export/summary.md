# atm-bench export — hf-loop-h1-a8-r1

- run_id: `hf-loop-h1-a8-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"sync"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 1288 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=113, dequeue=113 | — |
| bytes (JSONL) | 2457162 | — |
| duration_ms | 2991 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 354 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 113 | — |
| composer co-writes | 303 | — |
| CAS rebase on apply | 292 | — |
| mean wait_ms (all intents) | 8.2 | — |
| mean wait_ms (waited only) | 25.6 (n=113) | — |
| p95 / max wait_ms | 44 / 124 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2978.59 | — |
| throughput intents/s | 118.85 | — |
| goodput oracle-pass/s | 118.85 | — |
| latency_ms mean / p50 / p95 | 11.2 / 3.43 / 46 | — |
| wait_ms mean / p50 / p95 | 8.17 / 0 / 44 | — |
| apply_ms mean / p50 / p95 | 2.29 / 2.14 / 3.39 | — |
| total_ms mean / p50 / p95 | 57.19 / 55.23 / 93.26 | — |
| overhead_ms mean / p50 / p95 | 13.55 / 5.83 / 47.75 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 303 | 0 | 7.5 |
| hot_provisional | 51 | 0 | 12.2 |

## Reason codes

- atm: atm_compose+cas_rebase=193, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=90, atm_provisional_write_lease=29, overlay_wait_on_atm_true-conflict_then_proposal-required=13, atm_compose=12, overlay_wait_on_atm_true-conflict_then_compose=8, atm_provisional_write_lease+cas_rebase=7, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=226, hot_provisional=24 |
| no_conflict | composer_merge=32, hot_provisional=21 |
| composer_cowrite | composer_merge=45, hot_provisional=6 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1288, bytes=2457162, duration_ms=2991
