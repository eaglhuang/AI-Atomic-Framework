/** App entry (COLD). */
import { dbConfig, featureFlags } from './config.ts';
import { allRoutes } from './routes.ts';
import { initialState } from './store.ts';

// <region:body>
export function boot(): { ok: true; routes: number; db: string } {
  const routes = allRoutes();
  return {
    ok: true,
    routes: Object.keys(routes).length,
    db: `${dbConfig.host}/${dbConfig.name}`,
  };
}

export function isBillingV2(): boolean {
  return featureFlags.billingV2;
}

export { initialState };
// atm-edit s42-t000-i4 by claude:mock-s4
// atm-edit s42-t001-i9 by codex:mock-s10
// atm-edit s42-t002-i4 by codex:mock-s5
// atm-edit s42-t003-i9 by cursor:mock-s11
// atm-edit s42-t004-i0 by cursor:mock-s0
// atm-edit s42-t005-i4 by claude:mock-s4
// atm-edit s42-t006-i4 by claude:mock-s4
// atm-edit s42-t007-i4 by claude:mock-s4
// atm-edit s42-t008-i4 by claude:mock-s4
// atm-edit s42-t009-i14 by other:mock-s15
// atm-edit s42-t010-i6 by other:mock-s6
// atm-edit s42-t011-i5 by other:mock-s6
// atm-edit s42-t012-i11 by cursor:mock-s11
// atm-edit s42-t013-i9 by cursor:mock-s11
// atm-edit s42-t014-i10 by cursor:mock-s11
// atm-edit s42-t015-i2 by codex:mock-s2
// atm-edit s42-t016-i2 by cursor:mock-s3
// atm-edit s42-t017-i1 by claude:mock-s1
// atm-edit s42-t018-i13 by codex:mock-s13
// atm-edit s42-t019-i11 by cursor:mock-s11
// atm-edit s42-t020-i4 by codex:mock-s5
// atm-edit s42-t021-i12 by other:mock-s15
// atm-edit s42-t022-i8 by cursor:mock-s8
// atm-edit s42-t023-i6 by other:mock-s7
// atm-edit s42-t024-i6 by other:mock-s7
// atm-edit s42-t025-i11 by codex:mock-s13
// atm-edit s42-t026-i11 by codex:mock-s13
// atm-edit s42-t027-i9 by claude:mock-s9
// atm-edit s42-t028-i2 by cursor:mock-s3
// atm-edit s42-t029-i5 by codex:mock-s5
// atm-edit s42-t030-i9 by codex:mock-s10
// atm-edit s42-t031-i4 by codex:mock-s5
// atm-edit s42-t032-i3 by claude:mock-s4
// atm-edit s42-t033-i7 by claude:mock-s9
// atm-edit s42-t034-i8 by cursor:mock-s8
// atm-edit s42-t035-i5 by cursor:mock-s8
// atm-edit s42-t036-i14 by other:mock-s14
// atm-edit s42-t037-i2 by codex:mock-s2
// atm-edit s42-t038-i2 by codex:mock-s2
// atm-edit s42-t039-i2 by codex:mock-s2
// atm-edit s42-t040-i7 by claude:mock-s9
// atm-edit s42-t041-i14 by other:mock-s14
// atm-edit s42-t042-i6 by other:mock-s6
// atm-edit s42-t043-i7 by other:mock-s7
// atm-edit s42-t044-i6 by claude:mock-s9
// atm-edit s42-t045-i5 by codex:mock-s5
// atm-edit s42-t046-i5 by other:mock-s7
// atm-edit s42-t047-i14 by other:mock-s14
// atm-edit s42-t048-i3 by cursor:mock-s3
// atm-edit s42-t049-i7 by cursor:mock-s8
// atm-edit s42-t050-i8 by cursor:mock-s8
// atm-edit s42-t051-i8 by cursor:mock-s8
// atm-edit s42-t052-i8 by claude:mock-s9
// atm-edit s42-t053-i12 by claude:mock-s12
// atm-edit s42-t054-i12 by claude:mock-s12
// atm-edit s42-t055-i10 by cursor:mock-s11
// atm-edit s42-t056-i9 by cursor:mock-s11
// atm-edit s42-t057-i3 by claude:mock-s4
// atm-edit s42-t058-i3 by codex:mock-s5
// atm-edit s42-t059-i5 by codex:mock-s5
// </region:body>
