# atm-bench export — hf-nativestale-h1-a8-r1

- run_id: `hf-nativestale-h1-a8-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"stale"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 971 | — |
| event types | submit=354, decision=354, oracle=263 | — |
| bytes (JSONL) | 1890850 | — |
| duration_ms | 2549 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=263, reject=91 | — |
| committed | 263 | — |
| oracle pass (marker survives) | 94 | — |
| lost updates (oracle fail) | 169 | — |
| integration pass rate of committed | 35.7% | — |
| effective success rate of all intents | 26.6% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 207 | — |
| CAS rebase on apply | 206 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2541.25 | — |
| throughput intents/s | 139.3 | — |
| goodput oracle-pass/s | 36.99 | — |
| latency_ms mean / p50 / p95 | 2.6 / 2.76 / 4.64 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.75 / 2.02 / 3.22 | — |
| total_ms mean / p50 / p95 | 36.55 / 41.31 / 65.96 | — |
| overhead_ms mean / p50 / p95 | 4.45 / 5.07 / 7.41 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 207 | 0 | 0 |
| hot_provisional | 56 | 0 | 0 |
| reject | 91 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=191, atm_true_conflict=91, atm_provisional_write_lease=41, atm_compose=16, atm_provisional_write_lease+cas_rebase=15
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=153, reject=78, hot_provisional=19 |
| no_conflict | hot_provisional=30, composer_merge=17, reject=6 |
| composer_cowrite | composer_merge=37, hot_provisional=7, reject=7 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=971, bytes=1890850, duration_ms=2549
