/** App entry (COLD). */
import { dbConfig, featureFlags } from './config.ts';
import { allRoutes } from './routes.ts';
import { initialState } from './store.ts';

// <region:body>
export function boot(): { ok: true; routes: number; db: string } {
  const routes = allRoutes();
  return {
    ok: true,
    routes: Object.keys(routes).length,
    db: `${dbConfig.host}/${dbConfig.name}`,
  };
}

export function isBillingV2(): boolean {
  return featureFlags.billingV2;
}

export { initialState };
// atm-edit s42-t012-i1 by claude:mock-s1
// atm-edit s42-t012-i10 by codex:mock-s10
// atm-edit s42-t012-i3 by cursor:mock-s3
// atm-edit s42-t012-i2 by codex:mock-s2
// atm-edit s42-t012-i9 by claude:mock-s9
// atm-edit s42-t012-i4 by claude:mock-s4
// atm-edit s42-t012-i5 by codex:mock-s5
// atm-edit s42-t012-i6 by other:mock-s6
// atm-edit s42-t012-i11 by cursor:mock-s11
// atm-edit s42-t017-i4 by claude:mock-s4
// atm-edit s42-t012-i13 by codex:mock-s13
// atm-edit s42-t012-i0 by cursor:mock-s0
// atm-edit s42-t017-i9 by codex:mock-s10
// atm-edit s42-t012-i14 by other:mock-s14
// atm-edit s42-t017-i1 by claude:mock-s1
// atm-edit s42-t012-i7 by other:mock-s7
// atm-edit s42-t017-i3 by cursor:mock-s3
// atm-edit s42-t017-i6 by other:mock-s6
// atm-edit s42-t012-i8 by cursor:mock-s8
// atm-edit s42-t017-i2 by codex:mock-s2
// atm-edit s42-t030-i4 by claude:mock-s4
// atm-edit s42-t017-i8 by claude:mock-s9
// atm-edit s42-t012-i12 by claude:mock-s12
// atm-edit s42-t012-i15 by other:mock-s15
// atm-edit s42-t030-i9 by codex:mock-s10
// atm-edit s42-t017-i5 by codex:mock-s5
// atm-edit s42-t017-i0 by cursor:mock-s0
// atm-edit s42-t036-i4 by claude:mock-s4
// atm-edit s42-t017-i10 by cursor:mock-s11
// atm-edit s42-t017-i12 by codex:mock-s13
// atm-edit s42-t017-i13 by other:mock-s14
// atm-edit s42-t030-i1 by claude:mock-s1
// atm-edit s42-t017-i7 by cursor:mock-s8
// atm-edit s42-t017-i11 by claude:mock-s12
// atm-edit s42-t017-i14 by other:mock-s15
// atm-edit s42-t030-i3 by cursor:mock-s3
// atm-edit s42-t036-i10 by codex:mock-s10
// atm-edit s42-t042-i4 by claude:mock-s4
// atm-edit s42-t036-i3 by cursor:mock-s3
// atm-edit s42-t030-i6 by other:mock-s6
// atm-edit s42-t042-i3 by cursor:mock-s3
// atm-edit s42-t036-i1 by claude:mock-s1
// atm-edit s42-t030-i2 by codex:mock-s2
// atm-edit s42-t047-i4 by claude:mock-s4
// atm-edit s42-t049-i4 by claude:mock-s4
// atm-edit s42-t042-i10 by codex:mock-s10
// atm-edit s42-t042-i1 by claude:mock-s1
// atm-edit s42-t047-i3 by cursor:mock-s3
// atm-edit s42-t052-i4 by claude:mock-s4
// atm-edit s42-t030-i8 by claude:mock-s9
// atm-edit s42-t030-i0 by cursor:mock-s0
// atm-edit s42-t049-i3 by cursor:mock-s3
// atm-edit s42-t030-i5 by codex:mock-s5
// atm-edit s42-t036-i6 by other:mock-s6
// atm-edit s42-t036-i2 by codex:mock-s2
// atm-edit s42-t047-i10 by codex:mock-s10
// atm-edit s42-t030-i10 by cursor:mock-s11
// atm-edit s42-t055-i4 by claude:mock-s4
// atm-edit s42-t047-i1 by claude:mock-s1
// atm-edit s42-t030-i13 by other:mock-s14
// atm-edit s42-t052-i3 by cursor:mock-s3
// atm-edit s42-t030-i12 by codex:mock-s13
// atm-edit s42-t049-i1 by claude:mock-s1
// atm-edit s42-t030-i7 by other:mock-s7
// atm-edit s42-t042-i6 by other:mock-s6
// atm-edit s42-t052-i9 by codex:mock-s10
// atm-edit s42-t036-i9 by claude:mock-s9
// atm-edit s42-t042-i2 by codex:mock-s2
// atm-edit s42-t030-i14 by other:mock-s15
// atm-edit s42-t036-i0 by cursor:mock-s0
// atm-edit s42-t052-i1 by claude:mock-s1
// atm-edit s42-t036-i5 by codex:mock-s5
// atm-edit s42-t030-i11 by claude:mock-s12
// atm-edit s42-t036-i11 by cursor:mock-s11
// atm-edit s42-t055-i3 by cursor:mock-s3
// atm-edit s42-t036-i13 by codex:mock-s13
// atm-edit s42-t036-i14 by other:mock-s14
// atm-edit s42-t055-i9 by codex:mock-s10
// atm-edit s42-t036-i8 by cursor:mock-s8
// atm-edit s42-t042-i9 by claude:mock-s9
// atm-edit s42-t036-i7 by other:mock-s7
// atm-edit s42-t047-i6 by other:mock-s6
// atm-edit s42-t042-i5 by codex:mock-s5
// atm-edit s42-t042-i0 by cursor:mock-s0
// atm-edit s42-t055-i1 by claude:mock-s1
// atm-edit s42-t047-i2 by codex:mock-s2
// atm-edit s42-t036-i15 by other:mock-s15
// atm-edit s42-t042-i11 by cursor:mock-s11
// atm-edit s42-t049-i6 by other:mock-s6
// atm-edit s42-t036-i12 by claude:mock-s12
// atm-edit s42-t047-i5 by codex:mock-s5
// atm-edit s42-t047-i9 by claude:mock-s9
// atm-edit s42-t042-i13 by codex:mock-s13
// atm-edit s42-t047-i0 by cursor:mock-s0
// atm-edit s42-t049-i2 by codex:mock-s2
// atm-edit s42-t049-i5 by codex:mock-s5
// atm-edit s42-t042-i14 by other:mock-s14
// atm-edit s42-t042-i8 by cursor:mock-s8
// atm-edit s42-t052-i5 by other:mock-s6
// atm-edit s42-t042-i7 by other:mock-s7
// atm-edit s42-t047-i11 by cursor:mock-s11
// atm-edit s42-t049-i8 by claude:mock-s9
// atm-edit s42-t042-i15 by other:mock-s15
// atm-edit s42-t049-i0 by cursor:mock-s0
// atm-edit s42-t052-i2 by codex:mock-s2
// atm-edit s42-t042-i12 by claude:mock-s12
// atm-edit s42-t055-i5 by other:mock-s6
// atm-edit s42-t049-i9 by cursor:mock-s11
// atm-edit s42-t047-i13 by codex:mock-s13
// atm-edit s42-t047-i8 by cursor:mock-s8
// atm-edit s42-t052-i8 by claude:mock-s9
// atm-edit s42-t049-i11 by codex:mock-s13
// atm-edit s42-t052-i0 by cursor:mock-s0
// atm-edit s42-t047-i14 by other:mock-s14
// atm-edit s42-t049-i7 by cursor:mock-s8
// atm-edit s42-t055-i2 by codex:mock-s2
// atm-edit s42-t052-i10 by cursor:mock-s11
// atm-edit s42-t047-i7 by other:mock-s7
// atm-edit s42-t047-i12 by claude:mock-s12
// atm-edit s42-t055-i8 by claude:mock-s9
// atm-edit s42-t052-i12 by codex:mock-s13
// atm-edit s42-t049-i10 by claude:mock-s12
// atm-edit s42-t047-i15 by other:mock-s15
// atm-edit s42-t055-i0 by cursor:mock-s0
// atm-edit s42-t052-i11 by claude:mock-s12
// atm-edit s42-t049-i12 by other:mock-s15
// atm-edit s42-t052-i7 by cursor:mock-s8
// atm-edit s42-t052-i13 by other:mock-s14
// atm-edit s42-t055-i10 by cursor:mock-s11
// atm-edit s42-t052-i6 by other:mock-s7
// atm-edit s42-t055-i12 by codex:mock-s13
// atm-edit s42-t055-i11 by claude:mock-s12
// atm-edit s42-t052-i14 by other:mock-s15
// atm-edit s42-t055-i7 by cursor:mock-s8
// atm-edit s42-t055-i13 by other:mock-s14
// atm-edit s42-t055-i6 by other:mock-s7
// atm-edit s42-t055-i14 by other:mock-s15
// </region:body>
