/** Math helpers (COLD). */
// <region:body>
export function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}
export function sum(xs: readonly number[]): number {
  return xs.reduce((a, b) => a + b, 0);
}
// atm-edit s42-t002-i3 by cursor:mock-s3
// atm-edit s42-t002-i2 by codex:mock-s2
// atm-edit s42-t002-i5 by codex:mock-s5
// atm-edit s42-t002-i4 by claude:mock-s4
// atm-edit s42-t005-i3 by cursor:mock-s3
// atm-edit s42-t008-i0 by cursor:mock-s0
// atm-edit s42-t010-i2 by codex:mock-s2
// atm-edit s42-t014-i2 by codex:mock-s2
// atm-edit s42-t016-i4 by claude:mock-s4
// atm-edit s42-t016-i3 by cursor:mock-s3
// atm-edit s42-t016-i5 by codex:mock-s5
// atm-edit s42-t027-i1 by claude:mock-s1
// atm-edit s42-t029-i0 by cursor:mock-s0
// </region:body>
