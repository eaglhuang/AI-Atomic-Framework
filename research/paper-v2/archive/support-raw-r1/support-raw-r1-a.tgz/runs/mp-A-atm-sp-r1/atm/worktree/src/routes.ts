/** HTTP route table (HOT). */
export type Handler = (req: { path: string }) => { status: number; body: string };

// <region:users>
export const usersRoutes: Record<string, Handler> = {
  'GET /users': () => ({ status: 200, body: '[]' }),
  'POST /users': () => ({ status: 201, body: '{}' }),
};
// atm-edit s42-t000-i5 by codex:mock-s5
// atm-edit s42-t011-i5 by codex:mock-s5
// atm-edit s42-t022-i1 by claude:mock-s1
// </region:users>

// <region:orders>
export const ordersRoutes: Record<string, Handler> = {
  'GET /orders': () => ({ status: 200, body: '[]' }),
};
// atm-edit s42-t000-i2 by codex:mock-s2
// atm-edit s42-t012-i3 by cursor:mock-s3
// atm-edit s42-t012-i0 by cursor:mock-s0
// atm-edit s42-t012-i4 by codex:mock-s5
// atm-edit s42-t014-i4 by claude:mock-s4
// atm-edit s42-t017-i5 by codex:mock-s5
// </region:orders>

// <region:admin>
export const adminRoutes: Record<string, Handler> = {
  'GET /admin/health': () => ({ status: 200, body: 'ok' }),
};
// atm-edit s42-t002-i0 by cursor:mock-s0
// atm-edit s42-t005-i2 by codex:mock-s2
// atm-edit s42-t007-i0 by cursor:mock-s0
// atm-edit s42-t012-i1 by claude:mock-s1
// atm-edit s42-t014-i3 by cursor:mock-s3
// atm-edit s42-t021-i2 by codex:mock-s2
// atm-edit s42-t023-i5 by codex:mock-s5
// atm-edit s42-t029-i4 by claude:mock-s4
// </region:admin>

export function allRoutes(): Record<string, Handler> {
  return { ...usersRoutes, ...ordersRoutes, ...adminRoutes };
}
