/** String helpers (COLD). */
// <region:body>
export function trim(s: string): string {
  return s.trim();
}
export function slugify(s: string): string {
  return trim(s).toLowerCase().replace(/\s+/g, '-');
}
// atm-edit s42-t000-i0 by cursor:mock-s0
// atm-edit s42-t003-i1 by claude:mock-s1
// atm-edit s42-t004-i5 by codex:mock-s5
// atm-edit s42-t008-i5 by codex:mock-s5
// atm-edit s42-t010-i5 by codex:mock-s5
// atm-edit s42-t011-i1 by claude:mock-s1
// atm-edit s42-t011-i4 by claude:mock-s4
// atm-edit s42-t013-i3 by claude:mock-s4
// atm-edit s42-t016-i1 by claude:mock-s1
// atm-edit s42-t018-i1 by codex:mock-s2
// atm-edit s42-t018-i2 by cursor:mock-s3
// atm-edit s42-t020-i1 by codex:mock-s2
// atm-edit s42-t020-i2 by cursor:mock-s3
// atm-edit s42-t020-i3 by codex:mock-s5
// atm-edit s42-t027-i4 by claude:mock-s4
// atm-edit s42-t027-i0 by cursor:mock-s0
// atm-edit s42-t027-i5 by codex:mock-s5
// </region:body>
