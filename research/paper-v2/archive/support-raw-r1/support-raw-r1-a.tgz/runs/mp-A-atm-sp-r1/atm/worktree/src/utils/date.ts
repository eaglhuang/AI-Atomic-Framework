/** Date helpers (COLD). */
// <region:body>
export function isoDay(d: Date = new Date()): string {
  return d.toISOString().slice(0, 10);
}
export function addDays(d: Date, n: number): Date {
  const x = new Date(d.getTime());
  x.setUTCDate(x.getUTCDate() + n);
  return x;
}
// atm-edit s42-t004-i4 by claude:mock-s4
// atm-edit s42-t005-i5 by codex:mock-s5
// atm-edit s42-t014-i1 by claude:mock-s1
// atm-edit s42-t019-i3 by cursor:mock-s3
// atm-edit s42-t023-i4 by claude:mock-s4
// atm-edit s42-t024-i0 by cursor:mock-s0
// atm-edit s42-t024-i3 by cursor:mock-s3
// atm-edit s42-t024-i4 by claude:mock-s4
// atm-edit s42-t025-i2 by codex:mock-s2
// atm-edit s42-t026-i3 by claude:mock-s4
// atm-edit s42-t024-i5 by codex:mock-s5
// </region:body>
