/** Billing service (COLD). */
export interface LineItem { sku: string; qty: number; unitCents: number }

// <region:body>
export function totalCents(items: readonly LineItem[]): number {
  return items.reduce((s, i) => s + i.qty * i.unitCents, 0);
}
export function formatMoney(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}
// atm-edit s42-t001-i1 by codex:mock-s2
// atm-edit s42-t008-i0 by cursor:mock-s0
// atm-edit s42-t025-i4 by claude:mock-s4
// atm-edit s42-t032-i11 by claude:mock-s12
// atm-edit s42-t037-i6 by other:mock-s7
// atm-edit s42-t045-i14 by other:mock-s15
// atm-edit s42-t046-i12 by other:mock-s15
// atm-edit s42-t050-i5 by codex:mock-s5
// atm-edit s42-t053-i0 by cursor:mock-s0
// </region:body>
