# atm-bench export — hf-loopstale-h1-a6-r3

- run_id: `hf-loopstale-h1-a6-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"stale"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=269 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 269 | — |
| contended intents | 219 | — |
| events_total | 927 | — |
| event types | submit=269, decision=269, oracle=269, enqueue=60, dequeue=60 | — |
| bytes (JSONL) | 1779850 | — |
| duration_ms | 2735 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=269 | — |
| committed | 269 | — |
| oracle pass (marker survives) | 121 | — |
| lost updates (oracle fail) | 148 | — |
| integration pass rate of committed | 45% | — |
| effective success rate of all intents | 45% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 60 | — |
| composer co-writes | 200 | — |
| CAS rebase on apply | 196 | — |
| mean wait_ms (all intents) | 5.2 | — |
| mean wait_ms (waited only) | 23.2 (n=60) | — |
| p95 / max wait_ms | 36 / 57 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2726.53 | — |
| throughput intents/s | 98.66 | — |
| goodput oracle-pass/s | 44.38 | — |
| latency_ms mean / p50 / p95 | 7.86 / 2.82 / 39.1 | — |
| wait_ms mean / p50 / p95 | 5.17 / 0 / 36 | — |
| apply_ms mean / p50 / p95 | 2.12 / 1.99 / 3.18 | — |
| total_ms mean / p50 / p95 | 52.39 / 52.53 / 90.72 | — |
| overhead_ms mean / p50 / p95 | 10.07 / 5.07 / 41.2 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 200 | 0 | 5.5 |
| hot_provisional | 69 | 0 | 4.1 |

## Reason codes

- atm: atm_compose+cas_rebase=145, atm_provisional_write_lease=50, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=44, overlay_wait_on_atm_true-conflict_then_proposal-required=12, atm_compose=9, atm_provisional_write_lease+cas_rebase=5, overlay_wait_on_atm_true-conflict_then_compose=2, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=121, hot_provisional=30 |
| composer_cowrite | composer_merge=57, hot_provisional=11 |
| no_conflict | hot_provisional=28, composer_merge=22 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=927, bytes=1779850, duration_ms=2735
