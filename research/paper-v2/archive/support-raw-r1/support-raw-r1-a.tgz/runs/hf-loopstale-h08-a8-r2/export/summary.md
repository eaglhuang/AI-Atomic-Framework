# atm-bench export — hf-loopstale-h08-a8-r2

- run_id: `hf-loopstale-h08-a8-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0.8,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"stale"}`
- scenario reproducibility: **true** (`7422724bbf623e5c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 289 | — |
| events_total | 1204 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=71, dequeue=71 | — |
| bytes (JSONL) | 2302613 | — |
| duration_ms | 2755 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 157 | — |
| lost updates (oracle fail) | 197 | — |
| integration pass rate of committed | 44.4% | — |
| effective success rate of all intents | 44.4% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 71 | — |
| composer co-writes | 260 | — |
| CAS rebase on apply | 248 | — |
| mean wait_ms (all intents) | 5.2 | — |
| mean wait_ms (waited only) | 26 (n=71) | — |
| p95 / max wait_ms | 39 / 75 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2743.59 | — |
| throughput intents/s | 129.03 | — |
| goodput oracle-pass/s | 57.22 | — |
| latency_ms mean / p50 / p95 | 8.33 / 3.21 / 42.34 | — |
| wait_ms mean / p50 / p95 | 5.21 / 0 / 39 | — |
| apply_ms mean / p50 / p95 | 2.29 / 2.14 / 3.41 | — |
| total_ms mean / p50 / p95 | 54.22 / 53.11 / 89.29 | — |
| overhead_ms mean / p50 / p95 | 10.7 / 5.59 / 44.73 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 260 | 0 | 5.8 |
| hot_provisional | 55 | 0 | 6 |
| admit | 39 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=184, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=52, atm_provisional_write_lease=36, atm_direct=34, atm_compose=19, overlay_wait_on_atm_true-conflict_then_proposal-required=12, atm_provisional_write_lease+cas_rebase=5, overlay_wait_on_atm_true-conflict_then_compose=5, atm_direct+cas_rebase=5, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | composer_merge=59, admit=26 |
| no_conflict | hot_provisional=27, composer_merge=25, admit=13 |
| hot_provisional | composer_merge=148, hot_provisional=24 |
| composer_cowrite | composer_merge=28, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1204, bytes=2302613, duration_ms=2755
