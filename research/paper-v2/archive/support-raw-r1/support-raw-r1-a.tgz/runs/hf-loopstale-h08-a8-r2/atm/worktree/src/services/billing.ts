/** Billing service (COLD). */
export interface LineItem { sku: string; qty: number; unitCents: number }

// <region:body>
export function totalCents(items: readonly LineItem[]): number {
  return items.reduce((s, i) => s + i.qty * i.unitCents, 0);
}
export function formatMoney(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}
// atm-edit s42-t004-i2 by codex:mock-s2
// atm-edit s42-t015-i1 by claude:mock-s1
// atm-edit s42-t022-i7 by other:mock-s7
// atm-edit s42-t022-i5 by codex:mock-s5
// atm-edit s42-t022-i3 by cursor:mock-s3
// atm-edit s42-t026-i4 by claude:mock-s4
// atm-edit s42-t026-i6 by other:mock-s6
// atm-edit s42-t026-i3 by cursor:mock-s3
// atm-edit s42-t037-i1 by codex:mock-s2
// atm-edit s42-t041-i1 by claude:mock-s1
// atm-edit s42-t041-i2 by codex:mock-s2
// atm-edit s42-t041-i7 by other:mock-s7
// atm-edit s42-t041-i0 by cursor:mock-s0
// </region:body>
