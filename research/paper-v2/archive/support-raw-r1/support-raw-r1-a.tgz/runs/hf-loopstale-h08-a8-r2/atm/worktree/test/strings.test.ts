/** Tiny oracle-friendly test module (COLD). */
import { slugify, trim } from '../src/utils/strings.ts';

// <region:body>
export function runStringsSelfTest(): boolean {
  return trim('  x  ') === 'x' && slugify('Hello World') === 'hello-world';
}
// atm-edit s42-t006-i2 by claude:mock-s4
// atm-edit s42-t012-i7 by other:mock-s7
// atm-edit s42-t012-i2 by codex:mock-s2
// atm-edit s42-t012-i1 by claude:mock-s1
// atm-edit s42-t028-i5 by codex:mock-s5
// </region:body>
