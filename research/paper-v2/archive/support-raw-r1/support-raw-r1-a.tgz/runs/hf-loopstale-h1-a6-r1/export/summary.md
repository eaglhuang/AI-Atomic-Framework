# atm-bench export — hf-loopstale-h1-a6-r1

- run_id: `hf-loopstale-h1-a6-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"stale"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=269 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 269 | — |
| contended intents | 219 | — |
| events_total | 937 | — |
| event types | submit=269, decision=269, oracle=269, enqueue=65, dequeue=65 | — |
| bytes (JSONL) | 1797892 | — |
| duration_ms | 2841 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=269 | — |
| committed | 269 | — |
| oracle pass (marker survives) | 126 | — |
| lost updates (oracle fail) | 143 | — |
| integration pass rate of committed | 46.8% | — |
| effective success rate of all intents | 46.8% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 65 | — |
| composer co-writes | 201 | — |
| CAS rebase on apply | 196 | — |
| mean wait_ms (all intents) | 6.3 | — |
| mean wait_ms (waited only) | 26.1 (n=65) | — |
| p95 / max wait_ms | 37 / 107 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2833.07 | — |
| throughput intents/s | 94.95 | — |
| goodput oracle-pass/s | 44.47 | — |
| latency_ms mean / p50 / p95 | 9.21 / 3.14 / 38.51 | — |
| wait_ms mean / p50 / p95 | 6.32 / 0 / 37 | — |
| apply_ms mean / p50 / p95 | 2.38 / 2.25 / 3.6 | — |
| total_ms mean / p50 / p95 | 54.17 / 53.67 / 87.62 | — |
| overhead_ms mean / p50 / p95 | 11.68 / 5.72 / 41.38 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 201 | 0 | 6.1 |
| hot_provisional | 68 | 0 | 6.8 |

## Reason codes

- atm: atm_compose+cas_rebase=137, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=46, atm_provisional_write_lease=42, atm_compose=16, overlay_wait_on_atm_true-conflict_then_proposal-required=13, atm_provisional_write_lease+cas_rebase=9, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=4, overlay_wait_on_atm_true-conflict_then_compose=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=114, hot_provisional=37 |
| composer_cowrite | composer_merge=55, hot_provisional=13 |
| no_conflict | composer_merge=32, hot_provisional=18 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=937, bytes=1797892, duration_ms=2841
