/** In-memory store slices (HOT). */
export type State = { users: string[]; orders: number[]; meta: Record<string, string> };

// <region:reducers>
export function reduceUsers(state: State, user: string): State {
  return { ...state, users: [...state.users, user] };
}
// atm-edit s42-t008-i1 by claude:mock-s1
// atm-edit s42-t013-i3 by claude:mock-s4
// atm-edit s42-t031-i0 by cursor:mock-s0
// atm-edit s42-t031-i1 by claude:mock-s1
// atm-edit s42-t036-i4 by codex:mock-s5
// atm-edit s42-t041-i4 by codex:mock-s5
// atm-edit s42-t040-i3 by cursor:mock-s3
// atm-edit s42-t040-i0 by cursor:mock-s0
// atm-edit s42-t042-i0 by cursor:mock-s0
// atm-edit s42-t044-i3 by cursor:mock-s3
// atm-edit s42-t048-i0 by cursor:mock-s0
// </region:reducers>

// <region:selectors>
export function selectUserCount(state: State): number {
  return state.users.length;
}
// atm-edit s42-t001-i3 by codex:mock-s5
// atm-edit s42-t002-i4 by codex:mock-s5
// atm-edit s42-t006-i1 by claude:mock-s1
// atm-edit s42-t010-i3 by cursor:mock-s3
// atm-edit s42-t010-i2 by codex:mock-s2
// atm-edit s42-t012-i3 by cursor:mock-s3
// atm-edit s42-t016-i4 by claude:mock-s4
// atm-edit s42-t018-i3 by cursor:mock-s3
// atm-edit s42-t019-i1 by codex:mock-s2
// atm-edit s42-t021-i2 by codex:mock-s2
// atm-edit s42-t024-i3 by codex:mock-s5
// atm-edit s42-t027-i2 by codex:mock-s2
// atm-edit s42-t028-i2 by codex:mock-s2
// atm-edit s42-t041-i0 by cursor:mock-s0
// atm-edit s42-t048-i2 by codex:mock-s2
// atm-edit s42-t048-i4 by claude:mock-s4
// atm-edit s42-t048-i1 by claude:mock-s1
// </region:selectors>

// <region:actions>
export function createOrder(state: State, id: number): State {
  return { ...state, orders: [...state.orders, id] };
}
// atm-edit s42-t006-i2 by codex:mock-s2
// atm-edit s42-t008-i0 by cursor:mock-s0
// atm-edit s42-t012-i4 by codex:mock-s5
// atm-edit s42-t013-i1 by claude:mock-s1
// atm-edit s42-t029-i1 by codex:mock-s2
// atm-edit s42-t028-i5 by codex:mock-s5
// atm-edit s42-t028-i0 by cursor:mock-s0
// atm-edit s42-t031-i2 by codex:mock-s2
// atm-edit s42-t032-i2 by codex:mock-s2
// atm-edit s42-t036-i3 by cursor:mock-s3
// atm-edit s42-t048-i5 by codex:mock-s5
// atm-edit s42-t044-i1 by claude:mock-s1
// </region:actions>

export const initialState: State = { users: [], orders: [], meta: {} };
