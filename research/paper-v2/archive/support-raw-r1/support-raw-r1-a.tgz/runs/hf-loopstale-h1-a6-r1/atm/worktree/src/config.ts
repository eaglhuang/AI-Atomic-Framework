/** App config (HOT) — writable via ATM WriteIntent bounded regions. */
export interface DbConfig { host: string; port: number; name: string }
export interface CacheConfig { ttlSec: number; backend: 'memory' | 'redis' }
export interface FeatureFlags { billingV2: boolean; experimentalSearch: boolean }

// <region:db>
export const dbConfig: DbConfig = {
  host: 'localhost',
  port: 5432,
  name: 'app',
};
// atm-edit s42-t005-i1 by claude:mock-s1
// atm-edit s42-t006-i0 by cursor:mock-s0
// atm-edit s42-t010-i5 by codex:mock-s5
// atm-edit s42-t015-i3 by claude:mock-s4
// atm-edit s42-t017-i2 by cursor:mock-s3
// atm-edit s42-t018-i0 by cursor:mock-s0
// atm-edit s42-t019-i4 by codex:mock-s5
// atm-edit s42-t023-i4 by codex:mock-s5
// atm-edit s42-t032-i3 by cursor:mock-s3
// atm-edit s42-t033-i3 by cursor:mock-s3
// atm-edit s42-t032-i1 by claude:mock-s1
// atm-edit s42-t037-i2 by codex:mock-s5
// atm-edit s42-t042-i1 by claude:mock-s1
// atm-edit s42-t043-i1 by claude:mock-s1
// atm-edit s42-t046-i2 by codex:mock-s2
// atm-edit s42-t049-i3 by cursor:mock-s3
// atm-edit s42-t049-i4 by claude:mock-s4
// </region:db>

// <region:cache>
export const cacheConfig: CacheConfig = {
  ttlSec: 60,
  backend: 'memory',
};
// atm-edit s42-t002-i0 by cursor:mock-s0
// atm-edit s42-t003-i0 by cursor:mock-s0
// atm-edit s42-t020-i4 by codex:mock-s5
// atm-edit s42-t021-i5 by codex:mock-s5
// atm-edit s42-t024-i0 by cursor:mock-s0
// atm-edit s42-t022-i1 by claude:mock-s1
// atm-edit s42-t023-i1 by claude:mock-s1
// atm-edit s42-t027-i3 by cursor:mock-s3
// atm-edit s42-t029-i4 by codex:mock-s5
// atm-edit s42-t029-i3 by claude:mock-s4
// atm-edit s42-t038-i0 by cursor:mock-s0
// atm-edit s42-t038-i4 by claude:mock-s4
// atm-edit s42-t043-i3 by cursor:mock-s3
// atm-edit s42-t046-i4 by claude:mock-s4
// atm-edit s42-t049-i1 by claude:mock-s1
// </region:cache>

// <region:flags>
export const featureFlags: FeatureFlags = {
  billingV2: false,
  experimentalSearch: false,
};
// atm-edit s42-t000-i0 by cursor:mock-s0
// atm-edit s42-t011-i5 by codex:mock-s5
// atm-edit s42-t019-i2 by cursor:mock-s3
// atm-edit s42-t028-i3 by cursor:mock-s3
// atm-edit s42-t036-i0 by cursor:mock-s0
// atm-edit s42-t037-i0 by cursor:mock-s0
// atm-edit s42-t042-i2 by cursor:mock-s3
// atm-edit s42-t045-i0 by cursor:mock-s0
// </region:flags>
