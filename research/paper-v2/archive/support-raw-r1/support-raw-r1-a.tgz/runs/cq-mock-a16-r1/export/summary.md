# atm-bench export — cq-mock-a16-r1

- run_id: `cq-mock-a16-r1` · scenario_seed: **42** · atm_backend: **mock** (mock broker) · writer: mock
- atm_version: `mock-broker-0.1 (not ATM monorepo)`
- label: MOCK ATM (in-process mock-broker)
- params: `{"n_agents":16,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once"}`
- scenario reproducibility: **true** (`02660e85e1d47ffc…`)
- alignment: 0 both / atm_only=879 / control_only=0

## Headline numbers

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 879 | — |
| contended intents | 879 | — |
| events_total | 3863 | — |
| event types | submit=879, decision=879, oracle=879, enqueue=613, dequeue=613 | — |
| bytes (JSONL) | 2368602 | — |
| duration_ms | 8067 | — |
| distinct agents / vendors | 16 / claude,codex,cursor,other | — |
| outcomes | commit=879 | — |
| committed | 879 | — |
| oracle pass (marker survives) | 879 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 613 | — |
| composer co-writes | 0 | — |
| CAS rebase on apply | 0 | — |
| mean wait_ms (all intents) | 81 | — |
| mean wait_ms (waited only) | 116.2 (n=613) | — |
| p95 / max wait_ms | 274 / 559 | — |

## Latency / throughput (performance.now ms)

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 8046.43 | — |
| throughput intents/s | 109.24 | — |
| goodput oracle-pass/s | 109.24 | — |
| latency_ms mean / p50 / p95 | 81.09 / 50.03 / 274.17 | — |
| wait_ms mean / p50 / p95 | 81 / 50 / 274 | — |
| apply_ms mean / p50 / p95 | 0.13 / 0.13 / 0.21 | — |
| total_ms mean / p50 / p95 | 121.29 / 92.66 / 313.61 | — |
| overhead_ms mean / p50 / p95 | 81.31 / 50.2 / 274.42 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| admit | 266 | 0 | 0 |
| cold_queue | 613 | 0 | 116.2 |

## Reason codes

- atm: cold_queued_then_granted=613, cold_free=266
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | cold_queue=613, admit=266 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=3863, bytes=2368602, duration_ms=8067
