# atm-bench export — cq-real-a16-r1

- run_id: `cq-real-a16-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":16,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"region","cold_retry":"loop"}`
- scenario reproducibility: **true** (`02660e85e1d47ffc…`)
- alignment: 0 both / atm_only=879 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 879 | — |
| contended intents | 879 | — |
| events_total | 3857 | — |
| event types | submit=879, decision=879, oracle=879, enqueue=610, dequeue=610 | — |
| bytes (JSONL) | 7057845 | — |
| duration_ms | 9691 | — |
| distinct agents / vendors | 16 / claude,codex,cursor,other | — |
| outcomes | commit=879 | — |
| committed | 879 | — |
| oracle pass (marker survives) | 879 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 610 | — |
| composer co-writes | 0 | — |
| CAS rebase on apply | 0 | — |
| mean wait_ms (all intents) | 98.9 | — |
| mean wait_ms (waited only) | 142.5 (n=610) | — |
| p95 / max wait_ms | 330 / 621 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 9667.22 | — |
| throughput intents/s | 90.93 | — |
| goodput oracle-pass/s | 90.93 | — |
| latency_ms mean / p50 / p95 | 101.53 / 58.42 / 332.35 | — |
| wait_ms mean / p50 / p95 | 98.86 / 56 / 330 | — |
| apply_ms mean / p50 / p95 | 2.29 / 2.12 / 3.52 | — |
| total_ms mean / p50 / p95 | 146.68 / 104.18 / 380.1 | — |
| overhead_ms mean / p50 / p95 | 103.88 / 61.21 / 335.04 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| admit | 269 | 0 | 0 |
| cold_queue | 610 | 0 | 142.5 |

## Reason codes

- atm: overlay_wait_on_atm_true-conflict_then_direct=610, atm_direct=269
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | cold_queue=610, admit=269 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=3857, bytes=7057845, duration_ms=9691
