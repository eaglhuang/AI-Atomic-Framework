# atm-bench export — hf-nativestale-h1-a6-r2

- run_id: `hf-nativestale-h1-a6-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"stale"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=269 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 269 | — |
| contended intents | 219 | — |
| events_total | 748 | — |
| event types | submit=269, decision=269, oracle=210 | — |
| bytes (JSONL) | 1452048 | — |
| duration_ms | 2549 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=210, reject=59 | — |
| committed | 210 | — |
| oracle pass (marker survives) | 95 | — |
| lost updates (oracle fail) | 115 | — |
| integration pass rate of committed | 45.2% | — |
| effective success rate of all intents | 35.3% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 139 | — |
| CAS rebase on apply | 136 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2542.94 | — |
| throughput intents/s | 105.78 | — |
| goodput oracle-pass/s | 37.36 | — |
| latency_ms mean / p50 / p95 | 2.42 / 2.56 / 4.1 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.76 / 1.95 / 3.23 | — |
| total_ms mean / p50 / p95 | 37.22 / 41.72 / 65.12 | — |
| overhead_ms mean / p50 / p95 | 4.3 / 4.84 / 6.89 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 139 | 0 | 0 |
| reject | 59 | 0 | 0 |
| hot_provisional | 71 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=124, atm_true_conflict=59, atm_provisional_write_lease=59, atm_compose=15, atm_provisional_write_lease+cas_rebase=12
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=75, reject=49, hot_provisional=27 |
| composer_cowrite | composer_merge=52, hot_provisional=10, reject=6 |
| no_conflict | hot_provisional=34, composer_merge=12, reject=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=748, bytes=1452048, duration_ms=2549
