/** Math helpers (COLD). */
// <region:body>
export function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}
export function sum(xs: readonly number[]): number {
  return xs.reduce((a, b) => a + b, 0);
}
// atm-edit s42-t020-i1 by claude:mock-s1
// atm-edit s42-t029-i6 by other:mock-s6
// atm-edit s42-t034-i11 by claude:mock-s12
// atm-edit s42-t059-i5 by codex:mock-s5
// </region:body>
