/** String helpers (COLD). */
// <region:body>
export function trim(s: string): string {
  return s.trim();
}
export function slugify(s: string): string {
  return trim(s).toLowerCase().replace(/\s+/g, '-');
}
// atm-edit s42-t009-i2 by codex:mock-s2
// atm-edit s42-t009-i0 by cursor:mock-s0
// atm-edit s42-t023-i3 by claude:mock-s4
// atm-edit s42-t038-i2 by codex:mock-s2
// atm-edit s42-t041-i13 by codex:mock-s13
// atm-edit s42-t048-i2 by codex:mock-s2
// atm-edit s42-t057-i8 by codex:mock-s10
// </region:body>
