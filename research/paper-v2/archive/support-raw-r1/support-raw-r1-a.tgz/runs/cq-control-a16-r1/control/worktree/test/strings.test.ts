/** Tiny oracle-friendly test module (COLD). */
import { slugify, trim } from '../src/utils/strings.ts';

// <region:body>
export function runStringsSelfTest(): boolean {
  return trim('  x  ') === 'x' && slugify('Hello World') === 'hello-world';
}
// atm-edit s42-t006-i1 by claude:mock-s1
// atm-edit s42-t007-i4 by claude:mock-s4
// atm-edit s42-t013-i10 by codex:mock-s13
// atm-edit s42-t015-i0 by cursor:mock-s0
// atm-edit s42-t039-i6 by other:mock-s7
// atm-edit s42-t043-i1 by claude:mock-s1
// atm-edit s42-t043-i13 by codex:mock-s13
// atm-edit s42-t044-i10 by codex:mock-s13
// </region:body>
