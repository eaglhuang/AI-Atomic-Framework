/** App entry (COLD). */
import { dbConfig, featureFlags } from './config.ts';
import { allRoutes } from './routes.ts';
import { initialState } from './store.ts';

// <region:body>
export function boot(): { ok: true; routes: number; db: string } {
  const routes = allRoutes();
  return {
    ok: true,
    routes: Object.keys(routes).length,
    db: `${dbConfig.host}/${dbConfig.name}`,
  };
}

export function isBillingV2(): boolean {
  return featureFlags.billingV2;
}

export { initialState };
// atm-edit s42-t012-i10 by codex:mock-s10
// atm-edit s42-t017-i2 by codex:mock-s2
// atm-edit s42-t030-i9 by codex:mock-s10
// atm-edit s42-t036-i0 by cursor:mock-s0
// atm-edit s42-t042-i13 by codex:mock-s13
// atm-edit s42-t047-i15 by other:mock-s15
// atm-edit s42-t049-i3 by cursor:mock-s3
// atm-edit s42-t052-i6 by other:mock-s7
// atm-edit s42-t055-i12 by codex:mock-s13
// </region:body>
