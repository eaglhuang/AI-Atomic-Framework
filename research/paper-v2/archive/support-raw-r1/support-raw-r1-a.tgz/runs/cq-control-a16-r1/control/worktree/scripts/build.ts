/** Build stub (COLD) — lists entry modules. */
import { boot } from '../src/index.ts';

// <region:body>
export function buildSummary(): string {
  const b = boot();
  return `routes=${b.routes};db=${b.db}`;
}
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log(buildSummary());
}
// atm-edit s42-t004-i7 by codex:mock-s10
// atm-edit s42-t010-i0 by cursor:mock-s0
// atm-edit s42-t014-i0 by cursor:mock-s0
// atm-edit s42-t022-i12 by claude:mock-s12
// atm-edit s42-t024-i4 by claude:mock-s4
// atm-edit s42-t031-i9 by codex:mock-s10
// atm-edit s42-t033-i10 by claude:mock-s12
// atm-edit s42-t054-i10 by codex:mock-s10
// atm-edit s42-t056-i8 by codex:mock-s10
// atm-edit s42-t058-i3 by codex:mock-s5
// </region:body>
