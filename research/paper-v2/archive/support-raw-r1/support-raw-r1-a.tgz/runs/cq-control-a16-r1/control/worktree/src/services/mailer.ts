/** Mailer service (COLD). */
export interface Mail { to: string; subject: string; body: string }

// <region:body>
export function formatMail(mail: Mail): string {
  return `To: ${mail.to}\nSubject: ${mail.subject}\n\n${mail.body}`;
}
export function isValidAddress(addr: string): boolean {
  return addr.includes('@');
}
// atm-edit s42-t000-i4 by claude:mock-s4
// atm-edit s42-t005-i11 by cursor:mock-s11
// atm-edit s42-t005-i10 by codex:mock-s10
// atm-edit s42-t018-i3 by cursor:mock-s3
// atm-edit s42-t021-i5 by other:mock-s7
// atm-edit s42-t027-i14 by other:mock-s14
// atm-edit s42-t028-i5 by other:mock-s6
// atm-edit s42-t035-i5 by cursor:mock-s8
// atm-edit s42-t035-i9 by claude:mock-s12
// </region:body>
