/** Tiny oracle-friendly test module (COLD). */
import { slugify, trim } from '../src/utils/strings.ts';

// <region:body>
export function runStringsSelfTest(): boolean {
  return trim('  x  ') === 'x' && slugify('Hello World') === 'hello-world';
}
// atm-edit s42-t005-i1 by claude:mock-s1
// atm-edit s42-t006-i4 by codex:mock-s5
// atm-edit s42-t006-i2 by cursor:mock-s3
// atm-edit s42-t006-i1 by codex:mock-s2
// atm-edit s42-t006-i0 by cursor:mock-s0
// atm-edit s42-t013-i0 by claude:mock-s1
// atm-edit s42-t015-i4 by claude:mock-s4
// atm-edit s42-t017-i0 by cursor:mock-s0
// atm-edit s42-t018-i0 by claude:mock-s1
// atm-edit s42-t019-i2 by codex:mock-s2
// atm-edit s42-t019-i4 by claude:mock-s4
// atm-edit s42-t021-i4 by claude:mock-s4
// atm-edit s42-t021-i0 by cursor:mock-s0
// atm-edit s42-t021-i5 by codex:mock-s5
// atm-edit s42-t024-i2 by codex:mock-s2
// atm-edit s42-t025-i3 by cursor:mock-s3
// atm-edit s42-t028-i2 by codex:mock-s2
// atm-edit s42-t028-i0 by cursor:mock-s0
// atm-edit s42-t029-i2 by codex:mock-s2
// atm-edit s42-t028-i5 by codex:mock-s5
// </region:body>
