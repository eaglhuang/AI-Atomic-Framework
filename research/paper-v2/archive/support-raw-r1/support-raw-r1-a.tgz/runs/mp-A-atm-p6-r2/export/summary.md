# atm-bench export — mp-A-atm-p6-r2

- run_id: `mp-A-atm-p6-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs) — multi-process shared registry
- params: `{"n_agents":6,"hot_ratio":0.4,"overlap":"med","cold_policy":"queue","composer_enabled":true,"trial_count":30,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":2000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync","mp_registry_sync":"cas","mp_apply_lock":"on"}`
- scenario reproducibility: **true** (`80d54e045f6d9c41…`)
- alignment: 0 both / atm_only=168 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 30 | — |
| intents (decision events) | 168 | — |
| contended intents | 82 | — |
| events_total | 497 | — |
| event types | submit=168, decision=168, oracle=161 | — |
| bytes (JSONL) | 493705 | — |
| duration_ms | 1555.16 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=161, reject=7 | — |
| committed | 161 | — |
| oracle pass (marker survives) | 161 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 95.8% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 58 | — |
| CAS rebase on apply | 56 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 1554.84 | — |
| throughput intents/s | 108.05 | — |
| goodput oracle-pass/s | 103.55 | — |
| latency_ms mean / p50 / p95 | 5.47 / 4.23 / 13.6 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 3.27 / 2.84 / 8.58 | — |
| total_ms mean / p50 / p95 | 47.65 / 48.54 / 66.23 | — |
| overhead_ms mean / p50 / p95 | 8.89 / 7.66 / 18.14 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| reject | 7 | 0 | 0 |
| admit | 64 | 0 | 0 |
| composer_merge | 58 | 0 | 0 |
| hot_provisional | 39 | 0 | 0 |

## Reason codes

- atm: atm_direct=57, atm_compose+cas_rebase=48, atm_provisional_write_lease=38, atm_compose=10, atm_true_conflict=7, atm_direct+cas_rebase=7, atm_provisional_write_lease+cas_rebase=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | reject=5, hot_provisional=4, composer_merge=2 |
| no_conflict | admit=43, hot_provisional=30, composer_merge=11, reject=2 |
| cold_queue | composer_merge=41, admit=21 |
| composer_cowrite | hot_provisional=5, composer_merge=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=497, bytes=493705, duration_ms=1555.16
