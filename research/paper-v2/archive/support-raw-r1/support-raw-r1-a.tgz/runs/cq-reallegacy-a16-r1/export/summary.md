# atm-bench export — cq-reallegacy-a16-r1

- run_id: `cq-reallegacy-a16-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":16,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once"}`
- scenario reproducibility: **true** (`02660e85e1d47ffc…`)
- alignment: 0 both / atm_only=879 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 879 | — |
| contended intents | 879 | — |
| events_total | 2637 | — |
| event types | submit=879, decision=879, oracle=879 | — |
| bytes (JSONL) | 4951859 | — |
| duration_ms | 5878 | — |
| distinct agents / vendors | 16 / claude,codex,cursor,other | — |
| outcomes | commit=879 | — |
| committed | 879 | — |
| oracle pass (marker survives) | 879 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 798 | — |
| CAS rebase on apply | 797 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 5858.48 | — |
| throughput intents/s | 150.04 | — |
| goodput oracle-pass/s | 150.04 | — |
| latency_ms mean / p50 / p95 | 3.99 / 3.81 / 5.86 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 2.3 / 2.13 / 3.54 | — |
| total_ms mean / p50 / p95 | 80.56 / 81.6 / 106.38 | — |
| overhead_ms mean / p50 / p95 | 6.35 / 6.1 / 8.61 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| admit | 81 | 0 | 0 |
| composer_merge | 798 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=780, atm_direct=64, atm_compose=18, atm_direct+cas_rebase=17
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | composer_merge=798, admit=81 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=2637, bytes=4951859, duration_ms=5878
