/** App entry (COLD). */
import { dbConfig, featureFlags } from './config.ts';
import { allRoutes } from './routes.ts';
import { initialState } from './store.ts';

// <region:body>
export function boot(): { ok: true; routes: number; db: string } {
  const routes = allRoutes();
  return {
    ok: true,
    routes: Object.keys(routes).length,
    db: `${dbConfig.host}/${dbConfig.name}`,
  };
}

export function isBillingV2(): boolean {
  return featureFlags.billingV2;
}

export { initialState };
// atm-edit s42-t040-i2 by codex:mock-s2
// atm-edit s42-t041-i2 by codex:mock-s2
// atm-edit s42-t042-i2 by codex:mock-s2
// atm-edit s42-t040-i5 by codex:mock-s5
// atm-edit s42-t040-i3 by cursor:mock-s3
// atm-edit s42-t041-i5 by codex:mock-s5
// atm-edit s42-t041-i3 by cursor:mock-s3
// atm-edit s42-t047-i2 by codex:mock-s2
// atm-edit s42-t042-i5 by codex:mock-s5
// atm-edit s42-t042-i3 by cursor:mock-s3
// atm-edit s42-t050-i2 by codex:mock-s2
// atm-edit s42-t051-i2 by codex:mock-s2
// atm-edit s42-t047-i5 by codex:mock-s5
// atm-edit s42-t047-i3 by cursor:mock-s3
// atm-edit s42-t040-i6 by other:mock-s6
// atm-edit s42-t041-i6 by other:mock-s6
// atm-edit s42-t042-i6 by other:mock-s6
// atm-edit s42-t040-i7 by other:mock-s7
// atm-edit s42-t050-i3 by cursor:mock-s3
// atm-edit s42-t050-i5 by codex:mock-s5
// atm-edit s42-t041-i7 by other:mock-s7
// atm-edit s42-t051-i3 by cursor:mock-s3
// atm-edit s42-t047-i6 by other:mock-s6
// atm-edit s42-t051-i4 by codex:mock-s5
// atm-edit s42-t040-i4 by claude:mock-s4
// atm-edit s42-t042-i7 by other:mock-s7
// atm-edit s42-t040-i0 by cursor:mock-s0
// atm-edit s42-t040-i1 by claude:mock-s1
// atm-edit s42-t041-i4 by claude:mock-s4
// atm-edit s42-t050-i6 by other:mock-s6
// atm-edit s42-t041-i0 by cursor:mock-s0
// atm-edit s42-t041-i1 by claude:mock-s1
// atm-edit s42-t042-i4 by claude:mock-s4
// atm-edit s42-t051-i5 by other:mock-s6
// atm-edit s42-t047-i7 by other:mock-s7
// atm-edit s42-t042-i0 by cursor:mock-s0
// atm-edit s42-t042-i1 by claude:mock-s1
// atm-edit s42-t050-i7 by other:mock-s7
// atm-edit s42-t047-i4 by claude:mock-s4
// atm-edit s42-t051-i6 by other:mock-s7
// atm-edit s42-t047-i1 by claude:mock-s1
// atm-edit s42-t050-i4 by claude:mock-s4
// atm-edit s42-t047-i0 by cursor:mock-s0
// atm-edit s42-t050-i1 by claude:mock-s1
// atm-edit s42-t051-i1 by claude:mock-s1
// atm-edit s42-t050-i0 by cursor:mock-s0
// atm-edit s42-t051-i0 by cursor:mock-s0
// </region:body>
