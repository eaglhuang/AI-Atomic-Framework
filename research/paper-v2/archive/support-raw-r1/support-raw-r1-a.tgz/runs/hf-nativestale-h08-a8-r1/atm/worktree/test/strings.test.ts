/** Tiny oracle-friendly test module (COLD). */
import { slugify, trim } from '../src/utils/strings.ts';

// <region:body>
export function runStringsSelfTest(): boolean {
  return trim('  x  ') === 'x' && slugify('Hello World') === 'hello-world';
}
// atm-edit s42-t006-i3 by codex:mock-s5
// atm-edit s42-t006-i0 by claude:mock-s1
// atm-edit s42-t012-i1 by claude:mock-s1
// atm-edit s42-t028-i5 by codex:mock-s5
// </region:body>
