# atm-bench export — hf-loop-h1-a6-r2

- run_id: `hf-loop-h1-a6-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"sync"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=269 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 269 | — |
| contended intents | 219 | — |
| events_total | 947 | — |
| event types | submit=269, decision=269, oracle=269, enqueue=70, dequeue=70 | — |
| bytes (JSONL) | 1807460 | — |
| duration_ms | 2840 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=269 | — |
| committed | 269 | — |
| oracle pass (marker survives) | 269 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 70 | — |
| composer co-writes | 200 | — |
| CAS rebase on apply | 190 | — |
| mean wait_ms (all intents) | 7.4 | — |
| mean wait_ms (waited only) | 28.6 (n=70) | — |
| p95 / max wait_ms | 44 / 98 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2832.27 | — |
| throughput intents/s | 94.98 | — |
| goodput oracle-pass/s | 94.98 | — |
| latency_ms mean / p50 / p95 | 10.23 / 2.98 / 47.81 | — |
| wait_ms mean / p50 / p95 | 7.44 / 0 / 44 | — |
| apply_ms mean / p50 / p95 | 2.29 / 2.14 / 3.37 | — |
| total_ms mean / p50 / p95 | 55.19 / 54.07 / 93.85 | — |
| overhead_ms mean / p50 / p95 | 12.58 / 5.44 / 49.94 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 200 | 0 | 6.9 |
| hot_provisional | 69 | 0 | 9.1 |

## Reason codes

- atm: atm_compose+cas_rebase=137, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=45, atm_provisional_write_lease=42, overlay_wait_on_atm_true-conflict_then_proposal-required=19, atm_compose=16, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=4, atm_provisional_write_lease+cas_rebase=4, overlay_wait_on_atm_true-conflict_then_compose=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=123, hot_provisional=28 |
| composer_cowrite | composer_merge=58, hot_provisional=10 |
| no_conflict | hot_provisional=31, composer_merge=19 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=947, bytes=1807460, duration_ms=2840
