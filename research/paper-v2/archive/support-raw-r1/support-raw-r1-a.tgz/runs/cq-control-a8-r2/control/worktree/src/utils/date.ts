/** Date helpers (COLD). */
// <region:body>
export function isoDay(d: Date = new Date()): string {
  return d.toISOString().slice(0, 10);
}
export function addDays(d: Date, n: number): Date {
  const x = new Date(d.getTime());
  x.setUTCDate(x.getUTCDate() + n);
  return x;
}
// atm-edit s42-t000-i0 by cursor:mock-s0
// atm-edit s42-t021-i0 by cursor:mock-s0
// atm-edit s42-t021-i3 by cursor:mock-s3
// atm-edit s42-t023-i5 by codex:mock-s5
// atm-edit s42-t033-i3 by cursor:mock-s3
// atm-edit s42-t036-i3 by cursor:mock-s3
// atm-edit s42-t038-i1 by claude:mock-s1
// atm-edit s42-t055-i4 by claude:mock-s4
// </region:body>
