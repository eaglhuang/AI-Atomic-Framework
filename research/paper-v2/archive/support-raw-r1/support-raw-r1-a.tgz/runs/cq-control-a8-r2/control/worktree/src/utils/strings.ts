/** String helpers (COLD). */
// <region:body>
export function trim(s: string): string {
  return s.trim();
}
export function slugify(s: string): string {
  return trim(s).toLowerCase().replace(/\s+/g, '-');
}
// atm-edit s42-t002-i0 by cursor:mock-s0
// atm-edit s42-t007-i1 by codex:mock-s2
// atm-edit s42-t011-i4 by claude:mock-s4
// atm-edit s42-t015-i5 by other:mock-s6
// atm-edit s42-t018-i2 by cursor:mock-s3
// atm-edit s42-t034-i3 by cursor:mock-s3
// atm-edit s42-t035-i3 by cursor:mock-s3
// atm-edit s42-t043-i6 by other:mock-s7
// atm-edit s42-t048-i4 by claude:mock-s4
// atm-edit s42-t057-i2 by codex:mock-s2
// </region:body>
