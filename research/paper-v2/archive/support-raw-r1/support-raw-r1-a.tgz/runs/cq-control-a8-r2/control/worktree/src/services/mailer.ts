/** Mailer service (COLD). */
export interface Mail { to: string; subject: string; body: string }

// <region:body>
export function formatMail(mail: Mail): string {
  return `To: ${mail.to}\nSubject: ${mail.subject}\n\n${mail.body}`;
}
export function isValidAddress(addr: string): boolean {
  return addr.includes('@');
}
// atm-edit s42-t008-i4 by codex:mock-s5
// atm-edit s42-t017-i6 by other:mock-s7
// atm-edit s42-t019-i3 by cursor:mock-s3
// atm-edit s42-t020-i3 by cursor:mock-s3
// atm-edit s42-t024-i1 by claude:mock-s1
// atm-edit s42-t031-i4 by codex:mock-s5
// atm-edit s42-t044-i4 by codex:mock-s5
// atm-edit s42-t054-i2 by codex:mock-s2
// </region:body>
