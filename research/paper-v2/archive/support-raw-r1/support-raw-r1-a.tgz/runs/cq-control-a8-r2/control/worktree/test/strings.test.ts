/** Tiny oracle-friendly test module (COLD). */
import { slugify, trim } from '../src/utils/strings.ts';

// <region:body>
export function runStringsSelfTest(): boolean {
  return trim('  x  ') === 'x' && slugify('Hello World') === 'hello-world';
}
// atm-edit s42-t006-i1 by claude:mock-s1
// atm-edit s42-t014-i2 by codex:mock-s2
// atm-edit s42-t016-i0 by cursor:mock-s0
// atm-edit s42-t025-i6 by other:mock-s6
// </region:body>
