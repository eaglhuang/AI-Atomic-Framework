# atm-bench export — hf-nativestale-h08-a8-r3

- run_id: `hf-nativestale-h08-a8-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0.8,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"stale"}`
- scenario reproducibility: **true** (`7422724bbf623e5c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 289 | — |
| events_total | 999 | — |
| event types | submit=354, decision=354, oracle=291 | — |
| bytes (JSONL) | 1930376 | — |
| duration_ms | 2565 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=291, reject=63 | — |
| committed | 291 | — |
| oracle pass (marker survives) | 105 | — |
| lost updates (oracle fail) | 186 | — |
| integration pass rate of committed | 36.1% | — |
| effective success rate of all intents | 29.7% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 207 | — |
| CAS rebase on apply | 204 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2556.15 | — |
| throughput intents/s | 138.49 | — |
| goodput oracle-pass/s | 41.08 | — |
| latency_ms mean / p50 / p95 | 2.72 / 2.83 / 4.18 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.82 / 1.96 / 3.23 | — |
| total_ms mean / p50 / p95 | 39.43 / 44.08 / 65.04 | — |
| overhead_ms mean / p50 / p95 | 4.64 / 5.04 / 7.14 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 207 | 0 | 0 |
| hot_provisional | 57 | 0 | 0 |
| reject | 63 | 0 | 0 |
| admit | 27 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=188, atm_true_conflict=63, atm_provisional_write_lease=46, atm_direct=22, atm_compose=19, atm_provisional_write_lease+cas_rebase=11, atm_direct+cas_rebase=5
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | composer_merge=70, admit=15 |
| no_conflict | hot_provisional=33, admit=12, composer_merge=11, reject=9 |
| hot_provisional | composer_merge=99, reject=54, hot_provisional=19 |
| composer_cowrite | composer_merge=27, hot_provisional=5 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=999, bytes=1930376, duration_ms=2565
