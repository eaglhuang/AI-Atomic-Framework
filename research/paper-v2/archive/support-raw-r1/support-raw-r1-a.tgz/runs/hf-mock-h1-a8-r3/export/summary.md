# atm-bench export — hf-mock-h1-a8-r3

- run_id: `hf-mock-h1-a8-r3` · scenario_seed: **42** · atm_backend: **mock** (mock broker) · writer: mock
- atm_version: `mock-broker-0.1 (not ATM monorepo)`
- label: MOCK ATM (in-process mock-broker)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 990 | — |
| event types | submit=354, decision=354, oracle=282 | — |
| bytes (JSONL) | 661752 | — |
| duration_ms | 2528 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=282, reject=72 | — |
| committed | 282 | — |
| oracle pass (marker survives) | 282 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 79.7% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 109 | — |
| CAS rebase on apply | 213 | — |
| mean wait_ms (all intents) | 9.6 | — |
| mean wait_ms (waited only) | 31.8 (n=107) | — |
| p95 / max wait_ms | 48 / 57 | — |

## Latency / throughput (performance.now ms)

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2519.47 | — |
| throughput intents/s | 140.51 | — |
| goodput oracle-pass/s | 111.93 | — |
| latency_ms mean / p50 / p95 | 0.01 / 0.01 / 0.02 | — |
| wait_ms mean / p50 / p95 | 9.61 / 0 / 48 | — |
| apply_ms mean / p50 / p95 | 0.11 / 0.1 / 0.23 | — |
| total_ms mean / p50 / p95 | 34.03 / 39.12 / 58.9 | — |
| overhead_ms mean / p50 / p95 | 1.38 / 0.21 / 10.16 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| reject | 72 | 0 | 0 |
| admit | 66 | 0 | 0 |
| hot_provisional | 107 | 0 | 31.8 |
| composer_merge | 109 | 0 | 0 |

## Reason codes

- atm: hot_same_region_speculative+cas_rebase=107, hot_disjoint_region_cowrite+cas_rebase=92, provisional_depth_exceeded=72, hot_no_overlap=52, hot_disjoint_region_cowrite=17, hot_no_overlap+cas_rebase=14
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | hot_provisional=100, reject=71, composer_merge=57, admit=22 |
| no_conflict | admit=36, composer_merge=13, hot_provisional=3, reject=1 |
| composer_cowrite | composer_merge=39, admit=8, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=990, bytes=661752, duration_ms=2528
