/** In-memory store slices (HOT). */
export type State = { users: string[]; orders: number[]; meta: Record<string, string> };

// <region:reducers>
export function reduceUsers(state: State, user: string): State {
  return { ...state, users: [...state.users, user] };
}
// atm-edit s42-t001-i1 by claude:mock-s1
// atm-edit s42-t002-i1 by claude:mock-s1
// atm-edit s42-t004-i2 by codex:mock-s2
// atm-edit s42-t011-i0 by cursor:mock-s0
// atm-edit s42-t012-i3 by cursor:mock-s3
// atm-edit s42-t012-i5 by codex:mock-s5
// atm-edit s42-t014-i7 by other:mock-s7
// atm-edit s42-t018-i0 by cursor:mock-s0
// atm-edit s42-t020-i0 by cursor:mock-s0
// atm-edit s42-t022-i7 by other:mock-s7
// atm-edit s42-t022-i5 by codex:mock-s5
// atm-edit s42-t022-i0 by cursor:mock-s0
// atm-edit s42-t024-i6 by other:mock-s6
// atm-edit s42-t024-i4 by claude:mock-s4
// atm-edit s42-t025-i1 by claude:mock-s1
// atm-edit s42-t025-i0 by cursor:mock-s0
// atm-edit s42-t029-i6 by other:mock-s7
// atm-edit s42-t029-i2 by cursor:mock-s3
// atm-edit s42-t029-i0 by claude:mock-s1
// atm-edit s42-t031-i6 by other:mock-s7
// atm-edit s42-t031-i1 by claude:mock-s1
// atm-edit s42-t031-i5 by other:mock-s6
// atm-edit s42-t032-i4 by codex:mock-s5
// atm-edit s42-t032-i0 by cursor:mock-s0
// atm-edit s42-t033-i0 by cursor:mock-s0
// atm-edit s42-t034-i5 by other:mock-s6
// atm-edit s42-t035-i4 by codex:mock-s5
// atm-edit s42-t038-i3 by claude:mock-s4
// atm-edit s42-t039-i6 by other:mock-s7
// atm-edit s42-t042-i4 by other:mock-s6
// atm-edit s42-t043-i1 by codex:mock-s2
// atm-edit s42-t044-i0 by cursor:mock-s0
// atm-edit s42-t044-i6 by other:mock-s6
// atm-edit s42-t048-i3 by cursor:mock-s3
// atm-edit s42-t049-i0 by codex:mock-s2
// </region:reducers>

// <region:selectors>
export function selectUserCount(state: State): number {
  return state.users.length;
}
// atm-edit s42-t005-i5 by other:mock-s7
// atm-edit s42-t011-i1 by claude:mock-s1
// atm-edit s42-t012-i0 by cursor:mock-s0
// atm-edit s42-t012-i4 by claude:mock-s4
// atm-edit s42-t012-i2 by codex:mock-s2
// atm-edit s42-t014-i0 by cursor:mock-s0
// atm-edit s42-t016-i7 by other:mock-s7
// atm-edit s42-t018-i4 by other:mock-s6
// atm-edit s42-t019-i0 by cursor:mock-s0
// atm-edit s42-t022-i3 by cursor:mock-s3
// atm-edit s42-t022-i2 by codex:mock-s2
// atm-edit s42-t024-i0 by cursor:mock-s0
// atm-edit s42-t024-i2 by codex:mock-s2
// atm-edit s42-t025-i4 by claude:mock-s4
// atm-edit s42-t029-i4 by codex:mock-s5
// atm-edit s42-t030-i3 by claude:mock-s4
// atm-edit s42-t031-i3 by claude:mock-s4
// atm-edit s42-t032-i2 by codex:mock-s2
// atm-edit s42-t033-i3 by claude:mock-s4
// atm-edit s42-t034-i1 by codex:mock-s2
// atm-edit s42-t035-i5 by other:mock-s6
// atm-edit s42-t036-i5 by other:mock-s6
// atm-edit s42-t036-i1 by claude:mock-s1
// atm-edit s42-t039-i4 by codex:mock-s5
// atm-edit s42-t039-i2 by cursor:mock-s3
// atm-edit s42-t039-i5 by other:mock-s6
// atm-edit s42-t039-i3 by claude:mock-s4
// atm-edit s42-t039-i0 by cursor:mock-s0
// atm-edit s42-t042-i2 by cursor:mock-s3
// atm-edit s42-t042-i3 by claude:mock-s4
// atm-edit s42-t044-i4 by claude:mock-s4
// atm-edit s42-t044-i2 by codex:mock-s2
// atm-edit s42-t044-i7 by other:mock-s7
// atm-edit s42-t044-i3 by cursor:mock-s3
// atm-edit s42-t047-i2 by codex:mock-s2
// </region:selectors>

// <region:actions>
export function createOrder(state: State, id: number): State {
  return { ...state, orders: [...state.orders, id] };
}
// atm-edit s42-t011-i4 by claude:mock-s4
// atm-edit s42-t011-i2 by codex:mock-s2
// atm-edit s42-t011-i5 by codex:mock-s5
// atm-edit s42-t012-i6 by other:mock-s6
// atm-edit s42-t014-i3 by cursor:mock-s3
// atm-edit s42-t014-i5 by codex:mock-s5
// atm-edit s42-t014-i4 by claude:mock-s4
// atm-edit s42-t018-i1 by claude:mock-s1
// atm-edit s42-t022-i1 by claude:mock-s1
// atm-edit s42-t024-i1 by claude:mock-s1
// atm-edit s42-t026-i5 by other:mock-s6
// atm-edit s42-t027-i4 by claude:mock-s4
// atm-edit s42-t029-i5 by other:mock-s6
// atm-edit s42-t029-i3 by claude:mock-s4
// atm-edit s42-t031-i2 by codex:mock-s2
// atm-edit s42-t031-i0 by cursor:mock-s0
// atm-edit s42-t032-i3 by claude:mock-s4
// atm-edit s42-t033-i4 by codex:mock-s5
// atm-edit s42-t034-i0 by claude:mock-s1
// atm-edit s42-t035-i6 by other:mock-s7
// atm-edit s42-t036-i0 by cursor:mock-s0
// atm-edit s42-t036-i6 by other:mock-s7
// atm-edit s42-t038-i5 by other:mock-s7
// atm-edit s42-t038-i1 by claude:mock-s1
// atm-edit s42-t040-i5 by codex:mock-s5
// atm-edit s42-t042-i5 by other:mock-s7
// atm-edit s42-t044-i1 by claude:mock-s1
// </region:actions>

export const initialState: State = { users: [], orders: [], meta: {} };
