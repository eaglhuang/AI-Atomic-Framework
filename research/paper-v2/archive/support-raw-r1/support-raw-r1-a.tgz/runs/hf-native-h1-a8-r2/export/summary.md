# atm-bench export — hf-native-h1-a8-r2

- run_id: `hf-native-h1-a8-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 977 | — |
| event types | submit=354, decision=354, oracle=269 | — |
| bytes (JSONL) | 1893427 | — |
| duration_ms | 2553 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=269, reject=85 | — |
| committed | 269 | — |
| oracle pass (marker survives) | 269 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 76% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 213 | — |
| CAS rebase on apply | 211 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2544.34 | — |
| throughput intents/s | 139.13 | — |
| goodput oracle-pass/s | 105.72 | — |
| latency_ms mean / p50 / p95 | 2.55 / 2.71 / 4.22 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.68 / 1.92 / 3.15 | — |
| total_ms mean / p50 / p95 | 36.89 / 41.47 / 65.13 | — |
| overhead_ms mean / p50 / p95 | 4.31 / 4.91 / 6.93 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 213 | 0 | 0 |
| hot_provisional | 56 | 0 | 0 |
| reject | 85 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=199, atm_true_conflict=85, atm_provisional_write_lease=44, atm_compose=14, atm_provisional_write_lease+cas_rebase=12
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=159, reject=70, hot_provisional=21 |
| no_conflict | hot_provisional=30, composer_merge=15, reject=8 |
| composer_cowrite | composer_merge=39, reject=7, hot_provisional=5 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=977, bytes=1893427, duration_ms=2553
