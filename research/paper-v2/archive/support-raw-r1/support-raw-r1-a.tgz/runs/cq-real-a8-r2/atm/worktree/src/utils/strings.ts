/** String helpers (COLD). */
// <region:body>
export function trim(s: string): string {
  return s.trim();
}
export function slugify(s: string): string {
  return trim(s).toLowerCase().replace(/\s+/g, '-');
}
// atm-edit s42-t002-i2 by codex:mock-s2
// atm-edit s42-t002-i3 by cursor:mock-s3
// atm-edit s42-t002-i5 by other:mock-s6
// atm-edit s42-t002-i1 by claude:mock-s1
// atm-edit s42-t002-i0 by cursor:mock-s0
// atm-edit s42-t007-i1 by codex:mock-s2
// atm-edit s42-t002-i4 by codex:mock-s5
// atm-edit s42-t002-i6 by other:mock-s7
// atm-edit s42-t007-i2 by cursor:mock-s3
// atm-edit s42-t007-i3 by claude:mock-s4
// atm-edit s42-t007-i4 by codex:mock-s5
// atm-edit s42-t011-i2 by codex:mock-s2
// atm-edit s42-t007-i5 by other:mock-s6
// atm-edit s42-t011-i6 by other:mock-s6
// atm-edit s42-t007-i0 by claude:mock-s1
// atm-edit s42-t011-i3 by cursor:mock-s3
// atm-edit s42-t011-i4 by claude:mock-s4
// atm-edit s42-t011-i0 by cursor:mock-s0
// atm-edit s42-t015-i2 by codex:mock-s2
// atm-edit s42-t011-i5 by codex:mock-s5
// atm-edit s42-t007-i6 by other:mock-s7
// atm-edit s42-t015-i5 by other:mock-s6
// atm-edit s42-t018-i1 by codex:mock-s2
// atm-edit s42-t011-i1 by claude:mock-s1
// atm-edit s42-t015-i3 by cursor:mock-s3
// atm-edit s42-t018-i5 by other:mock-s6
// atm-edit s42-t015-i4 by claude:mock-s4
// atm-edit s42-t011-i7 by other:mock-s7
// atm-edit s42-t015-i0 by cursor:mock-s0
// atm-edit s42-t018-i2 by cursor:mock-s3
// atm-edit s42-t015-i1 by claude:mock-s1
// atm-edit s42-t018-i4 by codex:mock-s5
// atm-edit s42-t018-i3 by claude:mock-s4
// atm-edit s42-t018-i0 by cursor:mock-s0
// atm-edit s42-t018-i6 by other:mock-s7
// atm-edit s42-t034-i2 by codex:mock-s2
// atm-edit s42-t035-i2 by codex:mock-s2
// atm-edit s42-t034-i5 by codex:mock-s5
// atm-edit s42-t035-i5 by codex:mock-s5
// atm-edit s42-t034-i6 by other:mock-s6
// atm-edit s42-t043-i2 by codex:mock-s2
// atm-edit s42-t035-i6 by other:mock-s6
// atm-edit s42-t034-i3 by cursor:mock-s3
// atm-edit s42-t035-i3 by cursor:mock-s3
// atm-edit s42-t048-i2 by codex:mock-s2
// atm-edit s42-t043-i5 by codex:mock-s5
// atm-edit s42-t034-i4 by claude:mock-s4
// atm-edit s42-t035-i4 by claude:mock-s4
// atm-edit s42-t035-i7 by other:mock-s7
// atm-edit s42-t034-i1 by claude:mock-s1
// atm-edit s42-t035-i1 by claude:mock-s1
// atm-edit s42-t048-i5 by codex:mock-s5
// atm-edit s42-t034-i0 by cursor:mock-s0
// atm-edit s42-t043-i3 by cursor:mock-s3
// atm-edit s42-t035-i0 by cursor:mock-s0
// atm-edit s42-t048-i6 by other:mock-s6
// atm-edit s42-t057-i2 by codex:mock-s2
// atm-edit s42-t048-i3 by cursor:mock-s3
// atm-edit s42-t043-i4 by claude:mock-s4
// atm-edit s42-t043-i6 by other:mock-s7
// atm-edit s42-t057-i5 by codex:mock-s5
// atm-edit s42-t048-i4 by claude:mock-s4
// atm-edit s42-t043-i1 by claude:mock-s1
// atm-edit s42-t057-i6 by other:mock-s6
// atm-edit s42-t043-i0 by cursor:mock-s0
// atm-edit s42-t057-i3 by cursor:mock-s3
// atm-edit s42-t048-i1 by claude:mock-s1
// atm-edit s42-t048-i0 by cursor:mock-s0
// atm-edit s42-t057-i4 by claude:mock-s4
// atm-edit s42-t057-i7 by other:mock-s7
// atm-edit s42-t057-i1 by claude:mock-s1
// atm-edit s42-t057-i0 by cursor:mock-s0
// </region:body>
