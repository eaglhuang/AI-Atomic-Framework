/** Date helpers (COLD). */
// <region:body>
export function isoDay(d: Date = new Date()): string {
  return d.toISOString().slice(0, 10);
}
export function addDays(d: Date, n: number): Date {
  const x = new Date(d.getTime());
  x.setUTCDate(x.getUTCDate() + n);
  return x;
}
// atm-edit s42-t000-i2 by codex:mock-s2
// atm-edit s42-t000-i3 by cursor:mock-s3
// atm-edit s42-t000-i6 by other:mock-s6
// atm-edit s42-t000-i4 by claude:mock-s4
// atm-edit s42-t000-i1 by claude:mock-s1
// atm-edit s42-t000-i0 by cursor:mock-s0
// atm-edit s42-t000-i5 by codex:mock-s5
// atm-edit s42-t000-i7 by other:mock-s7
// atm-edit s42-t021-i2 by codex:mock-s2
// atm-edit s42-t023-i2 by codex:mock-s2
// atm-edit s42-t021-i6 by other:mock-s6
// atm-edit s42-t023-i6 by other:mock-s6
// atm-edit s42-t021-i5 by codex:mock-s5
// atm-edit s42-t021-i3 by cursor:mock-s3
// atm-edit s42-t023-i5 by codex:mock-s5
// atm-edit s42-t023-i3 by cursor:mock-s3
// atm-edit s42-t021-i7 by other:mock-s7
// atm-edit s42-t033-i2 by codex:mock-s2
// atm-edit s42-t021-i4 by claude:mock-s4
// atm-edit s42-t023-i7 by other:mock-s7
// atm-edit s42-t021-i0 by cursor:mock-s0
// atm-edit s42-t036-i2 by codex:mock-s2
// atm-edit s42-t021-i1 by claude:mock-s1
// atm-edit s42-t023-i4 by claude:mock-s4
// atm-edit s42-t023-i0 by cursor:mock-s0
// atm-edit s42-t033-i5 by codex:mock-s5
// atm-edit s42-t023-i1 by claude:mock-s1
// atm-edit s42-t033-i6 by other:mock-s6
// atm-edit s42-t036-i5 by codex:mock-s5
// atm-edit s42-t038-i4 by codex:mock-s5
// atm-edit s42-t036-i6 by other:mock-s6
// atm-edit s42-t033-i3 by cursor:mock-s3
// atm-edit s42-t038-i5 by other:mock-s6
// atm-edit s42-t036-i3 by cursor:mock-s3
// atm-edit s42-t033-i4 by claude:mock-s4
// atm-edit s42-t038-i2 by cursor:mock-s3
// atm-edit s42-t033-i7 by other:mock-s7
// atm-edit s42-t036-i4 by claude:mock-s4
// atm-edit s42-t033-i1 by claude:mock-s1
// atm-edit s42-t036-i7 by other:mock-s7
// atm-edit s42-t038-i3 by claude:mock-s4
// atm-edit s42-t033-i0 by cursor:mock-s0
// atm-edit s42-t038-i6 by other:mock-s7
// atm-edit s42-t036-i1 by claude:mock-s1
// atm-edit s42-t055-i2 by codex:mock-s2
// atm-edit s42-t038-i1 by claude:mock-s1
// atm-edit s42-t036-i0 by cursor:mock-s0
// atm-edit s42-t038-i0 by cursor:mock-s0
// atm-edit s42-t055-i5 by codex:mock-s5
// atm-edit s42-t055-i6 by other:mock-s6
// atm-edit s42-t055-i3 by cursor:mock-s3
// atm-edit s42-t055-i4 by claude:mock-s4
// atm-edit s42-t055-i7 by other:mock-s7
// atm-edit s42-t055-i1 by claude:mock-s1
// atm-edit s42-t055-i0 by cursor:mock-s0
// </region:body>
