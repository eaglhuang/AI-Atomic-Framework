# atm-bench export — cq-real-a8-r2

- run_id: `cq-real-a8-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"region","cold_retry":"loop"}`
- scenario reproducibility: **true** (`75dd85234758f67a…`)
- alignment: 0 both / atm_only=441 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 441 | — |
| contended intents | 441 | — |
| events_total | 1795 | — |
| event types | submit=441, decision=441, oracle=441, enqueue=236, dequeue=236 | — |
| bytes (JSONL) | 3290543 | — |
| duration_ms | 6162 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=441 | — |
| committed | 441 | — |
| oracle pass (marker survives) | 441 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 236 | — |
| composer co-writes | 0 | — |
| CAS rebase on apply | 0 | — |
| mean wait_ms (all intents) | 48 | — |
| mean wait_ms (waited only) | 89.6 (n=236) | — |
| p95 / max wait_ms | 221 / 327 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 6148.24 | — |
| throughput intents/s | 71.73 | — |
| goodput oracle-pass/s | 71.73 | — |
| latency_ms mean / p50 / p95 | 50.55 / 11.8 / 224.07 | — |
| wait_ms mean / p50 / p95 | 47.96 / 10 / 221 | — |
| apply_ms mean / p50 / p95 | 2.37 / 2.24 / 3.76 | — |
| total_ms mean / p50 / p95 | 94.24 / 64.24 / 268.45 | — |
| overhead_ms mean / p50 / p95 | 52.99 / 13.94 / 227.25 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| cold_queue | 236 | 0 | 89.6 |
| admit | 205 | 0 | 0 |

## Reason codes

- atm: overlay_wait_on_atm_true-conflict_then_direct=236, atm_direct=205
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | cold_queue=236, admit=205 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1795, bytes=3290543, duration_ms=6162
