# atm-bench export — cq-mock-a16-r3

- run_id: `cq-mock-a16-r3` · scenario_seed: **42** · atm_backend: **mock** (mock broker) · writer: mock
- atm_version: `mock-broker-0.1 (not ATM monorepo)`
- label: MOCK ATM (in-process mock-broker)
- params: `{"n_agents":16,"hot_ratio":0,"overlap":"cold-same-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once"}`
- scenario reproducibility: **true** (`02660e85e1d47ffc…`)
- alignment: 0 both / atm_only=879 / control_only=0

## Headline numbers

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 879 | — |
| contended intents | 879 | — |
| events_total | 3855 | — |
| event types | submit=879, decision=879, oracle=879, enqueue=609, dequeue=609 | — |
| bytes (JSONL) | 2363652 | — |
| duration_ms | 7998 | — |
| distinct agents / vendors | 16 / claude,codex,cursor,other | — |
| outcomes | commit=879 | — |
| committed | 879 | — |
| oracle pass (marker survives) | 879 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 609 | — |
| composer co-writes | 0 | — |
| CAS rebase on apply | 0 | — |
| mean wait_ms (all intents) | 82.3 | — |
| mean wait_ms (waited only) | 118.8 (n=609) | — |
| p95 / max wait_ms | 266 / 552 | — |

## Latency / throughput (performance.now ms)

| metric | atm (mock) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 7979.73 | — |
| throughput intents/s | 110.15 | — |
| goodput oracle-pass/s | 110.15 | — |
| latency_ms mean / p50 / p95 | 82.4 / 41.31 / 266.18 | — |
| wait_ms mean / p50 / p95 | 82.33 / 41 / 266 | — |
| apply_ms mean / p50 / p95 | 0.13 / 0.13 / 0.2 | — |
| total_ms mean / p50 / p95 | 122.61 / 82.16 / 307.49 | — |
| overhead_ms mean / p50 / p95 | 82.61 / 41.53 / 266.67 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| admit | 270 | 0 | 0 |
| cold_queue | 609 | 0 | 118.8 |

## Reason codes

- atm: cold_queued_then_granted=609, cold_free=270
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | cold_queue=609, admit=270 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=3855, bytes=2363652, duration_ms=7998
