/** Build stub (COLD) — lists entry modules. */
import { boot } from '../src/index.ts';

// <region:body>
export function buildSummary(): string {
  const b = boot();
  return `routes=${b.routes};db=${b.db}`;
}
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log(buildSummary());
}
// atm-edit s42-t012-i3 by cursor:mock-s3
// atm-edit s42-t015-i6 by other:mock-s6
// atm-edit s42-t015-i7 by other:mock-s7
// atm-edit s42-t015-i5 by codex:mock-s5
// atm-edit s42-t015-i0 by cursor:mock-s0
// atm-edit s42-t019-i3 by codex:mock-s5
// </region:body>
