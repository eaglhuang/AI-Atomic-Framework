# atm-bench export — hf-loop-h08-a8-r1

- run_id: `hf-loop-h08-a8-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0.8,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"sync"}`
- scenario reproducibility: **true** (`7422724bbf623e5c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 289 | — |
| events_total | 1194 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=66, dequeue=66 | — |
| bytes (JSONL) | 2274458 | — |
| duration_ms | 2722 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 354 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 66 | — |
| composer co-writes | 259 | — |
| CAS rebase on apply | 252 | — |
| mean wait_ms (all intents) | 5 | — |
| mean wait_ms (waited only) | 26.9 (n=66) | — |
| p95 / max wait_ms | 42 / 91 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2713.68 | — |
| throughput intents/s | 130.45 | — |
| goodput oracle-pass/s | 130.45 | — |
| latency_ms mean / p50 / p95 | 7.87 / 2.9 / 45.64 | — |
| wait_ms mean / p50 / p95 | 5.01 / 0 / 42 | — |
| apply_ms mean / p50 / p95 | 2.03 / 1.93 / 2.81 | — |
| total_ms mean / p50 / p95 | 52.58 / 51.16 / 91.44 | — |
| overhead_ms mean / p50 / p95 | 9.98 / 5.08 / 47.54 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 259 | 0 | 5.7 |
| hot_provisional | 60 | 0 | 5 |
| admit | 35 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=191, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=49, atm_provisional_write_lease=42, atm_direct=30, atm_compose=17, overlay_wait_on_atm_true-conflict_then_proposal-required=11, atm_direct+cas_rebase=5, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=4, atm_provisional_write_lease+cas_rebase=3, overlay_wait_on_atm_true-conflict_then_compose=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | composer_merge=62, admit=23 |
| no_conflict | hot_provisional=28, composer_merge=25, admit=12 |
| hot_provisional | composer_merge=142, hot_provisional=30 |
| composer_cowrite | composer_merge=30, hot_provisional=2 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1194, bytes=2274458, duration_ms=2722
