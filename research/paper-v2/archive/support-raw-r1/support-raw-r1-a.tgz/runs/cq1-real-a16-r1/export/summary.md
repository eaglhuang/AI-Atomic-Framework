# atm-bench export — cq1-real-a16-r1

- run_id: `cq1-real-a16-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":16,"hot_ratio":0,"overlap":"cold-one-file","cold_policy":"queue","composer_enabled":true,"trial_count":60,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"region","cold_retry":"loop"}`
- scenario reproducibility: **true** (`9afad21d9589dc82…`)
- alignment: 0 both / atm_only=879 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 60 | — |
| intents (decision events) | 879 | — |
| contended intents | 879 | — |
| events_total | 4393 | — |
| event types | submit=879, decision=879, oracle=879, enqueue=878, dequeue=878 | — |
| bytes (JSONL) | 7985769 | — |
| duration_ms | 39997 | — |
| distinct agents / vendors | 16 / claude,codex,cursor,other | — |
| outcomes | commit=879 | — |
| committed | 879 | — |
| oracle pass (marker survives) | 879 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 878 | — |
| composer co-writes | 0 | — |
| CAS rebase on apply | 0 | — |
| mean wait_ms (all intents) | 655.2 | — |
| mean wait_ms (waited only) | 655.9 (n=878) | — |
| p95 / max wait_ms | 754 / 791 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 39962.31 | — |
| throughput intents/s | 22 | — |
| goodput oracle-pass/s | 22 | — |
| latency_ms mean / p50 / p95 | 657.56 / 671.55 / 756.47 | — |
| wait_ms mean / p50 / p95 | 655.18 / 669 / 754 | — |
| apply_ms mean / p50 / p95 | 2.87 / 2.71 / 4.36 | — |
| total_ms mean / p50 / p95 | 700.59 / 715.21 / 801.65 | — |
| overhead_ms mean / p50 / p95 | 660.53 / 675.05 / 759.56 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| admit | 1 | 0 | 0 |
| cold_queue | 878 | 0 | 655.9 |

## Reason codes

- atm: overlay_wait_on_atm_true-conflict_then_direct=878, atm_direct=1
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | cold_queue=878, admit=1 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=4393, bytes=7985769, duration_ms=39997
