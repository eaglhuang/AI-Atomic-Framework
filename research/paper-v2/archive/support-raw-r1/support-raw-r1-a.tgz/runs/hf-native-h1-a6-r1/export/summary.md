# atm-bench export — hf-native-h1-a6-r1

- run_id: `hf-native-h1-a6-r1` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":6,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"sync"}`
- scenario reproducibility: **true** (`45e8fc470f05fb62…`)
- alignment: 0 both / atm_only=269 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 269 | — |
| contended intents | 219 | — |
| events_total | 748 | — |
| event types | submit=269, decision=269, oracle=210 | — |
| bytes (JSONL) | 1445703 | — |
| duration_ms | 2565 | — |
| distinct agents / vendors | 6 / claude,codex,cursor | — |
| outcomes | commit=210, reject=59 | — |
| committed | 210 | — |
| oracle pass (marker survives) | 210 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 78.1% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 138 | — |
| CAS rebase on apply | 135 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2559.49 | — |
| throughput intents/s | 105.1 | — |
| goodput oracle-pass/s | 82.05 | — |
| latency_ms mean / p50 / p95 | 2.51 / 2.65 / 4.15 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.78 / 1.98 / 3.13 | — |
| total_ms mean / p50 / p95 | 37.5 / 42.41 / 64.9 | — |
| overhead_ms mean / p50 / p95 | 4.39 / 4.99 / 6.85 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 138 | 0 | 0 |
| reject | 59 | 0 | 0 |
| hot_provisional | 72 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=123, atm_provisional_write_lease=60, atm_true_conflict=59, atm_compose=15, atm_provisional_write_lease+cas_rebase=12
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=80, reject=45, hot_provisional=26 |
| composer_cowrite | composer_merge=49, hot_provisional=12, reject=7 |
| no_conflict | hot_provisional=34, composer_merge=9, reject=7 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=748, bytes=1445703, duration_ms=2565
