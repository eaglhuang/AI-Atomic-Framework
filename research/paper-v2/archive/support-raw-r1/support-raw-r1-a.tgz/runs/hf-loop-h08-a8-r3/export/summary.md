# atm-bench export — hf-loop-h08-a8-r3

- run_id: `hf-loop-h08-a8-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":0.8,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"sync"}`
- scenario reproducibility: **true** (`7422724bbf623e5c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 289 | — |
| events_total | 1198 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=68, dequeue=68 | — |
| bytes (JSONL) | 2282311 | — |
| duration_ms | 2800 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 354 | — |
| lost updates (oracle fail) | 0 | — |
| integration pass rate of committed | 100% | — |
| effective success rate of all intents | 100% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 68 | — |
| composer co-writes | 263 | — |
| CAS rebase on apply | 254 | — |
| mean wait_ms (all intents) | 5.1 | — |
| mean wait_ms (waited only) | 26.7 (n=68) | — |
| p95 / max wait_ms | 38 / 62 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2790.05 | — |
| throughput intents/s | 126.88 | — |
| goodput oracle-pass/s | 126.88 | — |
| latency_ms mean / p50 / p95 | 8.24 / 3.24 / 42.39 | — |
| wait_ms mean / p50 / p95 | 5.12 / 0 / 38 | — |
| apply_ms mean / p50 / p95 | 2.2 / 2.09 / 3.23 | — |
| total_ms mean / p50 / p95 | 53.89 / 52.18 / 89.28 | — |
| overhead_ms mean / p50 / p95 | 10.49 / 5.58 / 45.49 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 263 | 0 | 5.9 |
| hot_provisional | 52 | 0 | 5 |
| admit | 39 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=193, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=52, atm_provisional_write_lease=39, atm_direct=35, atm_compose=13, overlay_wait_on_atm_true-conflict_then_proposal-required=8, overlay_wait_on_atm_true-conflict_then_compose=5, atm_direct+cas_rebase=4, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=3, atm_provisional_write_lease+cas_rebase=2
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| cold_queue | composer_merge=56, admit=29 |
| no_conflict | composer_merge=31, hot_provisional=24, admit=10 |
| hot_provisional | composer_merge=148, hot_provisional=24 |
| composer_cowrite | composer_merge=28, hot_provisional=4 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1198, bytes=2282311, duration_ms=2800
