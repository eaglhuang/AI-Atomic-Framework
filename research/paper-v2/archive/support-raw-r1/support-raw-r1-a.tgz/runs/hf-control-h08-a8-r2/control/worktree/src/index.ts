/** App entry (COLD). */
import { dbConfig, featureFlags } from './config.ts';
import { allRoutes } from './routes.ts';
import { initialState } from './store.ts';

// <region:body>
export function boot(): { ok: true; routes: number; db: string } {
  const routes = allRoutes();
  return {
    ok: true,
    routes: Object.keys(routes).length,
    db: `${dbConfig.host}/${dbConfig.name}`,
  };
}

export function isBillingV2(): boolean {
  return featureFlags.billingV2;
}

export { initialState };
// atm-edit s42-t017-i4 by claude:mock-s4
// atm-edit s42-t020-i3 by claude:mock-s4
// atm-edit s42-t035-i1 by claude:mock-s1
// atm-edit s42-t039-i3 by cursor:mock-s3
// atm-edit s42-t044-i2 by codex:mock-s2
// atm-edit s42-t048-i0 by cursor:mock-s0
// </region:body>
