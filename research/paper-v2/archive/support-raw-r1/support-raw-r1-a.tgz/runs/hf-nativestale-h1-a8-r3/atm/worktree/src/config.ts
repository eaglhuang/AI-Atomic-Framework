/** App config (HOT) — writable via ATM WriteIntent bounded regions. */
export interface DbConfig { host: string; port: number; name: string }
export interface CacheConfig { ttlSec: number; backend: 'memory' | 'redis' }
export interface FeatureFlags { billingV2: boolean; experimentalSearch: boolean }

// <region:db>
export const dbConfig: DbConfig = {
  host: 'localhost',
  port: 5432,
  name: 'app',
};
// atm-edit s42-t004-i6 by other:mock-s6
// atm-edit s42-t005-i3 by claude:mock-s4
// atm-edit s42-t011-i3 by cursor:mock-s3
// atm-edit s42-t018-i3 by codex:mock-s5
// atm-edit s42-t020-i5 by codex:mock-s5
// atm-edit s42-t023-i4 by codex:mock-s5
// atm-edit s42-t041-i3 by cursor:mock-s3
// atm-edit s42-t046-i6 by other:mock-s7
// atm-edit s42-t049-i1 by cursor:mock-s3
// </region:db>

// <region:cache>
export const cacheConfig: CacheConfig = {
  ttlSec: 60,
  backend: 'memory',
};
// atm-edit s42-t003-i0 by cursor:mock-s0
// atm-edit s42-t005-i2 by cursor:mock-s3
// atm-edit s42-t007-i5 by other:mock-s6
// atm-edit s42-t009-i2 by codex:mock-s2
// atm-edit s42-t024-i7 by other:mock-s7
// atm-edit s42-t026-i6 by other:mock-s7
// atm-edit s42-t047-i5 by codex:mock-s5
// atm-edit s42-t048-i5 by codex:mock-s5
// </region:cache>

// <region:flags>
export const featureFlags: FeatureFlags = {
  billingV2: false,
  experimentalSearch: false,
};
// atm-edit s42-t002-i7 by other:mock-s7
// atm-edit s42-t008-i1 by claude:mock-s1
// atm-edit s42-t021-i2 by claude:mock-s4
// atm-edit s42-t022-i4 by claude:mock-s4
// atm-edit s42-t027-i3 by cursor:mock-s3
// atm-edit s42-t030-i2 by cursor:mock-s3
// atm-edit s42-t032-i1 by claude:mock-s1
// atm-edit s42-t033-i5 by other:mock-s6
// atm-edit s42-t035-i2 by cursor:mock-s3
// atm-edit s42-t037-i7 by other:mock-s7
// atm-edit s42-t038-i2 by cursor:mock-s3
// atm-edit s42-t039-i1 by claude:mock-s1
// atm-edit s42-t043-i5 by other:mock-s7
// </region:flags>
