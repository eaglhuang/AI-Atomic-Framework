# atm-bench export — hf-nativestale-h1-a8-r3

- run_id: `hf-nativestale-h1-a8-r3` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"none","atm_writer":"stale"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 978 | — |
| event types | submit=354, decision=354, oracle=270 | — |
| bytes (JSONL) | 1902540 | — |
| duration_ms | 2566 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=270, reject=84 | — |
| committed | 270 | — |
| oracle pass (marker survives) | 91 | — |
| lost updates (oracle fail) | 179 | — |
| integration pass rate of committed | 33.7% | — |
| effective success rate of all intents | 25.7% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 0 | — |
| composer co-writes | 208 | — |
| CAS rebase on apply | 205 | — |
| mean wait_ms (all intents) | 0 | — |
| mean wait_ms (waited only) | 0 (n=0) | — |
| p95 / max wait_ms | 0 / 0 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2557.77 | — |
| throughput intents/s | 138.4 | — |
| goodput oracle-pass/s | 35.58 | — |
| latency_ms mean / p50 / p95 | 2.61 / 2.75 / 4.49 | — |
| wait_ms mean / p50 / p95 | 0 / 0 / 0 | — |
| apply_ms mean / p50 / p95 | 1.78 / 2.03 / 3.33 | — |
| total_ms mean / p50 / p95 | 37.22 / 41.67 / 65.85 | — |
| overhead_ms mean / p50 / p95 | 4.49 / 5.13 / 7.24 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| reject | 84 | 0 | 0 |
| hot_provisional | 62 | 0 | 0 |
| composer_merge | 208 | 0 | 0 |

## Reason codes

- atm: atm_compose+cas_rebase=190, atm_true_conflict=84, atm_provisional_write_lease=47, atm_compose=18, atm_provisional_write_lease+cas_rebase=15
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=157, reject=70, hot_provisional=23 |
| no_conflict | hot_provisional=32, composer_merge=14, reject=7 |
| composer_cowrite | composer_merge=37, hot_provisional=7, reject=7 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=978, bytes=1902540, duration_ms=2566
