# atm-bench export — hf-loopstale-h1-a8-r2

- run_id: `hf-loopstale-h1-a8-r2` · scenario_seed: **42** · atm_backend: **real** (REAL ATM monorepo broker) · writer: mock
- atm_version: `@ai-atomic-framework/core@0.1.2 (source:/workspace/AI-Atomic-Framework/packages/core)`
- label: REAL ATM (monorepo broker APIs)
- params: `{"n_agents":8,"hot_ratio":1,"overlap":"high","cold_policy":"queue","composer_enabled":true,"trial_count":50,"tick_interval_ms":50,"hold_ms_min":20,"hold_ms_max":60,"jitter_ms":15,"idle_prob":0.1,"queue_timeout_ms":15000,"max_provisional_depth":1,"cold_atom_identity":"intent","cold_retry":"once","hot_retry":"loop","atm_writer":"stale"}`
- scenario reproducibility: **true** (`2cb8ffa82f1dec8c…`)
- alignment: 0 both / atm_only=354 / control_only=0

## Headline numbers

| metric | atm (real) | control (no ATM) |
|---|---|---|
| trials | 50 | — |
| intents (decision events) | 354 | — |
| contended intents | 301 | — |
| events_total | 1264 | — |
| event types | submit=354, decision=354, oracle=354, enqueue=101, dequeue=101 | — |
| bytes (JSONL) | 2424060 | — |
| duration_ms | 2868 | — |
| distinct agents / vendors | 8 / claude,codex,cursor,other | — |
| outcomes | commit=354 | — |
| committed | 354 | — |
| oracle pass (marker survives) | 123 | — |
| lost updates (oracle fail) | 231 | — |
| integration pass rate of committed | 34.7% | — |
| effective success rate of all intents | 34.7% | — |
| racy_overwrite decisions | 0 | — |
| serialized (queued) | 101 | — |
| composer co-writes | 297 | — |
| CAS rebase on apply | 290 | — |
| mean wait_ms (all intents) | 6.8 | — |
| mean wait_ms (waited only) | 24 (n=101) | — |
| p95 / max wait_ms | 40 / 71 | — |

## Latency / throughput (performance.now ms)

| metric | atm (real) | control (no ATM) |
|---|---|---|
| timing available | true | — |
| wall_clock_ms (first submit→last decision) | 2858.45 | — |
| throughput intents/s | 123.84 | — |
| goodput oracle-pass/s | 43.03 | — |
| latency_ms mean / p50 / p95 | 9.75 / 3.14 / 42.61 | — |
| wait_ms mean / p50 / p95 | 6.85 / 0 / 40 | — |
| apply_ms mean / p50 / p95 | 2.03 / 1.9 / 2.89 | — |
| total_ms mean / p50 / p95 | 54.99 / 52.73 / 94.45 | — |
| overhead_ms mean / p50 / p95 | 11.86 / 5.26 / 44.71 | — |

## Decision histogram

| decision | atm | control | atm mean wait_ms |
|---|---|---|---|
| composer_merge | 297 | 0 | 6.7 |
| hot_provisional | 57 | 0 | 7.5 |

## Reason codes

- atm: atm_compose+cas_rebase=203, overlay_wait_on_atm_true-conflict_then_compose+cas_rebase=79, atm_provisional_write_lease=33, overlay_wait_on_atm_true-conflict_then_proposal-required=16, atm_compose=12, atm_provisional_write_lease+cas_rebase=5, overlay_wait_on_atm_true-conflict_then_proposal-required+cas_rebase=3, overlay_wait_on_atm_true-conflict_then_compose=3
- control: —

## Ground-truth label vs decision (atm)

| expected_class | decisions |
|---|---|
| hot_provisional | composer_merge=222, hot_provisional=28 |
| no_conflict | composer_merge=31, hot_provisional=22 |
| composer_cowrite | composer_merge=44, hot_provisional=7 |

## Ground-truth label vs decision (control)

| expected_class | decisions |
|---|---|

## Contended intents: atm vs control final result

- (single-mode run or no overlapping contended intents)

## Data volume

- events_total=1264, bytes=2424060, duration_ms=2868
